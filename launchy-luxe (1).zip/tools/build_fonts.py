#!/usr/bin/env python3
"""
Builds the clock digit fonts used by the live home-screen clocks (Android TextClock)
and by the studio preview, so both draw exactly the same digits.

Every font comes in two flavours:
  *_l  – Western digits 0-9; the Arabic-Indic code points (٠-٩ / ۰-۹) are mapped to
         the same Western shapes, so the phone language can't change the digits.
  *_a  – Arabic-Indic digits ٠-٩; Western code points are mapped to them as well.
Sources: Inter Display, Poppins, Lora (OFL), TeX Gyre Pagella (GUST), FreeSerif
(GPL + font exception) and two original sets drawn here (stroked Arabic-Indic digits
and a 7-segment LED face).
"""
import math, pathlib, json, base64, sys
from fontTools.ttLib import TTFont
from fontTools.fontBuilder import FontBuilder
from fontTools.pens.ttGlyphPen import TTGlyphPen
from fontTools.pens.cu2quPen import Cu2QuPen
from fontTools.pens.transformPen import TransformPen
from fontTools.pens.boundsPen import BoundsPen
from fontTools.pens.recordingPen import RecordingPen, DecomposingRecordingPen

ROOT = pathlib.Path(__file__).resolve().parent.parent
OUT_RES = ROOT / 'android/app/src/main/res/font'
OUT_JS = ROOT / 'src/fonts.js'
UPM = 1000
F = '/usr/share/fonts'
SRC = {
    'interThin': F + '/opentype/inter/InterDisplay-Thin.otf',
    'interXL': F + '/opentype/inter/InterDisplay-ExtraLight.otf',
    'interLight': F + '/opentype/inter/InterDisplay-Light.otf',
    'interMed': F + '/opentype/inter/InterDisplay-Medium.otf',
    'interBold': F + '/opentype/inter/InterDisplay-Bold.otf',
    'interBlack': F + '/opentype/inter/InterDisplay-Black.otf',
    'poppins': F + '/truetype/google-fonts/Poppins-Light.ttf',
    'lora': F + '/truetype/google-fonts/Lora-Variable.ttf',
    'pagella': '/usr/share/texmf/fonts/opentype/public/tex-gyre/texgyrepagella-regular.otf',
    'freeserif': F + '/truetype/freefont/FreeSerif.ttf',
    'freeserifB': F + '/truetype/freefont/FreeSerifBold.ttf',
}
DIGITS = ['zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine']
EXTRA = {'space': 0x20, 'colon': 0x3A, 'period': 0x2E, 'comma': 0x2C, 'hyphen': 0x2D, 'slash': 0x2F,
         'degree': 0xB0, 'percent': 0x25, 'A': 0x41, 'M': 0x4D, 'P': 0x50, 'a': 0x61, 'm': 0x6D, 'p': 0x70, 'I': 0x49, 'V': 0x56, 'X': 0x58}

_cache = {}
def load(key):
    if key in _cache: return _cache[key]
    t = TTFont(SRC[key])
    if 'fvar' in t:
        from fontTools.varLib import instancer
        t = instancer.instantiateVariableFont(t, {'wght': 430})
    _cache[key] = t
    return t

def glyph_rec(font, name, scale):
    """Recorded outline of `name`, scaled to UPM 1000 (components decomposed)."""
    gs = font.getGlyphSet()
    rec = DecomposingRecordingPen(gs)
    gs[name].draw(rec)
    out = RecordingPen()
    rec.replay(TransformPen(out, (scale, 0, 0, scale, 0, 0)))
    return out, gs[name].width * scale

def bounds(rec):
    bp = BoundsPen(None); rec.replay(bp); return bp.bounds

def to_glyph(rec, cubic, dx=0, dy=0, s=1.0):
    pen = TTGlyphPen(None)
    tp = TransformPen(Cu2QuPen(pen, 1.0, reverse_direction=True) if cubic else pen, (s, 0, 0, s, dx, dy))
    rec.replay(tp)
    return pen.glyph()

# ---------------------------------------------------------------- stroked Arabic-Indic digits
def catmull(pts, n=10):
    if len(pts) < 3: return pts
    out = []
    P = [pts[0]] + pts + [pts[-1]]
    for i in range(1, len(P) - 2):
        p0, p1, p2, p3 = P[i - 1], P[i], P[i + 1], P[i + 2]
        for k in range(n):
            t = k / n; t2 = t * t; t3 = t2 * t
            out.append(tuple(.5 * ((2 * p1[j]) + (-p0[j] + p2[j]) * t + (2 * p0[j] - 5 * p1[j] + 4 * p2[j] - p3[j]) * t2 + (-p0[j] + 3 * p1[j] - 3 * p2[j] + p3[j]) * t3) for j in (0, 1)))
    out.append(pts[-1])
    return out

def area(c): return sum(c[i][0] * c[(i + 1) % len(c)][1] - c[(i + 1) % len(c)][0] * c[i][1] for i in range(len(c))) / 2

def stroke(pts, w, closed=False):
    """Outline(s) of a polyline of width w with round caps (closed → ring)."""
    r = w / 2
    if closed: pts = pts + [pts[0], pts[1]]
    n = len(pts)
    normals = []
    for i in range(n):
        a = pts[max(0, i - 1)]; b = pts[min(n - 1, i + 1)]
        dx, dy = b[0] - a[0], b[1] - a[1]; L = math.hypot(dx, dy) or 1
        normals.append((-dy / L, dx / L))
    left = [(p[0] + nx * r, p[1] + ny * r) for p, (nx, ny) in zip(pts, normals)]
    right = [(p[0] - nx * r, p[1] - ny * r) for p, (nx, ny) in zip(pts, normals)]
    if closed:
        left, right = left[1:-1], right[1:-1]
        return [left, right[::-1]]
    def cap(p, nrm, sgn):
        ang0 = math.atan2(nrm[1], nrm[0]); pts2 = []
        for k in range(1, 12):
            t = ang0 + sgn * math.pi * k / 12
            pts2.append((p[0] + r * math.cos(t), p[1] + r * math.sin(t)))
        return pts2
    nE = normals[-1]; nS = normals[0]
    outline = left + cap(pts[-1], nE, -1) + right[::-1] + cap(pts[0], (-nS[0], -nS[1]), -1)
    return [outline]

def poly_glyph(contours):
    pen = TTGlyphPen(None)
    for c in contours:
        c = [(round(x), round(y)) for x, y in c]
        pen.moveTo(c[0])
        for p in c[1:]: pen.lineTo(p)
        pen.closePath()
    return pen.glyph()

def orient(contours, outer_cw=True):
    """TrueType: outer contours clockwise (negative area in y-up)."""
    out = []
    for i, c in enumerate(contours):
        out.append(c)
    return out

# skeletons in a 600-wide, 700-tall box (baseline 0); digits drawn with round strokes
AR_SKEL = {
    'one':   [[(300, 690), (300, 10)]],
    'two':   [[(236, 10), (236, 420), (246, 530), (284, 600), (350, 586), (404, 630), (446, 700)]],
    'three': [[(222, 10), (222, 420), (232, 530), (264, 600), (316, 562), (352, 624), (398, 578), (456, 700)]],
    'four':  [[(468, 680), (380, 708), (292, 682), (250, 612), (292, 552), (384, 532), (292, 514), (214, 440), (198, 306), (250, 184), (352, 134), (474, 148)]],
    'six':   [[(196, 690), (248, 642), (318, 626), (392, 646)], [(392, 646), (392, 10)]],
    'seven': [[(186, 690), (300, 20)], [(300, 20), (414, 690)]],
    'eight': [[(186, 10), (300, 680)], [(300, 680), (414, 10)]],
    'nine':  [[(372, 520), (300, 460), (222, 470), (180, 540), (204, 630), (290, 676), (360, 640), (374, 560), (374, 10)]],
}
def arabic_digit(name, w):
    if name == 'zero':
        s = 60 + w * .55
        return [[(300, 330 + s * 1.1), (300 + s * .8, 330), (300, 330 - s * 1.1), (300 - s * .8, 330)][::-1]]
    if name == 'five':
        loop = [(300, 470), (372, 400), (410, 270), (380, 120), (300, 60), (220, 120), (190, 270), (228, 400)]
        sm = catmull(loop + loop[:3], 8)[8:8 + 8 * len(loop) + 1]
        return stroke(sm, w, closed=True)
    out = []
    for part in AR_SKEL[name]:
        out += stroke(catmull(part, 10) if len(part) > 2 else part, w)
    return out

# ---------------------------------------------------------------- 7-segment LED face
def seg_glyph(segs, slant=.12):
    # segment hexagons in a 520×720 cell
    W, H, t, g = 440, 700, 78, 10
    x0, y0 = 70, 0
    def hseg(y):
        return [(x0 + t / 2 + g, y), (x0 + t + g, y + t / 2), (x0 + W - t - g, y + t / 2), (x0 + W - t / 2 - g, y), (x0 + W - t - g, y - t / 2), (x0 + t + g, y - t / 2)]
    def vseg(x, ya, yb):
        return [(x, ya + t / 2 + g), (x + t / 2, ya + t + g), (x + t / 2, yb - t - g), (x, yb - t / 2 - g), (x - t / 2, yb - t - g), (x - t / 2, ya + t + g)]
    L, R, B, M, T = x0 + t / 2, x0 + W - t / 2, t / 2, H / 2, H - t / 2
    S = {'a': hseg(T), 'g': hseg(M), 'd': hseg(B), 'f': vseg(L, M, T), 'b': vseg(R, M, T), 'e': vseg(L, B, M), 'c': vseg(R, B, M)}
    cs = []
    for s in segs:
        c = S[s]
        cs.append([(x + y * slant, y) for x, y in c][::-1])
    return cs

SEG = {'zero': 'abcdef', 'one': 'bc', 'two': 'abdeg', 'three': 'abcdg', 'four': 'bcfg', 'five': 'acdfg', 'six': 'acdefg',
       'seven': 'abc', 'eight': 'abcdefg', 'nine': 'abcdfg', 'A': 'abcefg', 'P': 'abefg', 'M': 'abcef', 'a': 'abcefg', 'p': 'abefg', 'm': 'abcef', 'hyphen': 'g'}

# ---------------------------------------------------------------- font assembly
def build(fid, family, latin, arabic, out_name, stroke_w=None):
    """latin: source key or 'led'; arabic: None (western digits), 'stroke', or a source key."""
    glyphs, adv = {}, {}
    order = ['.notdef']
    glyphs['.notdef'] = TTGlyphPen(None).glyph(); adv['.notdef'] = 500
    if latin == 'led':
        asc, desc, digit_h = 900, -250, 700
        for n, segs in SEG.items():
            glyphs[n] = poly_glyph(seg_glyph(segs)); adv[n] = 600 if n not in ('M', 'm') else 640
        glyphs['space'] = TTGlyphPen(None).glyph(); adv['space'] = 300
        dots = lambda ys: [[(270 + y * .12 - 45, y - 45), (270 + y * .12 - 45, y + 45), (270 + y * .12 + 45, y + 45), (270 + y * .12 + 45, y - 45)] for y in ys]
        glyphs['colon'] = poly_glyph(dots([200, 500])); adv['colon'] = 330
        glyphs['period'] = poly_glyph(dots([40])); adv['period'] = 300
        for n in ['comma', 'slash', 'degree', 'percent']:
            glyphs[n] = TTGlyphPen(None).glyph(); adv[n] = 300
        for n in ['colon']:
            pass
        order += list(SEG.keys()) + ['space', 'colon', 'period', 'comma', 'slash', 'degree', 'percent']
    else:
        font = load(latin)
        sc = UPM / font['head'].unitsPerEm
        cubic = 'CFF ' in font
        cmap = font.getBestCmap()
        asc, desc = round(font['hhea'].ascent * sc), round(font['hhea'].descent * sc)
        names = {}
        for n in DIGITS:
            tf = n + '.tf'
            names[n] = tf if tf in font.getGlyphOrder() else cmap[0x30 + DIGITS.index(n)]
        for n, cp in EXTRA.items():
            if cp in cmap: names[n] = cmap[cp]
        recs = {n: glyph_rec(font, g, sc) for n, g in names.items()}
        digit_h = bounds(recs['eight'][0])[3]
        tab = max(recs[n][1] for n in DIGITS)
        for n, (rec, w) in recs.items():
            if n in DIGITS:
                glyphs[n] = to_glyph(rec, cubic, dx=(tab - w) / 2); adv[n] = round(tab)
            else:
                glyphs[n] = to_glyph(rec, cubic); adv[n] = round(w)
        order += list(recs.keys())
    # Arabic-Indic shapes replace the digits (and keep the Western advance so the clock never jitters)
    if arabic:
        tab = max(adv[n] for n in DIGITS)
        for n in DIGITS:
            if arabic == 'stroke':
                cs = arabic_digit(n, stroke_w)
                pen = TTGlyphPen(None)
                # scale the 700-tall skeleton to the Latin digit height
                k = digit_h / 700 * .96
                dx = tab / 2 - 300 * k
                for c in cs:
                    c2 = [(round(x * k + dx), round(y * k)) for x, y in c]
                    pen.moveTo(c2[0]); [pen.lineTo(p) for p in c2[1:]]; pen.closePath()
                glyphs[n] = pen.glyph()
            else:
                af = load(arabic); asc_ = UPM / af['head'].unitsPerEm; acm = af.getBestCmap()
                rec, w = glyph_rec(af, acm[0x660 + DIGITS.index(n)], asc_)
                ref = bounds(glyph_rec(af, acm[0x661], asc_)[0])  # height of ١
                k = digit_h / (ref[3] - max(0, ref[1])) * .98
                bb = bounds(rec) or (0, 0, w, 0)
                dx = tab / 2 - (bb[0] + bb[2]) / 2 * k
                glyphs[n] = to_glyph(rec, 'CFF ' in af, dx=dx, s=k)
            adv[n] = tab
    cmap_out = {}
    for i, n in enumerate(DIGITS):
        for base in (0x30, 0x660, 0x6F0): cmap_out[base + i] = n
    for n, cp in EXTRA.items():
        if n in glyphs: cmap_out[cp] = n
    if latin == 'led':
        for n in ['A', 'M', 'P', 'a', 'm', 'p', 'hyphen']: cmap_out[EXTRA[n]] = n
    order = list(dict.fromkeys(order))
    fb = FontBuilder(UPM, isTTF=True)
    fb.setupGlyphOrder(order)
    fb.setupCharacterMap(cmap_out)
    fb.setupGlyf({n: glyphs[n] for n in order})
    gl = fb.font['glyf']
    fb.setupHorizontalMetrics({n: (adv[n], gl[n].xMin if hasattr(gl[n], 'xMin') and gl[n].numberOfContours else 0) for n in order})
    fb.setupHorizontalHeader(ascent=asc, descent=desc)
    fb.setupNameTable({'familyName': family, 'styleName': 'Regular', 'uniqueFontIdentifier': family, 'fullName': family, 'psName': family.replace(' ', ''), 'version': 'Version 1.0'})
    fb.setupOS2(version=4, sTypoAscender=asc, sTypoDescender=desc, sTypoLineGap=0, usWinAscent=asc, usWinDescent=-desc, fsSelection=0x40 | 0x80, achVendID='LLX ', usWeightClass=400)
    fb.setupPost()
    fb.setupHead(unitsPerEm=UPM)
    OUT_RES.mkdir(parents=True, exist_ok=True)
    path = OUT_RES / (out_name + '.ttf')
    fb.save(str(path))
    return path, {'asc': asc, 'desc': desc, 'digitH': round(digit_h)}

# key, Arabic label, latin source, arabic source/stroke width
FONTS = [
    ('thin', 'رفيع فاخر', 'interThin', ('stroke', 34)),
    ('xlight', 'رفيع ناعم', 'interXL', ('stroke', 52)),
    ('light', 'خفيف', 'interLight', ('stroke', 70)),
    ('medium', 'متوازن', 'interMed', ('stroke', 104)),
    ('bold', 'عريض', 'interBold', ('stroke', 140)),
    ('black', 'ضخم', 'interBlack', ('stroke', 176)),
    ('geo', 'هندسي', 'poppins', ('stroke', 62)),
    ('serif', 'كلاسيكي', 'lora', ('src', 'freeserif')),
    ('royal', 'ملكي', 'pagella', ('src', 'freeserif')),
    ('led', 'LED رقمي', 'led', None),
]

def main():
    meta = []
    js = ['/* Clock digit fonts (generated by tools/build_fonts.py) — the same files ship in the Android app (res/font). */', 'const CLOCK_FONTS = [']
    datas = []
    for key, label, latin, ar in FONTS:
        for flav in ('l', 'a'):
            if flav == 'a' and not ar: continue
            name = f'llx_{key}_{flav}'
            arabic = None if flav == 'l' else (ar[0] == 'stroke' and 'stroke' or ar[1])
            sw = ar[1] if ar and ar[0] == 'stroke' else None
            path, m = build(key, f'LLX {key} {flav}', latin, arabic, name, sw)
            b64 = base64.b64encode(path.read_bytes()).decode()
            datas.append(f"  {name}: 'data:font/ttf;base64,{b64}'")
            print(name, path.stat().st_size, 'bytes')
        meta.append(f"  {{ k: '{key}', n: '{label}', ar: {'true' if ar else 'false'}, asc: {m['asc']}, desc: {m['desc']}, digitH: {m['digitH']} }}")
    js.append(',\n'.join(meta)); js.append('];')
    js.append('const CLOCK_FONT_DATA = {'); js.append(',\n'.join(datas)); js.append('};')
    OUT_JS.write_text('\n'.join(js) + '\n', encoding='utf-8')
    print('wrote', OUT_JS, OUT_JS.stat().st_size)

if __name__ == '__main__':
    main()
