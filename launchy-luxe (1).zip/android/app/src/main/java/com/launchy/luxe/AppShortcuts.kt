package com.launchy.luxe

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.LauncherApps
import android.content.pm.PackageManager
import android.content.pm.ShortcutInfo
import android.content.res.Resources
import android.content.res.XmlResourceParser
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.os.Process
import android.util.Base64
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayOutputStream

/**
 * Internal shortcuts of other apps ("اختصارات التطبيقات الداخلية").
 *
 * What a normal (non-launcher) app is allowed to see, and nothing more:
 *  1. Static shortcuts every app publishes in its manifest (meta-data "android.app.shortcuts").
 *     They are read from the app's own resources; each intent is checked with the package manager
 *     and offered only when its activity is exported to other apps (otherwise only the launcher
 *     may start it, and we say so instead of showing a shortcut that would not open).
 *  2. Legacy "create shortcut" screens (ACTION_CREATE_SHORTCUT): the app itself returns the intent.
 *  3. Dynamic and pinned shortcuts — only when this app is the default launcher
 *     (LauncherApps.hasShortcutHostPermission). Android gives them to no one else.
 *
 * A shortcut is stored as a "value": "i:" + JSON array of intent URIs, or "s:" + package + "/" + id
 * for launcher-only shortcuts. Every launch re-checks the intent first.
 */
object AppShortcuts {
    private const val NS = "http://schemas.android.com/apk/res/android"
    private const val TAG = "AppShortcuts"
    private const val GRANTS = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
        Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or Intent.FLAG_GRANT_PREFIX_URI_PERMISSION

    class Sc(val id: String, val label: String, val long: String, val iconRes: Int, val intents: List<Intent>, val enabled: Boolean, val disabledMsg: String)

    // ------------------------------------------------------------------ static (manifest) shortcuts

    /** Static shortcuts of one package, with the package's resources for labels and icons. */
    fun staticOf(ctx: Context, pkg: String): Pair<Resources?, List<Sc>> {
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setPackage(pkg)
        @Suppress("DEPRECATION") val ris = try { pm.queryIntentActivities(main, PackageManager.GET_META_DATA) } catch (e: Exception) { emptyList() }
        val out = ArrayList<Sc>()
        var res: Resources? = null
        val seen = HashSet<Int>()
        for (ri in ris) {
            val ai = ri.activityInfo ?: continue
            val xmlId = ai.metaData?.getInt("android.app.shortcuts", 0) ?: 0
            if (xmlId == 0 || !seen.add(xmlId)) continue
            try {
                val r = pm.getResourcesForApplication(ai.applicationInfo)
                res = r
                val p = r.getXml(xmlId)
                try { parse(r, p, out) } finally { p.close() }
            } catch (e: Exception) { Log.w(TAG, "parse $pkg", e) }
        }
        return res to out
    }

    private fun str(r: Resources, p: XmlResourceParser, name: String): String {
        val id = p.getAttributeResourceValue(NS, name, 0)
        if (id != 0) return try { r.getString(id) } catch (_: Exception) { "" }
        return p.getAttributeValue(NS, name) ?: ""
    }

    private fun parse(r: Resources, p: XmlResourceParser, out: MutableList<Sc>) {
        var inSc = false
        var id = ""; var label = ""; var long = ""; var icon = 0; var enabled = true; var dis = ""
        var intents = ArrayList<Intent>()
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                when (p.name) {
                    "shortcut" -> {
                        inSc = true; intents = ArrayList()
                        id = str(r, p, "shortcutId"); label = str(r, p, "shortcutShortLabel"); long = str(r, p, "shortcutLongLabel")
                        icon = p.getAttributeResourceValue(NS, "icon", 0); enabled = p.getAttributeBooleanValue(NS, "enabled", true)
                        dis = str(r, p, "shortcutDisabledMessage")
                    }
                    // Intent.parseIntent reads action, data, mimeType, targetPackage/Class and the <extra>/<categories> children
                    "intent" -> if (inSc) { try { intents.add(Intent.parseIntent(r, p, p)) } catch (e: Exception) { Log.w(TAG, "intent", e) } }
                }
            } else if (ev == XmlPullParser.END_TAG && p.name == "shortcut") {
                val valid = intents.filter { it.action != null }
                if (inSc && id.isNotEmpty() && valid.isNotEmpty()) {
                    // same default as the system: the first intent starts a fresh task
                    if (valid[0].flags == 0) valid[0].flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                    out.add(Sc(id, label.ifEmpty { long }, long, icon, valid, enabled, dis))
                }
                inSc = false
            }
            ev = p.next()
        }
    }

    // ------------------------------------------------------------------ checks

    private fun clean(i: Intent): Intent {
        i.selector = null
        i.clipData = null
        i.flags = i.flags and GRANTS.inv()
        return i
    }

    /** "" when every intent opens an exported activity this app may start; otherwise the reason. */
    fun check(ctx: Context, intents: List<Intent>): String {
        if (intents.isEmpty()) return "empty"
        val pm = ctx.packageManager
        for (i in intents) {
            @Suppress("DEPRECATION") val ri = pm.resolveActivity(i, 0) ?: return "missing"
            val ai = ri.activityInfo ?: return "missing"
            if (ai.packageName == ctx.packageName) return "self"
            if (!ai.exported) return "private"
            if (!ai.enabled || !ai.applicationInfo.enabled) return "disabled"
            val perm = ai.permission
            if (perm != null && ctx.checkSelfPermission(perm) != PackageManager.PERMISSION_GRANTED) return "permission"
        }
        return ""
    }

    private fun encode(intents: List<Intent>): String = "i:" + JSONArray().apply { intents.forEach { put(it.toUri(Intent.URI_INTENT_SCHEME)) } }.toString()

    private fun decode(value: String): List<Intent> {
        val arr = JSONArray(value.substring(2))
        return (0 until arr.length()).map { clean(Intent.parseUri(arr.getString(it), Intent.URI_INTENT_SCHEME)) }
    }

    /** Short technical description of where a shortcut leads (shown under its name). */
    private fun describe(i: Intent): String {
        val parts = ArrayList<String>()
        i.data?.let { d -> parts.add((d.scheme ?: "") + ":" + (d.host ?: d.schemeSpecificPart?.take(30) ?: "")) }
        i.component?.let { parts.add(it.shortClassName.substringAfterLast('.')) }
        if (parts.isEmpty()) i.action?.let { parts.add(it.substringAfterLast('.')) }
        return parts.joinToString(" · ")
    }

    // ------------------------------------------------------------------ launcher-only (default launcher)

    private fun la(ctx: Context): LauncherApps? = ctx.getSystemService(LauncherApps::class.java)

    fun isHost(ctx: Context): Boolean = try { la(ctx)?.hasShortcutHostPermission() == true } catch (_: Exception) { false }

    private fun hostShortcuts(ctx: Context, pkg: String): List<ShortcutInfo> = try {
        val q = LauncherApps.ShortcutQuery().setPackage(pkg).setQueryFlags(
            LauncherApps.ShortcutQuery.FLAG_MATCH_DYNAMIC or LauncherApps.ShortcutQuery.FLAG_MATCH_MANIFEST or LauncherApps.ShortcutQuery.FLAG_MATCH_PINNED)
        la(ctx)?.getShortcuts(q, Process.myUserHandle()) ?: emptyList()
    } catch (e: Exception) { emptyList() }

    // ------------------------------------------------------------------ legacy creators

    fun creators(ctx: Context): Map<String, List<android.content.pm.ActivityInfo>> = try {
        @Suppress("DEPRECATION")
        ctx.packageManager.queryIntentActivities(Intent(Intent.ACTION_CREATE_SHORTCUT), 0)
            .mapNotNull { it.activityInfo }.filter { it.exported && it.packageName != ctx.packageName }
            .groupBy { it.packageName }
    } catch (e: Exception) { emptyMap() }

    // ------------------------------------------------------------------ JSON for the studio

    private fun dataUrl(d: Drawable?, size: Int): String {
        if (d == null) return ""
        return try {
            val b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            d.setBounds(0, 0, size, size); d.draw(Canvas(b))
            pngUrl(b)
        } catch (_: Exception) { "" }
    }
    private fun pngUrl(b: Bitmap): String {
        val out = ByteArrayOutputStream()
        b.compress(Bitmap.CompressFormat.PNG, 90, out)
        return "data:image/png;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    /** All launcher apps with the number of shortcuts this app can really open for each. */
    fun appsJson(ctx: Context): String {
        val pm = ctx.packageManager
        val host = isHost(ctx)
        val creators = creators(ctx)
        val list = JSONArray()
        val rows = ArrayList<Pair<String, JSONObject>>()
        try {
            @Suppress("DEPRECATION")
            val found = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            val seen = HashSet<String>()
            for (ri in found) {
                val pkg = ri.activityInfo.packageName
                if (pkg == ctx.packageName || !seen.add(pkg)) continue
                var ok = 0; var off = 0
                val (_, st) = staticOf(ctx, pkg)
                for (s in st) { if (s.enabled && check(ctx, s.intents).isEmpty()) ok++ else off++ }
                if (host) { val hs = hostShortcuts(ctx, pkg); if (hs.isNotEmpty()) { ok = hs.count { it.isEnabled }; off = hs.size - ok } }
                val leg = creators[pkg]?.size ?: 0
                val label = ri.loadLabel(pm).toString()
                rows.add(label to JSONObject().put("pkg", pkg).put("label", label)
                    .put("icon", dataUrl(ri.loadIcon(pm), 96))
                    .put("n", ok).put("off", off).put("legacy", leg))
            }
        } catch (e: Exception) { Log.w(TAG, "apps", e) }
        rows.sortBy { it.first.lowercase() }
        rows.forEach { list.put(it.second) }
        return JSONObject().put("host", host).put("apps", list).toString()
    }

    private fun reason(code: String): String = when (code) {
        "private" -> "النظام يسمح بفتحه لتطبيق الشاشة الرئيسية فقط (النشاط غير مُتاح للتطبيقات الأخرى)"
        "permission" -> "يتطلب إذناً خاصاً لا يملكه هذا التطبيق"
        "disabled" -> "معطّل في التطبيق حالياً"
        "missing" -> "لا يوجد في الإصدار المثبت ما يفتح هذا الاختصار"
        "self" -> "يشير إلى هذا التطبيق نفسه"
        else -> "غير متاح"
    }

    /** One app: its shortcuts (each with an exact availability verdict) and its legacy creators. */
    fun appJson(ctx: Context, pkg: String): String {
        val pm = ctx.packageManager
        val o = JSONObject().put("pkg", pkg)
        try {
            val ai = pm.getApplicationInfo(pkg, 0)
            o.put("label", pm.getApplicationLabel(ai).toString()).put("icon", dataUrl(pm.getApplicationIcon(ai), 144))
        } catch (e: Exception) { return o.put("missing", true).toString() }
        val host = isHost(ctx)
        o.put("host", host)
        val items = JSONArray()
        val (res, st) = staticOf(ctx, pkg)
        val hs = if (host) hostShortcuts(ctx, pkg) else emptyList()
        if (hs.isNotEmpty()) {
            val den = ctx.resources.displayMetrics.densityDpi
            for (s in hs) {
                val icon = try { la(ctx)?.getShortcutIconDrawable(s, den) } catch (_: Exception) { null }
                items.put(JSONObject().put("id", s.id).put("label", (s.shortLabel ?: s.longLabel ?: s.id).toString())
                    .put("desc", (s.longLabel ?: "").toString()).put("icon", dataUrl(icon, 112))
                    .put("value", "s:" + pkg + "/" + s.id).put("src", if (s.isDynamic) "dynamic" else if (s.isPinned) "pinned" else "static")
                    .put("ok", s.isEnabled).put("why", if (s.isEnabled) "" else ((s.disabledMessage ?: "").toString().ifEmpty { "معطّل في التطبيق حالياً" })))
            }
        } else for (s in st) {
            val code = if (!s.enabled) "disabled" else check(ctx, s.intents)
            val icon = if (s.iconRes != 0 && res != null) try { res.getDrawable(s.iconRes, null) } catch (_: Exception) { null } else null
            items.put(JSONObject().put("id", s.id).put("label", s.label.ifEmpty { s.id }).put("desc", if (s.long != s.label) s.long else "")
                .put("icon", dataUrl(icon, 112)).put("value", encode(s.intents.map { Intent(it) }))
                .put("src", "static").put("ok", code.isEmpty())
                .put("why", if (code.isEmpty()) "" else if (!s.enabled && s.disabledMsg.isNotEmpty()) s.disabledMsg else reason(code))
                .put("to", describe(s.intents.last())))
        }
        o.put("items", items)
        val cr = JSONArray()
        creators(ctx)[pkg]?.forEach { a ->
            cr.put(JSONObject().put("cls", a.name).put("label", a.loadLabel(pm).toString()).put("icon", dataUrl(a.loadIcon(pm), 96)))
        }
        o.put("creators", cr)
        return o.toString()
    }

    /** Result of an app's legacy "create shortcut" screen → a checked shortcut, or the honest reason why not. */
    fun legacyResult(ctx: Context, resultCode: Int, data: Intent?): String {
        val o = JSONObject()
        if (resultCode != Activity.RESULT_OK || data == null) return o.put("ok", false).put("why", "cancel").toString()
        @Suppress("DEPRECATION") val si: Intent? = try { data.getParcelableExtra(Intent.EXTRA_SHORTCUT_INTENT) } catch (_: Exception) { null }
        if (si == null) {
            val pinOnly = data.hasExtra(LauncherApps.EXTRA_PIN_ITEM_REQUEST)
            return o.put("ok", false).put("why", if (pinOnly) "pinOnly" else "empty").toString()
        }
        clean(si)
        @Suppress("DEPRECATION") val name = data.getStringExtra(Intent.EXTRA_SHORTCUT_NAME) ?: ""
        var icon = ""
        try {
            @Suppress("DEPRECATION") val bmp: Bitmap? = data.getParcelableExtra(Intent.EXTRA_SHORTCUT_ICON)
            if (bmp != null) icon = pngUrl(Bitmap.createScaledBitmap(bmp, 112, 112, true))
            else {
                @Suppress("DEPRECATION") val ir: Intent.ShortcutIconResource? = data.getParcelableExtra(Intent.EXTRA_SHORTCUT_ICON_RESOURCE)
                if (ir != null) {
                    val r = ctx.packageManager.getResourcesForApplication(ir.packageName)
                    val id = r.getIdentifier(ir.resourceName, null, null)
                    if (id != 0) icon = dataUrl(r.getDrawable(id, null), 112)
                }
            }
        } catch (_: Exception) { }
        val code = check(ctx, listOf(si))
        o.put("ok", code.isEmpty()).put("why", if (code.isEmpty()) "" else reason(code))
            .put("label", name).put("icon", icon).put("value", encode(listOf(si))).put("to", describe(si))
        return o.toString()
    }

    /** Re-check a stored shortcut (e.g. after the app was updated). */
    fun verify(ctx: Context, value: String): String = try {
        when {
            value.startsWith("i:") -> check(ctx, decode(value)).let { if (it.isEmpty()) "" else reason(it) }
            value.startsWith("s:") -> if (isHost(ctx)) "" else "هذا الاختصار يعمل فقط عندما يكون هذا التطبيق هو الشاشة الرئيسية الافتراضية"
            else -> "غير متاح"
        }
    } catch (e: Exception) { "غير متاح" }

    /** Opens a shortcut; false when it can no longer be opened (the caller falls back to the app). */
    fun launch(ctx: Context, value: String): Boolean {
        try {
            if (value.startsWith("i:")) {
                val list = decode(value)
                if (check(ctx, list).isNotEmpty()) return false
                list[0].addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                if (list.size == 1) ctx.startActivity(list[0]) else ctx.startActivities(list.toTypedArray())
                return true
            }
            if (value.startsWith("s:")) {
                val rest = value.substring(2); val cut = rest.indexOf('/')
                if (cut <= 0 || !isHost(ctx)) return false
                la(ctx)?.startShortcut(rest.substring(0, cut), rest.substring(cut + 1), null, null, Process.myUserHandle()) ?: return false
                return true
            }
        } catch (e: Exception) { Log.w(TAG, "launch", e) }
        return false
    }

    /** Package a stored value belongs to (for the "open the app instead" fallback). */
    fun packageOf(value: String): String = try {
        when {
            value.startsWith("i:") -> decode(value).last().let { it.component?.packageName ?: it.`package` ?: "" }
            value.startsWith("s:") -> value.substring(2).substringBefore('/')
            else -> ""
        }
    } catch (_: Exception) { "" }
}
