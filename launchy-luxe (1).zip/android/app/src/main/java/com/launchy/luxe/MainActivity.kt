package com.launchy.luxe

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Rect
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.ContactsContract
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import kotlin.math.min

/** Hosts the studio (assets/web/index.html) and exposes the LaunchyNative bridge. */
class MainActivity : Activity() {
    private lateinit var web: WebView
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var pendingExport: String? = null
    private var pendingCall: String? = null

    companion object {
        /** The open studio (if any), so the alarm service can tell it when an alarm rings or stops. */
        @Volatile var current: MainActivity? = null
        fun notify(kind: String, json: String) { current?.sendToJsPublic(kind, json) }
        const val REQ_FILE = 11
        const val REQ_EXPORT = 12
        const val REQ_CALL = 13
        const val REQ_CONTACTS = 14
        const val REQ_CALL_PERMISSION = 15
        const val REQ_LOCATION = 16
        const val REQ_SHORTCUT = 17
        private const val BG = 0xFF0C0C0E.toInt()
        private const val BASE = "file:///android_asset/web/index.html"
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        web = WebView(this)
        web.setBackgroundColor(BG)
        setContentView(web)
        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            textZoom = 100
        }
        web.addJavascriptInterface(Bridge(), "LaunchyNative")
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean = handleUrl(request.url)
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(view: WebView, cb: ValueCallback<Array<Uri>>, params: FileChooserParams): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = cb
                return try {
                    startActivityForResult(params.createIntent(), REQ_FILE); true
                } catch (e: Exception) {
                    fileCallback = null; false
                }
            }
        }
        if (savedInstanceState != null) web.restoreState(savedInstanceState)
        else web.loadUrl(BASE + "#/" + (intent?.getStringExtra("route") ?: "screen"))
    }

    fun sendToJsPublic(kind: String, json: String) = sendToJs(kind, json)

    override fun onDestroy() { if (current === this) current = null; super.onDestroy() }

    override fun onResume() {
        super.onResume()
        current = this
        sendToJs("resume", "{}")
        TimeJobs.scheduleAll(this)
        Loc.refreshQuietly(this)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        intent.getStringExtra("route")?.let { web.evaluateJavascript("location.hash='#/$it'", null) }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else @Suppress("DEPRECATION") super.onBackPressed()
    }

    /** Links tapped inside "شاشتي" behave exactly like widget taps. */
    private fun handleUrl(uri: Uri): Boolean {
        val scheme = uri.scheme?.lowercase() ?: return false
        if (scheme == "file" || scheme == "about" || scheme == "data" || scheme == "blob") return false
        val host = uri.host?.lowercase() ?: ""
        try {
            when {
                scheme == "launchy" && host == "wa" -> Actions.whatsapp(this, uri.getQueryParameter("n") ?: "", uri.getQueryParameter("b") ?: "auto")
                scheme == "launchy" && host == "ishort" -> Actions.runShortcut(this, uri.getQueryParameter("v") ?: "")
                scheme == "launchy" && host == "url" -> Actions.openUrl(this, uri.getQueryParameter("u") ?: "", uri.getQueryParameter("p") ?: "")
                scheme == "sms" || scheme == "smsto" -> Actions.sms(this, uri.schemeSpecificPart ?: "")
                scheme == "tel" -> callNumber(uri.schemeSpecificPart ?: "")
                scheme == "intent" -> Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME).`package`?.let { Actions.openApp(this, it) }
                (scheme == "http" || scheme == "https") && host == "wa.me" -> Actions.whatsapp(this, "+" + (uri.path ?: "").filter { it.isDigit() })
                (scheme == "http" || scheme == "https") && host.endsWith("whatsapp.com") -> Actions.whatsapp(this, uri.getQueryParameter("phone") ?: "")
                scheme == "http" || scheme == "https" -> Actions.openUrl(this, uri.toString())
                else -> startActivity(Intent(Intent.ACTION_VIEW, uri))
            }
        } catch (_: Exception) { }
        return true
    }

    private fun callNumber(n: String) {
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) Actions.call(this, n)
        else { pendingCall = n; requestPermissions(arrayOf(Manifest.permission.CALL_PHONE), REQ_CALL) }
    }

    private fun sendToJs(kind: String, json: String) = runOnUiThread {
        web.evaluateJavascript("window.LaunchyStudio&&LaunchyStudio.onNative(${JSONObject.quote(kind)},${JSONObject.quote(json)})", null)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        val ok = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
        when (requestCode) {
            REQ_CALL -> { pendingCall?.let { Actions.call(this, it) }; pendingCall = null }
            REQ_CONTACTS -> if (ok) loadContacts() else sendToJs("contacts", "{\"denied\":true}")
            REQ_LOCATION -> if (ok) Loc.fetch(this) { sendToJs("location", it) } else sendToJs("location", "{\"ok\":false,\"denied\":true}")
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION") super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQ_FILE -> {
                fileCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
                fileCallback = null
            }
            REQ_SHORTCUT -> sendToJs("innerLegacy", AppShortcuts.legacyResult(this, resultCode, data))
            REQ_EXPORT -> {
                val uri = data?.data
                val text = pendingExport
                pendingExport = null
                var ok = false
                if (resultCode == RESULT_OK && uri != null && text != null) {
                    try { contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray()) }; ok = true } catch (_: Exception) { }
                }
                sendToJs("exported", "{\"ok\":$ok}")
            }
        }
    }

    // ------------------------------------------------------------- data for the pickers

    private fun toBitmap(d: Drawable, size: Int): Bitmap {
        val b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        d.setBounds(0, 0, size, size)
        d.draw(c)
        return b
    }

    private fun dataUrl(b: Bitmap, png: Boolean): String {
        val out = ByteArrayOutputStream()
        b.compress(if (png) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG, 85, out)
        return (if (png) "data:image/png;base64," else "data:image/jpeg;base64,") + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    private fun loadApps() = Thread {
        val pm = packageManager
        val list = JSONArray()
        try {
            val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            @Suppress("DEPRECATION")
            val found = pm.queryIntentActivities(main, 0)
            val seen = HashSet<String>()
            val rows = ArrayList<Pair<String, JSONObject>>()
            for (ri in found) {
                val pkg = ri.activityInfo.packageName
                if (pkg == packageName || !seen.add(pkg)) continue
                val label = ri.loadLabel(pm).toString()
                // original icon, drawn whole (adaptive icons keep their own shape) at a crisp size
                val icon = try { dataUrl(toBitmap(ri.loadIcon(pm), 144), true) } catch (_: Exception) { "" }
                val ai = ri.activityInfo.applicationInfo
                val installed = try { @Suppress("DEPRECATION") pm.getPackageInfo(pkg, 0).firstInstallTime } catch (_: Exception) { 0L }
                rows.add(label to JSONObject().put("label", label).put("pkg", pkg).put("icon", icon)
                    .put("cat", if (Build.VERSION.SDK_INT >= 26) ai.category else -1).put("installed", installed))
            }
            rows.sortBy { it.first.lowercase() }
            rows.forEach { list.put(it.second) }
        } catch (_: Exception) { }
        sendToJs("apps", list.toString())
    }.start()

    private fun loadContacts() = Thread {
        val byId = LinkedHashMap<Long, JSONObject>()
        try {
            contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER,
                    ContactsContract.CommonDataKinds.Phone.TYPE,
                    ContactsContract.CommonDataKinds.Phone.LABEL,
                    ContactsContract.CommonDataKinds.Phone.PHOTO_THUMBNAIL_URI,
                    ContactsContract.CommonDataKinds.Phone.PHOTO_URI
                ),
                null, null, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC"
            )?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getLong(0)
                    val name = c.getString(1) ?: continue
                    val num = c.getString(2) ?: continue
                    val o = byId.getOrPut(id) {
                        JSONObject().put("id", id.toString()).put("name", name).put("numbers", JSONArray())
                            .put("thumbUri", c.getString(5) ?: "").put("photo", c.getString(6) ?: c.getString(5) ?: "")
                    }
                    val nums = o.getJSONArray("numbers")
                    val digits = num.filter { it.isDigit() }
                    var dup = false
                    for (k in 0 until nums.length()) if (nums.getJSONObject(k).optString("n").filter { it.isDigit() }.takeLast(9) == digits.takeLast(9)) dup = true
                    if (!dup) {
                        val type = ContactsContract.CommonDataKinds.Phone.getTypeLabel(resources, c.getInt(3), c.getString(4) ?: "").toString()
                        nums.put(JSONObject().put("n", num).put("t", type))
                    }
                }
            }
            // small thumbnails for the picker (full photos are fetched only for chosen people)
            var n = 0
            for (o in byId.values) {
                val t = o.optString("thumbUri")
                if (t.isNotEmpty() && n < 800) { o.put("thumb", photoData(t, 72)); n++ }
                o.remove("thumbUri")
            }
        } catch (_: Exception) { }
        val list = JSONArray(); byId.values.forEach { list.put(it) }
        sendToJs("contacts", JSONObject().put("list", list).toString())
    }.start()

    private fun photoData(uri: String, size: Int): String = try {
        contentResolver.openInputStream(Uri.parse(uri))?.use { ins ->
            val b = BitmapFactory.decodeStream(ins) ?: return ""
            val side = min(b.width, b.height)
            val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            Canvas(out).drawBitmap(b, Rect((b.width - side) / 2, (b.height - side) / 2, (b.width + side) / 2, (b.height + side) / 2), Rect(0, 0, size, size), null)
            dataUrl(out, false)
        } ?: ""
    } catch (e: Exception) { "" }

    // ------------------------------------------------------------- JavaScript bridge

    inner class Bridge {
        @JavascriptInterface
        fun info(): String = JSONObject(WidgetInfo.json(this@MainActivity))
            .put("pinSupported", AppWidgetManager.getInstance(this@MainActivity).isRequestPinAppWidgetSupported)
            .put("callPermission", checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED)
            .toString()

        @JavascriptInterface
        fun syncDesigns(json: String) {
            try {
                Store.saveDesigns(this@MainActivity, json)
                Widgets.updateAll(this@MainActivity)
                TimeJobs.scheduleAll(this@MainActivity)
            } catch (_: Exception) { }
        }

        @JavascriptInterface
        fun pinWidget(designId: String): String {
            val ctx = this@MainActivity
            val d = Store.design(ctx, designId) ?: return "missing"
            val mgr = AppWidgetManager.getInstance(ctx)
            if (!mgr.isRequestPinAppWidgetSupported) return "unsupported"
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
            val cb = PendingIntent.getBroadcast(ctx, designId.hashCode(),
                Intent(ctx, PinReceiver::class.java).putExtra("designId", designId), flags)
            return try {
                if (mgr.requestPinAppWidget(ComponentName(ctx, Widgets.providerFor(d.type)), null, cb)) "requested" else "unsupported"
            } catch (e: Exception) { "unsupported" }
        }

        @JavascriptInterface
        fun requestApps() { loadApps() }

        // ---- internal shortcuts of other apps (static, legacy creators, launcher-only)
        @JavascriptInterface
        fun requestInnerApps() { Thread { sendToJs("innerApps", try { AppShortcuts.appsJson(this@MainActivity) } catch (e: Exception) { "{\"apps\":[]}" }) }.start() }

        @JavascriptInterface
        fun requestInnerShortcuts(pkg: String) { Thread { sendToJs("innerShortcuts", try { AppShortcuts.appJson(this@MainActivity, pkg) } catch (e: Exception) { JSONObject().put("pkg", pkg).put("error", true).toString() }) }.start() }

        @JavascriptInterface
        fun createInnerShortcut(pkg: String, cls: String) = runOnUiThread {
            try { @Suppress("DEPRECATION") startActivityForResult(Intent(Intent.ACTION_CREATE_SHORTCUT).setComponent(ComponentName(pkg, cls)), REQ_SHORTCUT) }
            catch (e: Exception) { sendToJs("innerLegacy", "{\"ok\":false,\"why\":\"start\"}") }
        }

        @JavascriptInterface
        fun verifyInnerShortcut(value: String): String = AppShortcuts.verify(this@MainActivity, value)

        /** Really opens the shortcut now (the user's own test); answers with onNative('innerTest'). */
        @JavascriptInterface
        fun testInnerShortcut(value: String) = runOnUiThread {
            val ok = AppShortcuts.launch(this@MainActivity, value)
            sendToJs("innerTest", JSONObject().put("ok", ok).put("why", if (ok) "" else AppShortcuts.verify(this@MainActivity, value)).toString())
        }

        /** Weather & city search requests (https only), answered with onNative('http', …). */
        @JavascriptInterface
        fun httpGet(id: String, url: String) { Net.getAsync(id, url) { sendToJs("http", it) } }

        /** Device position for "my location" weather — asks for permission the first time. */
        @JavascriptInterface
        fun requestLocation() = runOnUiThread {
            if (Loc.granted(this@MainActivity)) Loc.fetch(this@MainActivity) { sendToJs("location", it) }
            else requestPermissions(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION), REQ_LOCATION)
        }

        @JavascriptInterface
        fun lastLocation(): String = Loc.saved(this@MainActivity)

        @JavascriptInterface
        fun isBaker(): Boolean = false

        /** Opens the system clock / calendar app, or refreshes the weather widgets. */
        @JavascriptInterface
        fun openSystem(kind: String) = runOnUiThread {
            when (kind) { "clockApp", "alarms" -> Actions.openClock(this@MainActivity); "setAlarm" -> Actions.setAlarm(this@MainActivity); "calendarApp" -> Actions.openCalendar(this@MainActivity); "refresh" -> TimeJobs.refreshWeatherNow(this@MainActivity) }
        }

        // ---- alarms (this app's own, scheduled by Android) + the device's next alarm
        @JavascriptInterface
        fun alarmsGet(): String = AlarmStore.list(this@MainActivity).toString()
        @JavascriptInterface
        fun alarmsSet(json: String) { AlarmStore.save(this@MainActivity, json) }
        @JavascriptInterface
        fun alarmTest() { AlarmService.start(this@MainActivity, "test") }
        @JavascriptInterface
        fun alarmStop() { AlarmService.stop(this@MainActivity, false) }
        @JavascriptInterface
        fun nextAlarm(): String = AlarmBridge.nextAlarmJson(this@MainActivity)
        @JavascriptInterface
        fun alarmPerms(): String = AlarmBridge.perms(this@MainActivity).toString()
        @JavascriptInterface
        fun requestAlarmPerm(kind: String) = runOnUiThread { AlarmBridge.request(this@MainActivity, kind) }

        /** Download an image from a link (any site, no CORS limits) and return it as a data URL. */
        @JavascriptInterface
        fun requestImage(url: String) = Thread {
            var res = JSONObject().put("ok", false)
            try {
                var conn = java.net.URL(url).openConnection() as java.net.HttpURLConnection
                conn.connectTimeout = 8000; conn.readTimeout = 10000; conn.instanceFollowRedirects = true
                conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) AppleWebKit/537.36 Chrome Mobile")
                var code = conn.responseCode
                if (code in 300..399) { // https → other host redirects
                    val loc = conn.getHeaderField("Location"); conn.disconnect()
                    conn = java.net.URL(java.net.URL(url), loc).openConnection() as java.net.HttpURLConnection
                    conn.connectTimeout = 8000; conn.readTimeout = 10000; code = conn.responseCode
                }
                if (code == 200) {
                    val bytes = conn.inputStream.use { ins -> val out = ByteArrayOutputStream(); val buf = ByteArray(16384); var tot = 0
                        while (true) { val n = ins.read(buf); if (n < 0) break; tot += n; if (tot > 8_000_000) throw IllegalStateException("too big"); out.write(buf, 0, n) }; out.toByteArray() }
                    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
                    var sample = 1; while (maxOf(o.outWidth, o.outHeight) / (sample * 2) >= 320) sample *= 2
                    val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
                    if (bmp != null) {
                        val k = minOf(1f, 320f / maxOf(bmp.width, bmp.height))
                        val sc = if (k < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * k).toInt().coerceAtLeast(1), (bmp.height * k).toInt().coerceAtLeast(1), true) else bmp
                        res = JSONObject().put("ok", true).put("data", dataUrl(sc, true))
                    }
                }
                conn.disconnect()
            } catch (_: Exception) { }
            sendToJs("image", res.toString())
        }.start()

        @JavascriptInterface
        fun recentApps(): String = Store.recent(this@MainActivity).toString()

        @JavascriptInterface
        fun setCountryCode(cc: String) { Store.setCc(this@MainActivity, cc) }

        @JavascriptInterface
        fun saveBake(designId: String, w: Int, h: Int, hash: String, json: String) {
            try { Store.saveBake(this@MainActivity, designId, w, h, hash, json) } catch (_: Exception) { }
        }

        @JavascriptInterface
        fun bakeKeys(): String = try { Store.bakeKeys(this@MainActivity).toString() } catch (e: Exception) { "{}" }

        @JavascriptInterface
        fun widgetSlots(): String = try { Widgets.slots(this@MainActivity).toString() } catch (e: Exception) { "[]" }

        @JavascriptInterface
        fun bakesDone() { try { Widgets.updateAll(this@MainActivity) } catch (_: Exception) { } }

        /** Apps that can open this link (browsers and app links), for "open with". */
        @JavascriptInterface
        fun requestUrlHandlers(url: String) = Thread {
            val out = JSONArray()
            try {
                val pm = packageManager
                val i = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addCategory(Intent.CATEGORY_BROWSABLE)
                @Suppress("DEPRECATION")
                val found = pm.queryIntentActivities(i, if (Build.VERSION.SDK_INT >= 23) PackageManager.MATCH_ALL else 0)
                val seen = HashSet<String>()
                for (ri in found) {
                    val pkg = ri.activityInfo.packageName
                    if (pkg == packageName || !seen.add(pkg)) continue
                    out.put(JSONObject().put("pkg", pkg).put("label", ri.loadLabel(pm).toString())
                        .put("icon", try { dataUrl(toBitmap(ri.loadIcon(pm), 72), true) } catch (_: Exception) { "" }))
                }
            } catch (_: Exception) { }
            sendToJs("handlers", out.toString())
        }.start()

        @JavascriptInterface
        fun iconPacks(): String = try { IconPacks.list(this@MainActivity).toString() } catch (e: Exception) { "[]" }

        @JavascriptInterface
        fun iconPackIcons(pkg: String, query: String, offset: Int, limit: Int): String =
            try { IconPacks.page(this@MainActivity, pkg, query, offset, limit).toString() } catch (e: Exception) { "{\"total\":0,\"items\":[]}" }

        @JavascriptInterface
        fun iconPackIcon(pkg: String, name: String): String = try { IconPacks.icon(this@MainActivity, pkg, name) } catch (e: Exception) { "" }

        @JavascriptInterface
        fun iconPackMatch(pkg: String, appPkg: String): String = try { IconPacks.match(this@MainActivity, pkg, appPkg) } catch (e: Exception) { "" }

        /** Website logo for a link (runs on the bridge thread, not the UI thread). */
        @JavascriptInterface
        fun fetchFavicon(url: String): String = try {
            val s = url.trim()
            val host = Uri.parse(if (s.contains("://")) s else "https://$s").host ?: ""
            if (host.isEmpty()) "" else {
                val conn = java.net.URL("https://www.google.com/s2/favicons?domain=" + Uri.encode(host) + "&sz=128").openConnection() as java.net.HttpURLConnection
                conn.connectTimeout = 6000
                conn.readTimeout = 6000
                conn.instanceFollowRedirects = true
                val bmp = conn.inputStream.use { BitmapFactory.decodeStream(it) }
                conn.disconnect()
                if (bmp == null || bmp.width < 8) "" else IconPacks.png(bmp)
            }
        } catch (e: Exception) { "" }

        @JavascriptInterface
        fun requestContacts() = runOnUiThread {
            if (checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) loadContacts()
            else requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), REQ_CONTACTS)
        }

        @JavascriptInterface
        fun contactPhoto(uri: String): String = photoData(uri, 256)

        @JavascriptInterface
        fun requestCallPermission() = runOnUiThread {
            if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED)
                requestPermissions(arrayOf(Manifest.permission.CALL_PHONE), REQ_CALL_PERMISSION)
        }

        @JavascriptInterface
        fun exportJson(name: String, text: String) = runOnUiThread {
            pendingExport = text
            try {
                @Suppress("DEPRECATION")
                startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                    .setType("application/json").putExtra(Intent.EXTRA_TITLE, name), REQ_EXPORT)
            } catch (e: Exception) { sendToJs("exported", "{\"ok\":false}") }
        }
    }
}
