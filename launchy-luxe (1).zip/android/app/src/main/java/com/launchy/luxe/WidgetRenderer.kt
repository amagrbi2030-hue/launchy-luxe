package com.launchy.luxe

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.Icon
import android.os.Build
import android.view.Gravity
import android.graphics.RectF
import android.net.Uri
import android.util.Log
import android.util.TypedValue
import android.view.View
import android.widget.RemoteViews
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Turns a saved studio design into RemoteViews. Layout math is a port of
 * renderGrid / renderPeople / renderCard / renderDock in index.html, run on the
 * widget's real size so the grid adapts to whatever space the launcher gives it.
 */
object WidgetRenderer {
    const val ROWS = 5
    const val COLS = 8
    private const val TAG = "LaunchyWidget"

    // --------------------------------------------------------------- layout plan (studio px units)
    class PCell(val item: JSONObject, val size: Float, val shape: String)
    class PRow(val slots: Int, val cells: List<PCell?>, val title: String? = null)
    class Plan(
        val rows: List<PRow>, val featured: PCell?, val featCols: Int,
        val pad: Float, val gap: Float, val font: Float, val labels: Boolean, val perIcon: Boolean,
        val title: String? = null, val subtitle: String? = null, val headGap: Float = 0f,
        val people: Boolean = false, val soft: Boolean = false, val frame: String = "none",
        val side: Boolean = false, val nameW: Float = 0f, val call: Boolean = false, val wa: Boolean = false,
        val radius: Float, val vInset: Float = 0f
    )

    private fun grid(d: Design, W: Float, H: Float, items: List<JSONObject>): Plan {
        val o = d.opts("grid")
        val pad = d.num("padding", 14.0); val gap = d.num("gap", 10.0); val font = d.num("font", 11.0)
        val labels = o.optBoolean("labels", true)
        val shape = o.optString("shape", "rounded")
        val labelH = if (labels) (font * 1.3f).roundToInt() + 4f else 0f
        val aw = W - 2 * pad; val ah = H - 2 * pad
        val ratio = if (shape == "rect") .74f else 1f
        val minT = 30f
        val cols = max(1, min(o.optInt("cols", 4), floor((aw + gap) / (minT + gap)).toInt()))
        val rowsFit = max(1, min(ROWS, floor((ah + gap) / (minT * ratio + labelH + gap)).toInt()))
        val n = minOf(o.optInt("count", 8), items.size, cols * rowsFit)
        val rows = max(1, ceil(n / cols.toFloat()).toInt())
        val cellW = (aw - gap * (cols - 1)) / cols
        val cellH = (ah - gap * (rows - 1)) / rows - labelH
        val t = max(22f, floor(min(cellW, cellH / ratio) * d.num("iconScale", 88.0) / 100f))
        val out = ArrayList<PRow>()
        for (r in 0 until rows) {
            out.add(PRow(cols, List(cols) { c -> val i = r * cols + c; if (i < n) PCell(items[i], t, shape) else null }))
        }
        return Plan(out, null, 4, pad, gap, font, labels, o.optBoolean("perIcon", false), radius = d.num("radius", 26.0))
    }

    private fun people(d: Design, W: Float, H: Float, items: List<JSONObject>): Plan {
        val o = d.opts("people")
        val pad = d.num("padding", 14.0); val gap = d.num("gap", 10.0); val fs = d.num("font", 11.0)
        val side = o.optString("namePos") == "side"
        val frame = o.optString("frame", "ring")
        val nameH = (fs * 1.35f).roundToInt() + 4f
        val aw = W - 2 * pad; val ah = H - 2 * pad
        val gp = if (frame == "glass") 12f else 0f
        var av = if (side) ah - gp else ah - nameH - 6 - gp
        av = max(24f, floor(min(av, if (side) 72f else 84f) * d.num("iconScale", 88.0) / 100f))
        val nameW = if (side) (fs * 5).roundToInt().toFloat() else 0f
        val unit = (if (side) av + 8 + nameW else max(av + (if (frame == "ring") 8 else 0), fs * 4.4f)) + gp
        val fit = max(1, floor((aw + gap) / (unit + gap)).toInt())
        val n = minOf(o.optInt("count", 5), items.size, fit, COLS)
        val row = PRow(n, List(n) { PCell(items[it], av, if (o.optString("shape") == "soft") "soft" else "circle") })
        return Plan(listOf(row), null, 4, pad, gap, fs, !side, false, people = true,
            soft = o.optString("shape") == "soft", frame = frame, side = side, nameW = nameW,
            call = o.optBoolean("call", true), wa = o.optBoolean("wa", true), radius = d.num("radius", 26.0))
    }

    private fun card(d: Design, W: Float, H: Float, items: List<JSONObject>): Plan {
        val o = d.opts("card")
        val pad = max(12f, d.num("padding", 14.0)); val gap = d.num("gap", 10.0); val fs = max(12f, d.num("font", 11.0))
        val title = o.optString("title").takeIf { it.isNotBlank() }
        val sub = o.optString("subtitle").takeIf { it.isNotBlank() }
        var headH = 0f
        if (title != null) headH += (fs * 1.45f * 1.35f).roundToInt()
        if (sub != null) headH += (fs * .95f * 1.4f).roundToInt()
        val gapB = max(8f, (gap * .9f).roundToInt().toFloat())
        if (headH > 0) headH += gapB
        val aw = W - 2 * pad; val bh = H - 2 * pad - headH
        val cols = max(2, min(o.optInt("cols", 4), floor((aw + gap) / (40 + gap)).toInt()))
        val labels = o.optBoolean("labels", true)
        val shape = o.optString("shape", "rounded")
        val labelH = if (labels) (fs * 1.3f).roundToInt() + 4f else 0f
        val cellW = (aw - gap * (cols - 1)) / cols
        val iconBase = max(26f, floor(min(cellW, 64f) * d.num("iconScale", 88.0) / 100f))
        val rowH = iconBase + labelH
        val rows = ArrayList<PRow>()
        var featured: PCell? = null
        if (!o.optBoolean("sections", false)) {
            val rowsFit = max(1, min(ROWS, floor((bh + gap) / (rowH + gap)).toInt()))
            val feat = o.optBoolean("featured", true) && rowsFit >= 2 && cols >= 3 && items.size > 1
            val perRow = if (feat) cols - 2 else cols
            var idx = 0
            if (feat) {
                val big = floor(min(cellW * 2 + gap, rowsFit * rowH + (rowsFit - 1) * gap - labelH) * .88f)
                featured = PCell(items[0], big, shape); idx = 1
            }
            for (r in 0 until rowsFit) {
                if (idx >= items.size) break
                rows.add(PRow(perRow, List(perRow) { if (idx < items.size) PCell(items[idx++], iconBase, shape) else null }))
            }
            return Plan(rows, featured, cols, pad, gap, fs, labels, o.optBoolean("perIcon", false),
                title, sub, gapB, radius = d.num("radius", 26.0))
        }
        val groups = listOf("app" to "التطبيقات", "url" to "المواقع", "call" to "الاتصال", "wa" to "واتساب")
            .map { (k, n) -> n to items.filter { it.optString("kind") == k } }.filter { it.second.isNotEmpty() }
        val secH = (fs * .88f * 1.4f).roundToInt() + 6f
        var remaining = bh
        for ((name, list) in groups) {
            if (remaining < secH + rowH || rows.size >= ROWS) break
            val need = ceil(list.size / cols.toFloat()).toInt()
            val fitRows = floor((remaining - secH + gap) / (rowH + gap)).toInt()
            val rcount = minOf(need, fitRows, ROWS - rows.size)
            if (rcount < 1) break
            var idx = 0
            for (r in 0 until rcount) {
                rows.add(PRow(cols, List(cols) { if (idx < list.size) PCell(list[idx++], iconBase, shape) else null }, if (r == 0) name else null))
            }
            remaining -= secH + rcount * rowH + (rcount - 1) * gap + gap
        }
        return Plan(rows, null, cols, pad, gap, fs, labels, o.optBoolean("perIcon", false), title, sub, gapB, radius = d.num("radius", 26.0))
    }

    private fun dock(d: Design, W: Float, H: Float, items: List<JSONObject>, targetH: Float): Plan {
        val o = d.opts("dock")
        val gap = max(4f, (d.num("gap", 10.0) * .8f).roundToInt().toFloat())
        val pad = max(6f, (d.num("padding", 14.0) * .6f).roundToInt().toFloat())
        val vInset = max(0f, (H - targetH) / 2f)
        val h = H - 2 * vInset
        var labels = o.optBoolean("labels", false)
        val font = d.num("font", 11.0)
        val aw = W - 2 * pad; val ah = h - 2 * pad
        var labelH = if (labels) (font * 1.3f).roundToInt() + 3f else 0f
        if (labels && ah - labelH < 24) { labels = false; labelH = 0f }
        var n = minOf(o.optInt("count", 5), items.size, COLS)
        var t = 0f
        while (n > 0) { t = min((aw - gap * (n - 1)) / n, ah - labelH); if (t >= 26) break; n-- }
        t = max(20f, floor(t * d.num("iconScale", 88.0) / 100f))
        val shape = o.optString("shape", "circle")
        val row = PRow(n, List(n) { PCell(items[it], t, shape) })
        return Plan(listOf(row), null, 4, pad, gap, font, labels, o.optBoolean("perIcon", false),
            radius = min(d.num("radius", 26.0), h / 2f), vInset = vInset)
    }

    // --------------------------------------------------------------- RemoteViews

    private var idCache: IntArray? = null
    private fun idx(r: Int, c: Int, part: Int) = ((r * COLS + c) * 6) + part
    private fun ids(ctx: Context): IntArray {
        idCache?.let { return it }
        val res = ctx.resources
        val pkg = ctx.packageName
        val arr = IntArray(ROWS * COLS * 6)
        val parts = listOf("cell", "ho", "ic", "bc", "bw", "lb")
        for (r in 0 until ROWS) for (c in 0 until COLS) for ((p, name) in parts.withIndex())
            arr[idx(r, c, p)] = res.getIdentifier("${name}_${r}_$c", "id", pkg)
        idCache = arr
        return arr
    }
    private fun rowId(ctx: Context, r: Int) = ctx.resources.getIdentifier("row_$r", "id", ctx.packageName)
    private fun rowTitleId(ctx: Context, r: Int) = ctx.resources.getIdentifier("rowt_$r", "id", ctx.packageName)

    fun actionIntent(ctx: Context, widgetId: Int, slot: Int, kind: String, value: String): PendingIntent {
        val i = Intent(ctx, ActionActivity::class.java).apply {
            action = "com.launchy.luxe.RUN"
            data = Uri.parse("launchy://w/$widgetId/$slot")
            putExtra("kind", kind)
            putExtra("value", value)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
        }
        return PendingIntent.getActivity(ctx, widgetId * 1000 + slot, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun configureIntent(ctx: Context, widgetId: Int): PendingIntent {
        val i = Intent(ctx, ConfigureActivity::class.java).apply {
            data = Uri.parse("launchy://configure/$widgetId")
            putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return PendingIntent.getActivity(ctx, 900000 + widgetId, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun appIntent(ctx: Context, widgetId: Int, route: String): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java).apply {
            data = Uri.parse("launchy://open/$widgetId/$route")
            putExtra("route", route)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return PendingIntent.getActivity(ctx, 800000 + widgetId, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    fun placeholder(ctx: Context, widgetId: Int, text: String, openApp: Boolean = false): RemoteViews {
        val rv = RemoteViews(ctx.packageName, R.layout.widget_placeholder)
        rv.setTextViewText(R.id.ph_text, text)
        rv.setOnClickPendingIntent(R.id.ph_root, if (openApp) appIntent(ctx, widgetId, "designs") else configureIntent(ctx, widgetId))
        return rv
    }

    /** Widget size in dp (portrait), with sensible fallbacks. */
    fun widgetDp(mgr: AppWidgetManager, widgetId: Int, d: Design): Pair<Int, Int> {
        val (cCells, rCells) = d.cells()
        val opts = mgr.getAppWidgetOptions(widgetId)
        var wDp = opts?.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH) ?: 0
        var hDp = opts?.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT) ?: 0
        if (wDp <= 0) wDp = cCells * 76
        if (hDp <= 0) hDp = rCells * 88
        return wDp to hDp
    }

    /** Same geometry as the studio: width = design cells (4 cells = 320 css px), height follows the real widget. */
    fun cssSize(mgr: AppWidgetManager, widgetId: Int, d: Design): Pair<Float, Float> {
        val (wDp, hDp) = widgetDp(mgr, widgetId, d)
        val designW = d.cells().first * 82f - 8f
        val k = wDp / designW
        return designW to (hDp / k)
    }

    private fun hitIntent(ctx: Context, widgetId: Int, slot: Int, h: JSONObject): PendingIntent {
        val k = h.optString("k")
        val i = if (k == "open") Intent(ctx, MainActivity::class.java).apply {
            data = Uri.parse("launchy://open/$widgetId/$slot")
            putExtra("route", h.optString("v", "screen"))
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        } else Intent(ctx, ActionActivity::class.java).apply {
            action = "com.launchy.luxe.RUN"
            data = Uri.parse("launchy://w/$widgetId/$slot")
            putExtra("kind", k)
            putExtra("value", h.optString("v"))
            putExtra("pkg", h.optString("p"))
            putExtra("biz", h.optString("b", "auto"))
            putExtra("name", h.optString("n"))
            putExtra("wa", h.optString("wn"))
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
        }
        return PendingIntent.getActivity(ctx, widgetId * 1000 + slot, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    /**
     * Widget from the studio's baked image: the picture is drawn with fitCenter and every
     * tap area is an exact transparent slot positioned with paddings (works on all Android versions).
     */
    private fun buildBaked(ctx: Context, mgr: AppWidgetManager, widgetId: Int, d: Design, b: Store.Bake): RemoteViews {
        val den = ctx.resources.displayMetrics.density
        val (wDp, hDp) = widgetDp(mgr, widgetId, d)
        val wPx = wDp * den; val hPx = hDp * den
        val ringing = d.type == "clock" && AlarmStore.isRinging(ctx)
        val bmp = (if (ringing) b.alertFile?.let { Store.decodeFile(it, 1400) } else null) ?: Store.decodeBake(b, 1400) ?: throw IllegalStateException("bake decode")
        val rv = RemoteViews(ctx.packageName, R.layout.w_baked)
        rv.setImageViewBitmap(R.id.baked, bmp)
        rv.setContentDescription(R.id.baked, d.name)
        val f = minOf(wPx / b.w, hPx / b.h)
        val ox = (wPx - b.w * f) / 2f; val oy = (hPx - b.h * f) / 2f
        rv.removeAllViews(R.id.hits)
        rv.removeAllViews(R.id.live)
        b.live.forEachIndexed { i, el -> try { addLive(ctx, rv, b, el, i, f, ox, oy, wPx, hPx, ringing) } catch (e: Exception) { Log.w(TAG, "live", e) } }
        b.hits.forEachIndexed { i, h ->
            val x = (ox + h.optDouble("x", 0.0).toFloat() * f).roundToInt().coerceAtLeast(0)
            val y = (oy + h.optDouble("y", 0.0).toFloat() * f).roundToInt().coerceAtLeast(0)
            val w = (h.optDouble("w", 0.0).toFloat() * f).roundToInt().coerceAtLeast(8)
            val hh = (h.optDouble("h", 0.0).toFloat() * f).roundToInt().coerceAtLeast(8)
            val slot = RemoteViews(ctx.packageName, R.layout.w_hit)
            slot.setViewPadding(R.id.hs_top, 0, y, 0, 0)
            slot.setViewPadding(R.id.hs_left, x, 0, 0, 0)
            slot.setViewPadding(R.id.hs_hit, w, hh, 0, 0)
            slot.setContentDescription(R.id.hs_hit, h.optString("n").ifEmpty { h.optString("k") })
            slot.setOnClickPendingIntent(R.id.hs_hit, hitIntent(ctx, widgetId, i, h))
            rv.addView(R.id.hits, slot)
        }
        return rv
    }

    /**
     * Live parts of a time widget, drawn by Android itself so they are always exact:
     * an AnalogClock with the design's own hand images (Android 12+) or a TextClock
     * in the bundled digit font. Positioned with paddings inside a full-size frame.
     */
    /** ViewFlipper layouts with fixed intervals (the interval is set in XML, never by a reflective call). */
    private val FLIP_MS = intArrayOf(80, 100, 120, 140, 170, 200, 250, 320)

    private fun addLive(ctx: Context, rv: RemoteViews, b: Store.Bake, el: JSONObject, i: Int, f: Float, ox: Float, oy: Float, wPx: Float, hPx: Float, ringing: Boolean = false) {
        val x = ox + el.optDouble("x", 0.0).toFloat() * f
        val y = oy + el.optDouble("y", 0.0).toFloat() * f
        val w = el.optDouble("w", 0.0).toFloat() * f
        val h = el.optDouble("h", 0.0).toFloat() * f
        val pl = x.roundToInt().coerceAtLeast(0); val pt = y.roundToInt().coerceAtLeast(0)
        val pr = (wPx - x - w).roundToInt().coerceAtLeast(0); val pb = (hPx - y - h).roundToInt().coerceAtLeast(0)
        val tz = el.optString("tz")
        if (el.optString("k") == "pendulum") {
            // a short loop of baked frames that the launcher itself plays (ViewFlipper): no periodic updates from us
            val key = if (ringing && el.optInt("pa") > 0) "pa" else if (el.optInt("pf") > 0) "pf" else return
            val n = el.optInt(key)
            val ms = if (key == "pa") el.optInt("ams", 110) else el.optInt("ms", 170)
            val bucket = FLIP_MS.minByOrNull { abs(it - ms) } ?: 170
            val layout = ctx.resources.getIdentifier("w_pend_$bucket", "layout", ctx.packageName).takeIf { it != 0 } ?: return
            val v = RemoteViews(ctx.packageName, layout)
            v.setViewPadding(R.id.pd_box, pl, pt, pr, pb)
            val side = maxOf(w, h).coerceAtLeast(8f)
            val k = minOf(1f, 300f / side)  // frames stay small: RemoteViews has a bitmap memory budget
            for (j in 0 until n) {
                val file = b.part("$key${i}_$j") ?: continue
                val bm = BitmapFactory.decodeFile(file.path) ?: continue
                val sb = Bitmap.createScaledBitmap(bm, (w * k).roundToInt().coerceAtLeast(2), (h * k).roundToInt().coerceAtLeast(2), true)
                val fr = RemoteViews(ctx.packageName, R.layout.w_frame)
                fr.setImageViewBitmap(R.id.fr_img, sb)
                v.addView(R.id.pd_flip, fr)
            }
            rv.addView(R.id.live, v)
            return
        }
        if (el.optString("k") == "chrono") {
            // countdown to the next alarm on the device, ticking on its own (Chronometer)
            val next = AlarmBridge.nextAlarmAt(ctx)
            if (next <= System.currentTimeMillis()) return
            val v = RemoteViews(ctx.packageName, R.layout.w_chrono)
            v.setViewPadding(R.id.ch_box, pl, pt, pr, pb)
            v.setChronometer(R.id.ch, android.os.SystemClock.elapsedRealtime() + (next - System.currentTimeMillis()), "⏰ %s", true)
            v.setChronometerCountDown(R.id.ch, true)
            v.setTextColor(R.id.ch, parseCssColor(el.optString("color"), Color.WHITE))
            v.setTextViewTextSize(R.id.ch, TypedValue.COMPLEX_UNIT_PX, el.optDouble("size", 14.0).toFloat() * f)
            rv.addView(R.id.live, v)
            return
        }
        if (el.optString("k") == "analog") {
            val v = RemoteViews(ctx.packageName, R.layout.w_analog)
            v.setViewPadding(R.id.ac_box, pl, pt, pr, pb)
            if (Build.VERSION.SDK_INT >= 31) {
                val side = minOf(w, h).roundToInt().coerceAtLeast(8)
                val icon = { name: String -> b.part(name + i)?.let { file ->
                    BitmapFactory.decodeFile(file.path)?.let { bm -> Icon.createWithBitmap(Bitmap.createScaledBitmap(bm, side, side, true)) } } }
                v.setIcon(R.id.ac, "setDial", Icon.createWithBitmap(Bitmap.createBitmap(side, side, Bitmap.Config.ALPHA_8)))
                icon("hh")?.let { v.setIcon(R.id.ac, "setHourHand", it) }
                icon("mm")?.let { v.setIcon(R.id.ac, "setMinuteHand", it) }
                icon("ss")?.let { v.setIcon(R.id.ac, "setSecondHand", it) }
                if (tz.isNotEmpty()) v.setString(R.id.ac, "setTimeZone", tz)
            }
            rv.addView(R.id.live, v)
            return
        }
        val font = el.optString("font", "llx_thin_l")
        val layout = ctx.resources.getIdentifier("w_tc_$font", "layout", ctx.packageName).takeIf { it != 0 } ?: R.layout.w_tc_llx_thin_l
        val v = RemoteViews(ctx.packageName, layout)
        v.setViewPadding(R.id.tc_box, pl, pt, pr, pb)
        v.setCharSequence(R.id.tc, "setFormat12Hour", el.optString("f12", "h:mm"))
        v.setCharSequence(R.id.tc, "setFormat24Hour", el.optString("f24", "HH:mm"))
        v.setTextColor(R.id.tc, parseCssColor(el.optString("color"), Color.WHITE))
        v.setTextViewTextSize(R.id.tc, TypedValue.COMPLEX_UNIT_PX, el.optDouble("size", 40.0).toFloat() * f)
        v.setInt(R.id.tc, "setGravity", Gravity.CENTER_VERTICAL or when (el.optString("align")) { "left" -> Gravity.LEFT; "right" -> Gravity.RIGHT; else -> Gravity.CENTER_HORIZONTAL })
        if (tz.isNotEmpty()) v.setString(R.id.tc, "setTimeZone", tz)
        rv.addView(R.id.live, v)
    }

    private val NATIVE_TYPES = setOf("grid", "people", "card", "dock")

    fun update(ctx: Context, mgr: AppWidgetManager, widgetId: Int) {
        val designId = Store.designFor(ctx, widgetId)
        val design = designId?.let { Store.design(ctx, it) }
        val views = when {
            design == null -> placeholder(ctx, widgetId, if (designId == null) "اضغط لاختيار تصميم من الاختصارات الشامل" else "التصميم غير موجود — اضغط لاختيار غيره")
            design.items.isEmpty() && design.type !in Widgets.TIME_TYPES -> placeholder(ctx, widgetId, "«${design.name}» بلا عناصر — اضغط لإضافتها", openApp = true)
            else -> try {
                val (w, h) = cssSize(mgr, widgetId, design)
                val bake = Store.bakeFor(ctx, design.id, w, h)
                // self-healing: a new size, a new day or a missing drawing → re-draw in the background
                if (bake == null) TimeJobs.bakeSoonThrottled(ctx, "miss_${design.id}", 10 * 60_000)
                else {
                    if (abs(bake.w - w.roundToInt()) > 1.5f || abs(bake.h - h.roundToInt()) > 1.5f) TimeJobs.bakeSoonThrottled(ctx, "size_${widgetId}_${w.roundToInt()}x${h.roundToInt()}", 120_000)
                    if (design.type in Widgets.TIME_TYPES && bake.day.isNotEmpty() && bake.day != TimeJobs.today()) TimeJobs.bakeSoonThrottled(ctx, "day", 10 * 60_000)
                }
                when {
                    bake == null && design.type in Widgets.TIME_TYPES -> placeholder(ctx, widgetId, "جارٍ تجهيز «${design.name}»… إن طال الانتظار افتح التطبيق مرة", openApp = true)
                    bake != null -> buildBaked(ctx, mgr, widgetId, design, bake)
                    design.type in NATIVE_TYPES -> build(ctx, mgr, widgetId, design)
                    else -> placeholder(ctx, widgetId, "افتح الاختصارات الشامل مرة واحدة لتجهيز «${design.name}»", openApp = true)
                }
            } catch (e: Exception) {
                Log.e(TAG, "render failed", e)
                placeholder(ctx, widgetId, "تعذّر رسم الويدجت — اضغط لإعادة الاختيار")
            }
        }
        try { mgr.updateAppWidget(widgetId, views) } catch (e: Exception) {
            Log.e(TAG, "update failed", e)
            mgr.updateAppWidget(widgetId, placeholder(ctx, widgetId, "الويدجت أكبر من المسموح — صغّر الحجم"))
        }
    }

    private fun build(ctx: Context, mgr: AppWidgetManager, widgetId: Int, d: Design): RemoteViews {
        val den = ctx.resources.displayMetrics.density
        val (cCells, rCells) = d.cells()
        val opts = mgr.getAppWidgetOptions(widgetId)
        var wDp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH)
        var hDp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT)
        if (wDp <= 0) wDp = cCells * 76
        if (hDp <= 0) hDp = rCells * 88

        // Studio geometry: 4 cells = 328 css px; the widget keeps the studio's width and adapts its height.
        val designW = cCells * 82f - 8f
        val k = wDp / designW          // dp per studio px
        val W = designW
        val H = hDp / k
        val items = d.items
        val dockTargetH = (rCells * 96f - 8f) * d.num("dockH", 80.0) / 100f
        val plan = when (d.type) {
            "people" -> people(d, W, H, items)
            "card" -> card(d, W, H, items)
            "dock" -> dock(d, W, H, items, dockTargetH)
            else -> grid(d, W, H, items)
        }
        val px = k * den                // device px per studio px

        val layout = if (plan.featured != null) when (plan.featCols) { 3 -> R.layout.widget_c3; 5 -> R.layout.widget_c5; else -> R.layout.widget_c4 } else R.layout.widget_c4
        val rv = RemoteViews(ctx.packageName, layout)
        val sp = d.spec

        // ---- background (scaled down if very large to respect the RemoteViews bitmap budget)
        val fullW = (wDp * den).roundToInt()
        val fullH = (hDp * den).roundToInt()
        val scale = min(1f, 1000f / max(fullW, fullH))
        val bW = max(1, (fullW * scale).roundToInt())
        val bH = max(1, (fullH * scale).roundToInt())
        val margin = Painter.bgMargin(sp, px, min(fullW, fullH) * 0.06f)
        val vIn = plan.vInset * px
        val box = RectF(margin * scale, (margin + vIn) * scale, bW - margin * scale, bH - (margin + vIn) * scale)
        rv.setImageViewBitmap(R.id.bg, Painter.background(sp, bW, bH, box, plan.radius * px * scale, px * scale))

        val gapPx = plan.gap * px
        val padPx = plan.pad * px
        val hPad = (margin + padPx - gapPx / 2f).roundToInt().coerceAtLeast(0)
        val vPad = (margin + vIn + padPx - gapPx / 2f).roundToInt().coerceAtLeast(0)
        rv.setViewPadding(R.id.content, hPad, vPad, hPad, vPad)

        // ---- header (big card only)
        if (plan.title != null || plan.subtitle != null) {
            rv.setViewVisibility(R.id.head, View.VISIBLE)
            rv.setViewPadding(R.id.head, (gapPx / 2).roundToInt(), (gapPx / 2).roundToInt(), (gapPx / 2).roundToInt(), (plan.headGap * px - gapPx / 2).roundToInt().coerceAtLeast(0))
            if (plan.title != null) {
                rv.setViewVisibility(R.id.title, View.VISIBLE)
                rv.setTextViewText(R.id.title, plan.title)
                rv.setTextViewTextSize(R.id.title, TypedValue.COMPLEX_UNIT_PX, plan.font * 1.45f * px)
                rv.setTextColor(R.id.title, sp.text)
            } else rv.setViewVisibility(R.id.title, View.GONE)
            if (plan.subtitle != null) {
                rv.setViewVisibility(R.id.subtitle, View.VISIBLE)
                rv.setTextViewText(R.id.subtitle, plan.subtitle)
                rv.setTextViewTextSize(R.id.subtitle, TypedValue.COMPLEX_UNIT_PX, plan.font * .95f * px)
                rv.setTextColor(R.id.subtitle, sp.sub)
            } else rv.setViewVisibility(R.id.subtitle, View.GONE)
        } else rv.setViewVisibility(R.id.head, View.GONE)

        // ---- featured shortcut (big card)
        val tileMarginOf = { size: Float -> Painter.tileMargin(sp, px, size) }
        var slot = 0
        val f = plan.featured
        if (f != null) {
            rv.setViewVisibility(R.id.feat, View.VISIBLE)
            rv.setViewPadding(R.id.feat, (gapPx / 2).roundToInt(), 0, (gapPx / 2).roundToInt(), 0)
            val size = f.size * px
            rv.setImageViewBitmap(R.id.ic_f, Painter.tile(sp, f.item, size, f.shape, plan.perIcon, px, tileMarginOf(size)))
            setLabel(rv, R.id.lb_f, f.item, plan, sp, px)
            rv.setOnClickPendingIntent(R.id.feat, actionIntent(ctx, widgetId, 999, f.item.optString("kind"), f.item.optString("value")))
        } else rv.setViewVisibility(R.id.feat, View.GONE)

        // ---- rows
        val id = ids(ctx)
        for (r in 0 until ROWS) {
            val row = plan.rows.getOrNull(r)
            val rid = rowId(ctx, r)
            val tid = rowTitleId(ctx, r)
            if (row == null) {
                rv.setViewVisibility(rid, View.GONE); rv.setViewVisibility(tid, View.GONE)
                continue
            }
            rv.setViewVisibility(rid, View.VISIBLE)
            rv.setViewPadding(rid, 0, (gapPx / 2).roundToInt(), 0, (gapPx / 2).roundToInt())
            if (row.title != null) {
                rv.setViewVisibility(tid, View.VISIBLE)
                rv.setTextViewText(tid, row.title)
                rv.setTextViewTextSize(tid, TypedValue.COMPLEX_UNIT_PX, plan.font * .88f * px)
                rv.setTextColor(tid, sp.sub)
                rv.setViewPadding(tid, (gapPx / 2).roundToInt(), (gapPx / 2).roundToInt(), (gapPx / 2).roundToInt(), 0)
            } else rv.setViewVisibility(tid, View.GONE)

            for (c in 0 until COLS) {
                val cellId = id[idx(r, c, 0)]
                if (c >= row.slots) { rv.setViewVisibility(cellId, View.GONE); continue }
                val cell = row.cells.getOrNull(c)
                if (cell == null) { rv.setViewVisibility(cellId, View.INVISIBLE); continue }
                rv.setViewVisibility(cellId, View.VISIBLE)
                rv.setViewPadding(cellId, (gapPx / 2).roundToInt(), 0, (gapPx / 2).roundToInt(), 0)
                val icId = id[idx(r, c, 2)]
                val kind = cell.item.optString("kind")
                val value = cell.item.optString("value")
                val size = cell.size * px
                if (plan.people) {
                    val m = max(tileMarginOf(size), when (plan.frame) { "glow" -> 8f; "glass" -> 7f; "ring" -> 4.5f; else -> 1f } * px)
                    rv.setImageViewBitmap(icId, Painter.avatar(sp, cell.item, size, plan.soft, plan.frame, px, m,
                        if (plan.side) plan.nameW * px else 0f, plan.font * px))
                    val phone = if ((kind == "call" || kind == "wa") && value.count { it.isDigit() } >= 6) value else null
                    val bs = max(16f, cell.size * .34f) * px
                    val bc = id[idx(r, c, 3)]
                    val bwId = id[idx(r, c, 4)]
                    if (phone != null && plan.call) {
                        rv.setViewVisibility(bc, View.VISIBLE)
                        rv.setImageViewBitmap(bc, Painter.badge("call", bs, px))
                        rv.setOnClickPendingIntent(bc, actionIntent(ctx, widgetId, 300 + slot, "call", phone))
                    } else rv.setViewVisibility(bc, View.GONE)
                    if (phone != null && plan.wa) {
                        rv.setViewVisibility(bwId, View.VISIBLE)
                        rv.setImageViewBitmap(bwId, Painter.badge("wa", bs, px))
                        rv.setOnClickPendingIntent(bwId, actionIntent(ctx, widgetId, 600 + slot, "wa", phone))
                    } else rv.setViewVisibility(bwId, View.GONE)
                } else {
                    rv.setImageViewBitmap(icId, Painter.tile(sp, cell.item, size, cell.shape, plan.perIcon, px, tileMarginOf(size)))
                    rv.setViewVisibility(id[idx(r, c, 3)], View.GONE)
                    rv.setViewVisibility(id[idx(r, c, 4)], View.GONE)
                }
                setLabel(rv, id[idx(r, c, 5)], cell.item, plan, sp, px)
                rv.setOnClickPendingIntent(cellId, actionIntent(ctx, widgetId, slot, kind, value))
                slot++
            }
        }
        return rv
    }

    private fun setLabel(rv: RemoteViews, lid: Int, item: JSONObject, plan: Plan, sp: Spec, px: Float) {
        if (!plan.labels) { rv.setViewVisibility(lid, View.GONE); return }
        rv.setViewVisibility(lid, View.VISIBLE)
        rv.setTextViewText(lid, item.optString("label"))
        rv.setTextViewTextSize(lid, TypedValue.COMPLEX_UNIT_PX, plan.font * px)
        rv.setTextColor(lid, sp.text)
    }
}
