package com.launchy.luxe

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.PendingIntent
import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.Calendar
import java.util.Locale

/**
 * Keeps the time widgets fresh with the least battery use:
 *  - the time itself is drawn live by Android (AnalogClock / TextClock), no updates needed;
 *  - dates are re-drawn once a day (alarm just after midnight, and after boot / time-zone changes);
 *  - weather is fetched by a periodic JobScheduler job (network required, system-batched).
 * Re-drawing uses the studio's own renderer in a hidden WebView, so the result matches the preview.
 */
object TimeJobs {
    private const val TAG = "LaunchyTime"
    const val JOB_BAKE = 4201
    const val JOB_WEATHER = 4202
    const val ACTION_MIDNIGHT = "com.launchy.luxe.MIDNIGHT"

    private fun js(ctx: Context) = ctx.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler

    /** One re-draw soon (repeated calls within the delay collapse into one job). */
    fun bakeSoon(ctx: Context, delayMs: Long = 1500, weather: Boolean = false) {
        try {
            val b = JobInfo.Builder(JOB_BAKE, ComponentName(ctx, BakeJobService::class.java))
                .setMinimumLatency(delayMs)
                .setOverrideDeadline(delayMs + 30_000)
                .setExtras(android.os.PersistableBundle().apply { putInt("weather", if (weather) 1 else 0) })
            js(ctx).schedule(b.build())
        } catch (e: Exception) { Log.w(TAG, "bakeSoon", e) }
    }

    /** Re-draw only if we have not asked for one recently (self-healing checks from the widgets). */
    fun bakeSoonThrottled(ctx: Context, key: String, minGapMs: Long) {
        val p = ctx.getSharedPreferences("launchy_time", Context.MODE_PRIVATE)
        val last = p.getLong("ask_$key", 0L)
        val now = System.currentTimeMillis()
        if (now - last < minGapMs) return
        p.edit().putLong("ask_$key", now).apply()
        bakeSoon(ctx, 2000)
    }

    fun refreshWeatherNow(ctx: Context) {
        ctx.getSharedPreferences("launchy_time", Context.MODE_PRIVATE).edit().putBoolean("forceWx", true).apply()
        bakeSoon(ctx, 300, true)
    }

    /** (Re)schedules the midnight alarm and the weather job according to the placed widgets. */
    fun scheduleAll(ctx: Context) {
        try {
            val types = Widgets.timeTypesPlaced(ctx)
            if (types.isNotEmpty()) scheduleMidnight(ctx)
            val iv = Widgets.weatherInterval(ctx)
            val sched = js(ctx)
            if (iv <= 0) { sched.cancel(JOB_WEATHER); return }
            val period = maxOf(15, iv) * 60_000L
            val cur = sched.getPendingJob(JOB_WEATHER)
            if (cur != null && cur.intervalMillis == period) return
            sched.schedule(JobInfo.Builder(JOB_WEATHER, ComponentName(ctx, BakeJobService::class.java))
                .setPeriodic(period)
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setPersisted(true)
                .setExtras(android.os.PersistableBundle().apply { putInt("weather", 1) })
                .build())
        } catch (e: Exception) { Log.w(TAG, "scheduleAll", e) }
    }

    private fun scheduleMidnight(ctx: Context) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val c = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 20); set(Calendar.MILLISECOND, 0) }
        val pi = PendingIntent.getBroadcast(ctx, 77, Intent(ctx, TimeReceiver::class.java).setAction(ACTION_MIDNIGHT), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, c.timeInMillis, pi)
    }

    fun today(): String { val c = Calendar.getInstance(); return String.format(Locale.US, "%04d-%02d-%02d", c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH)) }
}

/** Midnight, boot, clock and time-zone changes → re-draw the dates. */
class TimeReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        TimeJobs.scheduleAll(ctx)
        if (intent.action != "com.launchy.luxe.MIDNIGHT") try { AlarmScheduler.scheduleAll(ctx) } catch (_: Exception) { }
        if (Widgets.timeTypesPlaced(ctx).isNotEmpty() || intent.action == Intent.ACTION_MY_PACKAGE_REPLACED) TimeJobs.bakeSoon(ctx, 500)
    }
}

/** Runs the hidden renderer for the jobs above. */
class BakeJobService : JobService() {
    override fun onStartJob(params: JobParameters): Boolean {
        val weather = params.extras?.getInt("weather", 0) == 1
        Baker.run(applicationContext, weather) { jobFinished(params, false) }
        return true
    }
    override fun onStopJob(params: JobParameters): Boolean { Baker.cancel(); return true }
}

/** Plain HTTPS GET used by the studio (weather data) — no CORS limits, works in the background. */
object Net {
    fun get(url: String, max: Int = 2_000_000): Pair<Int, String> {
        var conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 10_000; conn.readTimeout = 15_000; conn.instanceFollowRedirects = true
        conn.setRequestProperty("User-Agent", "LaunchyLuxe/3.0 (Android)")
        conn.setRequestProperty("Accept", "application/json")
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val body = stream?.use { ins -> val out = ByteArrayOutputStream(); val buf = ByteArray(16384); var tot = 0
            while (true) { val n = ins.read(buf); if (n < 0) break; tot += n; if (tot > max) break; out.write(buf, 0, n) }; out.toString("UTF-8") } ?: ""
        conn.disconnect()
        return code to body
    }

    /** Runs the request on a worker thread and answers the page with LaunchyStudio.onNative('http', …). */
    fun getAsync(id: String, url: String, reply: (String) -> Unit) = Thread {
        val res = JSONObject().put("id", id)
        try {
            if (!url.startsWith("https://")) throw IllegalArgumentException("https only")
            val (code, body) = get(url)
            res.put("ok", code in 200..299).put("status", code).put("body", body)
        } catch (e: Exception) { res.put("ok", false).put("status", 0).put("body", "") }
        reply(res.toString())
    }.start()
}

/** Last known device position (coarse) — asked only after the user allows location. */
object Loc {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("launchy_time", Context.MODE_PRIVATE)
    fun saved(ctx: Context): String = prefs(ctx).getString("myloc", "") ?: ""
    fun granted(ctx: Context) = ctx.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    fun lastKnown(ctx: Context): Location? {
        if (!granted(ctx)) return null
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        var best: Location? = null
        for (p in listOf(LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER, LocationManager.GPS_PROVIDER)) {
            val l = try { lm.getLastKnownLocation(p) } catch (_: Exception) { null } ?: continue
            if (best == null || l.time > best.time) best = l
        }
        return best
    }

    /** Fresh-enough position → JSON {ok, lat, lon, name}; asks the network provider once if needed. */
    @SuppressLint("MissingPermission")
    fun fetch(ctx: Context, done: (String) -> Unit) {
        if (!granted(ctx)) { done(JSONObject().put("ok", false).put("denied", true).toString()); return }
        val finish = { l: Location? ->
            Thread {
                val o = JSONObject()
                if (l == null) o.put("ok", false) else {
                    o.put("ok", true).put("lat", l.latitude).put("lon", l.longitude).put("at", System.currentTimeMillis())
                    var name = ""
                    try {
                        @Suppress("DEPRECATION")
                        val a = Geocoder(ctx, Locale("ar")).getFromLocation(l.latitude, l.longitude, 1)
                        if (!a.isNullOrEmpty()) name = a[0].locality ?: a[0].subAdminArea ?: a[0].adminArea ?: ""
                    } catch (_: Exception) { }
                    o.put("name", name)
                    prefs(ctx).edit().putString("myloc", o.toString()).apply()
                }
                done(o.toString())
            }.start()
        }
        val last = lastKnown(ctx)
        if (last != null && System.currentTimeMillis() - last.time < 30 * 60_000L) { finish(last); return }
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val provider = if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) LocationManager.NETWORK_PROVIDER else LocationManager.GPS_PROVIDER
        var answered = false
        val h = Handler(Looper.getMainLooper())
        val listener = object : android.location.LocationListener {
            override fun onLocationChanged(l: Location) { if (!answered) { answered = true; lm.removeUpdates(this); finish(l) } }
            @Deprecated("Deprecated in Java") override fun onStatusChanged(p: String?, s: Int, b: android.os.Bundle?) {}
            override fun onProviderEnabled(p: String) {}
            override fun onProviderDisabled(p: String) {}
        }
        try { lm.requestLocationUpdates(provider, 0L, 0f, listener, Looper.getMainLooper()) } catch (_: Exception) { finish(last); return }
        h.postDelayed({ if (!answered) { answered = true; lm.removeUpdates(listener); finish(last) } }, 15_000)
    }

    /** Quietly refresh the saved position while the app is open (never asks for permission). */
    fun refreshQuietly(ctx: Context) { if (granted(ctx)) lastKnown(ctx)?.let { l ->
        val old = try { JSONObject(saved(ctx)) } catch (_: Exception) { JSONObject() }
        if (old.optDouble("lat", 999.0) == l.latitude && old.optDouble("lon", 999.0) == l.longitude) return
        fetch(ctx) { } } }
}

/**
 * Hidden instance of the studio that re-draws the widgets (dates, weather, new sizes)
 * while the app is closed. It loads the same index.html with ?baker=1.
 */
@SuppressLint("SetJavaScriptEnabled")
object Baker {
    private const val TAG = "LaunchyBaker"
    private var web: WebView? = null
    private var onDone: (() -> Unit)? = null
    private var again = false
    private val main = Handler(Looper.getMainLooper())
    private val timeout = Runnable { Log.w(TAG, "timeout"); finish() }

    fun run(ctx: Context, weather: Boolean, done: () -> Unit) = main.post {
        if (web != null) { again = true; val prev = onDone; onDone = { prev?.invoke(); done() }; return@post }
        onDone = done
        val prefs = ctx.getSharedPreferences("launchy_time", Context.MODE_PRIVATE)
        val force = prefs.getBoolean("forceWx", false)
        if (force) prefs.edit().putBoolean("forceWx", false).apply()
        try {
            val w = WebView(ctx)
            web = w
            with(w.settings) { javaScriptEnabled = true; domStorageEnabled = true; allowFileAccess = true; textZoom = 100 }
            w.addJavascriptInterface(Bridge(ctx, weather, force), "LaunchyNative")
            w.webViewClient = object : WebViewClient() {}
            w.loadUrl("file:///android_asset/web/index.html?baker=1#/bake")
            main.postDelayed(timeout, 90_000)
        } catch (e: Exception) { Log.e(TAG, "start", e); finish() }
    }

    fun cancel() = main.post { finish() }

    private fun finish() {
        main.removeCallbacks(timeout)
        try { web?.destroy() } catch (_: Exception) { }
        web = null
        val cb = onDone; onDone = null
        cb?.invoke()
    }

    private fun reply(kind: String, json: String) = main.post {
        web?.evaluateJavascript("window.LaunchyStudio&&LaunchyStudio.onNative(${JSONObject.quote(kind)},${JSONObject.quote(json)})", null)
    }

    /** The subset of the app bridge the renderer needs in the background. */
    class Bridge(private val ctx: Context, private val weather: Boolean, private val force: Boolean) {
        @JavascriptInterface fun isBaker(): Boolean = true
        @JavascriptInterface fun bakerMode(): String = JSONObject().put("weather", weather).put("force", force).toString()
        @JavascriptInterface fun info(): String = WidgetInfo.json(ctx)
        @JavascriptInterface fun syncDesigns(json: String) { }
        @JavascriptInterface fun setCountryCode(cc: String) { }
        @JavascriptInterface fun saveBake(designId: String, w: Int, h: Int, hash: String, json: String) { try { Store.saveBake(ctx, designId, w, h, hash, json) } catch (_: Exception) { } }
        @JavascriptInterface fun bakeKeys(): String = try { Store.bakeKeys(ctx).toString() } catch (e: Exception) { "{}" }
        @JavascriptInterface fun widgetSlots(): String = try { Widgets.slots(ctx).toString() } catch (e: Exception) { "[]" }
        @JavascriptInterface fun bakesDone() { main.post { try { Widgets.updateAll(ctx) } catch (_: Exception) { } } }
        @JavascriptInterface fun httpGet(id: String, url: String) { Net.getAsync(id, url) { reply("http", it) } }
        @JavascriptInterface fun lastLocation(): String = Loc.saved(ctx)
        @JavascriptInterface fun nextAlarm(): String = AlarmBridge.nextAlarmJson(ctx)
        @JavascriptInterface fun alarmsGet(): String = AlarmStore.list(ctx).toString()
        @JavascriptInterface fun bakerDone() { main.post { try { Widgets.updateAll(ctx) } catch (_: Exception) { }; if (again) { again = false; web?.reload() } else finish() } }
    }
}

/** Device facts shared with the studio page. */
object WidgetInfo {
    fun json(ctx: Context): String = JSONObject()
        .put("native", true)
        .put("version", "3.2")
        .put("density", ctx.resources.displayMetrics.density.toDouble())
        .put("is24", android.text.format.DateFormat.is24HourFormat(ctx))
        .put("locale", Locale.getDefault().toLanguageTag())
        .put("sdk", android.os.Build.VERSION.SDK_INT)
        .toString()
}
