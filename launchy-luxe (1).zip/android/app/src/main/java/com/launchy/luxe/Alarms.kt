package com.launchy.luxe

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import kotlin.math.PI
import kotlin.math.min
import kotlin.math.sin

/*
 * This app's own alarms.
 *  - Scheduled with AlarmManager.setAlarmClock (exact, shown by the system as the next alarm).
 *  - Ring through a foreground service: alarm sound + vibration + full-screen alarm screen
 *    with a natively animated pendulum.
 *  - While ringing, every clock widget switches to its baked "ringing" look and faster pendulum loop.
 * Alarms of other apps: Android only exposes the time of the next alarm (getNextAlarmClock),
 * never whether one is ringing — so we never claim to detect that.
 */

private const val TAG = "LaunchyAlarm"

object AlarmStore {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("llx_alarms", Context.MODE_PRIVATE)

    fun list(ctx: Context): JSONArray = try { JSONArray(prefs(ctx).getString("list", "[]")) } catch (_: Exception) { JSONArray() }

    fun save(ctx: Context, json: String) {
        val arr = JSONArray(json)  // validate first
        prefs(ctx).edit().putString("list", arr.toString()).apply()
        AlarmScheduler.scheduleAll(ctx)
    }

    fun find(ctx: Context, id: String?): JSONObject? {
        if (id == null) return null
        val l = list(ctx)
        for (i in 0 until l.length()) { val a = l.optJSONObject(i) ?: continue; if (a.optString("id") == id) return a }
        return null
    }

    fun update(ctx: Context, id: String, fn: (JSONObject) -> Unit) {
        val l = list(ctx)
        for (i in 0 until l.length()) { val a = l.optJSONObject(i) ?: continue; if (a.optString("id") == id) fn(a) }
        prefs(ctx).edit().putString("list", l.toString()).apply()
    }

    fun ringingId(ctx: Context): String? = prefs(ctx).getString("ringing", null)?.takeIf { it.isNotEmpty() }
    fun isRinging(ctx: Context): Boolean = ringingId(ctx) != null

    /** Ringing on/off: store it, redraw the clock widgets, tell the open studio. */
    fun setRinging(ctx: Context, id: String?) {
        prefs(ctx).edit().putString("ringing", id ?: "").apply()
        try {
            val m = android.appwidget.AppWidgetManager.getInstance(ctx)
            for (wid in Widgets.allIds(ctx)) {
                val d = Store.designFor(ctx, wid)?.let { Store.design(ctx, it) } ?: continue
                if (d.type == "clock") WidgetRenderer.update(ctx, m, wid)
            }
        } catch (e: Exception) { Log.w(TAG, "widgets", e) }
        MainActivity.notify("alarm", JSONObject().put("ringing", id != null).put("id", id ?: "").toString())
    }
}

object AlarmScheduler {
    const val ACTION_RING = "com.launchy.luxe.ALARM_RING"

    /** Next fire time (ms) of an alarm after `from`, or 0. days: 0 = Sunday … 6 = Saturday; empty = once. */
    fun nextTrigger(a: JSONObject, from: Long = System.currentTimeMillis()): Long {
        if (!a.optBoolean("on", true)) return 0
        val days = HashSet<Int>()
        a.optJSONArray("days")?.let { for (i in 0 until it.length()) days.add(it.optInt(i)) }
        val snooze = a.optLong("snoozeAt", 0)
        for (i in 0..7) {
            val c = Calendar.getInstance().apply {
                timeInMillis = from; add(Calendar.DAY_OF_YEAR, i)
                set(Calendar.HOUR_OF_DAY, a.optInt("h")); set(Calendar.MINUTE, a.optInt("m")); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            val t = c.timeInMillis
            if (t <= from) continue
            if (snooze in (from + 1) until t) return snooze
            if (days.isEmpty() || days.contains(c.get(Calendar.DAY_OF_WEEK) - 1)) return t
        }
        return if (snooze > from) snooze else 0
    }

    private fun ringIntent(ctx: Context, id: String, flags: Int): PendingIntent? =
        PendingIntent.getBroadcast(ctx, 7000 + (id.hashCode() and 0xffff), Intent(ctx, AlarmReceiver::class.java).setAction(ACTION_RING).putExtra("id", id), flags or PendingIntent.FLAG_IMMUTABLE)

    fun canExact(ctx: Context): Boolean {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        return Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
    }

    /** Cancel what was scheduled before and schedule every enabled alarm again. */
    fun scheduleAll(ctx: Context) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val p = ctx.getSharedPreferences("llx_alarms", Context.MODE_PRIVATE)
        for (old in (p.getString("scheduled", "") ?: "").split(',').filter { it.isNotBlank() }) ringIntent(ctx, old, PendingIntent.FLAG_NO_CREATE)?.let { am.cancel(it) }
        val done = ArrayList<String>()
        val l = AlarmStore.list(ctx)
        for (i in 0 until l.length()) {
            val a = l.optJSONObject(i) ?: continue
            val id = a.optString("id"); val t = nextTrigger(a)
            if (id.isEmpty() || t == 0L) continue
            val pi = ringIntent(ctx, id, PendingIntent.FLAG_UPDATE_CURRENT) ?: continue
            val show = PendingIntent.getActivity(ctx, 6999, Intent(ctx, MainActivity::class.java).putExtra("route", "alarms").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            try {
                if (canExact(ctx)) am.setAlarmClock(AlarmManager.AlarmClockInfo(t, show), pi)
                else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi)  // without the exact-alarm permission: may be a few minutes late
                done.add(id)
            } catch (e: Exception) { Log.w(TAG, "schedule", e) }
        }
        p.edit().putString("scheduled", done.joinToString(",")).apply()
    }

    fun ownNext(ctx: Context): Long {
        var best = 0L; val l = AlarmStore.list(ctx)
        for (i in 0 until l.length()) { val t = nextTrigger(l.optJSONObject(i) ?: continue); if (t > 0 && (best == 0L || t < best)) best = t }
        return best
    }
}

/** Next alarm on the device and alarm-related permissions, for the studio and the widgets. */
object AlarmBridge {
    fun nextAlarmAt(ctx: Context): Long = try { (ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager).nextAlarmClock?.triggerTime ?: 0L } catch (_: Exception) { 0L }

    fun nextAlarmJson(ctx: Context): String = try {
        val info = (ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager).nextAlarmClock
        val own = AlarmScheduler.ownNext(ctx)
        val at = info?.triggerTime ?: own
        if (at <= 0L) "null" else JSONObject().put("at", at).put("own", own > 0 && kotlin.math.abs(own - at) < 61_000)
            .put("pkg", info?.showIntent?.creatorPackage ?: "").toString()
    } catch (_: Exception) { "null" }

    fun perms(ctx: Context): JSONObject {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        return JSONObject()
            .put("exact", AlarmScheduler.canExact(ctx))
            .put("notif", Build.VERSION.SDK_INT < 33 || ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED)
            .put("fullScreen", Build.VERSION.SDK_INT < 34 || nm.canUseFullScreenIntent())
            .put("battery", pm.isIgnoringBatteryOptimizations(ctx.packageName))
    }

    fun request(a: Activity, kind: String) {
        val pkg = Uri.parse("package:" + a.packageName)
        try {
            when (kind) {
                "exact" -> if (Build.VERSION.SDK_INT >= 31) a.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, pkg))
                "notif" -> if (Build.VERSION.SDK_INT >= 33) a.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 21)
                "fullScreen" -> if (Build.VERSION.SDK_INT >= 34) a.startActivity(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, pkg))
                "battery" -> a.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        } catch (_: Exception) {
            try { a.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg)) } catch (_: Exception) { }
        }
    }
}

/** Alarm fired / notification buttons. */
class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        when (intent.action) {
            AlarmScheduler.ACTION_RING -> try { AlarmService.start(ctx, intent.getStringExtra("id") ?: "") } catch (e: Exception) {
                // e.g. a background start was refused: never crash, try again shortly as an exact alarm
                Log.e(TAG, "ring", e); AlarmScheduler.scheduleAll(ctx)
            }
            AlarmService.ACTION_STOP -> AlarmService.stop(ctx, false)
            AlarmService.ACTION_SNOOZE -> AlarmService.stop(ctx, true)
        }
    }
}

/** The device's next alarm changed (any app): re-draw clocks that show it. */
class NextAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        try {
            val uses = Store.designs(ctx).any { d -> d.type == "clock" && d.opts("clock").let { it.optBoolean("nextAlarm") || it.optBoolean("countdown") || it.optString("face") == "pill" } }
            if (uses) { TimeJobs.bakeSoon(ctx, 2000); Widgets.updateAll(ctx) }
        } catch (_: Exception) { }
    }
}

/** Foreground service that rings: sound (alarm stream), vibration, full-screen alarm screen, auto-stop. */
class AlarmService : Service() {
    companion object {
        const val ACTION_START = "com.launchy.luxe.ALARM_START"
        const val ACTION_STOP = "com.launchy.luxe.ALARM_STOP"
        const val ACTION_SNOOZE = "com.launchy.luxe.ALARM_SNOOZE"
        private const val CHANNEL = "llx_alarm"
        private const val NOTE_ID = 4300
        private const val TIMEOUT = 10 * 60_000L

        fun start(ctx: Context, id: String) {
            val i = Intent(ctx, AlarmService::class.java).setAction(ACTION_START).putExtra("id", id)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        }
        fun stop(ctx: Context, snooze: Boolean) {
            if (!AlarmStore.isRinging(ctx)) return
            ctx.startService(Intent(ctx, AlarmService::class.java).setAction(if (snooze) ACTION_SNOOZE else ACTION_STOP))
        }
    }

    private var player: MediaPlayer? = null
    private var wake: PowerManager.WakeLock? = null
    private val main = Handler(Looper.getMainLooper())
    private val timeout = Runnable { finishRing(false) }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startRing(intent.getStringExtra("id") ?: "test")
            ACTION_STOP -> finishRing(false)
            ACTION_SNOOZE -> finishRing(true)
            else -> stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun pi(action: String, code: Int) = PendingIntent.getBroadcast(this, code, Intent(this, AlarmReceiver::class.java).setAction(action), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    private fun startRing(id: String) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel(CHANNEL, "المنبهات", NotificationManager.IMPORTANCE_HIGH).apply {
            setSound(null, null); enableVibration(false); lockscreenVisibility = Notification.VISIBILITY_PUBLIC })
        val a = AlarmStore.find(this, id)
        val label = a?.optString("label")?.takeIf { it.isNotBlank() } ?: if (id == "test") "تجربة المنبه" else "المنبه"
        val full = PendingIntent.getActivity(this, 4301, Intent(this, AlarmActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_USER_ACTION), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val note = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(label)
            .setContentText("اضغط لفتح شاشة المنبه")
            .setCategory(Notification.CATEGORY_ALARM)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setContentIntent(full)
            .setFullScreenIntent(full, true)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "إيقاف", pi(ACTION_STOP, 4302)).build())
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_lock_idle_alarm), "غفوة", pi(ACTION_SNOOZE, 4303)).build())
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTE_ID, note, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK) else startForeground(NOTE_ID, note)
        if (AlarmStore.isRinging(this)) stopSound()
        wake = (getSystemService(Context.POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "launchy:alarm").apply { acquire(TIMEOUT + 30_000) }
        try {
            val uri = RingtoneManager.getActualDefaultRingtoneUri(this, RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM) ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            player = MediaPlayer().apply {
                setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                setDataSource(this@AlarmService, uri); isLooping = true; prepare(); start()
            }
        } catch (e: Exception) { Log.w(TAG, "sound", e) }
        if (a == null || a.optBoolean("vibrate", true)) try {
            (getSystemService(Context.VIBRATOR_SERVICE) as Vibrator).vibrate(VibrationEffect.createWaveform(longArrayOf(0, 700, 500), 0),
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build())
        } catch (_: Exception) { }
        AlarmStore.setRinging(this, id)
        main.removeCallbacks(timeout); main.postDelayed(timeout, TIMEOUT)
    }

    private fun stopSound() {
        try { player?.stop(); player?.release() } catch (_: Exception) { }
        player = null
        try { (getSystemService(Context.VIBRATOR_SERVICE) as Vibrator).cancel() } catch (_: Exception) { }
    }

    private fun finishRing(snooze: Boolean) {
        val id = AlarmStore.ringingId(this)
        stopSound()
        main.removeCallbacks(timeout)
        if (id != null && id != "test") {
            AlarmStore.update(this, id) { a ->
                if (snooze) a.put("snoozeAt", System.currentTimeMillis() + a.optInt("snooze", 10) * 60_000L)
                else { a.remove("snoozeAt"); if ((a.optJSONArray("days")?.length() ?: 0) == 0) a.put("on", false) }
            }
        }
        AlarmScheduler.scheduleAll(this)
        AlarmStore.setRinging(this, null)
        try { wake?.release() } catch (_: Exception) { }
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else @Suppress("DEPRECATION") stopForeground(true)
        stopSelf()
    }

    override fun onDestroy() { stopSound(); main.removeCallbacks(timeout); super.onDestroy() }
}

/** Full-screen alarm screen (over the lock screen) with a smoothly animated pendulum. */
class AlarmActivity : Activity() {
    private lateinit var pv: PendulumView
    private val main = Handler(Looper.getMainLooper())
    private var closing = false
    private val watch = object : Runnable {
        override fun run() {
            if (!closing && !AlarmStore.isRinging(this@AlarmActivity)) close()
            else if (!closing) main.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true) }
        else @Suppress("DEPRECATION") window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = Color.BLACK; window.navigationBarColor = Color.BLACK
        val id = AlarmStore.ringingId(this)
        val a = AlarmStore.find(this, id)
        val den = resources.displayMetrics.density
        pv = PendulumView(this, try { Store.pendulumBake(this, a?.optString("design")) } catch (_: Exception) { null })
        val clock = TextClock(this).apply {
            format12Hour = "h:mm"; format24Hour = "HH:mm"; textSize = 64f; setTextColor(0xFFF6EAD2.toInt()); gravity = Gravity.CENTER
            textDirection = View.TEXT_DIRECTION_LTR
        }
        val label = TextView(this).apply {
            text = a?.optString("label")?.takeIf { it.isNotBlank() } ?: if (id == "test") "تجربة المنبه" else "المنبه"
            textSize = 20f; setTextColor(0xFFE8D7B0.toInt()); gravity = Gravity.CENTER
        }
        fun btn(t: String, gold: Boolean, fn: () -> Unit) = Button(this).apply {
            text = t; textSize = 18f; isAllCaps = false
            setTextColor(if (gold) 0xFF1A1205.toInt() else 0xFFF6EAD2.toInt())
            background = android.graphics.drawable.GradientDrawable().apply {
                cornerRadius = 28 * den
                if (gold) colors = intArrayOf(0xFFF3D27A.toInt(), 0xFFB8862E.toInt()) else { setColor(0x22FFFFFF); setStroke((1 * den).toInt(), 0x66FFFFFF) }
            }
            setPadding((28 * den).toInt(), (12 * den).toInt(), (28 * den).toInt(), (12 * den).toInt())
            setOnClickListener { fn() }
        }
        val snooze = a?.optInt("snooze", 10) ?: 10
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            addView(btn("غفوة $snooze د", false) { AlarmService.stop(this@AlarmActivity, true); close() }, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = (14 * den).toInt() })
            addView(btn("إيقاف", true) { AlarmService.stop(this@AlarmActivity, false); close() })
        }
        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, 0, 0, (36 * den).toInt())
            addView(clock); addView(label); addView(row, LinearLayout.LayoutParams(-2, -2).apply { topMargin = (22 * den).toInt() })
        }
        val root = FrameLayout(this)
        root.addView(pv, FrameLayout.LayoutParams(-1, -1))
        root.addView(bottom, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        setContentView(root)
        main.postDelayed(watch, 800)
    }

    /** Stop: the pendulum settles back to rest, then the screen closes. */
    private fun close() {
        if (closing) return
        closing = true
        pv.settle { finish() }
    }

    override fun onBackPressed() { /* the alarm is stopped with the buttons */ }
    override fun onDestroy() { main.removeCallbacks(watch); super.onDestroy() }
}

/**
 * Draws the user's baked clock (its ringing variant when available) and animates the pendulum
 * inside its window natively at the display's frame rate. Falls back to a drawn brown & gold case.
 */
class PendulumView(ctx: Context, private val bake: Pair<Store.Bake, JSONObject>?) : View(ctx) {
    private val den = resources.displayMetrics.density
    private val bmp: Bitmap? = bake?.let { (b, _) -> (b.alertFile ?: b.imgFile).let { Store.decodeFile(it, 1600) } }
    private val geo: JSONObject? = bake?.second?.optJSONObject("geo")
    private val rod = parse(geo?.optString("rod"), 0xFFD4AF37.toInt())
    private val inner = parse(geo?.optString("inner"), 0xFF120A05.toInt())
    private val light = parse(geo?.optString("light"), 0xFFFFD98A.toInt())
    private val swingDeg = (geo?.optDouble("swing", 10.0) ?: 10.0).coerceIn(2.0, 24.0)
    private val speed = (geo?.optDouble("speed", 100.0) ?: 100.0).coerceIn(40.0, 250.0)
    private val motion = geo?.optString("motion") ?: "pendulum"
    private val t0 = System.nanoTime()
    private var last = t0
    private var phase = 0.0
    private var settleAt = 0L
    private var onSettled: (() -> Unit)? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    private fun parse(c: String?, def: Int): Int = try { if (c.isNullOrEmpty()) def else Color.parseColor(c) } catch (_: Exception) { def }

    fun settle(done: () -> Unit) { if (settleAt == 0L) { settleAt = System.nanoTime(); onSettled = done } }

    /** 0…1 ringing intensity: ramps up, and fades out gently after stop. */
    private fun level(now: Long): Double {
        val up = min(1.0, (now - t0) / 450e6)
        if (settleAt == 0L) return up
        val k = 1.0 - (now - settleAt) / 2600e6
        return if (k <= 0) 0.0 else up * k * k
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val now = System.nanoTime()
        val lv = level(now)
        val boost = if (motion == "fastAlarm") 1.0 else 0.75
        val period = 2000.0 * (if (motion == "slowLux") 1.55 else 1.0) * 100.0 / speed * (1 - 0.42 * boost * lv)
        val rest = if (settleAt == 0L) 1.0 else (1.0 - (now - settleAt) / 2600e6).coerceAtLeast(0.0).let { it * it }  // gradual return to rest
        val amp = swingDeg * (1 + 0.55 * boost * lv) * rest
        phase += min(100.0, (now - last) / 1e6) * 2 * PI / period; last = now
        val ang = amp * sin(phase)  // degrees

        val W = width.toFloat(); val H = height.toFloat()
        p.shader = RadialGradient(W / 2, H * .32f, maxOf(W, H) * .8f, intArrayOf(0xFF2A1D0E.toInt(), 0xFF07060A.toInt()), null, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, W, H, p); p.shader = null

        // fit the clock in the upper area
        val areaH = H * .62f
        val bw = bake?.first?.w ?: 160f; val bh = bake?.first?.h ?: 300f
        val s = min(W * .78f / bw, areaH * .9f / bh)
        val ox = (W - bw * s) / 2; val oy = (areaH - bh * s) / 2 + 24 * den
        val shake = if (lv > 0 && ((now - t0) / 1_000_000L) % 2400 < 900) (sin((now - t0) / 22e6) * 1.2 * den * lv).toFloat() else 0f
        c.save(); c.translate(shake, 0f)
        // golden halo behind the clock while ringing
        if (lv > 0.01) {
            val pulse = 0.75 + 0.25 * sin((now - t0) / 180e6)
            val a = (150 * lv * pulse).toInt().coerceIn(0, 255)
            p.shader = RadialGradient(W / 2, oy + bh * s / 2, maxOf(bw, bh) * s * .75f, intArrayOf(Color.argb(a, Color.red(light), Color.green(light), Color.blue(light)), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, W, H, p); p.shader = null
        }
        val win: RectF
        val r: Float
        if (bmp != null && bake != null) {
            c.drawBitmap(bmp, null, RectF(ox, oy, ox + bw * s, oy + bh * s), p)
            val el = bake.second
            win = RectF(ox + el.optDouble("x").toFloat() * s, oy + el.optDouble("y").toFloat() * s, ox + (el.optDouble("x") + el.optDouble("w")).toFloat() * s, oy + (el.optDouble("y") + el.optDouble("h")).toFloat() * s)
            r = (geo?.optDouble("r", 12.0) ?: 12.0).toFloat() * s
        } else {
            // fallback: brown wooden case with a gold rim
            val case = RectF(ox, oy, ox + bw * s, oy + bh * s)
            p.shader = LinearGradient(case.left, case.top, case.right, case.bottom, 0xFF5A3A1E.toInt(), 0xFF2A170A.toInt(), Shader.TileMode.CLAMP)
            c.drawRoundRect(case, 30 * s, 30 * s, p); p.shader = null
            win = RectF(case.left + case.width() * .14f, case.top + case.height() * .36f, case.right - case.width() * .14f, case.bottom - case.height() * .06f)
            r = win.width() * .2f
            p.color = rod; p.style = Paint.Style.STROKE; p.strokeWidth = 5 * s
            c.drawRoundRect(RectF(win.left - 3 * s, win.top - 3 * s, win.right + 3 * s, win.bottom + 3 * s), r, r, p); p.style = Paint.Style.FILL
        }
        drawWindow(c, win, r, s, ang.toFloat(), lv.toFloat())
        c.restore()

        if (settleAt != 0L && rest <= 0.0) { val cb = onSettled; onSettled = null; cb?.invoke(); return }
        postInvalidateOnAnimation()
    }

    private fun drawWindow(c: Canvas, w: RectF, r: Float, s: Float, angDeg: Float, lv: Float) {
        val clip = Path().apply { addRoundRect(w, r, r, Path.Direction.CW) }
        c.save(); c.clipPath(clip)
        p.shader = LinearGradient(0f, w.top, 0f, w.bottom, intArrayOf(darken(inner, .2f), inner, darken(inner, .45f)), null, Shader.TileMode.CLAMP)
        c.drawRect(w, p); p.shader = null
        val gpx = (geo?.optDouble("px", w.width() / s / 2.0) ?: (w.width() / s / 2.0)).toFloat() * s
        val gpy = (geo?.optDouble("py", 10.0) ?: 10.0).toFloat() * s
        val len = (geo?.optDouble("len", w.height() / s * .7) ?: (w.height() / s * .7)).toFloat() * s
        val bob = (geo?.optDouble("bob", w.width() / s * .18) ?: (w.width() / s * .18)).toFloat() * s
        val px = w.left + gpx; val py = w.top + gpy; val rw = maxOf(1.5f * den, w.width() * .03f)
        // soft spot behind the pivot
        p.shader = RadialGradient(w.centerX(), w.top + w.height() * .2f, w.height() * .8f, intArrayOf(Color.argb((60 + 80 * lv).toInt(), Color.red(rod), Color.green(rod), Color.blue(rod)), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
        c.drawRect(w, p); p.shader = null
        c.save(); c.rotate(angDeg, px, py)
        p.shader = LinearGradient(px - rw, 0f, px + rw, 0f, intArrayOf(lighten(rod, .5f), rod, darken(rod, .45f)), null, Shader.TileMode.CLAMP)
        c.drawRect(px - rw / 2, py, px + rw / 2, py + len - bob * .9f, p)
        val dm = Path().apply { val y = py + len * .42f; moveTo(px, y - rw * 3); lineTo(px + rw * 1.8f, y); lineTo(px, y + rw * 3); lineTo(px - rw * 1.8f, y); close() }
        c.drawPath(dm, p); p.shader = null
        if (lv > 0.01) {
            p.shader = RadialGradient(px, py + len, bob * (2.2f + lv), intArrayOf(Color.argb((170 * lv).toInt(), Color.red(light), Color.green(light), Color.blue(light)), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
            c.drawCircle(px, py + len, bob * (2.2f + lv), p); p.shader = null
        }
        p.shader = RadialGradient(px - bob * .35f, py + len - bob * .35f, bob * 1.1f, intArrayOf(lighten(rod, .75f), rod, darken(rod, .55f)), floatArrayOf(0f, .45f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(px, py + len, bob, p); p.shader = null
        p.style = Paint.Style.STROKE; p.strokeWidth = maxOf(1f, bob * .05f); p.color = lighten(rod, .4f)
        c.drawCircle(px, py + len, bob * .62f, p); p.style = Paint.Style.FILL
        c.restore()
        p.color = darken(rod, .3f); c.drawCircle(px, py, rw * 1.6f, p)
        p.color = lighten(rod, .6f); c.drawCircle(px, py, rw * .7f, p)
        // glass reflection
        val rf = Path().apply { moveTo(w.left - w.width() * .1f, w.top + w.height() * .45f); lineTo(w.left + w.width() * .55f, w.top - w.height() * .05f); lineTo(w.left + w.width() * .75f, w.top - w.height() * .05f); lineTo(w.left - w.width() * .1f, w.top + w.height() * .62f); close() }
        p.color = 0x22FFFFFF; c.drawPath(rf, p)
        c.restore()
    }

    private fun darken(c: Int, k: Float) = Color.rgb((Color.red(c) * (1 - k)).toInt(), (Color.green(c) * (1 - k)).toInt(), (Color.blue(c) * (1 - k)).toInt())
    private fun lighten(c: Int, k: Float) = Color.rgb((Color.red(c) + (255 - Color.red(c)) * k).toInt(), (Color.green(c) + (255 - Color.green(c)) * k).toInt(), (Color.blue(c) + (255 - Color.blue(c)) * k).toInt())
}
