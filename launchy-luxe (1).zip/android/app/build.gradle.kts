plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.launchy.luxe"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.launchy.luxe"
        minSdk = 26
        targetSdk = 34
        versionCode = 9
        versionName = "3.2.2"
    }

    // Fixed key so every new APK installs as an update (your designs are kept).
    signingConfigs {
        create("launchy") {
            storeFile = file("../launchy.keystore")
            storePassword = "launchy-luxe"
            keyAlias = "launchy"
            keyPassword = "launchy-luxe"
        }
    }

    buildTypes {
        getByName("release") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("launchy")
        }
        getByName("debug") {
            signingConfig = signingConfigs.getByName("launchy")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}
