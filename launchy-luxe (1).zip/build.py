#!/usr/bin/env python3
"""Inject src/*.js into index.html between the @@ENGINE markers."""
import pathlib
root = pathlib.Path(__file__).parent
html = (root / 'index.html').read_text(encoding='utf-8')
parts = ['styles.js', 'glyphs.js', 'engine.js', 'fonts.js', 'timecore.js', 'weather.js', 'scenedata', 'scenes.js', 'clocks.js', 'timewidgets.js','clockfx.js', 'render.js', 'widget.js', 'ui.js', 'timepresets.js', 'timeui.js','alarmui.js','innerapps.js']
import base64
scene_data = 'const SCENE_DATA = {\n' + ',\n'.join(f"  {f.stem}: 'data:image/webp;base64,{base64.b64encode(f.read_bytes()).decode()}'" for f in sorted((root / 'src' / 'scenes').glob('*.webp'))) + '\n};'
code = '\n'.join((root / 'src' / p).read_text(encoding='utf-8') if p != 'scenedata' else scene_data for p in parts)
start, end = '/* @@ENGINE START */', '/* @@ENGINE END */'
i, j = html.index(start) + len(start), html.index(end)
html = html[:i] + '\n' + code + '\n' + html[j:]
(root / 'index.html').write_text(html, encoding='utf-8')
print('injected', len(code), 'chars')
