/* =========================================================
   Alarms & the interactive clock library.
   • This app's own alarms: on Android they are scheduled with
     AlarmManager.setAlarmClock and ring through a foreground service
     with a full-screen alarm screen (animated pendulum). Their ringing
     state drives the "ringing" look of the clock widgets.
   • Other alarm apps: Android only tells us the time of the next
     alarm (getNextAlarmClock) — never whether it is ringing.
   • In a browser, alarms ring only while this page stays open.
   ========================================================= */
const AL_DAYS = [['ح', 'الأحد'], ['ن', 'الاثنين'], ['ث', 'الثلاثاء'], ['ر', 'الأربعاء'], ['خ', 'الخميس'], ['ج', 'الجمعة'], ['س', 'السبت']];
const hasNativeAlarms = () => NATIVE && typeof window.LaunchyNative.alarmsGet === 'function';
function alarmsLoad() {
  if (hasNativeAlarms()) { try { const l = JSON.parse(window.LaunchyNative.alarmsGet() || '[]'); if (Array.isArray(l)) return l; } catch (e) {} }
  return store.get('llx.alarms', []) || [];
}
function alarmsSave(list) {
  store.set('llx.alarms', list);
  if (hasNativeAlarms()) { try { window.LaunchyNative.alarmsSet(JSON.stringify(list)); } catch (e) { toast('تعذّر حفظ المنبه في النظام'); } }
  refreshNextAlarm();
  if (NATIVE) bakeAll();
  for (const w of $$('.wcv')) if (w._redraw) w._redraw();
}
/** Next time an alarm fires after `from` (Date) or null. days: 0=Sunday … 6=Saturday; empty = once. */
function nextTrigger(a, from = new Date()) {
  if (!a || a.on === false) return null;
  const days = Array.isArray(a.days) ? a.days : [];
  for (let i = 0; i < 8; i++) {
    const t = new Date(from.getFullYear(), from.getMonth(), from.getDate() + i, a.h, a.m, 0, 0);
    if (t <= from) continue;
    if (a.snoozeAt && a.snoozeAt > from.getTime() && a.snoozeAt < t.getTime()) return new Date(a.snoozeAt);
    if (!days.length || days.includes(t.getDay())) return t;
  }
  return null;
}
function nextOwnAlarm() {
  let best = null;
  for (const a of alarmsLoad()) { const t = nextTrigger(a); if (t && (!best || t < best.t)) best = { t, a }; }
  return best ? { at: best.t.getTime(), label: best.a.label || '', own: true } : null;
}
const alarmTime = a => timeText({ h: a.h, m: a.m, s: 0 }, 'system', 'latn') + (is24System() ? '' : ' ' + ampmText({ h: a.h }, 'ar'));
function daysText(a) {
  const d = (a.days || []).slice().sort();
  if (!d.length) return 'مرة واحدة';
  if (d.length === 7) return 'كل يوم';
  if (d.join() === '0,1,2,3,4') return 'الأحد إلى الخميس';
  if (d.join() === '5,6') return 'الجمعة والسبت';
  return d.map(i => AL_DAYS[i][1]).join('، ');
}

/* ---------------------------------------------------------- browser ringing (page open) */
let ringing = null, audioCtx = null, fired = new Set();
function chime() {
  try {
    audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
    const t0 = audioCtx.currentTime;
    for (const [f, dt] of [[880, 0], [1175, .18], [1568, .36]]) {
      const o = audioCtx.createOscillator(), g = audioCtx.createGain();
      o.type = 'sine'; o.frequency.value = f; g.gain.setValueAtTime(0, t0 + dt); g.gain.linearRampToValueAtTime(.25, t0 + dt + .02); g.gain.exponentialRampToValueAtTime(.001, t0 + dt + .9);
      o.connect(g).connect(audioCtx.destination); o.start(t0 + dt); o.stop(t0 + dt + 1);
    }
  } catch (e) {}
}
function ringStart(a) {
  if (ringing) return;
  setClockAlert(true);
  const designs = loadDesigns().map(normalize).filter(d => d.type === 'clock');
  const d = (a.design && designs.find(x => x.id === a.design)) || designs.find(x => x.clock.face === 'pendulum') || presetDesign(CLOCK_HOME_P);
  const holder = h('div', {});
  const ov = h('div', { class: 'ring-ov', role: 'alertdialog', 'aria-label': 'المنبه يرن' },
    holder, h('h2', {}, alarmTime(a)), h('div', {}, a.label || 'المنبه'),
    h('div', { class: 'ring-acts' },
      h('button', { type: 'button', class: 'btn', onclick: () => ringStop(a, true) }, 'غفوة ' + (a.snooze || 10) + ' د'),
      h('button', { type: 'button', class: 'btn btn-gold', onclick: () => ringStop(a, false) }, 'إيقاف')));
  document.body.append(ov);
  const { W, H } = sizeOf(d); holder.append(renderWidget(d, { k: Math.min(1.6, 280 / Math.max(W, H)) * 1.2 }).el);
  const iv = setInterval(chime, 1600); chime();
  try { navigator.vibrate && navigator.vibrate([400, 200, 400]); } catch (e) {}
  ringing = { a, ov, iv, auto: setTimeout(() => ringStop(a, false), 5 * 60000) };
}
function ringStop(a, snooze) {
  if (!ringing) return;
  clearInterval(ringing.iv); clearTimeout(ringing.auto);
  setClockAlert(false); // the pendulum settles back gradually
  const ov = ringing.ov; ringing = null;
  setTimeout(() => ov.remove(), 2600); ov.style.transition = 'opacity 2.4s'; ov.style.opacity = '0'; ov.style.pointerEvents = 'none';
  if (a.id === 'test') return;
  const list = alarmsLoad(), x = list.find(q => q.id === a.id); if (!x) return;
  if (snooze) x.snoozeAt = Date.now() + (x.snooze || 10) * 60000;
  else { delete x.snoozeAt; if (!(x.days || []).length) x.on = false; }
  alarmsSave(list); if (curRoute() === 'alarms') route(false);
}
setTimeout(() => { if (!NATIVE) setInterval(() => {
  if (ringing) return;
  const now = Date.now();
  for (const a of alarmsLoad()) {
    if (a.on === false) continue;
    const t = nextTrigger(a, new Date(now - 61000));
    if (t && t.getTime() <= now && now - t.getTime() < 60000) { const key = a.id + '@' + t.getTime(); if (!fired.has(key)) { fired.add(key); ringStart(a); break; } }
  }
}, 1000); }, 0);

/* ---------------------------------------------------------- permissions (Android) */
function alarmPerms() {
  if (!NATIVE || typeof window.LaunchyNative.alarmPerms !== 'function') return null;
  try { return JSON.parse(window.LaunchyNative.alarmPerms() || '{}'); } catch (e) { return null; }
}
function permBox() {
  const p = alarmPerms();
  if (!p) return h('div', { class: 'note' }, icon('eye', 16), h('span', {}, NATIVE ? 'حدّث التطبيق لأحدث نسخة لتفعيل المنبهات.' : 'أنت في المتصفح: يرن المنبه هنا فقط ما دامت الصفحة مفتوحة. على تطبيق Android يجدوله النظام نفسه فيرن والهاتف مقفل والتطبيق مغلق.'));
  const row = (ok, name, desc, kind) => h('div', { class: 'perm-row' }, h('div', {}, h('b', {}, name), h('div', { class: 'fine' }, desc)),
    ok ? h('span', { class: 'ok' }, icon('check', 16), ' مفعّل') : h('button', { type: 'button', class: 'btn btn-sm btn-gold', onclick: () => { try { window.LaunchyNative.requestAlarmPerm(kind); } catch (e) {} } }, 'تفعيل'));
  return h('div', { class: 'form' },
    row(p.exact, 'المنبهات الدقيقة', 'ليرن المنبه في دقيقته تماماً (Android 12+).', 'exact'),
    row(p.notif, 'الإشعارات', 'لإظهار المنبه وزرّي الإيقاف والغفوة (Android 13+).', 'notif'),
    row(p.fullScreen, 'شاشة المنبه الكاملة', 'لتظهر شاشة البندول فوق قفل الشاشة (Android 14+).', 'fullScreen'),
    row(p.battery, 'استثناء توفير البطارية', 'مستحسن على هواتف Honor/Huawei كي لا يُوقف النظام التطبيق.', 'battery'));
}

/* ---------------------------------------------------------- alarm dialog */
function openAlarmDialog(id) {
  const list = alarmsLoad();
  const a = clone(list.find(x => x.id === id) || { id: uid(), h: 7, m: 0, days: [0, 1, 2, 3, 4], on: true, label: '', snooze: 10, vibrate: true, design: '' });
  const body = h('div', { class: 'form' });
  const clocks = loadDesigns().filter(d => d.type === 'clock');
  const draw = () => {
    const tm = h('input', { type: 'time', class: 'inp', value: pad2(a.h) + ':' + pad2(a.m), style: { fontSize: '26px', direction: 'ltr' } });
    tm.addEventListener('change', () => { const [hh, mm] = tm.value.split(':').map(Number); if (!isNaN(hh)) { a.h = hh; a.m = mm; } });
    const lab = h('input', { type: 'text', class: 'inp', value: a.label || '', maxlength: 30, placeholder: 'مثال: صلاة الفجر' }); lab.addEventListener('input', () => a.label = lab.value);
    const vib = h('input', { type: 'checkbox', class: 'sw' }); vib.checked = a.vibrate !== false; vib.onchange = () => a.vibrate = vib.checked;
    const sel = h('select', { class: 'inp' }, h('option', { value: '' }, 'تلقائي (أول ساعة بندول)'), clocks.map(d => h('option', { value: d.id, selected: a.design === d.id }, d.name)));
    sel.onchange = () => a.design = sel.value;
    body.replaceChildren(
      h('label', { class: 'field' }, h('span', {}, 'الوقت'), tm),
      h('div', { class: 'field' }, h('span', {}, 'التكرار'), h('div', { class: 'day-chips' }, AL_DAYS.map(([s, n], i) => h('button', { type: 'button', title: n, class: (a.days || []).includes(i) ? 'on' : '', onclick: () => { a.days = (a.days || []).includes(i) ? a.days.filter(x => x !== i) : [...(a.days || []), i]; draw(); } }, s))),
        h('p', { class: 'fine' }, daysText(a))),
      h('label', { class: 'field' }, h('span', {}, 'الاسم'), lab),
      h('div', { class: 'field' }, h('span', {}, 'الغفوة'), h('div', { class: 'seg' }, [5, 10, 15, 20].map(n => h('button', { type: 'button', class: (a.snooze || 10) === n ? 'on' : '', onclick: () => { a.snooze = n; draw(); } }, n + ' د')))),
      h('label', { class: 'ctl-row' }, h('span', {}, 'الاهتزاز'), vib),
      h('label', { class: 'field' }, h('span', {}, 'تصميم شاشة الرنين'), sel));
  };
  draw();
  openDialog(list.some(x => x.id === a.id) ? 'تعديل المنبه' : 'منبه جديد', body, [
    { label: 'حفظ', cls: 'btn-gold', onClick: () => { const l = alarmsLoad(); const i = l.findIndex(x => x.id === a.id); a.on = true; delete a.snoozeAt; if (i >= 0) l[i] = a; else l.push(a); alarmsSave(l); const t = nextTrigger(a); toast(t ? 'سيرن ' + remainText(t - Date.now(), { lang: 'ar', digits: 'latn' }) : 'حُفظ المنبه'); route(false); } },
    { label: 'إلغاء', cls: 'btn-ghost' }]);
}

/* ---------------------------------------------------------- pages */
function viewAlarms() {
  const v = $('#view'); refreshNextAlarm();
  const list = alarmsLoad().slice().sort((a, b) => (a.h * 60 + a.m) - (b.h * 60 + b.m));
  const sys = NEXT_ALARM;
  const sysBox = h('div', { class: 'tprompt' },
    h('div', { class: 'sub-h', style: { marginTop: 0 } }, 'المنبه التالي في الجهاز'),
    sys && sys.at ? h('div', {}, h('div', { style: { fontSize: '30px', fontWeight: 300 } }, nextAlarmText({ lang: 'ar', digits: 'latn', fmt: 'system' })),
      h('div', { class: 'fine' }, remainText(sys.at - Date.now(), { lang: 'ar', digits: 'latn' }) + (sys.own ? ' — من منبهات هذا التطبيق' : sys.pkg ? ' — من تطبيق المنبه في الجهاز' : '')))
      : h('p', { class: 'fine' }, 'لا يوجد منبه مجدول' + (NATIVE ? ' في الجهاز.' : ' (في المتصفح تُعرض منبهات التطبيق فقط).')),
    h('div', { style: { display: 'flex', gap: '8px', flexWrap: 'wrap', marginTop: '10px' } },
      h('button', { type: 'button', class: 'btn btn-sm', onclick: () => NATIVE && window.LaunchyNative.openSystem ? window.LaunchyNative.openSystem('clockApp') : toast('على هاتف Android يفتح هذا قائمة منبهات الجهاز') }, icon('clock', 15), 'منبهات الجهاز'),
      h('button', { type: 'button', class: 'btn btn-sm', onclick: () => NATIVE && window.LaunchyNative.openSystem ? window.LaunchyNative.openSystem('setAlarm') : toast('على هاتف Android يفتح هذا شاشة إنشاء منبه في تطبيق الساعة') }, icon('plus', 15), 'منبه جديد في تطبيق الساعة')));
  const rows = h('div', { class: 'alarm-list' }, list.length ? list.map(a => {
    const sw = h('input', { type: 'checkbox', class: 'sw', 'aria-label': 'تشغيل المنبه' }); sw.checked = a.on !== false;
    sw.onchange = () => { const l = alarmsLoad(); const x = l.find(q => q.id === a.id); if (x) { x.on = sw.checked; delete x.snoozeAt; alarmsSave(l); route(false); } };
    const t = nextTrigger(a);
    return h('div', { class: 'alarm-row' + (a.on === false ? ' off' : '') },
      h('div', { class: 'alarm-t' }, alarmTime(a)),
      h('div', { class: 'alarm-info' }, h('b', {}, a.label || 'منبه'), h('small', {}, daysText(a) + (t && a.on !== false ? ' · ' + remainText(t - Date.now(), { lang: 'ar', digits: 'latn' }) : '') + (a.snoozeAt && a.snoozeAt > Date.now() ? ' · غفوة' : ''))),
      h('button', { type: 'button', class: 'btn btn-sm', 'aria-label': 'تعديل', onclick: () => openAlarmDialog(a.id) }, icon('edit', 15)),
      h('button', { type: 'button', class: 'btn btn-sm btn-danger', 'aria-label': 'حذف', onclick: async () => { if (await confirmBox('حذف المنبه', 'حذف منبه ' + alarmTime(a) + '؟', 'حذف', true)) { alarmsSave(alarmsLoad().filter(x => x.id !== a.id)); route(false); } } }, icon('trash', 15)),
      sw);
  }) : [h('p', { class: 'fine' }, 'لا توجد منبهات في التطبيق بعد.')]);
  v.replaceChildren(h('div', { class: 'wrap' },
    h('div', { class: 'page-h' },
      h('div', {}, h('div', { class: 'eyebrow' }, 'Alarms'), h('h1', { class: 'page-t' }, 'المنبهات'),
        h('p', { class: 'page-d' }, 'منبهات التطبيق تحرّك بندول ساعاتك وتُظهر تأثيرات الرنين على الويدجت وفي شاشة منبه كاملة. ومن هنا تصل أيضاً إلى منبهات الجهاز.')),
      h('div', { class: 'page-act' },
        h('button', { type: 'button', class: 'btn', onclick: () => { if (hasNativeAlarms() && window.LaunchyNative.alarmTest) window.LaunchyNative.alarmTest(); else ringStart({ id: 'test', h: new Date().getHours(), m: new Date().getMinutes(), label: 'تجربة المنبه', snooze: 10 }); } }, icon('bell', 18), 'تجربة الرنين'),
        h('button', { type: 'button', class: 'btn btn-gold', onclick: () => openAlarmDialog(null) }, icon('plus', 18), 'منبه جديد'))),
    h('div', { class: 'tcards', style: { gridTemplateColumns: 'repeat(auto-fit,minmax(280px,1fr))' } }, sysBox, h('div', { class: 'tprompt' }, h('div', { class: 'sub-h', style: { marginTop: 0 } }, 'الأذونات'), permBox())),
    h('section', { class: 'sec' }, h('div', { class: 'sec-h' }, h('h2', {}, 'منبهات التطبيق'), h('p', {}, `${list.length} منبه`)), rows),
    h('section', { class: 'sec' }, h('div', { class: 'note' }, icon('eye', 16), h('span', {},
      'للأمانة: يكتشف التطبيق رنين منبهاته هو فقط. Android لا يسمح لأي تطبيق بمعرفة أن منبه تطبيق آخر يرن الآن؛ لذلك تعرض الساعات وقت المنبه التالي في الجهاز، أما تأثيرات الرنين وتسارع البندول فمع منبهات هذا التطبيق.')))));
}
function viewClocks() {
  const v = $('#view');
  const colls = [['pendulums', 'ساعات البندول'], ['interactive', 'ساعات تفاعلية وزجاجية'], ['library', 'مكتبة الخامات والأنماط'], ['classic', 'كلاسيكية'], ['plush', 'مخملية'], ['royal', 'الذهب الملكي'], ['glass', 'الزجاج السائل'], ['digital', 'رقمية']];
  const alertBtn = h('button', { type: 'button', class: 'btn', onclick: () => { setClockAlert(!CLOCK_ALERT.on); alertBtn.lastChild.textContent = CLOCK_ALERT.on ? 'إيقاف الرنين التجريبي' : 'جرّب تأثير الرنين'; } }, icon('bell', 18), h('span', {}, CLOCK_ALERT.on ? 'إيقاف الرنين التجريبي' : 'جرّب تأثير الرنين'));
  const packs = h('div', { class: 'pack-grid' }, CLOCK_PACKS.map(p => h('button', { type: 'button', class: 'pack', onclick: () => { const d = presetDesign(CLOCK_HOME_P); applyClockPack(d, p.k); d.name = 'بندول ' + p.n; startNew(d, 2); } }, h('i', { style: { background: `linear-gradient(135deg, ${p.sw[0]} 0 55%, ${p.sw[1]} 55%)` } }), h('span', {}, p.n))));
  v.replaceChildren(h('div', { class: 'wrap' },
    h('div', { class: 'page-h' },
      h('div', {}, h('div', { class: 'eyebrow' }, 'Interactive Clocks'), h('h1', { class: 'page-t' }, 'الساعات التفاعلية'),
        h('p', { class: 'page-d' }, 'ساعة بندول ذهبي، كبسولة زجاجية بزر منبه، مربع زجاجي، رقمية مع عقارب، وعشرات الخامات. الضغط على الساعة في الشاشة الرئيسية يفتح منبهات الجهاز.')),
      h('div', { class: 'page-act' }, alertBtn, h('a', { class: 'btn btn-gold', href: '#/alarms' }, icon('bell', 18), 'المنبهات'))),
    h('section', { class: 'sec' }, h('div', { class: 'sec-h' }, h('h2', {}, 'باقات الخامات'), h('p', {}, 'ابدأ ساعة بندول بالباقة التي تحبها')), packs),
    ...colls.map(([k, n]) => { const list = TIME_PRESETS.filter(p => p.coll === k); return list.length ? h('section', { class: 'sec tcoll' }, h('div', { class: 'sec-h' }, h('h2', {}, n), h('p', {}, list.length + ' تصميم')), presetGrid(list)) : null; }),
    h('section', { class: 'sec' }, h('div', { class: 'note' }, icon('clock', 16), h('span', {},
      'المعاينة داخل التطبيق متحركة بالكامل. على الشاشة الرئيسية: العقارب والأرقام حيّة يرسمها Android، والبندول حلقة صور قصيرة يشغّلها المشغّل (Launcher) بلا تحديثات متكررة؛ وتختلف سلاستها بين المشغّلات. الحركة الكاملة السلسة أثناء الرنين تظهر في شاشة المنبه الكاملة.')))));
}
