/* =========================================================
   Time & Weather widgets — layouts for the clock, date and
   weather types. They share the design model, styles, materials,
   frames, effects and the baking pipeline with the shortcut
   widgets. "Live" elements (clock hands and digits) are drawn
   here for the preview and handed to Android's own AnalogClock /
   TextClock on the home screen, so the time is always exact
   without waking the phone every minute.
   ========================================================= */
const TIME_TYPES = new Set(['clock', 'date', 'weather']);
const isTimeType = d => TIME_TYPES.has(d.type);
const TEXT_FONTS = [
  ['plex', 'آي بي إم بلكس', '"IBM Plex Sans Arabic"'], ['readex', 'ريدكس', '"Readex Pro"'], ['amiri', 'أميري (نسخ كلاسيكي)', '"Amiri"'],
  ['kufi', 'كوفي حديث', '"Noto Kufi Arabic"'], ['messiri', 'المسيري الأنيق', '"El Messiri"'], ['reem', 'ريم كوفي', '"Reem Kufi"'],
  ['ruqaa', 'رقعة', '"Aref Ruqaa"'], ['tajawal', 'تجوال', '"Tajawal"']
];
const textFam = k => ((TEXT_FONTS.find(f => f.k === k || f[0] === k) || TEXT_FONTS[0])[2]) + ', "IBM Plex Sans Arabic", "Noto Sans Arabic", system-ui, sans-serif';
const CLOCK_SHAPES = [['circle', 'دائري'], ['rounded', 'مربع بزوايا دائرية'], ['square', 'مربع'], ['rect', 'مستطيل']];
const DIGITAL_LAYOUTS = [['stack', 'الوقت مع التاريخ'], ['big', 'أرقام كبيرة'], ['side', 'جانبي مع المعلومات'], ['flip', 'بطاقات قلابة'], ['led', 'شاشة LED'], ['minimal', 'بسيط']];
const DATE_VARIANTS = [['dual', 'بطاقة التاريخ المزدوج'], ['calendar', 'التقويم الشهري الفاخر'], ['mini', 'التاريخ المصغر'], ['big', 'التاريخ الكبير مع عبارة'], ['combo', 'الساعة + التاريخ'], ['islamic', 'التاريخ الإسلامي المزخرف']];
const WX_VARIANTS = [['mini', 'مصغر'], ['medium', 'متوسط'], ['large', 'كبير بالتفاصيل'], ['panorama', 'أفقي بانورامي'], ['round', 'دائري بحلقة الحرارة']];
const BG_MODES = [['weather', 'تلقائية حسب الطقس'], ['time', 'حسب وقت اليوم'], ['fixed', 'خلفية ثابتة (مثبّتة)'], ['rotate', 'تبديل بين مفضلاتي'], ['photo', 'صورتي الشخصية'], ['none', 'بدون (خامة التصميم)']];
const TAPS = [['clockApp', 'فتح منبهات الجهاز'], ['setAlarm', 'إنشاء منبه جديد'], ['appAlarms', 'منبهات التطبيق'], ['calendarApp', 'فتح التقويم'], ['refresh', 'تحديث الطقس'], ['studio', 'فتح الاستوديو'], ['none', 'بدون']];

const defaultClock = () => ({ face: 'analog', shape: 'circle', numerals: 'roman', numFont: '', numScale: 1, indices: 'bars', ticks: true, hands: 'breguet', handColor: 'gold', secColor: '#c0392b', seconds: false,
  dial: 'ivory', dialMat: 'velvet', dialColor: '', bezel: 'goldMulti', bezelW: 100, ornaments: false, raised: false, glowHands: '',
  layout: 'stack', font: 'thin', fmt: 'system', digits: 'latn', ampm: true, timeColor: '', gradient: '', glow: 0, lead: false,
  date: 'both', weekday: true, lang: 'ar', calc: 'umalqura', offset: 0, wx: false, city: false, phrase: false, phraseSet: 'mixed', phraseText: '', tz: '', tzName: '', tfont: 'plex', tap: 'clockApp',
  motion: 'classic', speed: 100, swing: 10, light: 60, shadowK: 50, pendulum: true, alarmFx: true, pendFace: 'digital', rod: '', inner: '',
  hourStyle: '', minStyle: '', secStyle: 'line', handW: 100, handL: 100, cap: 'dome', nextAlarm: false, countdown: false, alarmTap: 'clockApp', pack: '' });
const defaultDate = () => ({ scale: 100, variant: 'dual', primary: 'hijri', show: 'both', calc: 'umalqura', offset: 0, lang: 'ar', digits: 'latn', tfont: 'amiri', numFont: 'serif', todayColor: '', weekStart: 0,
  occasions: true, white: false, national: true, phrase: true, phraseSet: 'mixed', phraseText: '', weekday: true, fmt: 'system', font: 'light', tap: 'calendarApp' });
const defaultWeather = () => ({ variant: 'medium', loc: Object.assign({}, DEFAULT_LOC), unit: 'C', interval: 60, lang: 'ar', digits: 'latn', tfont: 'plex', numFont: 'light', h12: true,
  show: { city: true, desc: true, hilo: true, feels: false, hum: true, wind: true, aqi: true, sun: true, uv: false, hourly: true, daily: true, updated: true },
  bg: { mode: 'weather', scene: 'greenPeak', favs: ['greenPeak', 'lakeHouse', 'coastSunset', 'forestFalls'], every: 'update', photo: '', alpha: 100, overlay: 'dark', overlayAmt: 30, blur: 0 },
  tempPos: 'start', iconSize: 100, iconStyle: 'color', tap: 'refresh' });

/* ---------------------------------------------------------- small drawing helpers */
function tText(ctx, S, text, x, y, w, o) {
  fillText(ctx, text, x, y, w, Object.assign({ font: textFam(o.f || 'plex'), weight: o.weight || 500, size: o.size, color: o.color, align: o.align, dir: o.dir, shadow: o.shadow, S }, o.fit === false ? { fit: false } : {}));
}
function wrapText(ctx, text, maxW, size, fam, weight, maxLines) {
  ctx.save(); ctx.font = fontStr(size, weight, fam);
  const words = String(text || '').split(/\s+/).filter(Boolean), lines = [];
  let cur = '';
  for (const w of words) { const t = cur ? cur + ' ' + w : w; if (ctx.measureText(t).width <= maxW || !cur) cur = t; else { lines.push(cur); cur = w; } }
  if (cur) lines.push(cur);
  ctx.restore();
  if (lines.length > maxLines) { lines.length = maxLines; lines[maxLines - 1] += '…'; }
  return lines;
}
const measureCtx = (() => { let c; return () => (c || (c = document.createElement('canvas').getContext('2d'))); })();
/** Weather icon (3D colour or white line style). */
function drawWxIcon(ctx, S, kind, day, cx, cy, s, style = 'color') {
  const mono = style === 'mono';
  const sun = (x, y, r) => {
    if (mono) { ctx.strokeStyle = '#fff'; ctx.lineWidth = s * .06; ctx.beginPath(); ctx.arc(x, y, r * .62, 0, TAU); ctx.stroke(); for (let i = 0; i < 8; i++) { const a = i * TAU / 8; ctx.beginPath(); ctx.moveTo(x + Math.cos(a) * r * .85, y + Math.sin(a) * r * .85); ctx.lineTo(x + Math.cos(a) * r * 1.05, y + Math.sin(a) * r * 1.05); ctx.stroke(); } return; }
    const gl = ctx.createRadialGradient(x, y, 0, x, y, r * 1.5); gl.addColorStop(0, 'rgba(255,200,80,.55)'); gl.addColorStop(1, 'rgba(255,200,80,0)'); ctx.fillStyle = gl; ctx.beginPath(); ctx.arc(x, y, r * 1.5, 0, TAU); ctx.fill();
    const g = ctx.createRadialGradient(x - r * .3, y - r * .3, r * .1, x, y, r * .75); g.addColorStop(0, '#fff3b0'); g.addColorStop(.55, '#ffc23a'); g.addColorStop(1, '#f08a1c'); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r * .72, 0, TAU); ctx.fill();
  };
  const moon = (x, y, r) => {
    ctx.save(); const p = new Path2D(); p.arc(x, y, r * .7, 0, TAU); const q = new Path2D(); q.arc(x + r * .36, y - r * .26, r * .62, 0, TAU);
    ctx.clip(p); if (mono) { ctx.fillStyle = '#fff'; } else { const g = ctx.createRadialGradient(x - r * .3, y, 0, x, y, r * .8); g.addColorStop(0, '#fffbe8'); g.addColorStop(1, '#d8cfa8'); ctx.fillStyle = g; }
    ctx.fill(p); ctx.globalCompositeOperation = 'destination-out'; ctx.fill(q); ctx.restore();
  };
  const cloudShape = (x, y, w, dark) => {
    const p = new Path2D(); p.arc(x - w * .22, y + w * .04, w * .2, Math.PI * .5, Math.PI * 1.5); p.arc(x - w * .02, y - w * .1, w * .27, Math.PI, Math.PI * 1.9); p.arc(x + w * .24, y + w * .02, w * .2, Math.PI * 1.4, Math.PI * .5); p.closePath();
    if (mono) { ctx.strokeStyle = '#fff'; ctx.lineWidth = s * .06; ctx.stroke(p); return; }
    ctx.save(); ctx.shadowColor = 'rgba(0,0,0,.25)'; ctx.shadowBlur = w * .12 * S; ctx.shadowOffsetY = w * .05 * S;
    const g = ctx.createLinearGradient(0, y - w * .35, 0, y + w * .25); g.addColorStop(0, dark ? '#c9ced8' : '#ffffff'); g.addColorStop(1, dark ? '#7d8796' : '#d5dde8');
    ctx.fillStyle = g; ctx.fill(p); ctx.restore();
  };
  const drops = (n, col, snow) => {
    for (let i = 0; i < n; i++) {
      const x = cx - s * .2 + i * s * .2, y = cy + s * .3 + (i % 2) * s * .08;
      if (snow) { ctx.save(); ctx.strokeStyle = mono ? '#fff' : '#eaf6ff'; ctx.lineWidth = s * .035; for (let k = 0; k < 3; k++) { const a = k * Math.PI / 3; ctx.beginPath(); ctx.moveTo(x - Math.cos(a) * s * .06, y - Math.sin(a) * s * .06); ctx.lineTo(x + Math.cos(a) * s * .06, y + Math.sin(a) * s * .06); ctx.stroke(); } ctx.restore(); }
      else { ctx.save(); ctx.strokeStyle = mono ? '#fff' : col; ctx.lineWidth = s * .05; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(x, y - s * .06); ctx.lineTo(x - s * .04, y + s * .08); ctx.stroke(); ctx.restore(); }
    }
  };
  ctx.save();
  switch (kind) {
    case 'clear': day ? sun(cx, cy, s * .5) : moon(cx, cy, s * .55); break;
    case 'partly': day ? sun(cx + s * .16, cy - s * .14, s * .36) : moon(cx + s * .16, cy - s * .14, s * .38); cloudShape(cx - s * .04, cy + s * .1, s * .78, false); break;
    case 'cloudy': cloudShape(cx + s * .12, cy - s * .1, s * .6, true); cloudShape(cx - s * .04, cy + s * .08, s * .82, false); break;
    case 'fog': cloudShape(cx, cy - s * .08, s * .78, true); ctx.strokeStyle = mono ? '#fff' : '#e3e8ef'; ctx.lineWidth = s * .05; ctx.lineCap = 'round'; for (let i = 0; i < 3; i++) { ctx.beginPath(); ctx.moveTo(cx - s * .32 + i * s * .06, cy + s * .2 + i * s * .1); ctx.lineTo(cx + s * .3 - i * s * .04, cy + s * .2 + i * s * .1); ctx.stroke(); } break;
    case 'drizzle': cloudShape(cx, cy - s * .06, s * .8, true); drops(2, '#6ec1ff'); break;
    case 'rain': case 'showers': if (kind === 'showers' && day) sun(cx + s * .2, cy - s * .2, s * .3); cloudShape(cx, cy - s * .06, s * .82, true); drops(3, '#4aa8ff'); break;
    case 'snow': cloudShape(cx, cy - s * .06, s * .8, false); drops(3, '#fff', true); break;
    case 'storm': cloudShape(cx, cy - s * .08, s * .82, true);
      ctx.fillStyle = mono ? '#fff' : '#ffd23a'; ctx.beginPath(); ctx.moveTo(cx + s * .02, cy + s * .08); ctx.lineTo(cx - s * .12, cy + s * .32); ctx.lineTo(cx - s * .01, cy + s * .3); ctx.lineTo(cx - s * .08, cy + s * .5); ctx.lineTo(cx + s * .14, cy + s * .22); ctx.lineTo(cx + s * .03, cy + s * .24); ctx.closePath(); ctx.fill(); break;
    default: ctx.strokeStyle = mono ? '#fff' : 'rgba(255,255,255,.7)'; ctx.setLineDash([s * .06, s * .05]); ctx.lineWidth = s * .04; cloudShape(cx, cy, s * .8, true);
  }
  ctx.restore();
}

/* ---------------------------------------------------------- live elements */
function liveFormats(kind, mode, lead) {
  const h12 = lead ? 'hh' : 'h';
  const pick = (f12, f24) => mode === '12' ? [f12, f12] : mode === '24' ? [f24, f24] : [f12, f24];
  switch (kind) {
    case 'hour': return pick(h12, 'HH');
    case 'min': return ['mm', 'mm'];
    case 'sec': return ['ss', 'ss'];
    case 'ampm': return mode === '24' ? null : mode === '12' ? ['a', 'a'] : ['a', ''];
    default: return pick(h12 + ':mm', 'HH:mm');
  }
}
/** Preview string a live text element shows right now. */
function liveString(el, t) {
  const use12 = el.mode === '12' || (el.mode === 'system' && !is24System());
  let h = t.h; if (use12) { h = h % 12; if (h === 0) h = 12; }
  const hs = use12 && !el.lead ? String(h) : pad2(h);
  const s = { hour: hs, min: pad2(t.m), sec: pad2(t.s), ampm: use12 ? ampmText(t, el.lang) : '' }[el.kind] ?? hs + ':' + pad2(t.m);
  return el.kind === 'ampm' ? s : toDigits(s, el.digits);
}
/** Font size so that the widest possible string fits the box. */
function fitLiveSize(el, w, h) {
  const sample = el.kind === 'time' ? (el.mode === '24' || el.lead ? '00:00' : '00:00') : el.kind === 'ampm' ? 'PM' : '00';
  const c = measureCtx(); const ref = 100;
  const mw = measureClockText(c, toDigits(sample, el.digits), ref, el.font, el.digits) || ref * sample.length * .6;
  const m = clockFontMeta(el.font), lineH = (m.asc - m.desc) / 1000;
  return Math.max(6, Math.min(h / lineH * .98, w / mw * ref * .97));
}
function addLive(LY, el) {
  const f = el.kind === 'analog' ? true : liveFormats(el.kind, el.mode, el.lead);
  if (!f) return;
  if (el.kind !== 'analog') { el.f12 = f[0]; el.f24 = f[1]; if (!el.size) el.size = fitLiveSize(el, el.w, el.h); }
  LY.live.push(el);
}
const flipState = new Map();
function paintLive(ctx, S, L, el, now, d, mode = {}) {
  if (paintLiveFx(ctx, S, L, el, now, d, mode)) return;
  const t = nowIn(el.tz, now);
  if (el.kind === 'analog') {
    if (mode.anim) { const tms = performance.now(); if (el.o.motion === 'lightHands') el = Object.assign({}, el, { o: Object.assign({}, el.o, { glowA: .55 + .45 * Math.sin(tms / 650) }) }); }
    paintHands(ctx, S, L, el.cx, el.cy, el.R, el.o, t, mode.anim ? el.o.motion : '');
    if (mode.anim) paintAnalogFx(ctx, S, L, el, performance.now(), alertLevel());
    return;
  }
  const str = liveString(el, t);
  if (!str) return;
  if (el.flip && mode.redraw) { // flip-card animation when the digits change (in the app)
    const key = (mode.key || '') + '|' + Math.round(el.x) + '|' + Math.round(el.y) + '|' + el.kind;
    let st = flipState.get(key);
    if (!st) flipState.set(key, st = { str, prev: str, t0: 0 });
    else if (st.str !== str) { st.prev = st.str; st.str = str; st.t0 = performance.now(); }
    const p = st.t0 ? (performance.now() - st.t0) / 650 : 1;
    if (p < 1 && !matchMedia('(prefers-reduced-motion: reduce)').matches) {
      const cx = el.x + el.w / 2, cy = el.y + el.h / 2, mid = cy, top = el.y - el.h * .1, bot = el.y + el.h * 1.1, card = d.clock.cardColor || '#1c1c20';
      const half = (s2, y0, y1, sy, anchor) => { ctx.save(); ctx.beginPath(); ctx.rect(el.x - el.w * .06, y0, el.w * 1.12, y1 - y0); ctx.clip(); ctx.translate(0, anchor); ctx.scale(1, sy); ctx.translate(0, -anchor);
        ctx.fillStyle = mix(card, '#ffffff', y0 < mid ? .07 : 0); ctx.fillRect(el.x - el.w * .06, y0, el.w * 1.12, y1 - y0);
        drawClockText(ctx, s2, cx, cy, el.size, el.font, el.digits, el.color); ctx.restore(); };
      half(st.str, top, mid, 1, mid);                       // new top
      half(p < .5 ? st.prev : st.str, mid, bot, 1, mid);    // bottom: old until the flap passes
      if (p < .5) half(st.prev, top, mid, Math.max(.001, Math.cos(p * Math.PI)), mid);           // old top folding down
      else half(st.str, mid, bot, Math.max(.001, -Math.cos(p * Math.PI)), mid);                 // new bottom unfolding
      ctx.fillStyle = 'rgba(0,0,0,.55)'; ctx.fillRect(el.x - el.w * .06, mid - .8, el.w * 1.12, 1.6);
      mode.redraw();
      return;
    }
  }
  if (el.grad) {
    ctx.save();
    const g = ctx.createLinearGradient(el.x, el.y, el.x + el.w, el.y + el.h); g.addColorStop(0, el.color); g.addColorStop(1, el.grad);
    drawClockText(ctx, str, el.x + el.w / 2, el.y + el.h / 2, el.size, el.font, el.digits, g, el.align, el.x, el.w);
    ctx.restore();
  } else drawClockText(ctx, str, el.x + el.w / 2, el.y + el.h / 2, el.size, el.font, el.digits, el.color, el.align, el.x, el.w);
}

/* ---------------------------------------------------------- body + background */
function timeBody(d, W, H, m) {
  if (d.type === 'clock' && d.clock.face === 'analog' && d.clock.shape !== 'rect' || (d.type === 'weather' && d.weather.variant === 'round')) {
    const D = Math.min(W, H) - 2 * m, circle = d.type === 'weather' || d.clock.shape === 'circle';
    return { x: (W - D) / 2, y: (H - D) / 2, w: D, h: D, r: circle ? D / 2 : d.clock.shape === 'square' ? Math.min(10, d.a.radius) : Math.max(D * .22, d.a.radius), circle };
  }
  return { x: m, y: m, w: W - 2 * m, h: H - 2 * m, r: d.a.radius };
}
/** Photo background painter for weather designs (library photo or the user's own). */
function weatherBg(d, wv, B, LY) {
  const bg = d.weather.bg; if (bg.mode === 'none') return null;
  let src, fx = .5, fy = .5;
  if (bg.mode === 'photo' && bg.photo) src = bg.photo;
  else { const sc = pickScene(bg, wv); src = sc.src; fx = sc.fx; fy = sc.fy; LY.info.scene = sc.k; }
  LY.imgs = [src];
  return (ctx, S) => {
    const img = getImg(src); if (!img) return;
    const P = boxPath(B);
    ctx.save(); ctx.clip(P);
    ctx.globalAlpha = (bg.alpha ?? 100) / 100;
    if (bg.blur) ctx.filter = `blur(${bg.blur * S * .25}px)`;
    const pad = bg.blur ? bg.blur * .5 : 0;
    drawCoverFocus(ctx, img, B.x - pad, B.y - pad, B.w + 2 * pad, B.h + 2 * pad, fx, fy);
    ctx.filter = 'none'; ctx.globalAlpha = 1;
    if (bg.overlay !== 'none' && bg.overlayAmt) {
      const a = bg.overlayAmt / 100, c = bg.overlay === 'light' ? '#ffffff' : '#000000';
      const g = ctx.createLinearGradient(0, B.y, 0, B.y + B.h); g.addColorStop(0, rgba(c, a * .9)); g.addColorStop(.5, rgba(c, a * .45)); g.addColorStop(1, rgba(c, a));
      ctx.fillStyle = g; ctx.fillRect(B.x, B.y, B.w, B.h);
    }
    ctx.restore();
  };
}

/* ---------------------------------------------------------- shared text blocks */
function lineSet(d, o, now) {
  const di = dateInfo(now, { calc: o.calc, offset: o.offset, lang: o.lang, digits: o.digits });
  return di;
}
function tapHit(LY, d, B) {
  const o = d[d.type], k = o.tap || 'none';
  if (k === 'none') return;
  const tap = k === 'studio' ? { k: 'open', v: 'time' } : k === 'appAlarms' ? { k: 'open', v: 'alarms' } : { k, v: k === 'refresh' ? (d.id || '') : '' };
  LY.hits.push({ x: B.x, y: B.y, w: B.w, h: B.h, act: 'tap', tap });
}

/* ---------------------------------------------------------- CLOCK */
function clockInfoLines(d, now) {
  const o = d.clock, di = dateInfo(now, { calc: o.calc, offset: o.offset, lang: o.lang, digits: o.digits }), lines = [];
  if (o.weekday) lines.push({ t: di.weekday, k: 'wd' });
  if (o.date === 'both' || o.date === 'greg') lines.push({ t: di.gFull, k: 'g' });
  if (o.date === 'both' || o.date === 'hijri') lines.push({ t: di.hFull, k: 'h' });
  if (o.nextAlarm && d.type === 'clock' && o.face !== 'pill') lines.push({ t: nextAlarmText(o, now), k: 'alarm' });
  if (o.city && (o.tzName || o.tz)) lines.push({ t: o.tzName || o.tz.split('/').pop().replace(/_/g, ' '), k: 'city' });
  if (o.wx) { const loc = store.get('llx.clockloc', null) || DEFAULT_LOC; const wv = wxView(wxCached(loc), { weather: Object.assign(defaultWeather(), { lang: o.lang, digits: o.digits }) }); lines.push({ t: wv ? `${wv.temp}  ${wv.desc}` : (o.lang === 'en' ? 'Weather —' : 'الطقس —'), k: 'wx', code: wv ? wv.code : null, day: wv ? wv.day : true }); }
  if (o.phrase) lines.push({ t: dailyPhrase(now, o.phraseSet, o.lang, o.phraseText), k: 'phrase' });
  return lines;
}
function drawInfoLines(ctx, S, L, lines, x, y, w, h, o, align = 'center', shadow) {
  if (!lines.length) return;
  const n = lines.length, lh = Math.min(h / n, Math.max(9, w * .1));
  let yy = y + (h - lh * n) / 2 + lh / 2;
  const ax = align === 'start' ? x + w : align === 'end' ? x : x + w / 2;
  for (const ln of lines) {
    const big = ln.k === 'wd', size = lh * (big ? .62 : ln.k === 'phrase' ? .5 : .54);
    let tx = ax, tw = w;
    if (ln.k === 'wx' && ln.code != null) { const ic = size * 1.4; drawWxIcon(ctx, S, wxIcon(ln.code), ln.day, align === 'start' ? x + w - ic / 2 : align === 'end' ? x + ic / 2 : x + w / 2 - measure(ctx, ln.t, size, 500, textFam(o.tfont)) / 2 - ic * .7, yy, ic, 'color'); if (align === 'start') { tx -= ic * 1.1; tw -= ic * 1.1; } else if (align === 'end') { tx += ic * 1.1; tw -= ic * 1.1; } }
    tText(ctx, S, ln.t, tx, yy, tw, { size, f: o.tfont, weight: big ? 700 : 500, color: ln.k === 'h' || ln.k === 'phrase' ? L.acc : big ? L.text : L.sub, align, shadow });
    yy += lh;
  }
}
function layClock(d, LY, C, now) {
  const o = effClock(d.clock), B = LY.B;
  if (o.alarmFx !== false) LY.alertFx = true;
  if (o.face === 'pendulum') return layPendulum(d, LY, C, now, o);
  if (o.face === 'pill') return layPill(d, LY, C, now, o);
  if (o.face === 'combo') return layCombo(d, LY, C, now, o);
  const tc = o.timeColor || L_textOf(d);
  const lines = clockInfoLines(d, now);
  useClockFont(o.font, o.digits); useClockFont(o.numFont || (o.numerals === 'roman' ? 'royal' : 'serif'), o.numerals === 'arabic' ? 'arab' : 'latn');
  if (o.face === 'analog') {
    let R, cx, cy, info = null;
    if (B.circle || o.shape !== 'rect' || !lines.length) {
      R = Math.min(C.w, C.h) / 2; cx = C.x + C.w / 2; cy = C.y + C.h / 2;
      if (o.shape === 'rect' && !lines.length) R = Math.min(C.w, C.h) / 2;
      if (B.circle) R = B.w / 2 - Math.max(0, (d.a.frame !== 'none' ? frameAllowance(d) * .6 : 0));
      else if (o.shape !== 'rect') R = Math.min(C.w, C.h) / 2;
      // date lines inside the dial (like a complication) when the face stands alone
      if (lines.length && o.shape !== 'rect') info = 'dial';
    } else if (C.w >= C.h) {
      R = C.h / 2; cx = C.x + C.w - R; cy = C.y + C.h / 2; info = { x: C.x, y: C.y, w: C.w - 2 * R - C.h * .12, h: C.h, align: 'center' };
    } else {
      R = C.w / 2; cx = C.x + C.w / 2; cy = C.y + R; info = { x: C.x, y: C.y + 2 * R + C.w * .06, w: C.w, h: C.h - 2 * R - C.w * .06, align: 'center' };
    }
    LY.nodes.push({ k: 'draw', fn: (ctx, S, L) => {
      const r = paintAnalogFace(ctx, S, L, cx, cy, R, o);
      if (info === 'dial') {
        const sub = lines.filter(l => l.k !== 'phrase').slice(0, 2);
        const L2 = Object.assign({}, L, { text: dialInk(o, L), sub: dialInk(o, L, .75), acc: METAL_HANDS.has(o.handColor) && (o.dial === 'black' || o.dial === 'material') ? handBase(o, L) : dialInk(o, L, .85) });
        drawInfoLines(ctx, S, L2, sub, cx - r * .48, cy + r * .2, r * .96, r * .36, o, 'center');
      } else if (info) drawInfoLines(ctx, S, L, lines, info.x, info.y, info.w, info.h, o, info.align, d.type === 'weather');
    } });
    addLive(LY, { kind: 'analog', cx, cy, R: R * (1 - ({ goldMulti: .16, gold: .09, woodDark: .15, velvet3d: .17, chrome: .1, silver: .08, glass: .1, marble: .14, thin: .025, none: 0 }[o.bezel] ?? .1) * (o.bezelW ?? 100) / 100), o: Object.assign({}, o), tz: o.tz, x: cx - R, y: cy - R, w: 2 * R, h: 2 * R });
    tapHit(LY, d, B); return;
  }
  // ---- digital
  const lay = o.layout, mode = o.fmt, font = lay === 'led' ? 'led' : o.font, digits = lay === 'led' ? 'latn' : o.digits;
  useClockFont(font, digits);
  const base = { font, digits, mode, color: tc, tz: o.tz, lang: o.lang, lead: lay === 'led' || lay === 'flip' || o.lead, grad: o.gradient || '' };
  const ampmOn = o.ampm && mode !== '24';
  if (lay === 'flip') {
    const gap = C.w * .04, cw = (C.w - gap) / 2, chh = Math.min(C.h * (lines.length ? .66 : .9), cw * 1.15), top = C.y + (lines.length ? 0 : (C.h - chh) / 2);
    const cards = [[C.x + cw + gap, 'hour'], [C.x, 'min']]; // RTL reading order is irrelevant for digits: HH | mm left-to-right
    cards.reverse();
    LY.nodes.push({ k: 'draw', fn: (ctx, S, L) => {
      for (const [x] of cards) paintFlipCard(ctx, S, L, x, top, cw, chh, o);
      if (lines.length) drawInfoLines(ctx, S, L, lines.slice(0, 3), C.x, top + chh + C.h * .04, C.w, C.y + C.h - top - chh - C.h * .04, o, 'center');
    } });
    cards.forEach(([x, kind], i) => addLive(LY, Object.assign({}, base, { kind: i === 0 ? 'hour' : 'min', x: x + cw * .06, y: top + chh * .08, w: cw * .88, h: chh * .84, color: o.timeColor || '#f4f1ea', flip: true })));
    if (ampmOn) addLive(LY, Object.assign({}, base, { kind: 'ampm', x: cards[0][0] + cw * .04, y: top + chh * .78, w: cw * .22, h: chh * .16, size: chh * .11, font: 'medium', color: rgba('#f4f1ea', .8), align: 'left' }));
    tapHit(LY, d, B); return;
  }
  if (lay === 'big') {
    const lh = (C.h - (lines.length ? C.h * .18 : 0)) / 2;
    addLive(LY, Object.assign({}, base, { kind: 'hour', x: C.x, y: C.y, w: C.w, h: lh }));
    addLive(LY, Object.assign({}, base, { kind: 'min', x: C.x, y: C.y + lh, w: C.w, h: lh, color: o.timeColor ? o.timeColor : L_accOf(d) }));
    if (lines.length) LY.nodes.push({ k: 'draw', fn: (ctx, S, L) => drawInfoLines(ctx, S, L, lines.slice(0, 1), C.x, C.y + 2 * lh, C.w, C.h * .18, o, 'center') });
    tapHit(LY, d, B); return;
  }
  if (lay === 'side' && C.w > C.h * 1.3) {
    const tw = C.w * .56;
    const ampW = ampmOn ? tw * .16 : 0;
    addLive(LY, Object.assign({}, base, { kind: 'time', x: C.x + C.w - tw, y: C.y + C.h * .12, w: tw - ampW, h: C.h * .76 }));
    if (ampmOn) addLive(LY, Object.assign({}, base, { kind: 'ampm', x: C.x + C.w - tw - ampW * .1, y: C.y + C.h * .52, w: ampW, h: C.h * .2, font: 'medium', size: C.h * .12, color: L_subOf(d) }));
    LY.nodes.push({ k: 'draw', fn: (ctx, S, L) => {
      ctx.save(); ctx.strokeStyle = rgba(L.frameColor, .6); ctx.lineWidth = 1; ctx.beginPath(); const xd = C.x + C.w - tw - C.w * .03; ctx.moveTo(xd, C.y + C.h * .15); ctx.lineTo(xd, C.y + C.h * .85); ctx.stroke(); ctx.restore();
      drawInfoLines(ctx, S, L, lines, C.x, C.y, C.w - tw - C.w * .06, C.h, o, 'center');
    } });
    tapHit(LY, d, B); return;
  }
  // stack / led / minimal
  const nInfo = lay === 'minimal' ? Math.min(1, lines.length) : Math.min(lines.length, C.h > C.w * .9 ? 4 : 2);
  const infoH = nInfo ? C.h * (lay === 'minimal' ? .22 : nInfo > 2 ? .42 : .34) : 0;
  const th = C.h - infoH - (nInfo ? C.h * .03 : 0);
  const ampW = ampmOn ? C.w * .13 : 0;
  const timeBox = { x: C.x + ampW, y: C.y, w: C.w - ampW * (lay === 'minimal' ? 1 : 2), h: th };
  if (lay === 'minimal') timeBox.x = C.x + C.w * .0, timeBox.w = C.w - ampW;
  if (lay === 'led') {
    LY.nodes.push({ k: 'draw', fn: (ctx, S, L) => {
      const ghost = { kind: 'time', font: 'led', digits: 'latn', mode: '24', lead: true };
      const sz = fitLiveSize(Object.assign({}, ghost), timeBox.w, timeBox.h);
      drawClockText(ctx, '88:88', timeBox.x + timeBox.w / 2, timeBox.y + timeBox.h / 2, sz, 'led', 'latn', rgba(tc.slice(0, 7), .09));
    } });
  }
  if (o.glow) LY.nodes.push({ k: 'draw', fn: (ctx, S, L) => {
    const g = ctx.createRadialGradient(timeBox.x + timeBox.w / 2, timeBox.y + timeBox.h / 2, 0, timeBox.x + timeBox.w / 2, timeBox.y + timeBox.h / 2, Math.max(timeBox.w, timeBox.h) * .55);
    g.addColorStop(0, rgba(tc.slice(0, 7), .28 * o.glow / 100)); g.addColorStop(1, rgba(tc.slice(0, 7), 0)); ctx.fillStyle = g; ctx.fillRect(timeBox.x - 20, timeBox.y - 20, timeBox.w + 40, timeBox.h + 40);
  } });
  const timeEl = Object.assign({}, base, { kind: 'time', x: timeBox.x, y: timeBox.y, w: timeBox.w, h: timeBox.h, align: lay === 'minimal' ? 'right' : 'center' });
  if (lay === 'led') timeEl.mode = mode === 'system' ? 'system' : mode;
  addLive(LY, timeEl);
  if (ampmOn) {
    const sz = Math.min(timeEl.size * .32, ampW * .7);
    addLive(LY, Object.assign({}, base, { kind: 'ampm', x: C.x, y: timeBox.y + timeBox.h / 2 + timeEl.size * .05, w: ampW, h: sz * 1.4, size: sz, font: lay === 'led' ? 'led' : 'medium', color: L_subOf(d), align: 'left' }));
  }
  if (nInfo) LY.nodes.push({ k: 'draw', fn: (ctx, S, L) => drawInfoLines(ctx, S, L, lines.slice(0, nInfo), C.x, C.y + C.h - infoH, C.w, infoH, o, lay === 'minimal' ? 'start' : 'center') });
  tapHit(LY, d, B);
}
function paintFlipCard(ctx, S, L, x, y, w, h, o) {
  const r = Math.min(w, h) * .1, P = rrPath(new Path2D(), x, y, w, h, r);
  outerShadow(ctx, S, P, 'rgba(0,0,0,.5)', h * .06, 0, h * .03);
  ctx.save();
  const base = o.cardColor || '#1c1c20';
  let g = ctx.createLinearGradient(0, y, 0, y + h / 2); g.addColorStop(0, mix(base, '#ffffff', .1)); g.addColorStop(1, mix(base, '#ffffff', .02));
  ctx.save(); ctx.beginPath(); ctx.rect(x, y, w, h / 2); ctx.clip(); ctx.fillStyle = g; ctx.fill(P); ctx.restore();
  g = ctx.createLinearGradient(0, y + h / 2, 0, y + h); g.addColorStop(0, mix(base, '#000000', .15)); g.addColorStop(1, mix(base, '#000000', .3));
  ctx.save(); ctx.beginPath(); ctx.rect(x, y + h / 2, w, h / 2); ctx.clip(); ctx.fillStyle = g; ctx.fill(P); ctx.restore();
  ctx.fillStyle = 'rgba(0,0,0,.55)'; ctx.fillRect(x, y + h / 2 - Math.max(.8, h * .008), w, Math.max(1.6, h * .016));
  for (const sx of [x - w * .02, x + w * .98]) { ctx.fillStyle = mix(base, '#888888', .5); ctx.beginPath(); rrPath(ctx, sx, y + h * .44, w * .04, h * .12, w * .01); ctx.fill(); }
  ctx.strokeStyle = 'rgba(255,255,255,.08)'; ctx.lineWidth = 1; ctx.stroke(P);
  ctx.restore();
}
/* colours before the painter's look object exists (layout time) */
function L_textOf(d) { const sp = buildSpec(d); return sp.text.slice(0, 7); }
function L_subOf(d) { const sp = buildSpec(d); return sp.sub.length === 9 ? rgba(sp.sub.slice(0, 7), parseInt(sp.sub.slice(7), 16) / 255) : sp.sub; }
function L_accOf(d) { const sp = buildSpec(d); return sp.acc.slice(0, 7); }

/* ---------------------------------------------------------- DATE */
function layDate(d, LY, C, now) {
  const o = d.date, B = LY.B, v = o.variant, K = (o.scale || 100) / 100;
  const dct = (ctx, t, x, y, size, ...r) => drawClockText(ctx, t, x, y, size * K, ...r);
  const di = dateInfo(now, { calc: o.calc, offset: o.offset, lang: o.lang, digits: o.digits });
  const occ = o.occasions ? occasionsOf(now, { calc: o.calc, offset: o.offset, white: o.white, national: o.national, lang: o.lang }) : [];
  const phrase = o.phrase ? dailyPhrase(now, o.phraseSet, o.lang, o.phraseText) : '';
  const nf = o.numFont || 'serif', fam = textFam(o.tfont);
  useClockFont(nf, o.digits); useClockFont(o.font || 'light', o.digits);
  const hijriFirst = o.primary !== 'greg';
  const P1 = hijriFirst ? { day: di.hDay, month: di.hMonth, year: di.hYear + ' ' + di.H } : { day: di.gDay, month: di.gMonth, year: di.gYear + ' ' + di.G };
  const P2 = hijriFirst ? { day: di.gDay, month: di.gMonth, year: di.gYear + ' ' + di.G, full: di.gFull } : { day: di.hDay, month: di.hMonth, year: di.hYear + ' ' + di.H, full: di.hFull };
  const one = o.show !== 'both';
  const only = o.show === 'greg' ? { day: di.gDay, month: di.gMonth, year: di.gYear + ' ' + di.G } : o.show === 'hijri' ? { day: di.hDay, month: di.hMonth, year: di.hYear + ' ' + di.H } : null;
  const block = (ctx, S, L, x, y, w, h, b, accent) => { // big day + month + year
    const ds = Math.min(h * .55, w * .5);
    dct(ctx, b.day, x + w / 2, y + h * .33, ds, nf, o.digits, accent ? L.acc : L.text);
    tText(ctx, S, b.month, x + w / 2, y + h * .7, w, { size: Math.min(h * .17, w * .16), f: o.tfont, weight: 700, color: L.text });
    tText(ctx, S, b.year, x + w / 2, y + h * .89, w, { size: Math.min(h * .12, w * .11), f: o.tfont, color: L.sub });
  };
  const dateHit = () => tapHit(LY, d, B);
  if (v === 'mini') {
    LY.nodes.push({ k: 'draw', fn: (ctx, S, L) => {
      const b = only || P1, wide = C.w > C.h * 1.4;
      if (wide) {
        const ds = C.h * .78; dct(ctx, b.day, C.x + C.w - C.h * .5, C.y + C.h / 2, ds, nf, o.digits, L.acc);
        tText(ctx, S, di.weekday, C.x + (C.w - C.h) / 2, C.y + C.h * .3, C.w - C.h * 1.05, { size: C.h * .24, f: o.tfont, weight: 700, color: L.text });
        tText(ctx, S, b.month, C.x + (C.w - C.h) / 2, C.y + C.h * .62, C.w - C.h * 1.05, { size: C.h * .2, f: o.tfont, color: L.sub });
        if (!one) tText(ctx, S, P2.day + ' ' + P2.month, C.x + (C.w - C.h) / 2, C.y + C.h * .86, C.w - C.h * 1.05, { size: C.h * .15, f: o.tfont, color: L.acc });
      } else {
        tText(ctx, S, di.weekday, C.x + C.w / 2, C.y + C.h * .13, C.w, { size: C.h * .14, f: o.tfont, weight: 700, color: L.acc });
        dct(ctx, b.day, C.x + C.w / 2, C.y + C.h * .47, C.h * .44, nf, o.digits, L.text);
        tText(ctx, S, b.month, C.x + C.w / 2, C.y + C.h * .78, C.w, { size: C.h * .14, f: o.tfont, weight: 600, color: L.text });
        if (!one) tText(ctx, S, P2.day + ' ' + P2.month, C.x + C.w / 2, C.y + C.h * .94, C.w, { size: C.h * .1, f: o.tfont, color: L.sub });
      }
    } });
    return dateHit();
  }
  if (v === 'calendar') { layCalendar(d, LY, C, now, di, occ); return dateHit(); }
  if (v === 'combo') {
    const th = C.h * .48;
    addLive(LY, { kind: 'time', font: o.font || 'light', digits: o.digits, mode: o.fmt || 'system', color: L_textOf(d), lang: o.lang, x: C.x, y: C.y, w: C.w, h: th });
    LY.nodes.push({ k: 'draw', fn: (ctx, S, L) => {
      ctx.save(); ctx.strokeStyle = rgba(L.frameColor, .55); ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(C.x + C.w * .25, C.y + th + C.h * .03); ctx.lineTo(C.x + C.w * .75, C.y + th + C.h * .03); ctx.stroke(); ctx.restore();
      const lines = [{ t: di.weekday, k: 'wd' }]; if (o.show !== 'greg') lines.push({ t: di.hFull, k: 'h' }); if (o.show !== 'hijri') lines.push({ t: di.gFull, k: 'g' });
      drawInfoLines(ctx, S, L, lines, C.x, C.y + th + C.h * .06, C.w, C.h - th - C.h * .06, o, 'center');
    } });
    return dateHit();
  }
  if (v === 'big') {
    LY.nodes.push({ k: 'draw', fn: (ctx, S, L) => {
      const b = only || P1, wide = C.w > C.h * 1.35;
      const phH = phrase ? C.h * (wide ? .22 : .2) : 0, occH = occ.length ? C.h * .1 : 0;
      const mainH = C.h - phH - occH;
      if (wide) {
        const dw = Math.min(mainH * 1.1, C.w * .4);
        dct(ctx, b.day, C.x + C.w - dw / 2, C.y + mainH * .5, Math.min(mainH * .92, dw * .75), nf, o.digits, L.acc);
        const tx = C.x, tw = C.w - dw - C.w * .04;
        tText(ctx, S, di.weekday, tx + tw / 2, C.y + mainH * .2, tw, { size: mainH * .16, f: o.tfont, weight: 700, color: L.text });
        tText(ctx, S, b.month + ' ' + b.year, tx + tw / 2, C.y + mainH * .46, tw, { size: mainH * .15, f: o.tfont, weight: 600, color: L.text });
        if (!one) tText(ctx, S, P2.full || (P2.day + ' ' + P2.month + ' ' + P2.year), tx + tw / 2, C.y + mainH * .72, tw, { size: mainH * .12, f: o.tfont, color: L.sub });
      } else {
        tText(ctx, S, di.weekday, C.x + C.w / 2, C.y + mainH * .09, C.w, { size: mainH * .1, f: o.tfont, weight: 700, color: L.sub });
        dct(ctx, b.day, C.x + C.w / 2, C.y + mainH * .4, Math.min(mainH * .46, C.w * .5), nf, o.digits, L.acc);
        tText(ctx, S, b.month, C.x + C.w / 2, C.y + mainH * .68, C.w, { size: Math.min(mainH * .1, C.w * .13), f: o.tfont, weight: 700, color: L.text });
        tText(ctx, S, b.year, C.x + C.w / 2, C.y + mainH * .79, C.w, { size: Math.min(mainH * .07, C.w * .09), f: o.tfont, color: L.sub });
        if (!one) tText(ctx, S, P2.day + ' ' + P2.month + ' ' + P2.year, C.x + C.w / 2, C.y + mainH * .91, C.w, { size: Math.min(mainH * .07, C.w * .085), f: o.tfont, color: L.sub });
      }
      if (occ.length) occasionBanner(ctx, S, L, occ[0].text, C.x + C.w * .1, C.y + mainH, C.w * .8, occH * .9, o);
      if (phrase) phraseBlock(ctx, S, L, phrase, C.x, C.y + C.h - phH, C.w, phH, o);
    } });
    return dateHit();
  }
  if (v === 'islamic') {
    LY.nodes.push({ k: 'draw', fn: (ctx, S, L) => {
      const ax = C.x + C.w * .06, aw = C.w * .88, ay = C.y + C.h * .02, ah = C.h * (phrase ? .74 : .96);
      // mihrab arch with a double gold line and stars
      const arch = (inset) => { const p = new Path2D(), x0 = ax + inset, x1 = ax + aw - inset, yb = ay + ah - inset, yt = ay + inset, cx = (x0 + x1) / 2, rr = (x1 - x0) / 2;
        p.moveTo(x0, yb); p.lineTo(x0, yt + rr * .9); p.bezierCurveTo(x0, yt + rr * .25, cx - rr * .35, yt + rr * .1, cx, yt); p.bezierCurveTo(cx + rr * .35, yt + rr * .1, x1, yt + rr * .25, x1, yt + rr * .9); p.lineTo(x1, yb); p.closePath(); return p; };
      const outer = arch(0), inner = arch(Math.min(aw, ah) * .035);
      ctx.save(); ctx.fillStyle = rgba(L.darkText ? '#ffffff' : '#000000', L.darkText ? .35 : .18); ctx.fill(outer);
      ctx.lineWidth = Math.max(1, C.w * .008); ctx.strokeStyle = L.frameColor; ctx.stroke(outer); ctx.lineWidth = Math.max(.6, C.w * .004); ctx.stroke(inner);
      const st = new Path2D(); star8(st, ax + aw / 2, ay + Math.min(aw, ah) * .16, Math.min(aw, ah) * .05); ctx.fillStyle = L.frameColor; ctx.fill(st);
      for (const sx of [ax + aw * .14, ax + aw * .86]) { const s2 = new Path2D(); star8(s2, sx, ay + ah * .5, Math.min(aw, ah) * .025); ctx.fill(s2); }
      ctx.restore();
      const cx = ax + aw / 2, top = ay + ah * .26;
      tText(ctx, S, di.weekday, cx, top, aw * .8, { size: ah * .085, f: o.tfont, weight: 700, color: L.text });
      dct(ctx, di.hDay, cx, top + ah * .2, Math.min(ah * .24, aw * .4), nf, o.digits, L.acc);
      tText(ctx, S, di.hMonth, cx, top + ah * .38, aw * .82, { size: Math.min(ah * .08, aw * .12), f: o.tfont, weight: 700, color: L.text });
      tText(ctx, S, di.hYear + ' ' + di.H, cx, top + ah * .46, aw * .8, { size: Math.min(ah * .055, aw * .085), f: o.tfont, color: L.sub });
      tText(ctx, S, di.gFull, cx, top + ah * .54, aw * .86, { size: Math.min(ah * .05, aw * .075), f: o.tfont, color: L.sub });
      if (occ.length) occasionBanner(ctx, S, L, occ[0].text, ax + aw * .14, top + ah * .6, aw * .72, ah * .09, o);
      if (phrase) phraseBlock(ctx, S, L, phrase, C.x, C.y + C.h * .77, C.w, C.h * .23, o);
    } });
    return dateHit();
  }
  // dual
  LY.nodes.push({ k: 'draw', fn: (ctx, S, L) => {
    const wide = C.w > C.h * 1.35;
    const wdH = o.weekday ? C.h * (wide ? .2 : .14) : 0, occH = occ.length ? C.h * .11 : 0;
    if (o.weekday) tText(ctx, S, di.weekday, C.x + C.w / 2, C.y + wdH * .45, C.w, { size: wdH * .62, f: o.tfont, weight: 700, color: L.text });
    const by = C.y + wdH, bh = C.h - wdH - occH;
    if (one) block(ctx, S, L, C.x, by, C.w, bh, only, true);
    else if (wide) {
      const cw = C.w / 2;
      block(ctx, S, L, C.x + cw, by, cw, bh, P1, true); block(ctx, S, L, C.x, by, cw, bh, P2, false);
      ctx.save(); ctx.strokeStyle = rgba(L.frameColor, .7); ctx.lineWidth = Math.max(.8, C.w * .004); ctx.beginPath(); ctx.moveTo(C.x + cw, by + bh * .1); ctx.lineTo(C.x + cw, by + bh * .9); ctx.stroke();
      const st = new Path2D(); star4(st, C.x + cw, by + bh * .5, Math.min(cw, bh) * .07); ctx.fillStyle = L.frameColor; ctx.fill(st); ctx.restore();
    } else {
      const hh = bh / 2;
      block(ctx, S, L, C.x, by, C.w, hh * .98, P1, true);
      drawDivider(ctx, S, C.x + C.w * .15, by + hh, C.w * .7, 'islamic', L.frameColor, Math.min(1, C.w / 160));
      block(ctx, S, L, C.x, by + hh * 1.02, C.w, hh * .98, P2, false);
    }
    if (occ.length) occasionBanner(ctx, S, L, occ[0].text, C.x + C.w * .1, C.y + C.h - occH, C.w * .8, occH * .92, o);
  } });
  dateHit();
}
function occasionBanner(ctx, S, L, text, x, y, w, h, o) {
  ctx.save();
  const p = new Path2D(); const r = h / 2;
  p.moveTo(x + r, y); p.lineTo(x + w - r, y); p.lineTo(x + w, y + h / 2); p.lineTo(x + w - r, y + h); p.lineTo(x + r, y + h); p.lineTo(x, y + h / 2); p.closePath();
  ctx.fillStyle = rgba(L.frameColor, .2); ctx.fill(p); ctx.lineWidth = Math.max(.6, h * .05); ctx.strokeStyle = rgba(L.frameColor, .85); ctx.stroke(p);
  ctx.restore();
  tText(ctx, S, text, x + w / 2, y + h / 2, w - h * 1.2, { size: h * .5, f: o.tfont, weight: 700, color: L.text });
}
function phraseBlock(ctx, S, L, text, x, y, w, h, o) {
  const fam = textFam(o.tfont);
  let size = Math.min(h * .36, w * .065);
  let lines = wrapText(ctx, text, w * .92, size, fam, 500, 2);
  if (lines.length === 1) size = Math.min(h * .42, size * 1.15), lines = wrapText(ctx, text, w * .92, size, fam, 500, 2);
  const lh = size * 1.45, y0 = y + h / 2 - (lines.length - 1) * lh / 2;
  lines.forEach((ln, i) => tText(ctx, S, ln, x + w / 2, y0 + i * lh, w * .94, { size, f: o.tfont, color: L.acc, weight: 500 }));
}
function layCalendar(d, LY, C, now, di, occ) {
  const o = d.date, hijri = o.primary !== 'greg', ws = +o.weekStart || 0, K = (o.scale || 100) / 100;
  const dct = (ctx, t, x, y, size, ...r) => drawClockText(ctx, t, x, y, size * K, ...r);
  const days = [];
  let title, sub;
  if (hijri) {
    const hm = hijriMonth(now, o.calc, o.offset);
    for (let i = 0; i < hm.len; i++) days.push(new Date(hm.first.getFullYear(), hm.first.getMonth(), hm.first.getDate() + i));
    title = toDigits(`${HIJRI_MONTHS[o.lang === 'en' ? 'en' : 'ar'][hm.m - 1]} ${hm.y}`, o.digits);
    const a = days[0], b = days[days.length - 1], gm = GREG_MONTHS[o.lang === 'en' ? 'en' : 'ar'];
    sub = a.getMonth() === b.getMonth() ? `${gm[a.getMonth()]} ${toDigits(a.getFullYear(), o.digits)}` : `${gm[a.getMonth()]} – ${gm[b.getMonth()]} ${toDigits(b.getFullYear(), o.digits)}`;
  } else {
    const n = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
    for (let i = 1; i <= n; i++) days.push(new Date(now.getFullYear(), now.getMonth(), i));
    title = `${di.gMonth} ${di.gYear}`;
    const h1 = hijriOf(days[0], o.calc, o.offset), h2 = hijriOf(days[n - 1], o.calc, o.offset), hm = HIJRI_MONTHS[o.lang === 'en' ? 'en' : 'ar'];
    sub = h1.m === h2.m ? `${hm[h1.m - 1]} ${toDigits(h1.y, o.digits)}` : `${hm[h1.m - 1]} – ${hm[h2.m - 1]} ${toDigits(h2.y, o.digits)}`;
  }
  const lead = (days[0].getDay() - ws + 7) % 7, rows = Math.ceil((lead + days.length) / 7);
  const nextOcc = o.occasions && !occ.length ? nextOccasion(now, { calc: o.calc, offset: o.offset, national: o.national, lang: o.lang }) : null;
  LY.nodes.push({ k: 'draw', fn: (ctx, S, L) => {
    const headH = C.h * .16, wdH = C.h * .08, footH = (occ.length || nextOcc) ? C.h * .09 : 0;
    const gx = C.x, gy = C.y + headH + wdH, gw = C.w, gh = C.h - headH - wdH - footH, cw = gw / 7, ch = gh / rows;
    tText(ctx, S, title, C.x + C.w / 2, C.y + headH * .38, C.w, { size: headH * .42, f: o.tfont, weight: 700, color: L.text });
    tText(ctx, S, sub, C.x + C.w / 2, C.y + headH * .8, C.w, { size: headH * .26, f: o.tfont, color: L.sub });
    const names = WEEKDAYS[o.lang === 'en' ? 'enShort' : 'arShort'];
    for (let i = 0; i < 7; i++) { const wd = (ws + i) % 7; const x = gx + gw - (i + 1) * cw; tText(ctx, S, o.lang === 'en' ? names[wd].slice(0, 2) : names[wd].slice(0, o.lang === 'en' ? 2 : 3), x + cw / 2, C.y + headH + wdH * .5, cw, { size: Math.min(wdH * .55, cw * .3), f: o.tfont, weight: 700, color: wd === 5 ? L.acc : L.sub }); }
    const todayKey = isoDay(now), tc = o.todayColor || L.acc;
    days.forEach((dt, i) => {
      const slot = lead + i, r = Math.floor(slot / 7), c = slot % 7;
      const x = gx + gw - (c + 1) * cw, y = gy + r * ch, cx = x + cw / 2, cy = y + ch / 2;
      const isToday = isoDay(dt) === todayKey;
      const main = hijri ? (i + 1) : dt.getDate();
      const second = hijri ? dt.getDate() : hijriOf(dt, o.calc, o.offset).d;
      if (isToday) { ctx.save(); const rr = Math.min(cw, ch) * .46; const g = ctx.createRadialGradient(cx - rr * .3, cy - rr * .3, 0, cx, cy, rr); g.addColorStop(0, mix(tc, '#ffffff', .25)); g.addColorStop(1, tc); ctx.fillStyle = g; ctx.shadowColor = rgba(tc, .6); ctx.shadowBlur = rr * .5 * S; ctx.beginPath(); ctx.arc(cx, cy, rr, 0, TAU); ctx.fill(); ctx.restore(); }
      const col = isToday ? (lum(tc) > .5 ? '#1d1a16' : '#ffffff') : dt.getDay() === 5 ? L.acc : L.text;
      dct(ctx, toDigits(main, o.digits), cx, cy - ch * .1, Math.min(ch * .42, cw * .45), o.numFont || 'medium', o.digits, col);
      dct(ctx, toDigits(second, o.digits), cx, cy + ch * .25, Math.min(ch * .22, cw * .25), o.numFont || 'medium', o.digits, isToday ? rgba(col, .8) : L.sub);
      if (o.occasions && occasionsOf(dt, { calc: o.calc, offset: o.offset, national: o.national, white: false }).length) { ctx.fillStyle = isToday ? col : L.frameColor; ctx.beginPath(); ctx.arc(cx + Math.min(cw, ch) * .32, cy - ch * .3, Math.max(1.2, ch * .045), 0, TAU); ctx.fill(); }
    });
    if (footH) { const t = occ.length ? occ[0].text : (o.lang === 'en' ? `${nextOcc.text} in ${nextOcc.inDays} days` : `${nextOcc.text} بعد ${toDigits(nextOcc.inDays, o.digits)} ${nextOcc.inDays <= 10 && nextOcc.inDays > 2 ? 'أيام' : 'يوماً'}`); tText(ctx, S, t, C.x + C.w / 2, C.y + C.h - footH / 2, C.w, { size: footH * .5, f: o.tfont, weight: 600, color: L.acc }); }
  } });
}

/* ---------------------------------------------------------- WEATHER */
const hiloStr = wv => `↑${wv.hi}   ↓${wv.lo}`;
function layWeather(d, LY, C, now) {
  const o = d.weather, B = LY.B, v = o.variant, sh = o.show;
  const loc = locOf(d), entry = wxCached(loc), wv = wxView(entry, d);
  LY.info.wx = { loc, has: !!wv, err: entry && entry.err, at: entry && entry.at };
  LY.bg = weatherBg(d, wv, B, LY);
  const onScene = o.bg.mode !== 'none';
  const nf = o.numFont || 'light'; useClockFont(nf, o.digits);
  const city = loc ? (o.lang === 'en' && loc.en ? loc.en : loc.name) : (o.lang === 'en' ? 'Location needed' : 'حدّد الموقع');
  const shadow = onScene ? 'rgba(0,0,0,.55)' : null;
  const T = (ctx, S, L) => onScene && !d.a.text ? { text: '#ffffff', sub: 'rgba(255,255,255,.82)', acc: '#ffffff' } : { text: L.text, sub: L.sub, acc: L.acc };
  const isz = (o.iconSize || 100) / 100, ist = o.iconStyle;
  const msg = !loc ? (o.lang === 'en' ? 'Allow location or pick a city' : 'اسمح بالموقع أو اختر مدينة') : entry && entry.err && !wv ? (o.lang === 'en' ? 'Could not update — tap to retry' : 'تعذّر التحديث — اضغط للمحاولة') : (o.lang === 'en' ? 'Waiting for weather data' : 'بانتظار بيانات الطقس');
  const upd = wv && sh.updated ? (o.lang === 'en' ? 'Updated ' : 'تحديث ') + wv.updated + (wv.stale ? (o.lang === 'en' ? ' · old' : ' · قديم') : '') : '';
  const align = o.tempPos === 'center' ? 'center' : o.tempPos === 'end' ? 'end' : 'start';
  const ax = (x, w) => align === 'center' ? x + w / 2 : align === 'end' ? x : x + w;
  const temp = (ctx, x, y, size, c) => { const t = wv ? wv.temp : '—°'; const w = measureClockText(ctx, t, size, nf, o.digits); const cx = align === 'center' ? x : align === 'end' ? x + w / 2 : x - w / 2; drawClockText(ctx, t, cx, y, size, nf, o.digits, c); return w; };
  LY.nodes.push({ k: 'draw', fn: (ctx, S, L) => {
    const c = T(ctx, S, L);
    const stat = (x, y, w, h) => tText(ctx, S, msg, x + w / 2, y + h / 2, w, { size: Math.min(h * .4, w * .07), color: c.sub, shadow, f: o.tfont });
    if (v === 'round') {
      const cx = B.x + B.w / 2, cy = B.y + B.h / 2, R = B.w / 2;
      // temperature ring: cold → hot, with today's range and the current reading
      const rr = R * .86, lw = R * .07, a0 = Math.PI * .75, a1 = Math.PI * 2.25;
      ctx.save(); ctx.lineCap = 'round'; ctx.lineWidth = lw;
      ctx.strokeStyle = 'rgba(255,255,255,.18)'; ctx.beginPath(); ctx.arc(cx, cy, rr, a0, a1); ctx.stroke();
      if (wv && wv.loC != null) {
        const tmin = -10, tmax = 50, f = t => clamp((t - tmin) / (tmax - tmin), 0, 1);
        const g = ctx.createConicGradient ? ctx.createConicGradient(a0 - .02, cx, cy) : null;
        if (g) { g.addColorStop(0, '#4aa8ff'); g.addColorStop(.25, '#5fd7c4'); g.addColorStop(.45, '#ffd23a'); g.addColorStop(.65, '#ff8a3a'); g.addColorStop(.75, '#e8433a'); g.addColorStop(1, '#4aa8ff'); }
        ctx.strokeStyle = g || '#ffb03a'; ctx.beginPath(); ctx.arc(cx, cy, rr, a0 + (a1 - a0) * f(wv.loC), a0 + (a1 - a0) * Math.max(f(wv.hiC), f(wv.loC) + .02)); ctx.stroke();
        const ac = a0 + (a1 - a0) * f(wv.tempC);
        ctx.fillStyle = '#ffffff'; ctx.shadowColor = 'rgba(0,0,0,.5)'; ctx.shadowBlur = lw * S; ctx.beginPath(); ctx.arc(cx + Math.cos(ac) * rr, cy + Math.sin(ac) * rr, lw * .75, 0, TAU); ctx.fill();
      }
      ctx.restore();
      if (wv) drawWxIcon(ctx, S, wxIcon(wv.code), wv.day, cx, cy - R * .36, R * .36 * isz, ist);
      drawClockText(ctx, wv ? wv.temp : '—°', cx + R * .05, cy + R * .06, R * .5, nf, o.digits, c.text);
      if (sh.city) tText(ctx, S, city, cx, cy + R * .42, R * 1.1, { size: R * .12, weight: 600, color: c.text, shadow, f: o.tfont });
      if (wv && sh.hilo) tText(ctx, S, hiloStr(wv), cx, cy + R * .6, R, { size: R * .1, color: c.sub, shadow, f: o.tfont, dir: 'ltr' });
      if (!wv) tText(ctx, S, msg, cx, cy + R * .62, R * 1.2, { size: R * .08, color: c.sub, shadow, f: o.tfont });
      return;
    }
    if (v === 'mini') {
      const wide = C.w > C.h * 1.3;
      if (wide) {
        const ic = C.h * .7 * isz;
        if (wv) drawWxIcon(ctx, S, wxIcon(wv.code), wv.day, C.x + C.w - ic * .55, C.y + C.h / 2, ic, ist);
        drawClockText(ctx, wv ? wv.temp : '—°', C.x + (C.w - ic) / 2, C.y + C.h * .4, C.h * .55, nf, o.digits, c.text);
        if (sh.city) tText(ctx, S, city, C.x + (C.w - ic) / 2, C.y + C.h * .84, C.w - ic, { size: C.h * .18, color: c.sub, shadow, f: o.tfont });
      } else {
        if (wv) drawWxIcon(ctx, S, wxIcon(wv.code), wv.day, C.x + C.w / 2, C.y + C.h * .28, C.h * .4 * isz, ist);
        drawClockText(ctx, wv ? wv.temp : '—°', C.x + C.w / 2 + C.h * .03, C.y + C.h * .66, C.h * .34, nf, o.digits, c.text);
        if (sh.city) tText(ctx, S, city, C.x + C.w / 2, C.y + C.h * .92, C.w, { size: C.h * .12, color: c.sub, shadow, f: o.tfont });
      }
      return;
    }
    if (v === 'panorama') {
      const lw = C.w * .48;
      const x0 = align === 'end' ? C.x : C.x + C.w - lw;
      const tx = ax(x0, lw);
      if (sh.city) tText(ctx, S, city, tx, C.y + C.h * .14, lw, { size: C.h * .13, weight: 700, color: c.text, shadow, f: o.tfont, align });
      temp(ctx, tx, C.y + C.h * .48, C.h * .44, c.text);
      if (wv && sh.desc) tText(ctx, S, wv.desc, tx, C.y + C.h * .76, lw, { size: C.h * .1, color: c.text, shadow, f: o.tfont, align, weight: 600 });
      if (wv && sh.hilo) tText(ctx, S, hiloStr(wv), tx, C.y + C.h * .89, lw, { size: C.h * .085, color: c.sub, shadow, f: o.tfont, align, dir: 'ltr' });
      if (!wv) stat(x0, C.y + C.h * .7, lw, C.h * .2);
      if (wv && sh.daily) {
        const n = Math.min(4, wv.days.length - 1), cw = (C.w - lw - C.w * .04) / Math.max(1, n), bx = align === 'end' ? C.x + C.w - n * cw : C.x;
        for (let i = 0; i < n; i++) {
          const dd = wv.days[i + 1], x = bx + (n - 1 - i) * cw;
          tText(ctx, S, dd.n, x + cw / 2, C.y + C.h * .22, cw, { size: C.h * .1, color: c.sub, shadow, f: o.tfont, weight: 600 });
          drawWxIcon(ctx, S, wxIcon(dd.code), true, x + cw / 2, C.y + C.h * .48, C.h * .26 * isz, ist);
          drawClockText(ctx, dd.hi, x + cw / 2, C.y + C.h * .74, Math.min(C.h * .11, cw * .3), nf, o.digits, c.text);
          drawClockText(ctx, dd.lo, x + cw / 2, C.y + C.h * .87, Math.min(C.h * .085, cw * .24), nf, o.digits, c.sub);
        }
      }
      if (upd) tText(ctx, S, upd, C.x + C.w / 2, C.y + C.h * .98, C.w, { size: C.h * .065, color: c.sub, shadow, f: o.tfont });
      return;
    }
    // medium & large
    const large = v === 'large' && C.h > 150;
    const headH = large ? C.h * .3 : C.h;
    const hx = C.x, hw = C.w;
    const icon = Math.min(headH * .4, C.w * .24) * isz;
    const tx = ax(hx, hw - (align === 'start' || align === 'center' ? 0 : 0));
    if (sh.city) tText(ctx, S, city + (loc && loc.mode === 'device' ? ' ⌖' : ''), tx, C.y + headH * .13, hw * .7, { size: headH * .12, weight: 700, color: c.text, shadow, f: o.tfont, align });
    const tw = temp(ctx, tx, C.y + headH * .44, headH * .38, c.text);
    if (wv) drawWxIcon(ctx, S, wxIcon(wv.code), wv.day, align === 'end' ? C.x + C.w - icon * .6 : align === 'center' ? C.x + icon * .6 : C.x + icon * .6, C.y + headH * .3, icon, ist);
    if (wv) {
      if (sh.desc) tText(ctx, S, wv.desc, tx, C.y + headH * .72, hw * .7, { size: headH * .1, color: c.text, shadow, f: o.tfont, align, weight: 600 });
      if (sh.hilo) tText(ctx, S, hiloStr(wv), tx, C.y + headH * .87, hw * .5, { size: headH * .085, color: c.sub, shadow, f: o.tfont, align, dir: 'ltr' });
      if (sh.feels) tText(ctx, S, (o.lang === 'en' ? 'Feels ' : 'المحسوسة ') + wv.feels, align === 'end' ? C.x + C.w : C.x, C.y + headH * .87, hw * .45, { size: headH * .08, color: c.sub, shadow, f: o.tfont, align: align === 'end' ? 'start' : 'end' });
    } else stat(C.x, C.y + headH * .66, C.w, headH * .26);
    if (!large) { if (upd) tText(ctx, S, upd, align === 'end' ? C.x + C.w : C.x, C.y + C.h * .97, C.w * .6, { size: C.h * .06, color: c.sub, shadow, f: o.tfont, align: align === 'end' ? 'start' : 'end' }); return; }
    // details row
    let y = C.y + headH + C.h * .02;
    const det = [];
    if (wv) {
      if (sh.hum) det.push([o.lang === 'en' ? 'Humidity' : 'الرطوبة', wv.hum]);
      if (sh.wind) det.push([o.lang === 'en' ? 'Wind' : 'الرياح', wv.wind]);
      if (sh.aqi && wv.aqi != null) det.push([o.lang === 'en' ? 'Air quality' : 'جودة الهواء', wv.aqi + ' ' + wv.aqiText, wv.aqiColor]);
      if (sh.sun) { det.push([o.lang === 'en' ? 'Sunrise' : 'الشروق', wv.sunrise]); det.push([o.lang === 'en' ? 'Sunset' : 'الغروب', wv.sunset]); }
      if (sh.uv) det.push([o.lang === 'en' ? 'UV' : 'الأشعة', wv.uv]);
    }
    const panel = (yy, hh) => { const P = rrPath(new Path2D(), C.x, yy, C.w, hh, Math.min(14, hh * .2)); ctx.save(); ctx.fillStyle = onScene ? 'rgba(0,0,0,.22)' : rgba(L.darkText ? '#000000' : '#ffffff', .06); ctx.fill(P); ctx.restore(); };
    if (wv && sh.hourly && wv.hours.length) {
      const hh = C.h * .22; panel(y, hh);
      const n = Math.min(6, wv.hours.length), cw = C.w / n;
      for (let i = 0; i < n; i++) { const h1 = wv.hours[i], x = C.x + C.w - (i + 1) * cw;
        tText(ctx, S, h1.t, x + cw / 2, y + hh * .18, cw, { size: hh * .14, color: c.sub, shadow, f: o.tfont });
        drawWxIcon(ctx, S, wxIcon(h1.code), h1.day, x + cw / 2, y + hh * .48, hh * .34 * isz, ist);
        drawClockText(ctx, h1.temp, x + cw / 2, y + hh * .8, hh * .2, nf, o.digits, c.text); }
      y += hh + C.h * .02;
    }
    if (wv && sh.daily && wv.days.length > 1) {
      const n = Math.min(5, wv.days.length - 1), rh = Math.min(C.h * .07, (C.y + C.h - y - (det.length ? C.h * .16 : 0)) / n);
      for (let i = 0; i < n; i++) { const dd = wv.days[i + 1], yy = y + i * rh + rh / 2;
        tText(ctx, S, dd.n, C.x + C.w, yy, C.w * .25, { size: rh * .5, color: c.text, shadow, f: o.tfont, align: 'start', weight: 600 });
        drawWxIcon(ctx, S, wxIcon(dd.code), true, C.x + C.w * .62, yy, rh * .8 * isz, ist);
        // range bar
        const bx = C.x + C.w * .18, bw = C.w * .3; ctx.save(); ctx.lineCap = 'round'; ctx.lineWidth = rh * .14; ctx.strokeStyle = 'rgba(255,255,255,.2)'; ctx.beginPath(); ctx.moveTo(bx, yy); ctx.lineTo(bx + bw, yy); ctx.stroke();
        const g = ctx.createLinearGradient(bx, 0, bx + bw, 0); g.addColorStop(0, '#5fd7c4'); g.addColorStop(1, '#ffb03a'); ctx.strokeStyle = g; const f = t => clamp((t + 10) / 60, 0, 1); ctx.beginPath(); ctx.moveTo(bx + bw * f(dd.loC), yy); ctx.lineTo(bx + bw * Math.max(f(dd.hiC), f(dd.loC) + .03), yy); ctx.stroke(); ctx.restore();
        drawClockText(ctx, dd.hi, C.x + C.w * .5 + rh * .3, yy, rh * .45, nf, o.digits, c.text);
        drawClockText(ctx, dd.lo, C.x + C.w * .09, yy, rh * .45, nf, o.digits, c.sub); }
      y += n * rh + C.h * .015;
    }
    if (det.length) {
      const hh = C.y + C.h - y - (upd ? C.h * .045 : 0); if (hh > 14) {
        panel(y, hh);
        const n = Math.min(det.length, C.w > 260 ? 5 : 4), cw = C.w / n;
        for (let i = 0; i < n; i++) { const [k, val, col] = det[i], x = C.x + C.w - (i + 1) * cw;
          tText(ctx, S, k, x + cw / 2, y + hh * .32, cw * .95, { size: Math.min(hh * .22, cw * .14), color: c.sub, shadow, f: o.tfont });
          tText(ctx, S, val, x + cw / 2, y + hh * .68, cw * .95, { size: Math.min(hh * .26, cw * .16), color: col || c.text, shadow, f: o.tfont, weight: 700 }); }
      }
    }
    if (upd) tText(ctx, S, upd, C.x + C.w / 2, C.y + C.h - C.h * .02, C.w, { size: C.h * .035, color: c.sub, shadow, f: o.tfont });
  } });
  tapHit(LY, d, B);
}

/* ---------------------------------------------------------- entry */
function layoutTime(d, W, H) {
  const m = fxMargin(d, W, H);
  const B = timeBody(d, W, H, m);
  const LY = { B, nodes: [], hits: [], info: {}, live: [], time: true };
  const pad = Math.min(d.a.padding + frameAllowance(d), Math.min(B.w, B.h) * .2);
  const C = B.circle ? { x: B.x + pad * .5, y: B.y + pad * .5, w: B.w - pad, h: B.h - pad } : { x: B.x + pad, y: B.y + pad, w: B.w - 2 * pad, h: B.h - 2 * pad };
  const now = new Date();
  if (d.type === 'clock') layClock(d, LY, C, now);
  else if (d.type === 'date') layDate(d, LY, C, now);
  else layWeather(d, LY, C, now);
  return LY;
}
/** Fonts a time design uses (so canvases wait for them before drawing/baking). */
async function ensureTimeFonts(d) {
  const o = d[d.type] || {}, jobs = [];
  if (o.font) jobs.push(useClockFont(o.font, o.digits));
  if (d.type === 'clock' && o.face === 'digital' && o.layout === 'led') jobs.push(useClockFont('led', 'latn'));
  if (o.numFont) jobs.push(useClockFont(o.numFont, o.digits));
  if (d.type === 'clock') jobs.push(useClockFont(o.numFont || (o.numerals === 'roman' ? 'royal' : 'serif'), o.numerals === 'arabic' ? 'arab' : 'latn'), useClockFont('medium', o.digits));
  if (d.type === 'date') jobs.push(useClockFont('medium', o.digits));
  try { if (document.fonts && document.fonts.load) jobs.push(document.fonts.load(`700 20px ${textFam(o.tfont)}`, 'أبجد'), document.fonts.load(`500 20px ${textFam(o.tfont)}`, 'أبجد')); } catch (e) {}
  await Promise.race([Promise.all(jobs), new Promise(r => setTimeout(r, 4000))]);
}
/** What a bake of this design depends on besides the design itself (day, weather reading). */
function timeKeyOf(d) {
  if (!isTimeType(d)) return '';
  let k = isoDay(new Date());
  if (d.type === 'weather') { const e = wxCached(locOf(d)); k += '|' + (e ? (e.at || 0) + (e.err ? 'e' : '') : 'none') + '|' + todOf(new Date()); }
  if (d.type === 'clock' && d.clock.wx) { const e = wxCached(store.get('llx.clockloc', null) || DEFAULT_LOC); k += '|' + (e ? e.at : 0); }
  if (d.type === 'clock' && (d.clock.nextAlarm || d.clock.countdown || d.clock.face === 'pill')) k += '|al' + (NEXT_ALARM && NEXT_ALARM.at > Date.now() ? NEXT_ALARM.at : 0);
  return k;
}
