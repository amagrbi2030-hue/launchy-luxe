/* =========================================================
   Time core — Hijri (Umm al-Qura) & Gregorian calendars,
   digits, occasions and daily phrases. Everything is computed
   from the device clock; nothing here is fetched.
   ========================================================= */
const AR_DIGITS = '٠١٢٣٤٥٦٧٨٩';
/** Convert Western digits in a string to the chosen system ('latn' | 'arab'). */
function toDigits(s, sys) {
  s = String(s);
  if (sys === 'arab') return s.replace(/[0-9]/g, c => AR_DIGITS[+c]);
  return s.replace(/[٠-٩]/g, c => String(AR_DIGITS.indexOf(c))).replace(/[۰-۹]/g, c => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(c)));
}
const pad2 = n => String(n).padStart(2, '0');
const HIJRI_MONTHS = {
  ar: ['محرم', 'صفر', 'ربيع الأول', 'ربيع الآخر', 'جمادى الأولى', 'جمادى الآخرة', 'رجب', 'شعبان', 'رمضان', 'شوال', 'ذو القعدة', 'ذو الحجة'],
  en: ['Muharram', 'Safar', 'Rabi al-Awwal', 'Rabi al-Thani', 'Jumada al-Ula', 'Jumada al-Akhirah', 'Rajab', 'Shaban', 'Ramadan', 'Shawwal', 'Dhu al-Qadah', 'Dhu al-Hijjah']
};
const GREG_MONTHS = {
  ar: ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'],
  en: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']
};
const WEEKDAYS = {
  ar: ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'],
  en: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
  arShort: ['أحد', 'اثنين', 'ثلاثاء', 'أربعاء', 'خميس', 'جمعة', 'سبت'],
  enShort: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
};
const HIJRI_CALCS = [['umalqura', 'أم القرى (الرسمي في السعودية)'], ['civil', 'الهجري الجدولي (الحسابي)'], ['astro', 'الهجري الفلكي']];
const INTL_CAL = { umalqura: 'islamic-umalqura', civil: 'islamic-civil', astro: 'islamic' };
const calSupport = {};
function intlCalOk(calc) {
  if (calc in calSupport) return calSupport[calc];
  let ok = false;
  try {
    const f = new Intl.DateTimeFormat('en-u-ca-' + INTL_CAL[calc] + '-nu-latn', { day: 'numeric', month: 'numeric', year: 'numeric', timeZone: 'UTC' });
    ok = f.resolvedOptions().calendar === INTL_CAL[calc];
    // sanity check: 1 Ramadan 1447 = 18 Feb 2026 (Umm al-Qura)
    if (ok && calc === 'umalqura') { const p = f.formatToParts(new Date(Date.UTC(2026, 1, 18, 12))); ok = +p.find(x => x.type === 'month').value === 9 && +p.find(x => x.type === 'day').value === 1; }
  } catch (e) { ok = false; }
  return (calSupport[calc] = ok);
}
/* tabular (civil) Islamic calendar — exact arithmetic fallback */
const ISL_EPOCH = 1948439.5;
const gregToJD = (y, m, d) => { const a = Math.floor((14 - m) / 12), yy = y + 4800 - a, mm = m + 12 * a - 3; return d + Math.floor((153 * mm + 2) / 5) + 365 * yy + Math.floor(yy / 4) - Math.floor(yy / 100) + Math.floor(yy / 400) - 32045 - .5; };
const islToJD = (y, m, d) => d + Math.ceil(29.5 * (m - 1)) + (y - 1) * 354 + Math.floor((3 + 11 * y) / 30) + ISL_EPOCH - 1;
function islFromJD(jd) {
  jd = Math.floor(jd) + .5;
  const y = Math.floor((30 * (jd - ISL_EPOCH) + 10646) / 10631);
  const m = Math.min(12, Math.ceil((jd - (29 + islToJD(y, 1, 1))) / 29.5) + 1);
  return { y, m, d: jd - islToJD(y, m, 1) + 1 };
}
/** Local calendar day as a UTC-noon Date (safe for day arithmetic). */
function dayOnly(date) { return new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate(), 12)); }
const addDays = (dt, n) => new Date(dt.getTime() + n * 864e5);
/** Hijri date of a local day: {y, m (1-12), d, calc, approx}. */
function hijriOf(date, calc = 'umalqura', offset = 0) {
  const dt = addDays(dayOnly(date), offset || 0);
  if (intlCalOk(calc)) {
    const p = new Intl.DateTimeFormat('en-u-ca-' + INTL_CAL[calc] + '-nu-latn', { day: 'numeric', month: 'numeric', year: 'numeric', timeZone: 'UTC' }).formatToParts(dt);
    const g = t => +String(p.find(x => x.type === t).value).replace(/\D/g, '');
    return { y: g('year'), m: g('month'), d: g('day'), calc, approx: false };
  }
  const r = islFromJD(gregToJD(dt.getUTCFullYear(), dt.getUTCMonth() + 1, dt.getUTCDate()));
  return Object.assign(r, { calc: 'civil', approx: calc !== 'civil' });
}
/** First day (local Date) and length of the Hijri month that contains `date`. */
function hijriMonth(date, calc, offset) {
  const h = hijriOf(date, calc, offset);
  let first = new Date(date.getFullYear(), date.getMonth(), date.getDate() - (h.d - 1));
  let len = 29;
  const nxt = hijriOf(new Date(first.getFullYear(), first.getMonth(), first.getDate() + 29), calc, offset);
  if (nxt.d !== 1) len = 30;
  return { first, len, y: h.y, m: h.m };
}
function isoDay(date) { return date.getFullYear() + '-' + pad2(date.getMonth() + 1) + '-' + pad2(date.getDate()); }

/* ---- clocks in other time zones (world clock) */
const tzFmtCache = new Map();
/** {h, m, s, date(local-like)} for "now" in the IANA zone tz ('' = device). */
function nowIn(tz, base = new Date()) {
  if (!tz) return { h: base.getHours(), m: base.getMinutes(), s: base.getSeconds(), ms: base.getMilliseconds(), date: base };
  let f = tzFmtCache.get(tz);
  if (!f) { try { f = new Intl.DateTimeFormat('en-GB', { timeZone: tz, hourCycle: 'h23', year: 'numeric', month: 'numeric', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric' }); } catch (e) { f = null; } tzFmtCache.set(tz, f); }
  if (!f) return nowIn('', base);
  const p = {}; for (const x of f.formatToParts(base)) p[x.type] = +x.value;
  return { h: p.hour % 24, m: p.minute, s: p.second, ms: base.getMilliseconds(), date: new Date(p.year, p.month - 1, p.day, p.hour % 24, p.minute, p.second) };
}

/* ---- occasions (Hijri dates follow the chosen calendar & offset) */
const OCCASIONS = [
  { h: [1, 1], ar: 'رأس السنة الهجرية', en: 'Islamic New Year' },
  { h: [1, 10], ar: 'يوم عاشوراء', en: 'Day of Ashura' },
  { h: [9, 1], ar: 'بداية شهر رمضان المبارك', en: 'First day of Ramadan' },
  { h: [9, 21], to: 29, ar: 'العشر الأواخر من رمضان', en: 'Last ten nights of Ramadan' },
  { h: [10, 1], to: 3, ar: 'عيد الفطر المبارك', en: 'Eid al-Fitr' },
  { h: [12, 1], to: 7, ar: 'العشر من ذي الحجة', en: 'First ten days of Dhu al-Hijjah' },
  { h: [12, 8], ar: 'يوم التروية', en: 'Day of Tarwiyah' },
  { h: [12, 9], ar: 'يوم عرفة', en: 'Day of Arafah' },
  { h: [12, 10], ar: 'عيد الأضحى المبارك', en: 'Eid al-Adha' },
  { h: [12, 11], to: 13, ar: 'أيام التشريق', en: 'Days of Tashreeq' },
  { h: [0, 13], to: 15, ar: 'الأيام البيض', en: 'The White Days', white: true }
];
const NATIONAL = [
  { g: [2, 22], ar: 'يوم التأسيس', en: 'Founding Day' },
  { g: [3, 11], ar: 'يوم العلم', en: 'Flag Day' },
  { g: [9, 23], ar: 'اليوم الوطني السعودي', en: 'Saudi National Day' }
];
/** Occasions of a local day. o: {calc, offset, white, national, lang} */
function occasionsOf(date, o = {}) {
  const h = hijriOf(date, o.calc, o.offset), out = [];
  for (const x of OCCASIONS) {
    if (x.white && !o.white) continue;
    if (x.white && h.m === 12) continue; // 13 Dhu al-Hijjah is a day of Tashreeq
    const mOk = x.h[0] === 0 || x.h[0] === h.m;
    if (mOk && h.d >= x.h[1] && h.d <= (x.to || x.h[1])) out.push({ text: x[o.lang === 'en' ? 'en' : 'ar'], kind: 'hijri' });
  }
  if (o.national !== false) for (const x of NATIONAL) if (date.getMonth() + 1 === x.g[0] && date.getDate() === x.g[1]) out.push({ text: x[o.lang === 'en' ? 'en' : 'ar'], kind: 'national' });
  return out;
}
/** Next occasion within `days` days: {text, inDays}. */
function nextOccasion(date, o = {}, days = 60) {
  for (let i = 1; i <= days; i++) {
    const dt = new Date(date.getFullYear(), date.getMonth(), date.getDate() + i);
    const occ = occasionsOf(dt, Object.assign({}, o, { white: false }));
    if (occ.length) return { text: occ[0].text, inDays: i };
  }
  return null;
}

/* ---- daily phrases (one per day, the same all day) */
const PHRASES = {
  quran: ['إِنَّ مَعَ الْعُسْرِ يُسْرًا', 'أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ', 'وَقُل رَّبِّ زِدْنِي عِلْمًا', 'فَاذْكُرُونِي أَذْكُرْكُمْ', 'إِنَّ اللَّهَ مَعَ الصَّابِرِينَ', 'وَمَن يَتَوَكَّلْ عَلَى اللَّهِ فَهُوَ حَسْبُهُ', 'حَسْبُنَا اللَّهُ وَنِعْمَ الْوَكِيلُ', 'لَا يُكَلِّفُ اللَّهُ نَفْسًا إِلَّا وُسْعَهَا', 'وَهُوَ مَعَكُمْ أَيْنَ مَا كُنتُمْ', 'إِنَّ اللَّهَ يُحِبُّ الْمُحْسِنِينَ', 'وَلَسَوْفَ يُعْطِيكَ رَبُّكَ فَتَرْضَىٰ', 'رَبِّ اشْرَحْ لِي صَدْرِي', 'رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً'],
  adhkar: ['سبحان الله وبحمده، سبحان الله العظيم', 'لا حول ولا قوة إلا بالله', 'اللهم صلِّ وسلم على نبينا محمد', 'أستغفر الله وأتوب إليه', 'الحمد لله على كل حال', 'لا إله إلا الله وحده لا شريك له', 'اللهم بك أصبحنا وبك أمسينا'],
  wisdom: ['ابدأ يومك بنية صادقة وابتسامة', 'كل يوم صفحة جديدة، فاكتب فيها أجمل ما لديك', 'خطوة صغيرة كل يوم تصنع فرقاً كبيراً', 'الهدوء قوة', 'كن لطيفاً، فالكلمة الطيبة صدقة', 'رتّب يومك يرتّبك', 'الامتنان يجعل القليل كثيراً'],
  en: ['Every day is a fresh start.', 'Small steps every day.', 'Stay calm and carry kindness.', 'Make today count.', 'Indeed, with hardship comes ease.', 'Breathe. You are doing well.', 'Be grateful for little things.']
};
const PHRASE_SETS = [['mixed', 'منوّعة'], ['quran', 'آيات قرآنية'], ['adhkar', 'أذكار'], ['wisdom', 'حكم وعبارات'], ['custom', 'عبارتي الخاصة']];
function dailyPhrase(date, set = 'mixed', lang = 'ar', custom = '') {
  if (set === 'custom') return custom || '';
  const list = lang === 'en' ? PHRASES.en : set === 'mixed' ? [...PHRASES.quran, ...PHRASES.adhkar, ...PHRASES.wisdom] : (PHRASES[set] || PHRASES.wisdom);
  const n = Math.floor(dayOnly(date).getTime() / 864e5);
  return list[((n % list.length) + list.length) % list.length];
}

/* ---- formatted pieces used by the date widgets */
/**
 * All text a date design may need for a given day.
 * o: {calc, offset, lang, digits}
 */
function dateInfo(date, o = {}) {
  const lang = o.lang === 'en' ? 'en' : 'ar', dg = s => toDigits(s, o.digits || 'latn');
  const h = hijriOf(date, o.calc || 'umalqura', o.offset || 0);
  const gm = date.getMonth(), wd = date.getDay();
  const H = lang === 'en' ? 'AH' : 'هـ', G = lang === 'en' ? 'AD' : 'م';
  return {
    weekday: WEEKDAYS[lang][wd], weekdayShort: WEEKDAYS[lang + 'Short'][wd], wd,
    gDay: dg(date.getDate()), gMonth: GREG_MONTHS[lang][gm], gMonthNum: dg(pad2(gm + 1)), gYear: dg(date.getFullYear()),
    hDay: dg(h.d), hMonth: HIJRI_MONTHS[lang][h.m - 1], hMonthNum: dg(pad2(h.m)), hYear: dg(h.y), h,
    gFull: lang === 'en' ? `${GREG_MONTHS.en[gm]} ${date.getDate()}, ${date.getFullYear()}` : dg(`${date.getDate()} ${GREG_MONTHS.ar[gm]} ${date.getFullYear()}`) + ' ' + G,
    hFull: lang === 'en' ? `${h.d} ${HIJRI_MONTHS.en[h.m - 1]} ${h.y} ${H}` : dg(`${h.d} ${HIJRI_MONTHS.ar[h.m - 1]} ${h.y}`) + ' ' + H,
    gShort: dg(`${pad2(date.getDate())}/${pad2(gm + 1)}/${date.getFullYear()}`),
    hShort: dg(`${pad2(h.d)}/${pad2(h.m)}/${h.y}`),
    H, G, lang, approx: h.approx
  };
}
/** Hour/minute text for the preview (the home screen uses live system clocks). */
function timeText(t, fmt, digits, withSec) {
  const h12 = fmt === '12' || (fmt === 'system' && !is24System());
  let hh = t.h;
  if (h12) { hh = hh % 12; if (hh === 0) hh = 12; }
  const s = (h12 ? String(hh) : pad2(hh)) + ':' + pad2(t.m) + (withSec ? ':' + pad2(t.s) : '');
  return toDigits(s, digits);
}
function ampmText(t, lang) { return t.h < 12 ? (lang === 'en' ? 'AM' : 'ص') : (lang === 'en' ? 'PM' : 'م'); }
function is24System() {
  try { const inf = NATIVE ? nativeInfo() : null; if (inf && typeof inf.is24 === 'boolean') return inf.is24; } catch (e) {}
  try { return !/AM|PM|ص|م/i.test(new Date(2020, 0, 1, 15).toLocaleTimeString()); } catch (e) { return false; }
}
