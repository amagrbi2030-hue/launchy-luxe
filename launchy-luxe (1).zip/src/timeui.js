/* =========================================================
   Time & Weather Studio — home page, galleries, smart designer,
   random designs and the editor panels for clock/date/weather.
   It reuses the editor (steps, undo, save, Android pinning).
   ========================================================= */
const TIME_HOME = [
  { t: 'date', n: 'التاريخ الهجري والميلادي', d: 'أم القرى والميلادي معاً، تقويم شهري بالمناسبات الإسلامية، وعبارة يومية.', p: 'dateDual', coll: 'dates' },
  { t: 'weather', n: 'الطقس والخلفيات الطبيعية', d: 'بيانات حقيقية مباشرة فوق صور طبيعية تتبدل بحسب الطقس ووقت اليوم.', p: 'wxMedium', coll: 'weathers' },
  { t: 'clock', n: 'الساعات الفاخرة', d: 'مخمل ثلاثي الأبعاد، ذهب ملكي، زجاج سائل، كلاسيكية ورقمية بعقارب حية.', p: 'royalSmall', coll: 'royal' }
];
const tFavs = () => store.get('llx.tfav', []) || [];
const tRecent = () => store.get('llx.trecent', []) || [];
function pushRecent(key) { store.set('llx.trecent', [key, ...tRecent().filter(k => k !== key)].slice(0, 12)); }
function toggleFav(key) { const f = tFavs(); const on = !f.includes(key); store.set('llx.tfav', on ? [key, ...f] : f.filter(k => k !== key)); return on; }
const timeLoc = () => store.get('llx.timeloc', null);

/** Open a preset (or a ready design) in the editor. */
async function startTimeDesign(dOrKey, step = 2) {
  const d = typeof dOrKey === 'string' ? presetDesign(dOrKey, { weather: { loc: (timeLoc() || DEFAULT_LOC), unit: store.get('llx.tunit', 'C') } }) : dOrKey;
  if (typeof dOrKey === 'string') pushRecent('p:' + dOrKey);
  if (d.type === 'weather' && timeLoc()) d.weather.loc = clone(timeLoc());
  await startNew(d, step);
}

/* ---------------------------------------------------------- previews */
function previewBox(d, w, hh, cls = 'choice-prev wp-graphite') {
  const box = h('div', { class: cls });
  lazy(box, () => box.append(fitScaled(d, Math.max(60, (box.clientWidth || w) - 16), hh, {}, 1.2).el));
  return box;
}
function presetCard(p, i, onOpen) {
  const d = presetDesign(p);
  const fav = tFavs().includes(p.k);
  const star = h('button', { type: 'button', class: 'tstar' + (fav ? ' on' : ''), 'aria-label': fav ? 'إزالة من المفضلة' : 'إضافة إلى المفضلة', onclick: e => { e.stopPropagation(); const on = toggleFav(p.k); star.classList.toggle('on', on); toast(on ? 'أُضيف إلى المفضلة' : 'أُزيل من المفضلة'); } }, icon('star', 16));
  const [c, r] = p.size;
  return h('div', { class: 'choice tcard', style: { '--i': Math.min(i, 12) }, role: 'button', tabindex: '0', onclick: () => (onOpen || startTimeDesign)(p.k), onkeydown: e => { if (e.key === 'Enter') (onOpen || startTimeDesign)(p.k); } },
    previewBox(d, 180, 120), star,
    h('div', { class: 'choice-txt' }, h('strong', {}, p.n), h('span', {}, `${TYPES[p.type].short} · ${c}×${r} · ${STYLES[p.style].n}`)));
}
function presetGrid(list, onOpen) { return h('div', { class: 'choice-grid lib-grid tgal' }, list.map((p, i) => presetCard(p, i, onOpen))); }

/* ---------------------------------------------------------- page */
function viewTime() {
  const v = $('#view');
  let tab = ui.timeTab || 'all';
  const gal = h('div', { id: 'tgal' });
  const drawGal = () => {
    const colls = TIME_COLLS.filter(c => tab === 'all' || c[2] === tab || c[0] === tab);
    gal.replaceChildren(...colls.map(([k, n]) => h('section', { class: 'tcoll' }, h('div', { class: 'sub-h' }, n), presetGrid(TIME_PRESETS.filter(p => p.coll === k)))));
  };
  const tabs = h('div', { class: 'chips lib-filter' }, [['all', 'كل التصاميم'], ['clock', 'الساعات'], ['date', 'التاريخ'], ['weather', 'الطقس'], ...TIME_COLLS.filter(c => c[2] === 'clock').map(c => [c[0], c[1]])].map(([k, n]) =>
    h('button', { type: 'button', class: 'chip' + (tab === k ? ' on' : ''), onclick: e => { tab = ui.timeTab = k; $$('.chip', tabs).forEach(x => x.classList.toggle('on', x === e.currentTarget)); drawGal(); } }, n)));
  const showAll = k => { tab = ui.timeTab = k; drawGal(); $$('.chip', tabs).forEach(x => x.classList.toggle('on', x.textContent === ({ all: 'كل التصاميم', clock: 'الساعات', date: 'التاريخ', weather: 'الطقس' }[k] || (TIME_COLLS.find(c => c[0] === k) || [])[1]))); $('#tgal-h').scrollIntoView({ behavior: 'smooth', block: 'start' }); };

  // three main cards
  const cards = h('div', { class: 'tcards' }, TIME_HOME.map((c, i) => {
    const d = presetDesign(c.p);
    return h('article', { class: 'tmain', style: { '--i': i } },
      previewBox(d, 300, 170, 'tmain-prev wp-aurora'),
      h('div', { class: 'tmain-txt' }, h('h3', {}, c.n), h('p', {}, c.d),
        h('div', { class: 'tmain-act' },
          h('button', { type: 'button', class: 'btn btn-gold btn-sm', onclick: () => showAll(c.t) }, icon('sparkle', 15), 'استكشف التصاميم'),
          h('button', { type: 'button', class: 'btn btn-sm', onclick: () => startTimeDesign(c.p) }, icon('edit', 15), 'صمّم الآن'))));
  }));

  // favourites & recent
  const favList = tFavs().map(k => TIME_PRESET[k]).filter(Boolean);
  const saved = loadDesigns().filter(d => TIME_TYPES.has(d.type));
  const recentKeys = tRecent();
  const recent = recentKeys.map(k => k.startsWith('p:') ? { p: TIME_PRESET[k.slice(2)] } : { d: saved.find(x => x.id === k.slice(2)) }).filter(x => x.p || x.d).slice(0, 8);
  const recentRow = recent.length ? h('div', { class: 'choice-grid lib-grid tgal' }, recent.map((x, i) => x.p ? presetCard(x.p, i) :
    h('div', { class: 'choice tcard', role: 'button', tabindex: '0', onclick: () => editDesign(x.d.id) }, previewBox(normalize(x.d), 180, 120), h('div', { class: 'choice-txt' }, h('strong', {}, x.d.name), h('span', {}, 'تصميم محفوظ · ' + TYPES[x.d.type].short))))) : h('p', { class: 'fine' }, 'تظهر هنا التصاميم التي فتحتها أو حفظتها مؤخراً.');

  v.replaceChildren(h('div', { class: 'wrap' },
    h('div', { class: 'page-h' },
      h('div', {}, h('div', { class: 'eyebrow' }, 'Time & Weather Studio'), h('h1', { class: 'page-t' }, 'استوديو الوقت والتاريخ والطقس'),
        h('p', { class: 'page-d' }, 'ساعات حية، تقويم هجري وميلادي، وطقس حقيقي فوق صور طبيعية — كل تصميم يُحفظ مستقلاً ويُضاف إلى الشاشة الرئيسية.')),
      h('div', { class: 'page-act' },
        h('button', { type: 'button', class: 'btn', onclick: () => { const d = randomTimeDesign(); startTimeDesign(d); } }, icon('dice', 18), 'عشوائي'),
        h('button', { type: 'button', class: 'btn btn-gold', onclick: () => showAll('all') }, icon('layers', 18), 'عرض جميع الأنماط'))),
    cards,
    promptCard(),
    h('section', { class: 'sec' }, h('div', { class: 'sec-h' }, h('h2', {}, 'المفضلة'), h('p', {}, 'اضغط النجمة على أي تصميم لإضافته')),
      favList.length ? presetGrid(favList) : h('p', { class: 'fine' }, 'لا توجد تصاميم مفضلة بعد.')),
    h('section', { class: 'sec' }, h('div', { class: 'sec-h' }, h('h2', {}, 'آخر التصاميم المستخدمة')), recentRow),
    h('section', { class: 'sec', id: 'tgal-h' }, h('div', { class: 'sec-h' }, h('h2', {}, 'معرض التصاميم الجاهزة'), h('p', {}, `${TIME_PRESETS.length} تصميماً جاهزاً — اضغط أي تصميم لتخصيصه وحفظه`)), tabs, gal),
    h('section', { class: 'sec' }, h('div', { class: 'sec-h' }, h('h2', {}, 'الأشكال والأحجام'), h('p', {}, 'بأحجام خلايا Android الحقيقية (أعمدة × صفوف)')), shapesGallery()),
    h('section', { class: 'sec' }, h('div', { class: 'sec-h' }, h('h2', {}, 'استوديو الخامات'), h('p', {}, 'غيّر خامة الساعة دون تغيير شكلها')), materialsStudio()),
    h('section', { class: 'sec' }, h('div', { class: 'sec-h' }, h('h2', {}, 'مكتبة الخلفيات الطبيعية'), h('p', {}, `${SCENES.length} صورة طبيعية — أو صورتك من معرض الهاتف`)), photoLibrary(k => {
      const d = presetDesign('wxMedium', { weather: { loc: timeLoc() || DEFAULT_LOC, unit: store.get('llx.tunit', 'C') } });
      Object.assign(d.weather.bg, { mode: 'fixed', scene: k }); d.name = 'طقس — ' + SCENE[k].n; startTimeDesign(d);
    })),
    weatherStatusBox()));
  drawGal();
}

/* ---------------------------------------------------------- shapes & sizes */
function shapesGallery() {
  const base = presetDesign('royalSmall');
  const mk = (n, size, over, type = 'clock') => {
    const d = type === 'clock' ? clone(base) : presetDesign('dateCalendar');
    d.sizes[d.type] = size; if (over) Object.assign(d[d.type], over);
    d.name = n; return normalize(d);
  };
  const list = [
    ['دائري', [2, 2], { shape: 'circle' }], ['مربع', [2, 2], { shape: 'square' }], ['مربع بزوايا دائرية', [2, 2], { shape: 'rounded' }],
    ['مستطيل أفقي', [4, 2], { shape: 'rect', date: 'both', weekday: true }], ['مستطيل عمودي', [2, 3], { shape: 'rect', date: 'both', weekday: true }],
    ['بطاقة عريضة', [4, 3], { shape: 'rect', date: 'both', weekday: true, phrase: true }], ['ساعة صغيرة مستقلة', [1, 1], { shape: 'circle' }],
    ['ساعة كبيرة مع التاريخ', [4, 4], { shape: 'rounded', date: 'both', weekday: true }], ['ساعة مع تقويم شهري', [4, 4], null, 'date']
  ];
  return h('div', { class: 'choice-grid lib-grid tgal' }, list.map(([n, size, over, type], i) => {
    const d = mk(n, size, over, type);
    return h('div', { class: 'choice tcard', role: 'button', tabindex: '0', style: { '--i': i }, onclick: () => { pushRecent('p:' + (type === 'date' ? 'dateCalendar' : 'royalSmall')); startTimeDesign(d); } },
      previewBox(d, 180, 120), h('div', { class: 'choice-txt' }, h('strong', {}, n), h('span', {}, `${size[0]}×${size[1]} خلايا`)));
  }));
}

/* ---------------------------------------------------------- materials studio */
const MATERIAL_SWITCH = [
  ['velvet', 'مخمل', d => { Object.assign(d.a, { mat: 'velvet', matTint: true }); Object.assign(d.clock, { dial: 'material', dialMat: 'velvet', bezel: 'velvet3d', raised: true }); }],
  ['leather', 'جلد', d => { Object.assign(d.a, { mat: 'leatherEmb', matTint: false }); Object.assign(d.clock, { dial: 'material', dialMat: 'leather', bezel: 'gold', raised: true, ink: '#f3e2c0' }); }],
  ['marble', 'رخام', d => { Object.assign(d.a, { mat: 'marbleWhite', matTint: false }); Object.assign(d.clock, { dial: 'material', dialMat: 'marbleWhite', bezel: 'goldMulti', raised: false, ink: '' }); }],
  ['gold', 'ذهب', d => { Object.assign(d.a, { mat: 'goldAntique', matTint: false }); Object.assign(d.clock, { dial: 'ivory', bezel: 'goldMulti', raised: false, ink: '' }); }],
  ['glass', 'زجاج', d => { Object.assign(d.a, { mat: 'glassLiquid', matTint: true }); Object.assign(d.clock, { dial: 'glass', bezel: 'glass', raised: false, ink: '#ffffff', handColor: 'white', glowHands: '#9ef3ff' }); }]
];
function materialsStudio() {
  let sel = ui.tMat || 'velvet';
  const prev = h('div', { class: 'tmat-prev wp-aurora' });
  const info = h('div', { class: 'tmat-info' });
  const demo = () => { const d = presetDesign('plushBlack'); Object.assign(d.a, { mat: sel, matTint: !!MAT[sel].tint }); Object.assign(d.clock, { dial: 'material', dialMat: sel, bezel: MAT[sel].g === 'glass' ? 'glass' : MAT[sel].g === 'metal' ? 'goldMulti' : 'velvet3d', raised: MAT[sel].g === 'fabric', ink: ['metal', 'stone'].includes(MAT[sel].g) && sel !== 'marbleBlack' ? '' : '#ffffff' }); d.name = 'ساعة ' + MAT[sel].n; return normalize(d); };
  const draw = () => {
    prev.replaceChildren(fitScaled(demo(), 220, 200, {}, 1.3).el);
    info.replaceChildren(h('strong', {}, MAT[sel].n), h('p', { class: 'fine' }, MAT[sel].desc), h('button', { type: 'button', class: 'btn btn-gold btn-sm', onclick: () => startTimeDesign(demo()) }, icon('edit', 15), 'ابدأ تصميماً بهذه الخامة'));
    $$('.tmat', grid).forEach(b => b.classList.toggle('on', b.dataset.k === sel));
  };
  const grid = h('div', { class: 'tmat-grid' }, MATERIALS.filter(m => !m.hidden).map(m => h('button', { type: 'button', class: 'tmat', 'data-k': m.k, onclick: () => { sel = ui.tMat = m.k; draw(); } },
    (() => { const s = h('span', { class: 'tmat-sw' }); lazy(s, () => s.append(matSwatch(m.k, m.tint ? '#2547c9' : null, 54))); return s; })(), h('b', {}, m.n), h('small', {}, m.desc))));
  requestAnimationFrame(draw);
  return h('div', { class: 'tmat-wrap' }, h('div', { class: 'tmat-side' }, prev, info), grid);
}

/* ---------------------------------------------------------- photo library */
function photoLibrary(onPick, cur) {
  let cat = 'all';
  const grid = h('div', { class: 'photo-grid' });
  const draw = () => grid.replaceChildren(...SCENES.filter(s => cat === 'all' || s.cat === cat).map(s =>
    h('button', { type: 'button', class: 'photo' + (cur === s.k ? ' on' : ''), onclick: () => onPick(s.k) },
      h('img', { src: s.src, alt: s.n, loading: 'lazy', style: { objectPosition: `${s.fx * 100}% ${s.fy * 100}%` } }),
      h('span', {}, s.n), h('i', {}, s.wx.map(w => WXS.find(x => x[0] === w)[1]).concat(s.tod.map(t => TODS.find(x => x[0] === t)[1])).join(' · ')))));
  const chips = h('div', { class: 'chips lib-filter' }, [['all', 'الكل'], ...SCENE_CATS.filter(c => SCENES.some(s => s.cat === c[0]))].map(([k, n]) =>
    h('button', { type: 'button', class: 'chip' + (cat === k ? ' on' : ''), onclick: e => { cat = k; $$('.chip', chips).forEach(x => x.classList.toggle('on', x === e.currentTarget)); draw(); } }, n)));
  draw();
  return h('div', { class: 'form' }, chips, grid);
}

/* ---------------------------------------------------------- weather status */
function weatherStatusBox() {
  const loc = timeLoc() || DEFAULT_LOC, e = wxCached(loc);
  const st = h('p', { class: 'fine' }, e && e.cur ? `آخر تحديث لـ${loc.name}: ${new Date(e.at).toLocaleString('ar-SA-u-ca-gregory-nu-latn', { hour: '2-digit', minute: '2-digit', day: 'numeric', month: 'short' })}${e.err ? ' — آخر محاولة لم تنجح، تُعرض آخر بيانات صحيحة' : ''}` : 'لا توجد بيانات طقس محفوظة بعد.');
  return h('section', { class: 'sec' }, h('div', { class: 'info-box' },
    h('strong', {}, 'بيانات الطقس'),
    h('p', {}, 'المصدر: Open-Meteo (مجاني ومفتوح). تُحفظ آخر قراءة صحيحة مع وقتها، ولا تُعرض أرقام مختلقة عند انقطاع الاتصال.'), st,
    h('div', { style: { display: 'flex', gap: '8px', flexWrap: 'wrap' } },
      h('button', { type: 'button', class: 'btn btn-sm', onclick: async () => { st.textContent = 'جارٍ التحديث…'; const r = await refreshWx(loc); st.textContent = r && r.cur && !r.err ? 'تم التحديث الآن' : 'تعذّر الاتصال — تبقى آخر بيانات صحيحة معروضة'; bakeAll(); } }, icon('reset', 15), 'تحديث الآن'),
      h('button', { type: 'button', class: 'btn btn-sm', onclick: () => openLocationDialog(l => { store.set('llx.timeloc', l); route(false); }) }, icon('pin', 15), 'المدينة الافتراضية: ' + loc.name))));
}

/* ---------------------------------------------------------- location picker */
function openLocationDialog(onPick) {
  const q = h('input', { type: 'search', class: 'inp', placeholder: 'ابحث عن مدينة… (مثل: أبها، Zurich)', dir: 'auto' });
  const res = h('div', { class: 'pick-list' });
  const st = h('p', { class: 'fine' });
  const row = (l, sub) => h('button', { type: 'button', class: 'pick-row', onclick: () => { onPick(l); $('#dlg2').close(); } }, h('span', { class: 'pick-av' }, icon('pin', 16)), h('span', { class: 'pick-t' }, h('b', {}, l.name), h('small', {}, sub || '')));
  const quick = () => res.replaceChildren(
    h('div', { class: 'sub-h' }, 'مدن السعودية'), ...CITIES.filter(c => c.g === 'sa').map(c => row(cityLoc(c), c.en)),
    h('div', { class: 'sub-h' }, 'مدن العالم'), ...CITIES.filter(c => c.g === 'w').map(c => row(cityLoc(c), c.en)));
  quick();
  const go = debounce(async () => {
    const t = q.value.trim(); if (t.length < 2) { quick(); st.textContent = ''; return; }
    const local = CITIES.filter(c => c.n.includes(t) || c.en.toLowerCase().includes(t.toLowerCase()));
    res.replaceChildren(...local.map(c => row(cityLoc(c), c.en)));
    st.textContent = 'جارٍ البحث…';
    try { const r = await geocodeSearch(t); res.append(...r.filter(x => !local.some(c => Math.abs(c.lat - x.lat) < .05 && Math.abs(c.lon - x.lon) < .05)).map(x => row(x, x.sub))); st.textContent = r.length || local.length ? '' : 'لا توجد نتائج'; }
    catch (e) { st.textContent = local.length ? '' : 'تعذّر البحث — تحقق من الاتصال بالإنترنت'; }
  }, 350);
  q.addEventListener('input', go);
  const me = h('button', { type: 'button', class: 'btn', onclick: async () => {
    st.textContent = 'جارٍ تحديد موقعك…';
    const r = await deviceLocation();
    if (r.err) { st.textContent = r.err === 'denied' ? 'لم يُمنح إذن الموقع. يمكنك اختيار مدينة يدوياً.' : 'تعذّر تحديد الموقع الآن.'; return; }
    onPick({ mode: 'device', name: r.name || 'موقعي الحالي', lat: r.lat, lon: r.lon, tz: '' }); $('#dlg2').close();
  } }, icon('locate', 18), 'موقعي الحالي (بإذنك)');
  openDialog('اختيار الموقع', h('div', { class: 'form' }, me, q, st, res), [], { id: 'dlg2' });
}

/* ---------------------------------------------------------- random & smart designer */
const pickOne = a => a[Math.floor(Math.random() * a.length)];
function randomTimeDesign(type) {
  type = type || pickOne(['clock', 'clock', 'date', 'weather']);
  const p = pickOne(TIME_PRESETS.filter(x => x.type === type));
  const d = presetDesign(p, { weather: { loc: timeLoc() || DEFAULT_LOC, unit: store.get('llx.tunit', 'C') } });
  const st = pickOne(['royalGold', 'plush3d', 'holo', 'glass', 'quiet', 'neon', 'midnight', 'marble', 'leather', 'emerald', 'champagne', 'obsidian', 'sapphire', 'burgundy']);
  d.style = st; Object.assign(d.a, styleLook(st));
  d.theme = pickOne(THEMES).k;
  const mats = MATERIALS.filter(m => !m.hidden && m.g !== 'glass').map(m => m.k);
  d.a.mat = Math.random() < .8 ? pickOne(mats) : 'glassLiquid'; d.a.matTint = !!MAT[d.a.mat].tint;
  d.a.frame = pickOne(['none', 'none', 'goldDouble', 'royalGold', 'silverF', 'classic', 'islamicGeo', 'stitched']);
  if (type === 'clock' && d.clock.face === 'analog') {
    Object.assign(d.clock, { hands: pickOne(HAND_STYLES)[0], handColor: pickOne(HAND_COLORS.slice(0, 7))[0], numerals: pickOne(NUMERALS.slice(0, 5))[0], bezel: pickOne(BEZELS.slice(0, 8))[0], dial: pickOne(['ivory', 'black', 'sunburst', 'material', 'white']), dialMat: pickOne(mats), ornaments: Math.random() < .4 });
    d.clock.raised = d.clock.dial === 'material' && MAT[d.clock.dialMat].g === 'fabric';
    d.clock.ink = d.clock.dial === 'material' && !['metal', 'stone'].includes(MAT[d.clock.dialMat].g) ? '#ffffff' : '';
  }
  if (type === 'clock' && d.clock.face === 'digital') d.clock.font = pickOne(CLOCK_FONTS.filter(f => f.k !== 'led')).k;
  if (type === 'weather') { d.weather.bg.mode = pickOne(['weather', 'fixed', 'time']); d.weather.bg.scene = pickOne(SCENES).k; }
  if (type === 'date') d.date.tfont = pickOne(TEXT_FONTS)[0];
  d.name = 'تصميم عشوائي — ' + TYPES[type].short;
  return normalize(d);
}
/* keyword dictionaries for the text designer (Arabic + English) */
const PROMPT = {
  type: [[/ساع|clock|watch|عقارب|رقمي|digital/i, 'clock'], [/طقس|حرار|weather|مطر|غيوم/i, 'weather'], [/تقويم|تاريخ|calendar|date|هجري|ميلادي/i, 'date']],
  mat: [[/مخمل|velvet/i, 'velvet', 'مخمل'], [/جلد|leather/i, 'leatherEmb', 'جلد'], [/رخام أسود|black marble/i, 'marbleBlack', 'رخام أسود'], [/رخام|marble/i, 'marbleWhite', 'رخام'], [/زجاج|glass/i, 'glassLiquid', 'زجاج سائل'],
    [/خشب|wood/i, 'walnut', 'خشب'], [/كروم|chrome/i, 'chrome', 'كروم'], [/حجر|stone/i, 'stone', 'حجر'], [/كربون|carbon/i, 'carbon', 'كربون'], [/سيراميك|خزف|ceramic/i, 'ceramic', 'سيراميك'], [/ساتان|حرير|satin/i, 'satin', 'ساتان'], [/لؤلؤ|pearl/i, 'pearl', 'لؤلؤ'], [/مطفي|matte/i, 'matteSoft', 'مطفي']],
  color: [[/كحلي|navy|ليلي/i, 'navy', 'كحلي'], [/أزرق|ازرق|زرقاء|blue/i, 'royal', 'أزرق'], [/أسود|اسود|سوداء|black/i, 'onyx', 'أسود'], [/زيتوني|olive/i, 'olive', 'زيتوني'], [/أخضر|اخضر|خضراء|green|زمرد/i, 'emerald', 'أخضر'], [/بني|brown/i, 'brown', 'بني'],
    [/رمادي|grey|gray/i, 'graphite', 'رمادي'], [/بنفسج|purple|violet/i, 'purple', 'بنفسجي'], [/عنابي|أحمر|احمر|حمراء|red|burgundy/i, 'burgundy', 'عنابي'], [/وردي|pink|rose/i, 'rose', 'وردي'], [/فيروز|turquoise/i, 'turquoise', 'فيروزي'], [/عاجي|عاجية|أبيض|ابيض|بيضاء|ivory|white/i, 'ivory', 'عاجي'], [/ذهبي اللون|gold color/i, 'gold', 'ذهبي']],
  frame: [[/إطار ذهبي|اطار ذهبي|gold frame/i, 'gold', 'إطار ذهبي'], [/إطار فضي|اطار فضي|silver/i, 'silver', 'إطار فضي'], [/إسلامي|اسلامي|islamic/i, 'islamic', 'زخرفة إسلامية'], [/ملكي|royal/i, 'royal', 'ملكي'], [/خشب/i, 'wood', 'إطار خشبي']],
  num: [[/روماني|roman/i, 'roman', 'أرقام رومانية'], [/أرقام عربية|ارقام عربية|هندي|arabic/i, 'arabic', 'أرقام عربية'], [/إنجليزي|انجليزي|لاتيني|english|western/i, 'western', 'أرقام لاتينية']],
  shape: [[/دائري|دائرة|round|circle/i, 'circle', 'دائري'], [/مربع|square/i, 'rounded', 'مربع'], [/أفقي|افقي|عريض|wide|horizontal/i, 'wide', 'أفقي'], [/عمودي|طولي|vertical|tall/i, 'tall', 'عمودي']],
  size: [[/صغير|small|mini/i, 'small', 'صغير'], [/كبير|large|big/i, 'large', 'كبير']],
  style: [[/نيون|neon/i, 'neon', 'نيون'], [/فخامة هادئة|هادئ|quiet/i, 'quiet', 'فخامة هادئة'], [/زجاج فاخر|premium glass/i, 'glass', 'زجاج فاخر'], [/ذهب|gold/i, 'royalGold', 'ذهب ملكي']],
  digital: [[/رقمي|digital|led|ليد/i, 'digital', 'رقمية'], [/عقارب|analog|كلاسيك/i, 'analog', 'بعقارب']],
  extra: [[/هجري|hijri/i, 'hijri', 'التاريخ الهجري'], [/ميلادي|gregorian/i, 'greg', 'التاريخ الميلادي'], [/عبارة|phrase|ذكر|آية/i, 'phrase', 'عبارة يومية'], [/مع الطقس|درجة الحرارة|temperature/i, 'wx', 'الطقس'], [/24/, 'h24', '24 ساعة'], [/ثواني|ثانية|second/i, 'sec', 'عقرب الثواني'], [/تقويم شهري|شهري|month/i, 'month', 'تقويم شهري'], [/led|ليد/i, 'led', 'LED'], [/قلاب|flip/i, 'flip', 'قلابة']],
  scene: SCENES.map(s => [new RegExp(s.n.split(' ').filter(w => w.length > 3).slice(0, 2).join('|'), 'i'), s.k, s.n]).concat([[/جبل|جبال|mountain/i, 'greenPeak', 'جبال'], [/ثلج|snow/i, 'goldenPeak', 'ثلوج'], [/بحر|شاطئ|sea|beach/i, 'coastSunset', 'بحر'], [/غاب|forest/i, 'mistyValley', 'غابة'], [/شلال|waterfall/i, 'forestFalls', 'شلال'], [/بحير|lake/i, 'lakeHouse', 'بحيرة'], [/غروب|sunset/i, 'lakeSunset', 'غروب'], [/ليل|نجوم|night|star/i, 'cosmic', 'ليل']]),
  city: CITIES.map(c => [new RegExp(c.n.replace(/[()]/g, '') + '|' + c.en, 'i'), c, c.n])
};
const firstHit = (list, t) => list.find(([re]) => re.test(t));
/** Turn a description into a design. Returns {d, chips} (chips = what was understood). */
function parsePrompt(text) {
  const t = String(text || ''), chips = [];
  const ty = firstHit(PROMPT.type, t); const type = ty ? ty[1] : 'clock';
  chips.push(TYPES[type].n);
  const has = list => list.filter(([re]) => re.test(t));
  let base = type === 'clock' ? 'royalSmall' : type === 'date' ? 'dateDual' : 'wxMedium';
  const dig = firstHit(PROMPT.digital, t), ex = has(PROMPT.extra).map(x => x[1]);
  if (type === 'clock' && dig && dig[1] === 'digital') base = ex.includes('led') ? 'digitalLed' : ex.includes('flip') ? 'digitalFlip' : 'digital24';
  if (type === 'date' && ex.includes('month')) base = 'dateCalendar';
  const mat = firstHit(PROMPT.mat, t); if (type === 'clock' && mat && mat[1] === 'velvet' && base === 'royalSmall') base = 'plushNavy';
  if (type === 'clock' && mat && mat[1] === 'glassLiquid' && base === 'royalSmall') base = 'glassBlue';
  const d = presetDesign(base, { weather: { loc: timeLoc() || DEFAULT_LOC, unit: store.get('llx.tunit', 'C') } });
  const st = firstHit(PROMPT.style, t); if (st && !(st[1] === 'royalGold' && /إطار ذهبي|اطار ذهبي|gold frame/i.test(t) && !/ذهب ملكي|ملكي/.test(t))) { d.style = st[1]; Object.assign(d.a, styleLook(st[1])); chips.push('نمط ' + st[2]); }
  if (mat) { d.a.mat = mat[1]; d.a.matTint = !!MAT[mat[1]].tint; chips.push('خامة ' + mat[2]); if (type === 'clock' && d.clock.face === 'analog') { const sw = MATERIAL_SWITCH.find(m => mat[1].startsWith(m[0]) || (m[0] === 'glass' && mat[1] === 'glassLiquid')); if (sw) sw[2](d); else Object.assign(d.clock, { dial: 'material', dialMat: mat[1] }); } }
  const col = firstHit(PROMPT.color, t); if (col) { d.theme = col[1]; chips.push('لون ' + col[2]); if (!mat) d.a.matTint = !!(MAT[d.a.mat] && MAT[d.a.mat].tint); }
  const fr = firstHit(PROMPT.frame, t);
  if (fr) {
    chips.push(fr[2]);
    if (fr[1] === 'gold') { d.a.frame = type === 'clock' && d.clock.shape === 'circle' ? 'none' : 'goldDouble'; d.a.frameColor = '#d4af37'; if (type === 'clock') { d.clock.bezel = 'goldMulti'; d.clock.handColor = d.clock.handColor === 'white' ? 'gold' : d.clock.handColor; } }
    if (fr[1] === 'silver') { d.a.frame = 'silverF'; if (type === 'clock') d.clock.bezel = 'silver'; }
    if (fr[1] === 'islamic') d.a.frame = 'islamicGeo';
    if (fr[1] === 'royal') { d.a.frame = 'royalGold'; if (type === 'clock') d.clock.ornaments = true; }
    if (fr[1] === 'wood' && type === 'clock') d.clock.bezel = 'woodDark';
  }
  const shp = firstHit(PROMPT.shape, t), sz = firstHit(PROMPT.size, t);
  if (type === 'clock') {
    const nm = firstHit(PROMPT.num, t); if (nm) { d.clock.numerals = nm[1]; chips.push(nm[2]); }
    if (dig) chips.push(dig[2]);
    if (ex.includes('hijri') && ex.includes('greg')) d.clock.date = 'both'; else if (ex.includes('hijri')) d.clock.date = 'hijri'; else if (ex.includes('greg')) d.clock.date = 'greg';
    if (ex.includes('hijri') || ex.includes('greg')) { d.clock.weekday = true; chips.push(d.clock.date === 'both' ? 'التاريخان' : d.clock.date === 'hijri' ? 'التاريخ الهجري' : 'التاريخ الميلادي'); }
    if (ex.includes('phrase')) { d.clock.phrase = true; chips.push('عبارة يومية'); }
    if (ex.includes('wx')) { d.clock.wx = true; chips.push('الطقس'); }
    if (ex.includes('h24')) { d.clock.fmt = '24'; chips.push('24 ساعة'); }
    if (ex.includes('sec')) { d.clock.seconds = true; chips.push('عقرب الثواني'); }
    let size = d.sizes.clock;
    if (shp) { chips.push(shp[2]); if (shp[1] === 'circle') d.clock.shape = 'circle'; if (shp[1] === 'rounded') d.clock.shape = 'rounded'; if (shp[1] === 'wide') { d.clock.shape = 'rect'; size = [4, 2]; } if (shp[1] === 'tall') { d.clock.shape = 'rect'; size = [2, 3]; } }
    if (d.clock.face === 'analog' && d.clock.date !== 'none' && d.clock.shape === 'rect' && size[0] < 3 && size[1] < 3) size = [4, 2];
    if (sz) { chips.push(sz[2]); size = sz[1] === 'small' ? (d.clock.shape === 'rect' ? [3, 1] : [1, 1]) : (d.clock.shape === 'rect' ? [4, 3] : [3, 3]); }
    d.sizes.clock = size;
  } else if (type === 'date') {
    if (ex.includes('greg') && !ex.includes('hijri')) { d.date.primary = 'greg'; chips.push('الميلادي أولاً'); }
    if (ex.includes('phrase')) { d.date.variant = d.date.variant === 'calendar' ? 'calendar' : 'big'; d.date.phrase = true; chips.push('عبارة يومية'); }
    if (/إسلامي|اسلامي|مزخرف|islamic/i.test(t)) { d.date.variant = 'islamic'; d.sizes.date = [2, 3]; chips.push('مزخرف إسلامي'); }
    if (ex.includes('month')) chips.push('تقويم شهري');
    if (sz) { chips.push(sz[2]); if (sz[1] === 'small') { d.date.variant = 'mini'; d.sizes.date = [2, 1]; } else if (d.date.variant !== 'calendar') d.sizes.date = [4, 2]; }
    if (shp && shp[1] === 'wide' && d.date.variant !== 'calendar') { d.sizes.date = [4, 2]; chips.push('أفقي'); }
  } else {
    const sc = firstHit(PROMPT.scene, t); if (sc) { d.weather.bg.mode = 'fixed'; d.weather.bg.scene = sc[1]; chips.push('خلفية ' + SCENE[sc[1]].n); }
    if (/حسب الطقس|ذكية|تلقائي/i.test(t)) { d.weather.bg.mode = 'weather'; chips.push('خلفية ذكية حسب الطقس'); }
    const city = firstHit(PROMPT.city, t); if (city) { d.weather.loc = cityLoc(city[1]); chips.push('مدينة ' + city[2]); }
    if (/فهرنهايت|fahrenheit|°f/i.test(t)) { d.weather.unit = 'F'; chips.push('فهرنهايت'); }
    if (shp && shp[1] === 'circle') { d.weather.variant = 'round'; d.sizes.weather = [2, 2]; chips.push('دائري'); }
    else if (sz) { chips.push(sz[2]); if (sz[1] === 'small') { d.weather.variant = 'mini'; d.sizes.weather = [2, 2]; } else { d.weather.variant = 'large'; d.sizes.weather = [4, 4]; } }
    else if (shp && shp[1] === 'wide') { d.weather.variant = 'panorama'; chips.push('بانورامي'); }
  }
  d.name = t.trim().slice(0, 40) || 'تصميمي';
  return { d: normalize(d), chips };
}
function promptCard() {
  const ta = h('textarea', { class: 'inp tprompt-in', rows: 2, placeholder: 'صف الويدجت الذي تريده… مثل: أريد ساعة مخملية زرقاء بإطار ذهبي مع التاريخ الهجري', dir: 'auto' });
  const out = h('div', { class: 'tprompt-out' });
  const run = () => {
    const t = ta.value.trim(); if (!t) { ta.focus(); return; }
    const r = parsePrompt(t);
    const prev = h('div', { class: 'tprompt-prev wp-aurora' });
    out.replaceChildren(h('div', { class: 'chips' }, r.chips.map(c => h('span', { class: 'chip on' }, icon('check', 13), c))), prev,
      h('div', { style: { display: 'flex', gap: '8px', flexWrap: 'wrap' } },
        h('button', { type: 'button', class: 'btn btn-gold btn-sm', onclick: () => startTimeDesign(r.d) }, icon('edit', 15), 'افتح في المحرر للتعديل والحفظ'),
        h('button', { type: 'button', class: 'btn btn-sm', onclick: run }, icon('reset', 15), 'إعادة')));
    requestAnimationFrame(() => prev.append(fitScaled(r.d, Math.min(380, prev.clientWidth - 20), 220, {}, 1.4).el));
  };
  const ex = ['ساعة مخملية زرقاء بإطار ذهبي مع التاريخ الهجري', 'ساعة رقمية LED حمراء كبيرة', 'تقويم هجري شهري بلون كحلي', 'طقس جدة بخلفية غروب الساحل', 'تاريخ إسلامي مزخرف مع عبارة يومية', 'ساعة زجاجية بنفسجية بأرقام رومانية'];
  return h('section', { class: 'sec' }, h('div', { class: 'tprompt' },
    h('div', { class: 'sec-h' }, h('h2', {}, icon('wand', 20), ' المصمم الذكي بالوصف'), h('p', {}, 'اكتب ما تريد بالعربية أو الإنجليزية، ثم عدّله واحفظه')),
    h('div', { class: 'tprompt-row' }, ta, h('button', { type: 'button', class: 'btn btn-gold', onclick: run }, icon('sparkle', 18), 'صمّم')),
    h('div', { class: 'chips' }, ex.map(x => h('button', { type: 'button', class: 'chip', onclick: () => { ta.value = x; run(); } }, x))),
    h('p', { class: 'fine' }, 'يعمل على جهازك مباشرة ويفهم الكلمات المفتاحية للنوع والخامة واللون والإطار والأرقام والشكل والحجم والخلفية والمدينة.'),
    out));
}

/* ---------------------------------------------------------- weather refresh */
async function refreshAllWeather(force) {
  const locs = new Map();
  const add = (loc, iv) => { if (loc && loc.lat != null) { const k = wxKey(loc), cur = locs.get(k); locs.set(k, { loc, iv: cur ? Math.min(cur.iv, iv) : iv }); } };
  for (const raw of loadDesigns()) { const d = normalize(raw); if (d.type === 'weather') add(locOf(d), d.weather.interval || 60); if (d.type === 'clock' && d.clock.wx) add(store.get('llx.clockloc', null) || DEFAULT_LOC, 60); }
  if (draft && draft.type === 'weather') add(locOf(draft), draft.weather.interval || 60);
  await Promise.all([...locs.values()].map(({ loc, iv }) => refreshWx(loc, force ? 0 : Math.max(15, iv)).catch(() => null)));
}
let draftWxBusy = false;
function ensureDraftWeather() {
  if (!draft || draft.type !== 'weather' || draftWxBusy) return;
  const loc = locOf(draft); if (!loc) return;
  const e = wxCached(loc);
  if (e && e.cur && Date.now() - e.at < Math.max(15, draft.weather.interval || 60) * 6e4) return;
  if (e && e.errAt && Date.now() - e.errAt < 60e3) return;
  draftWxBusy = true;
  refreshWx(loc).then(() => { draftWxBusy = false; renderPreview(); if (STEPS[ui.step] && STEPS[ui.step].k === 'content') renderStep(); });
}
/** Taps on time widgets inside the app (the Android widget opens the system apps). */
function timeTap(d, a) {
  if (a.k === 'refresh') { const loc = locOf(d); toast('جارٍ تحديث الطقس…'); refreshWx(loc).then(e => { toast(e && e.cur && !e.err ? 'تم تحديث الطقس' : 'تعذّر التحديث — تُعرض آخر بيانات صحيحة'); route(false); bakeAll(); }); }
  else if (NATIVE && window.LaunchyNative.openSystem) { try { window.LaunchyNative.openSystem(a.k); } catch (e) {} }
  else toast(a.k === 'clockApp' ? 'على هاتف Android يفتح هذا الويدجت تطبيق الساعة' : 'على هاتف Android يفتح هذا الويدجت تطبيق التقويم');
}

/* ---------------------------------------------------------- editor panels */
const isTimeDraft = () => isTimeType(draft);
function timeStepType() {
  const t = draft.type;
  const typeRow = h('div', { class: 'choice-grid' }, ['clock', 'date', 'weather'].map((k, i) => {
    const prev = previewBox(presetDesign(TIME_HOME.find(x => x.t === k).p), 160, 96);
    return h('button', { type: 'button', class: 'choice' + (t === k ? ' on' : ''), style: { '--i': i }, onclick: () => { if (draft.type === k) return; const p = presetDesign(TIME_HOME.find(x => x.t === k).p); update(d => { d.type = k; d[k] = p[k]; d.sizes[k] = p.sizes[k]; }, { rebuild: true }); } },
      prev, h('div', { class: 'choice-txt' }, h('strong', {}, TYPES[k].n), h('span', {}, TYPES[k].desc)), h('i', { class: 'choice-check' }, icon('check', 14)));
  }));
  const applyPreset = k => {
    const p = presetDesign(k, draft);
    update(d => { const keep = { id: d.id, name: d.name, created: d.created }; Object.assign(d, clone(p), keep); }, { rebuild: true });
    pushRecent('p:' + k); toast('طُبّق تصميم «' + TIME_PRESET[k].n + '»');
  };
  const list = TIME_PRESETS.filter(p => p.type === t);
  const variants = t === 'clock' ? CLOCK_FACES : null;
  return [intro('النوع والشكل', 'اختر نوع ويدجت الوقت ثم تصميماً جاهزاً تبدأ منه، وحجمه وشكله. كل شيء قابل للتعديل لاحقاً.'),
    typeRow,
    h('div', { style: { display: 'flex', gap: '8px', flexWrap: 'wrap', margin: '14px 0' } },
      h('button', { type: 'button', class: 'btn btn-sm', onclick: () => openDialog('جميع أنماط ' + TYPES[t].n, presetGrid(list, k => { $('#dlg').close(); applyPreset(k); }), [], { wide: true }) }, icon('layers', 15), 'عرض جميع الأنماط'),
      h('button', { type: 'button', class: 'btn btn-sm', onclick: () => { const r = randomTimeDesign(t); update(d => { const keep = { id: d.id, name: d.name, created: d.created }; Object.assign(d, clone(r), keep); }, { rebuild: true }); } }, icon('dice', 15), 'عشوائي')),
    group('tsize', 'الحجم والشكل', sizeCtl(),
      t === 'clock' ? seg('نوع الساعة', 'clock.face', variants) : null,
      t === 'clock' && draft.clock.face === 'analog' ? seg('الشكل', 'clock.shape', CLOCK_SHAPES) : null,
      t === 'clock' && draft.clock.face === 'digital' ? seg('التوزيع', 'clock.layout', DIGITAL_LAYOUTS) : null,
      t === 'clock' && draft.clock.face === 'pendulum' ? seg('أعلى ساعة البندول', 'clock.pendFace', PEND_FACES) : null,
      t === 'clock' && draft.clock.face === 'pendulum' ? h('p', { class: 'fine' }, 'المقاس الأنسب للبندول: 2×3 أو 2×4 (عمودي).') : null,
      t === 'clock' && draft.clock.face === 'pill' ? h('p', { class: 'fine' }, 'الكبسولة مصممة لمقاس 4×1: زر المنبه في البداية، الوقت في الوسط، وشارة التاريخ في النهاية.') : null,
      t === 'date' ? seg('شكل بطاقة التاريخ', 'date.variant', DATE_VARIANTS) : null,
      t === 'weather' ? seg('شكل ويدجت الطقس', 'weather.variant', WX_VARIANTS) : null,
      h('p', { class: 'fine' }, 'الأحجام بخلايا الشاشة الرئيسية الفعلية في Android (أعمدة × صفوف). يمكنك أيضاً تغيير الحجم على الشاشة بعد الإضافة، ويُعاد رسم التصميم بالمقاس الجديد.')),
    h('div', { class: 'sub-h', style: { marginTop: '12px' } }, 'تصاميم جاهزة لهذا النوع'),
    presetGrid(list, applyPreset)];
}
function chipsSeg(label, path, opts) { return seg(label, path, opts); }
function timeLookGroups() {
  const t = draft.type, o = draft[t], out = [];
  if (t === 'clock') {
    out.push(group('tmatsw', 'بدّل خامة الساعة بلمسة', h('div', { class: 'chips' }, MATERIAL_SWITCH.map(([k, n, fn]) => h('button', { type: 'button', class: 'chip', onclick: () => { update(d => fn(d), { rebuild: true }); toast('أصبحت الساعة: ' + n); } }, n))),
      h('p', { class: 'fine' }, 'يتغير ملمس البطاقة والقرص والإطار معاً مع الحفاظ على الشكل والعقارب والإعدادات.')));
    out.push(...clockMotionGroups(o));
    const hasDial = o.face === 'analog' || o.face === 'combo' || (o.face === 'pendulum' && o.pendFace === 'analog');
    if (hasDial) out.push(group('tdial', 'القرص والإطار والعقارب',
      seg('القرص', 'clock.dial', DIALS),
      o.dial === 'material' ? h('details', { class: 'sub-det', open: true }, h('summary', {}, 'خامة القرص'), matGrid('clock.dialMat', 'a.matTint', { allowNone: false })) : null,
      o.dial === 'solid' || o.dial === 'sunburst' ? colorCtl('لون القرص', 'clock.dialColor', accentOf(draft)) : null,
      seg('إطار القرص', 'clock.bezel', BEZELS), o.bezel !== 'none' ? slider('سمك إطار القرص', 'clock.bezelW', 40, 180, 5, '%') : null,
      seg('الأرقام', 'clock.numerals', NUMERALS),
      o.numerals !== 'none' && o.numerals !== 'indices' ? seg('خط الأرقام', 'clock.numFont', [['', 'تلقائي'], ...CLOCK_FONTS.filter(f => f.k !== 'led').map(f => [f.k, f.n])]) : null,
      o.numerals !== 'none' && o.numerals !== 'indices' ? slider('حجم الأرقام', 'clock.numScale', .6, 1.4, .05, '×') : null,
      seg('المؤشرات', 'clock.indices', INDEX_STYLES), toggle('تدريج الدقائق', 'clock.ticks'),
      seg('شكل العقارب', 'clock.hands', HAND_STYLES), seg('لون العقارب', 'clock.handColor', HAND_COLORS.map(c => [c[0], c[1]])),
      colorCtl('لون الأرقام والمؤشرات', 'clock.ink', ''), toggle('أرقام بارزة (نقش)', 'clock.raised', 'مناسبة للمخمل والجلد'),
      toggle('زخارف دقيقة على القرص', 'clock.ornaments'),
      toggle('عقرب الثواني', 'clock.seconds', 'يتحرك كل ثانية على الشاشة الرئيسية (Android 12+) ويستهلك طاقة أكثر قليلاً'),
      o.seconds ? colorCtl('لون عقرب الثواني', 'clock.secColor') : null,
      h('p', { class: 'fine' }, 'العقارب على الشاشة الرئيسية حيّة يحرّكها نظام Android نفسه. على Android 12 وما بعده تُستخدم عقاربك بتصميمها نفسه، وعلى الإصدارات الأقدم تظهر عقارب أنيقة قياسية.')));
    if (o.face === 'digital' || o.face === 'pill' || o.face === 'combo' || (o.face === 'pendulum' && o.pendFace !== 'analog')) out.push(group('tdigits', 'خط الأرقام والألوان',
      o.layout !== 'led' ? seg('خط الوقت', 'clock.font', CLOCK_FONTS.filter(f => f.k !== 'led').map(f => [f.k, f.n])) : null,
      colorCtl('لون الأرقام', 'clock.timeColor', L_textOf(draft)),
      h('div', { class: 'ctl' }, colorCtl('لون التدرج الثاني', 'clock.gradient', ''), o.gradient ? h('button', { type: 'button', class: 'btn btn-sm btn-ghost', onclick: () => update(d => d.clock.gradient = '', { rebuild: true }) }, 'إيقاف التدرج') : null,
        h('p', { class: 'fine' }, 'التدرج يظهر في المعاينة وفي «شاشتي»؛ الوقت الحي على الشاشة الرئيسية يُرسم بلون واحد (لون الأرقام) لأن Android لا يدعم تدرج النص في الويدجت.')),
      slider('توهج خلف الأرقام', 'clock.glow', 0, 100, 1, '%'),
      o.layout === 'flip' ? colorCtl('لون البطاقات القلابة', 'clock.cardColor', '#1c1c20') : null));
  }
  if (t === 'date' || t === 'clock' || t === 'weather') {
    out.push(group('tfonts', 'الخطوط',
      seg('الخط العربي للنصوص', t + '.tfont', TEXT_FONTS.map(f => [f[0], f[1]])),
      t !== 'clock' ? seg('خط الأرقام الكبيرة', t + '.numFont', CLOCK_FONTS.filter(f => f.k !== 'led').map(f => [f.k, f.n])) : null,
      t === 'date' ? slider('حجم التاريخ', 'date.scale', 70, 130, 1, '%') : null,
      t === 'date' ? colorCtl('لون اليوم الحالي (التقويم)', 'date.todayColor', lookOf(draft).acc) : null,
      h('p', { class: 'fine' }, 'تُحمَّل الخطوط العربية من Google Fonts عند أول اتصال وتُحفظ بعدها؛ أرقام الساعات والتواريخ الكبيرة مدمجة في التطبيق وتعمل دون إنترنت.')));
  }
  if (t === 'weather') {
    const bg = o.bg;
    out.push(group('twbg', 'الخلفية الطبيعية',
      seg('طريقة الخلفية', 'weather.bg.mode', BG_MODES),
      bg.mode === 'weather' ? h('p', { class: 'fine' }, 'مشمس: قمم وشواطئ مشرقة · غائم: جبال وبحيرات بالغيوم · ممطر: غابات وشلالات · ثلوج: جبال شتوية · غروب: مناظر دافئة · ليل: سماء ليلية. تُفضَّل صورك المفضلة عند تطابقها.') : null,
      bg.mode === 'time' ? h('p', { class: 'fine' }, 'صباح: شروق · ظهر: مناظر مضيئة · غروب: ألوان دافئة · ليل: سماء هادئة.') : null,
      ['fixed', 'weather', 'time'].includes(bg.mode) ? h('div', { class: 'sub-h' }, bg.mode === 'fixed' ? 'اختر الخلفية الثابتة' : 'اختر الخلفية الاحتياطية') : null,
      ['fixed', 'weather', 'time'].includes(bg.mode) ? photoLibrary(k => update(d => { d.weather.bg.scene = k; }, { rebuild: true }), bg.scene) : null,
      bg.mode !== 'fixed' && bg.mode !== 'photo' && bg.mode !== 'none' ? h('button', { type: 'button', class: 'btn btn-sm', onclick: () => { const sc = layoutDesign(draft, sizeOf(draft).W, sizeOf(draft).H, []).info.scene; update(d => { d.weather.bg.mode = 'fixed'; if (sc) d.weather.bg.scene = sc; }, { rebuild: true }); toast('ثُبّتت الخلفية الحالية'); } }, icon('pinOn', 15), 'تثبيت الخلفية الظاهرة الآن') : null,
      bg.mode === 'rotate' || bg.mode === 'weather' ? h('details', { class: 'sub-det', open: bg.mode === 'rotate' }, h('summary', {}, `صوري المفضلة (${(bg.favs || []).length})`),
        h('div', { class: 'photo-grid small' }, SCENES.map(s => { const on = (bg.favs || []).includes(s.k); return h('button', { type: 'button', class: 'photo' + (on ? ' on' : ''), onclick: () => update(d => { const f = d.weather.bg.favs || []; d.weather.bg.favs = on ? f.filter(x => x !== s.k) : [...f, s.k]; }, { rebuild: true }) }, h('img', { src: s.src, alt: s.n, loading: 'lazy' }), h('span', {}, (on ? '★ ' : '') + s.n)); })),
        bg.mode === 'rotate' ? seg('مدة التبديل', 'weather.bg.every', [['update', 'مع كل تحديث للطقس (ساعة تقريباً)'], ['day', 'يومياً']]) : null,
        h('p', { class: 'fine' }, 'لا يسمح Android بتحديث الويدجت كل بضع ثوانٍ، لذلك يتم التبديل مع تحديثات الطقس أو يومياً.')) : null,
      bg.mode === 'photo' ? photoPick() : null,
      bg.mode !== 'none' ? slider('شفافية الصورة', 'weather.bg.alpha', 20, 100, 1, '%') : null,
      bg.mode !== 'none' ? seg('طبقة فوق الصورة', 'weather.bg.overlay', [['dark', 'داكنة'], ['light', 'فاتحة'], ['none', 'بدون']]) : null,
      bg.mode !== 'none' && bg.overlay !== 'none' ? slider('قوة الطبقة', 'weather.bg.overlayAmt', 0, 80, 1, '%') : null,
      bg.mode !== 'none' ? slider('التمويه', 'weather.bg.blur', 0, 40, 1, '') : null));
    out.push(group('twlay', 'توزيع العناصر والأيقونة',
      seg('مكان درجة الحرارة', 'weather.tempPos', [['start', 'يمين'], ['center', 'وسط'], ['end', 'يسار']]),
      slider('حجم أيقونة الطقس', 'weather.iconSize', 50, 160, 1, '%'),
      seg('نمط الأيقونات', 'weather.iconStyle', [['color', 'ملونة ثلاثية الأبعاد'], ['mono', 'خطية بيضاء']]),
      seg('الإطار', 'a.frame', [['none', 'بدون'], ['goldDouble', 'ذهبي'], ['royalGold', 'ذهبي ملكي'], ['silverF', 'فضي'], ['gradientGlow', 'زجاجي مضيء'], ['crystalF', 'كريستالي']])));
  }
  return out;
}
function photoPick() {
  const fi = h('input', { type: 'file', accept: 'image/*', hidden: true });
  fi.addEventListener('change', async () => { if (!fi.files[0]) return; try { const src = await readImageKeep(fi.files[0], 1100); update(d => { d.weather.bg.photo = src; }, { rebuild: true }); toast('أُضيفت صورتك خلفية للويدجت'); } catch (e) { toast('تعذّرت قراءة الصورة'); } });
  return h('div', { class: 'form' }, fi,
    draft.weather.bg.photo ? h('img', { src: draft.weather.bg.photo, alt: '', class: 'tphoto-prev' }) : null,
    h('button', { type: 'button', class: 'btn', onclick: () => fi.click() }, icon('image', 18), draft.weather.bg.photo ? 'تغيير الصورة' : 'اختيار صورة من معرض الهاتف'),
    h('p', { class: 'fine' }, 'تُحفظ الصورة داخل التصميم على جهازك فقط.'));
}
function tzOptions() { return [['', 'توقيت الجهاز'], ...CITIES.filter((c, i, a) => a.findIndex(x => x.tz === c.tz) === i).map(c => [c.tz, c.n])]; }
function timeStepContent() {
  const t = draft.type, o = draft[t];
  const common = (path) => [
    seg('اللغة', path + '.lang', [['ar', 'العربية'], ['en', 'English']]),
    seg('الأرقام', path + '.digits', [['latn', 'غربية 123'], ['arab', 'عربية ١٢٣']])];
  const calc = path => [seg('التقويم الهجري', path + '.calc', HIJRI_CALCS), slider('تعديل اليوم الهجري يدوياً', path + '.offset', -2, 2, 1, ' يوم'),
    h('p', { class: 'fine' }, (() => { const hh = hijriOf(new Date(), getPath(draft, path + '.calc'), getPath(draft, path + '.offset')); return 'اليوم حسب الإعداد: ' + toDigits(`${hh.d} ${HIJRI_MONTHS.ar[hh.m - 1]} ${hh.y} هـ`, 'latn') + (hh.approx ? ' — هذا المتصفح لا يدعم أم القرى، فاستُخدم الحساب الجدولي' : ''); })())];
  const els = [intro('الإعدادات والبيانات', t === 'weather' ? 'الموقع والوحدات والمعلومات المعروضة. البيانات حقيقية من Open-Meteo.' : 'كل التواريخ تُحسب من ساعة جهازك وتتحدث تلقائياً كل يوم — لا أرقام ثابتة.')];
  if (t === 'clock') {
    els.push(group('tcfmt', 'الوقت',
      seg('صيغة الوقت', 'clock.fmt', [['system', 'حسب الهاتف'], ['12', '12 ساعة'], ['24', '24 ساعة']]),
      o.face !== 'analog' ? toggle('إظهار ص/م', 'clock.ampm', 'بلغة الهاتف على الشاشة الرئيسية') : null,
      o.face === 'digital' ? toggle('صفر قبل الساعة (09:05)', 'clock.lead') : null,
      ...common('clock'),
      h('div', { class: 'ctl' }, h('span', { class: 'ctl-top' }, h('span', {}, 'المنطقة الزمنية (ساعة عالمية)')),
        (() => { const sel = h('select', { class: 'inp' }, tzOptions().map(([v, n]) => h('option', { value: v, selected: o.tz === v }, n))); sel.addEventListener('change', () => update(d => { d.clock.tz = sel.value; const c = CITIES.find(x => x.tz === sel.value); d.clock.tzName = sel.value ? (c ? c.n : sel.value) : ''; }, { rebuild: true })); return sel; })()),
      o.tz ? toggle('إظهار اسم المدينة', 'clock.city') : null));
    els.push(group('tcinfo', 'المعلومات مع الساعة',
      toggle('اسم اليوم', 'clock.weekday'),
      seg('التاريخ', 'clock.date', [['both', 'الهجري والميلادي'], ['hijri', 'الهجري'], ['greg', 'الميلادي'], ['none', 'بدون']]),
      toggle('حالة الطقس ودرجة الحرارة', 'clock.wx', 'تُستخدم المدينة الافتراضية للاستوديو'),
      toggle('عبارة يومية', 'clock.phrase'), o.phrase ? seg('مصدر العبارة', 'clock.phraseSet', PHRASE_SETS) : null,
      o.phrase && o.phraseSet === 'custom' ? textField('عبارتك', 'clock.phraseText', 60) : null,
      ...(o.date !== 'none' ? calc('clock') : [])));
  } else if (t === 'date') {
    els.push(group('tdcal', 'التقويم',
      seg('التاريخ الأساسي', 'date.primary', [['hijri', 'الهجري أولاً'], ['greg', 'الميلادي أولاً']]),
      seg('العرض', 'date.show', [['both', 'الهجري والميلادي معاً'], ['hijri', 'الهجري فقط'], ['greg', 'الميلادي فقط']]),
      ...calc('date'), ...common('date'),
      o.variant === 'calendar' ? seg('أول أيام الأسبوع', 'date.weekStart', [[0, 'الأحد'], [6, 'السبت'], [1, 'الاثنين']]) : null,
      toggle('اسم اليوم', 'date.weekday')));
    els.push(group('tdocc', 'المناسبات والعبارة اليومية',
      toggle('المناسبات الإسلامية', 'date.occasions', 'رمضان، العيدان، عرفة، عاشوراء، رأس السنة الهجرية…'),
      o.occasions ? toggle('الأيام البيض (13–15)', 'date.white') : null,
      o.occasions ? toggle('المناسبات الوطنية السعودية', 'date.national', 'يوم التأسيس، يوم العلم، اليوم الوطني') : null,
      toggle('عبارة يومية', 'date.phrase', 'تتغير كل يوم تلقائياً'), o.phrase ? seg('مصدر العبارة', 'date.phraseSet', PHRASE_SETS) : null,
      o.phrase && o.phraseSet === 'custom' ? textField('عبارتك', 'date.phraseText', 70) : null,
      o.variant === 'combo' ? seg('صيغة الوقت', 'date.fmt', [['system', 'حسب الهاتف'], ['12', '12 ساعة'], ['24', '24 ساعة']]) : null,
      o.variant === 'combo' ? seg('خط الوقت', 'date.font', CLOCK_FONTS.filter(f => f.k !== 'led').map(f => [f.k, f.n])) : null));
  } else {
    const loc = o.loc || DEFAULT_LOC, e = wxCached(locOf(draft));
    const st = !locOf(draft) ? 'لم يُحدَّد موقع الجهاز بعد — اضغط «موقعي الحالي» أو اختر مدينة.' : e && e.cur ? `آخر تحديث: ${new Date(e.at).toLocaleTimeString('ar-SA-u-ca-gregory-nu-latn', { hour: '2-digit', minute: '2-digit' })}${e.err ? ' — فشلت آخر محاولة، تُعرض آخر بيانات صحيحة' : ''}` : e && e.err ? 'تعذّر جلب البيانات — تحقق من الاتصال. لن تُعرض أرقام غير حقيقية.' : 'جارٍ جلب البيانات…';
    els.push(group('twloc', 'الموقع والتحديث',
      h('div', { class: 'ctl-row' }, h('span', {}, icon(loc.mode === 'device' ? 'locate' : 'pin', 16), ' ', loc.mode === 'device' ? 'موقعي الحالي' + (locOf(draft) && locOf(draft).name ? ' — ' + locOf(draft).name : '') : loc.name),
        h('button', { type: 'button', class: 'btn btn-sm', onclick: () => openLocationDialog(l => update(d => { d.weather.loc = l; }, { rebuild: true })) }, 'تغيير')),
      h('p', { class: 'fine' }, st),
      h('button', { type: 'button', class: 'btn btn-sm', onclick: async () => { const r = await refreshWx(locOf(draft)); toast(r && r.cur && !r.err ? 'تم التحديث' : 'تعذّر التحديث'); renderPreview(); renderStep(); } }, icon('reset', 15), 'تحديث الآن'),
      seg('الوحدة', 'weather.unit', [['C', 'مئوية °C'], ['F', 'فهرنهايت °F']]),
      seg('التحديث التلقائي', 'weather.interval', [[30, 'كل 30 دقيقة'], [60, 'كل ساعة'], [180, 'كل 3 ساعات'], [360, 'كل 6 ساعات']]),
      ...common('weather'), seg('ساعات التوقعات', 'weather.h12', [[true, '12 ساعة'], [false, '24 ساعة']]),
      h('p', { class: 'fine' }, 'يحدّث التطبيق الطقس في الخلفية ضمن قيود Android لتوفير البطارية؛ قد يتأخر التحديث قليلاً عندما يكون الهاتف في وضع توفير الطاقة.')));
    const sh = (k, n) => toggle(n, 'weather.show.' + k);
    els.push(group('twshow', 'المعلومات المعروضة', sh('city', 'اسم المدينة'), sh('desc', 'وصف الحالة'), sh('hilo', 'العظمى والصغرى'), sh('feels', 'الحرارة المحسوسة'),
      sh('hum', 'الرطوبة'), sh('wind', 'سرعة الرياح'), sh('aqi', 'جودة الهواء'), sh('sun', 'الشروق والغروب'), sh('uv', 'الأشعة فوق البنفسجية'), sh('hourly', 'توقعات الساعات'), sh('daily', 'توقعات الأيام'), sh('updated', 'وقت آخر تحديث'),
      h('p', { class: 'fine' }, 'بعض المعلومات تظهر فقط في الأحجام الكبيرة.')));
  }
  if (t === 'clock') {
    els.push(group('talarm', 'المنبه',
      toggle('إظهار المنبه التالي', 'clock.nextAlarm', 'وقت أقرب منبه في الجهاز (من أي تطبيق منبه يسجّله لدى Android)'),
      ['pendulum', 'combo'].includes(o.face) ? toggle('العد التنازلي للمنبه', 'clock.countdown', 'عدّاد حي على الشاشة الرئيسية حتى المنبه التالي') : null,
      o.face === 'pill' ? seg('زر المنبه في الكبسولة', 'clock.alarmTap', CLOCK_TAPS.filter(x => ['clockApp', 'setAlarm', 'appAlarms'].includes(x[0]))) : null,
      h('div', { class: 'note' }, icon('bell', 16), h('span', {}, 'الضغط على الساعة يفتح منبهات الجهاز. «منبهات التطبيق» منبه حقيقي داخل تطبيق الاختصارات يحرّك البندول ويُظهر تأثيرات الرنين على الويدجت. أما رنين تطبيقات المنبه الأخرى فلا يتيح Android اكتشافه، لذلك نعرض وقت المنبه التالي فقط.')),
      h('a', { class: 'btn btn-sm', href: '#/alarms', style: { marginTop: '8px' } }, icon('bell', 15), 'إدارة المنبهات')));
    els.push(group('ttap', 'عند الضغط على الساعة', seg('الإجراء', 'clock.tap', CLOCK_TAPS)));
  } else els.push(group('ttap', 'عند الضغط على الويدجت', seg('الإجراء', t + '.tap', TAPS.filter(x => (t === 'weather' || x[0] !== 'refresh') && !['setAlarm', 'appAlarms'].includes(x[0])))));
  return els;
}

/* ---------------------------------------------------------- clock motion, hands & packs panels */
/** Small sample clock for the motion cards (keeps the draft's look). */
function motionSample(m) {
  const d = clone(draft); d.id = 'motion-' + m; d.clock.motion = m;
  if (isPendMotion(m)) { if (d.clock.face !== 'pendulum') { d.clock.face = 'pendulum'; d.sizes.clock = [2, 3]; } d.clock.pendulum = true; }
  else if (d.clock.face === 'pendulum' || d.clock.face === 'pill' || d.clock.face === 'digital') { d.clock.face = 'analog'; d.clock.shape = 'circle'; d.sizes.clock = [2, 2]; }
  if (m === 'smooth' || m === 'mechanical') d.clock.seconds = true;
  return normalize(d);
}
function clockMotionGroups(o) {
  const cards = h('div', { class: 'motion-grid' }, MOTIONS.map(m => {
    const box = h('div', { class: 'motion-prev' });
    lazy(box, () => box.append(fitScaled(motionSample(m.k), 120, 120, {}, 1).el));
    return h('button', { type: 'button', class: 'motion-card' + (o.motion === m.k ? ' on' : ''), 'aria-pressed': String(o.motion === m.k), onclick: () => update(d => {
      d.clock.motion = m.k;
      if (isPendMotion(m.k) && d.clock.face !== 'pendulum') { d.clock.face = 'pendulum'; const [c, r] = d.sizes.clock; if (r < 3) d.sizes.clock = [2, 3]; d.clock.pendulum = true; }
      if ((m.k === 'smooth' || m.k === 'mechanical') && !d.clock.seconds) d.clock.seconds = true;
    }, { rebuild: true }) }, box, h('strong', {}, m.n), h('small', {}, m.d));
  }));
  const testBtn = h('button', { type: 'button', class: 'btn btn-sm' + (CLOCK_ALERT.on ? ' btn-gold' : ''), onclick: () => {
    setClockAlert(!CLOCK_ALERT.on);
    testBtn.classList.toggle('btn-gold', CLOCK_ALERT.on); testBtn.lastChild.textContent = CLOCK_ALERT.on ? 'إيقاف الرنين التجريبي' : 'جرّب تأثير الرنين';
    if (CLOCK_ALERT.on) setTimeout(() => { if (CLOCK_ALERT.on) { setClockAlert(false); testBtn.classList.remove('btn-gold'); testBtn.lastChild.textContent = 'جرّب تأثير الرنين'; } }, 8000);
  } }, icon('bell', 15), h('span', {}, CLOCK_ALERT.on ? 'إيقاف الرنين التجريبي' : 'جرّب تأثير الرنين'));
  const packs = h('div', { class: 'pack-grid' }, CLOCK_PACKS.map(p => h('button', { type: 'button', class: 'pack' + (o.pack === p.k ? ' on' : ''), onclick: () => { update(d => applyClockPack(d, p.k), { rebuild: true }); toast('باقة ' + p.n); } },
    h('i', { style: { background: `linear-gradient(135deg, ${p.sw[0]} 0 55%, ${p.sw[1]} 55%)` } }), h('span', {}, p.n))));
  const handOpts = [['', 'كالشكل العام'], ...HAND_STYLES];
  return [
    group('tpack', 'باقات الخامات', packs,
      h('p', { class: 'fine' }, 'كل باقة تغيّر الإطار والخلفية والعقارب والبندول معاً، ثم يمكنك تعديل كل جزء على حدة: «خامة الويدجت» للإطار والخلفية، و«القرص» و«لون العقارب» و«لون البندول» أدناه.')),
    group('tmotion', 'أنماط الحركة', cards,
      h('p', { class: 'fine' }, 'المعاينة هنا متحركة بسلاسة. على الشاشة الرئيسية يحرّك Android العقارب، ويُعرض البندول كحلقة صور قصيرة يشغّلها المشغّل نفسه (دون تحديثات متكررة تستنزف البطارية)، فتكون الحركة أبسط من المعاينة.')),
    group('tclockctl', 'لوحة التحكم بالساعة',
      ['pendulum', 'slowLux', 'fastAlarm'].includes(o.motion) || o.face === 'pendulum' ? toggle('تشغيل البندول', 'clock.pendulum', 'إيقافه يُبقي البندول ساكناً') : null,
      slider('سرعة الحركة', 'clock.speed', 50, 200, 5, '%'),
      o.face === 'pendulum' ? slider('زاوية التأرجح', 'clock.swing', 3, 20, 1, '°') : null,
      slider('شدة الإضاءة', 'clock.light', 0, 100, 5, '%'),
      slider('شدة الظلال', 'clock.shadowK', 0, 100, 5, '%'),
      o.face !== 'digital' && o.face !== 'pill' ? toggle('عقرب الثواني', 'clock.seconds') : null,
      toggle('تأثيرات الرنين', 'clock.alarmFx', 'توهج ذهبي، اهتزاز خفيف، وتسارع البندول عند رنين منبه التطبيق'),
      colorCtl('لون الإضاءة', 'a.lightColor', '#ffd98a'),
      o.face === 'pendulum' ? colorCtl('لون البندول والإطار الداخلي', 'clock.rod', '#d4af37') : null,
      o.face === 'pendulum' ? colorCtl('لون الخلفية الداخلية', 'clock.inner', '#120a05') : null,
      h('div', { style: { display: 'flex', gap: '8px', flexWrap: 'wrap', marginTop: '6px' } }, testBtn)),
    o.face === 'digital' || o.face === 'pill' || (o.face === 'pendulum' && o.pendFace !== 'analog') ? null : group('thands', 'تخصيص العقارب',
      seg('عقرب الساعات', 'clock.hourStyle', handOpts), seg('عقرب الدقائق', 'clock.minStyle', handOpts),
      seg('عقرب الثواني', 'clock.secStyle', SEC_STYLES),
      slider('سماكة العقارب', 'clock.handW', 50, 180, 5, '%'), slider('طول العقارب', 'clock.handL', 70, 120, 1, '%'),
      seg('غطاء المركز', 'clock.cap', CAPS),
      seg('لون العقارب', 'clock.handColor', HAND_COLORS.map(c => [c[0], c[1]])),
      colorCtl('توهج العقارب', 'clock.glowHands', ''))];
}
