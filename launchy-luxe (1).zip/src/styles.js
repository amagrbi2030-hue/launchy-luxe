/* =========================================================
   Style library — every style is a full look: base colours,
   material, frame, effects and tile finish. Picking a style
   replaces only these look fields; content and layout stay.
   ========================================================= */
const FX_KEYS = [
  ['soft', 'ظل ناعم', 'Soft Shadow'], ['inner', 'ظل داخلي', 'Inner Shadow'], ['ambient', 'توهج محيطي', 'Ambient Glow'],
  ['outer', 'توهج خارجي', 'Outer Glow'], ['golden', 'توهج ذهبي', 'Golden Glow'], ['neon', 'توهج نيون', 'Neon Glow'],
  ['edge', 'إضاءة الحواف', 'Edge Lighting'], ['reflect', 'انعكاس زجاجي', 'Glass Reflection'], ['elev', 'ارتفاع ثلاثي الأبعاد', '3D Elevation'],
  ['emboss', 'نقش بارز', 'Emboss'], ['depth', 'عمق', 'Depth']
];
const defaultFx = () => ({ soft: 45, inner: 0, ambient: 0, outer: 0, golden: 0, neon: 0, edge: 0, reflect: 0, elev: 0, emboss: 0, depth: 0, angle: 90, spread: 50 });
/** Look fields a style owns (replaced when a style is picked). */
const LOOK_KEYS = ['mat', 'matTint', 'matAlpha', 'mat2', 'frame', 'frameColor', 'frameW', 'ornDensity', 'ornSize', 'ornPos', 'frameGlow', 'frameAlpha', 'frameInset', 'lightColor', 'fx', 'tileMat', 'tileTint'];
const lookDefaults = () => ({ mat: 'none', matTint: false, matAlpha: 100, mat2: 'none', frame: 'none', frameColor: '', frameW: 3, ornDensity: 50, ornSize: 50, ornPos: 'all', frameGlow: 0, frameAlpha: 100, frameInset: 6, lightColor: '#ffd98a', fx: defaultFx(), tileMat: 'none', tileTint: false });
const fxOf = (o) => Object.assign(defaultFx(), o || {});
const GOLD = '#d4af37';

/* tweak helpers */
const T = {
  text: (sp, t, s) => { sp.text = ca(t, 1); sp.sub = ca(s || t, s ? 1 : .72); },
  tile: (sp, o) => Object.assign(sp.tile, o)
};

Object.assign(STYLES, {
  glass:    Object.assign(STYLES.glass,  { tags: ['modern', 'dark'], look: { fx: fxOf({ soft: 45, reflect: 35, edge: 18 }) } }),
  quiet:    Object.assign(STYLES.quiet,  { tags: ['luxury', 'light'], look: { fx: fxOf({ soft: 30 }) } }),
  neon:     Object.assign(STYLES.neon,   { tags: ['modern', 'dark'], look: { fx: fxOf({ soft: 40, neon: 20 }) } }),
  plush3d: { n: 'المخمل ثلاثي الأبعاد', en: 'Plush 3D', short: 'مخمل', mode: 'solid', base: 'clay', tags: ['luxury', 'dark'],
    desc: 'مخمل منفوخ بخياطة معيّنة وأيقونات بارزة كأنها وسائد ناعمة.',
    look: { mat: 'velvetEmb', matTint: true, fx: fxOf({ soft: 55, elev: 55, emboss: 40 }), tileMat: 'velvet', tileTint: true },
    tweak: sp => { T.text(sp, '#ffffff'); T.tile(sp, { glyph: '#ffffffff', border: '#00000000', bw: 0 }); } },
  royalGold: { n: 'الذهب الملكي', en: 'Royal Gold', short: 'ذهبي', mode: 'solid', base: 'amoled', tags: ['luxury', 'ornament', 'dark'],
    desc: 'مخمل أسود وإطار ذهبي ملكي بميداليات، وأيقونات ذهبية مصقولة.',
    look: { mat: 'velvet', frame: 'royalGold', frameColor: GOLD, frameW: 3, fx: fxOf({ soft: 50, golden: 30 }), tileMat: 'goldPolished' },
    tweak: sp => { T.text(sp, '#f6e7b8', '#c9ad6a'); T.tile(sp, { glyph: '#2a1d05ff', border: ca('#7a5a12', .6), hi: ca('#ffffff', .5), drop: { c: ca('#000000', .5), r: 10, dy: 4 } }); sp.acc = ca(GOLD, 1); } },
  minimal: { n: 'البساطة الحديثة', en: 'Minimal Modern', short: 'بسيط', mode: 'solid', base: 'quiet', tags: ['modern', 'light'],
    desc: 'سطح أبيض نقي وحدود رفيعة ومسافات هادئة بلا زخرفة.',
    look: { fx: fxOf({ soft: 22 }) },
    tweak: (sp, A) => { sp.bg = ['#ffffffff', '#f6f7f9ff']; sp.border = ca('#000000', .06); sp.gold = null; T.text(sp, '#1d1f23', '#6b7078'); T.tile(sp, { bg: ['#f1f2f5ff'], border: ca('#000000', .05), glyph: ca(lum(A) > .6 ? mix(A, '#000000', .5) : A, 1), drop: null }); } },
  royalOrn: { n: 'الزخارف الملكية', en: 'Royal Ornamental', short: 'ملكي', mode: 'solid', base: 'amoled', tags: ['luxury', 'ornament', 'dark'],
    desc: 'ساتان عميق بإطار ملكي مزخرف وزوايا ملتفّة ذهبية.',
    look: { mat: 'satin', matTint: true, frame: 'royalOrn', frameColor: '#d6b25e', ornDensity: 60, fx: fxOf({ soft: 50, golden: 15 }), tileMat: 'satin', tileTint: true },
    tweak: sp => { T.text(sp, '#fff6e0', '#e3cf9c'); T.tile(sp, { glyph: '#ffe9b5ff', border: ca('#d6b25e', .55), hi: ca('#ffffff', .25) }); } },
  baroque: { n: 'الزخارف الباروكية', en: 'Baroque Luxury', short: 'باروك', mode: 'solid', base: 'amoled', tags: ['luxury', 'ornament', 'dark'],
    desc: 'مخمل منقوش وإطار كلاسيكي بزوايا مقعّرة وأيقونات ذهب معتق.',
    look: { mat: 'velvetEmb', matTint: true, frame: 'classic', frameColor: '#caa24a', frameW: 3, fx: fxOf({ soft: 55, golden: 28, emboss: 20 }), tileMat: 'goldAntique' },
    tweak: sp => { T.text(sp, '#f3dfaa', '#cdb37a'); T.tile(sp, { glyph: '#2b1c06ff', border: ca('#5a3f0f', .6), hi: ca('#ffffff', .35) }); } },
  arabesque: { n: 'الأرابيسك المتوهج', en: 'Glowing Arabesque', short: 'أرابيسك', mode: 'solid', base: 'neon', tags: ['ornament', 'dark'],
    desc: 'زخارف نباتية مضيئة على مخمل داكن بتوهج محسوب.',
    look: { mat: 'velvet', matTint: false, frame: 'arabesque', frameColor: '', frameGlow: 70, lightColor: '#5ff2d6', fx: fxOf({ soft: 45, outer: 25 }) },
    tweak: (sp, A) => { sp.minA = .92; } },
  leather: { n: 'الجلد البارز', en: 'Embossed Leather', short: 'جلد', mode: 'solid', base: 'clay', tags: ['luxury', 'dark'],
    desc: 'جلد بني منقوش بخياطة ذهبية وأيقونات جلدية دافئة.',
    look: { mat: 'leatherEmb', frame: 'stitched', frameColor: '#d8b35a', fx: fxOf({ soft: 50, inner: 30 }), tileMat: 'leather' },
    tweak: sp => { T.text(sp, '#f5e6cc', '#d6bf98'); T.tile(sp, { glyph: '#f3d48aff', border: ca('#000000', .2), bw: 1, hi: ca('#ffffff', .18), lo: ca('#000000', .3) }); } },
  marble: { n: 'الرخام الملكي', en: 'Royal Marble', short: 'رخام', mode: 'solid', base: 'quiet', tags: ['luxury', 'light'],
    desc: 'رخام أبيض بعروق رمادية وإطار ذهبي مزدوج وأيقونات خزفية.',
    look: { mat: 'marbleWhite', frame: 'goldDouble', frameColor: '#c9a24a', frameW: 2.5, fx: fxOf({ soft: 35, reflect: 18 }), tileMat: 'porcelain' },
    tweak: sp => { sp.gold = null; T.text(sp, '#2a2520', '#7a7166'); T.tile(sp, { glyph: '#9a7630ff', border: ca('#9a7630', .25) }); } },
  holo: { n: 'الزجاج الهولوغرافي', en: 'Holographic Glass', short: 'هولو', mode: 'solid', base: 'glass', tags: ['modern', 'dark'],
    desc: 'زجاج سائل بانعكاسات قزحية وحافة مضيئة متدرجة.',
    look: { mat: 'glassLiquid', matTint: true, frame: 'gradientGlow', lightColor: '#9ef3ff', frameGlow: 50, frameW: 2, fx: fxOf({ soft: 40, reflect: 55, edge: 45 }), tileMat: 'pearl' },
    tweak: (sp, A) => { T.tile(sp, { glyph: ca(mix(A, '#000000', .35), 1), border: ca('#ffffff', .6) }); } },
  bronze: { n: 'النحاس المعتق', en: 'Antique Bronze', short: 'نحاس', mode: 'solid', base: 'mono', tags: ['luxury', 'ornament', 'dark'],
    desc: 'برونز بزنجار خفيف وإطار نحاسي محفور.',
    look: { mat: 'bronze', frame: 'copperEngr', frameColor: '#b5793f', fx: fxOf({ soft: 55, emboss: 35 }), tileMat: 'matteMetal' },
    tweak: sp => { T.text(sp, '#fbe7c6', '#d9b98a'); T.tile(sp, { glyph: '#e6b878ff', border: ca('#b5793f', .45) }); } },
  emerald: { n: 'الزمرد المتوهج', en: 'Emerald Glow', short: 'زمرد', mode: 'solid', base: 'amoled', tags: ['luxury', 'ornament', 'dark'],
    desc: 'رخام زمردي بنقوش ذهبية نباتية وتوهج ذهبي ناعم.',
    look: { mat: 'marbleGreen', frame: 'arabesque', frameColor: '#d8b75e', fx: fxOf({ soft: 45, golden: 30 }), tileMat: 'velvet', tileTint: true },
    tweak: sp => { T.text(sp, '#f7ecd0', '#d9c79a'); T.tile(sp, { glyph: '#f0d48aff', border: ca('#d8b75e', .5), hi: ca('#ffffff', .2) }); } },
  carbon: { n: 'الكربون والتيتانيوم', en: 'Carbon Titanium', short: 'كربون', mode: 'solid', base: 'mono', tags: ['modern', 'dark'],
    desc: 'نسيج كربوني وإطار تيتانيوم مشطوف وأيقونات معدنية مصقولة.',
    look: { mat: 'carbon', frame: 'metal3d', frameColor: '#9aa3ad', frameW: 2.5, fx: fxOf({ soft: 55, edge: 25 }), tileMat: 'titanium' },
    tweak: sp => { T.text(sp, '#e9edf2', '#a7afba'); T.tile(sp, { glyph: '#111316ff', border: ca('#ffffff', .25) }); } },
  crystal: { n: 'الكريستال الفاخر', en: 'Crystal Luxury', short: 'كريستال', mode: 'solid', base: 'glass', tags: ['luxury', 'light'],
    desc: 'كريستال مقطّع بأوجه لامعة وإطار كريستالي متلألئ.',
    look: { mat: 'crystal', frame: 'crystalF', frameGlow: 40, lightColor: '#cfeaff', fx: fxOf({ soft: 35, reflect: 45, outer: 18 }), tileMat: 'glassFrosted' },
    tweak: sp => { T.text(sp, '#13314f', '#3d5f80'); T.tile(sp, { glyph: '#1f4f7fff', border: ca('#ffffff', .8), hi: ca('#ffffff', .8) }); } },
  midnight: { n: 'الفخامة الليلية', en: 'Midnight Luxury', short: 'ليلي', mode: 'solid', base: 'amoled', tags: ['luxury', 'dark'],
    desc: 'مخمل كحلي عميق بإطار فضي وتوهج محيطي هادئ.',
    look: { mat: 'velvet', matTint: true, frame: 'silverF', frameColor: '#c7cdd6', frameW: 2, fx: fxOf({ soft: 45, ambient: 40 }), tileMat: 'glassFrosted' },
    tweak: sp => { T.text(sp, '#e8ecf5', '#a8b1c4'); T.tile(sp, { glyph: '#ffffffff', border: ca('#ffffff', .25) }); } },
  champagne: { n: 'الشامبانيا الذهبي', en: 'Champagne Gold', short: 'شامبانيا', mode: 'solid', base: 'quiet', tags: ['luxury', 'light'],
    desc: 'ساتان شامبانيا لامع بإطار ذهبي مزدوج وأيقونات لؤلؤية.',
    look: { mat: 'satin', frame: 'goldDouble', frameColor: '#c8a46a', frameW: 2, fx: fxOf({ soft: 35, reflect: 15 }), tileMat: 'pearl' },
    tweak: sp => { sp.gold = null; T.text(sp, '#3b2f1c', '#7d6a4b'); T.tile(sp, { glyph: '#9a7840ff', border: ca('#c8a46a', .45) }); } },
  obsidian: { n: 'الأسود البركاني', en: 'Obsidian Black', short: 'أوبسيديان', mode: 'solid', base: 'amoled', tags: ['modern', 'dark'],
    desc: 'رخام أسود عاكس بإطار معدني داكن وانعكاس زجاجي.',
    look: { mat: 'marbleBlack', frame: 'metal3d', frameColor: '#3a3d42', frameW: 2.5, fx: fxOf({ soft: 60, reflect: 35, edge: 20 }), tileMat: 'carbon' },
    tweak: sp => { T.text(sp, '#f0f0f0', '#9b9b9b'); T.tile(sp, { glyph: '#e8e8e8ff', border: ca('#ffffff', .12), hi: ca('#ffffff', .14) }); } },
  aurora:   Object.assign(STYLES.aurora, { en: 'Aurora Glow', n: 'التوهج الشفقي', tags: ['modern', 'dark'], look: { fx: fxOf({ soft: 40, ambient: 35, reflect: 18 }) } }),
  pearl: { n: 'اللؤلؤ الأبيض', en: 'Pearl White', short: 'لؤلؤ', mode: 'solid', base: 'quiet', tags: ['luxury', 'light'],
    desc: 'لؤلؤ قزحي ناعم بإطار فضي وأيقونات خزف أبيض.',
    look: { mat: 'pearl', frame: 'silverF', frameColor: '#c9ced6', frameW: 2, fx: fxOf({ soft: 30, reflect: 25 }), tileMat: 'porcelain' },
    tweak: (sp, A) => { sp.gold = null; T.text(sp, '#2b2a33', '#6f6c7c'); T.tile(sp, { glyph: ca(lum(A) > .55 ? mix(A, '#000000', .5) : A, 1), border: ca('#b9bcc9', .5) }); } },
  burgundy: { n: 'العنابي الملكي', en: 'Royal Burgundy', short: 'عنابي', mode: 'solid', base: 'amoled', tags: ['luxury', 'ornament', 'dark'],
    desc: 'مخمل عنابي بإطار ذهبي ملكي وأيقونات مخملية بارزة.',
    look: { mat: 'velvet', matTint: true, frame: 'royalGold', frameColor: GOLD, frameW: 2.5, fx: fxOf({ soft: 50, golden: 25 }), tileMat: 'velvetEmb', tileTint: true },
    tweak: sp => { T.text(sp, '#fbe9c8', '#dcc196'); T.tile(sp, { glyph: '#f1cf7dff', border: ca(GOLD, .55), hi: ca('#ffffff', .2) }); } },
  sapphire: { n: 'الأزرق الياقوتي', en: 'Sapphire Blue', short: 'ياقوت', mode: 'solid', base: 'glass', tags: ['luxury', 'dark'],
    desc: 'ساتان ياقوتي بإطار فضي وإضاءة حواف باردة.',
    look: { mat: 'satin', matTint: true, frame: 'silverF', frameColor: '#d6e2f2', frameW: 2, fx: fxOf({ soft: 40, edge: 40, reflect: 30 }), tileMat: 'glassFrosted' },
    tweak: sp => { T.text(sp, '#ffffff'); } },
  heritage: { n: 'التراث الإسلامي', en: 'Islamic Heritage', short: 'تراث', mode: 'solid', base: 'quiet', tags: ['ornament', 'light'],
    desc: 'سيراميك دافئ بإطار هندسي إسلامي بنجوم ثمانية وعناوين بقوس محراب.',
    look: { mat: 'ceramic', frame: 'islamicGeo', frameColor: '#1f6f73', frameW: 2.5, fx: fxOf({ soft: 35 }), tileMat: 'porcelain' },
    tweak: sp => { sp.gold = null; T.text(sp, '#1d3b3c', '#4f6b6b'); T.tile(sp, { glyph: '#1f6f73ff', border: ca('#1f6f73', .3) }); sp.acc = ca('#1f6f73', 1); } }
});
for (const k of ['mono', 'neumorph', 'outline', 'amoled', 'clay']) STYLES[k].tags = STYLES[k].tags || ['modern', ['neumorph'].includes(k) ? 'light' : 'dark'];
STYLES.mono.look = { fx: fxOf({ soft: 50 }) };
STYLES.neumorph.look = { fx: fxOf({ soft: 30 }) };
STYLES.outline.look = { fx: fxOf({ soft: 20 }) };
STYLES.amoled.look = { fx: fxOf({ soft: 45 }) };
STYLES.clay.look = { fx: fxOf({ soft: 55, elev: 30 }) };
/** Library order: the 24 signature styles first, then the extra finishes. */
const STYLE_ORDER = ['glass', 'quiet', 'neon', 'plush3d', 'royalGold', 'minimal', 'royalOrn', 'baroque', 'arabesque', 'leather', 'marble', 'holo', 'bronze', 'emerald', 'carbon', 'crystal', 'midnight', 'champagne', 'obsidian', 'aurora', 'pearl', 'burgundy', 'sapphire', 'heritage', 'mono', 'neumorph', 'outline', 'amoled', 'clay'];
const STYLE_TAGS = [['all', 'الكل'], ['luxury', 'فاخر'], ['ornament', 'زخرفي'], ['modern', 'عصري'], ['light', 'فاتح'], ['dark', 'داكن']];
Object.assign(SAMPLE_THEME, { plush3d: 'purple', royalGold: 'gold', minimal: 'royal', royalOrn: 'navy', baroque: 'burgundy', arabesque: 'turquoise', leather: 'brown', marble: 'gold', holo: 'lavender', bronze: 'brown', emerald: 'emerald', carbon: 'graphite', crystal: 'sky', midnight: 'navy', champagne: 'gold', obsidian: 'onyx', pearl: 'lavender', burgundy: 'burgundy', sapphire: 'royal', heritage: 'turquoise' });
function styleLook(k) { return Object.assign(lookDefaults(), clone((STYLES[k] && STYLES[k].look) || {})); }

/* =========================================================
   Premium templates — a complete design minus your content.
   ========================================================= */
const sec = (kind, layout, title, extra = {}) => Object.assign({ id: kind + layout + Math.random().toString(36).slice(2, 6), kind, layout, title, show: true, cols: 4, count: 8, ids: null }, extra);
const TEMPLATES = [
  { k: 'royalVertical', n: 'Royal Vertical', ar: 'العمودي الملكي', type: 'vertical', style: 'royalGold', theme: 'gold', size: [2, 4],
    vertical: { title: 'اختصاراتي', titleStyle: 'cartouche', divider: 'islamic', sections: [sec('people', 'people', 'العائلة', { cols: 2, count: 4 }), sec('apps', 'icons', 'التطبيقات', { cols: 3, count: 6 }), sec('links', 'list', 'مواقعي', { count: 3 })] } },
  { k: 'emeraldOrn', n: 'Emerald Ornamental', ar: 'الزمرد المزخرف', type: 'vertical', style: 'emerald', theme: 'emerald', size: [3, 4],
    vertical: { title: 'المفضلة', titleStyle: 'flourish', divider: 'islamic', sections: [sec('apps', 'iconsLabels', 'التطبيقات', { cols: 3, count: 6 }), sec('people', 'list', 'جهات الاتصال', { count: 3 })] } },
  { k: 'goldHeritage', n: 'Gold Heritage', ar: 'التراث الذهبي', type: 'card', style: 'heritage', theme: 'turquoise', size: [4, 3], a: { frame: 'islamicGeo' } },
  { k: 'midnightGlass', n: 'Midnight Glass', ar: 'زجاج منتصف الليل', type: 'grid', style: 'midnight', theme: 'navy', size: [4, 2] },
  { k: 'velvetBlack', n: 'Velvet Black', ar: 'المخمل الأسود', type: 'grid', style: 'royalGold', theme: 'onyx', size: [4, 2], a: { frame: 'goldDouble' } },
  { k: 'neonEdge', n: 'Neon Edge', ar: 'حافة النيون', type: 'dock', style: 'neon', theme: 'turquoise', size: [4, 1], a: { fx: fxOf({ soft: 40, neon: 45 }) } },
  { k: 'marblePrestige', n: 'Marble Prestige', ar: 'هيبة الرخام', type: 'card', style: 'marble', theme: 'gold', size: [4, 3] },
  { k: 'bronzeClassic', n: 'Bronze Classic', ar: 'البرونز الكلاسيكي', type: 'grid', style: 'bronze', theme: 'brown', size: [4, 2], a: { frame: 'classic', frameColor: '#c58b4c' } },
  { k: 'crystalBlue', n: 'Crystal Blue', ar: 'الكريستال الأزرق', type: 'circle', style: 'crystal', theme: 'sky', size: [3, 3], circle: { layout: 'ring', center: 'title', title: 'المفضلة' } },
  { k: 'arabicGeo', n: 'Arabic Geometric', ar: 'الهندسي العربي', type: 'vertical', style: 'heritage', theme: 'turquoise', size: [2, 4],
    vertical: { title: 'روابطي', titleStyle: 'arch', divider: 'arch', sections: [sec('links', 'cards', 'المواقع', { count: 3 }), sec('apps', 'icons', 'التطبيقات', { cols: 3, count: 3 })] } },
  { k: 'quietLux', n: 'Quiet Luxury', ar: 'الفخامة الهادئة', type: 'grid', style: 'quiet', theme: 'gold', size: [4, 2] },
  { k: 'royalContact', n: 'Royal Contact', ar: 'جهة الاتصال الملكية', type: 'people', style: 'burgundy', theme: 'burgundy', size: [4, 2], people: { layout: 'single', number: true, avatarFrame: 'gold', mask: 'circle' } },
  { k: 'familyCircle', n: 'Family Circle', ar: 'دائرة العائلة', type: 'circle', style: 'champagne', theme: 'gold', size: [3, 3], circle: { layout: 'hero' }, people: { avatarFrame: 'gold' } },
  { k: 'business', n: 'Business Shortcuts', ar: 'اختصارات الأعمال', type: 'card', style: 'carbon', theme: 'graphite', size: [4, 3], card: { title: 'العمل', subtitle: 'أدوات اليوم', sections: true } },
  { k: 'mixedVertical', n: 'Mixed Vertical', ar: 'العمودي المختلط', type: 'vertical', style: 'glass', theme: 'royal', size: [2, 4],
    vertical: { title: 'كل ما أحتاجه', titleStyle: 'flourish', divider: 'goldLine', sections: [sec('mixed', 'iconsLabels', '', { cols: 3, count: 6 }), sec('people', 'people', 'المقرّبون', { cols: 2, count: 2 })] } },
  { k: 'titaniumGrid', n: 'Titanium Grid', ar: 'شبكة التيتانيوم', type: 'grid', style: 'carbon', theme: 'graphite', size: [4, 3], grid: { cols: 4, count: 12 } },
  { k: 'auroraGlass', n: 'Aurora Glass', ar: 'زجاج الشفق', type: 'people', style: 'aurora', theme: 'rose', size: [4, 1], people: { layout: 'row', avatarFrame: 'glass' } },
  { k: 'pearlLux', n: 'Pearl Luxury', ar: 'اللؤلؤ الفاخر', type: 'vertical', style: 'pearl', theme: 'lavender', size: [2, 3],
    vertical: { title: 'اليوم', titleStyle: 'plain', divider: 'dots', sections: [sec('apps', 'list', '', { count: 4 })] } }
];
