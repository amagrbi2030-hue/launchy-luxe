/* =========================================================
   Nature backgrounds — a library of real photographs (shipped
   inside the app, so they work offline and in the background
   baker). Each photo carries tags used by the smart modes:
   weather (clear / cloudy / rain / snow / fog) and time of day
   (morning / noon / evening / night), plus a focus point so it
   crops well into any Android widget size.
   ========================================================= */
const SCENE_CATS = [
  ['mountains', 'الجبال والمرتفعات'], ['snow', 'الثلوج والجبال الشتوية'], ['forests', 'الغابات والأشجار'], ['falls', 'الشلالات والأنهار'],
  ['lakes', 'البحيرات والطبيعة الهادئة'], ['seas', 'البحار والشواطئ'], ['sky', 'السماء والليل والغروب'], ['gardens', 'الحدائق والمناظر الريفية']
];
const TODS = [['morning', 'صباح'], ['noon', 'ظهر'], ['evening', 'غروب'], ['night', 'ليل']];
const WXS = [['clear', 'مشمس'], ['cloudy', 'غائم'], ['rain', 'ممطر'], ['snow', 'ثلجي'], ['fog', 'ضبابي']];
/* k, name, category, weather tags, time tags, focus x/y (0..1) */
const SCENES = [
  ['greenPeak', 'القمة الخضراء', 'mountains', ['clear'], ['noon', 'morning'], .5, .42],
  ['fallsValley', 'وادي الشلالات', 'falls', ['clear'], ['noon', 'morning'], .55, .45],
  ['goldenPeak', 'القمة الذهبية', 'snow', ['snow', 'clear'], ['evening', 'night'], .5, .38],
  ['peaksClouds', 'القمم فوق الغيوم', 'snow', ['snow', 'cloudy'], ['morning'], .5, .35],
  ['mistyValley', 'وادي الخيول الضبابي', 'forests', ['fog', 'cloudy', 'rain'], ['morning', 'noon'], .5, .55],
  ['forestRoad', 'طريق الغابة بين الغيوم', 'forests', ['fog', 'cloudy'], ['morning', 'noon'], .5, .5],
  ['forestFalls', 'شلال الغابة الخضراء', 'falls', ['rain', 'cloudy'], ['noon'], .5, .5],
  ['mountainStream', 'الجدول الجبلي الصافي', 'lakes', ['clear'], ['noon'], .5, .5],
  ['lakeHouse', 'كوخ البحيرة الجبلية', 'lakes', ['cloudy', 'rain', 'fog'], ['noon', 'morning'], .55, .5],
  ['lakeSunset', 'انعكاس الغروب على البحيرة', 'lakes', ['cloudy', 'clear'], ['evening'], .5, .5],
  ['coastSunset', 'غروب الساحل', 'seas', ['clear'], ['evening'], .5, .5],
  ['riceFields', 'حقول الأرز عند الشروق', 'gardens', ['clear'], ['morning', 'evening'], .5, .45],
  ['moonTree', 'شجرة القمر', 'sky', ['clear'], ['night'], .5, .5],
  ['cosmic', 'السماء الكونية', 'sky', ['clear', 'cloudy'], ['night'], .5, .4]
].map(([k, n, cat, wx, tod, fx, fy]) => ({ k, n, cat, wx, tod, fx, fy, src: SCENE_DATA[k] }));
const SCENE = Object.fromEntries(SCENES.map(s => [s.k, s]));
const DEFAULT_SCENE = 'greenPeak';

/** Time of day from a Date (night when the weather says the sun is down). */
function todOf(date, wv) {
  const h = date.getHours() + date.getMinutes() / 60;
  if (wv && wv.day === false) return h > 4 && h < 7 ? 'morning' : 'night';
  if (h >= 5 && h < 10) return 'morning';
  if (h >= 10 && h < 16.5) return 'noon';
  if (h >= 16.5 && h < 19) return 'evening';
  return 'night';
}
/** Which photo a background shows right now (smart modes pick from the tags). */
function pickScene(bg, wv, now = new Date()) {
  const day = Math.floor(dayOnly(now).getTime() / 864e5);
  const favs = (bg.favs || []).filter(k => SCENE[k]);
  const choose = list => {
    if (!list.length) return SCENE[bg.scene] || SCENE[DEFAULT_SCENE];
    const pref = list.filter(s => favs.includes(s.k)); const L = pref.length ? pref : list;
    return L[day % L.length];
  };
  if (bg.mode === 'fixed') return SCENE[bg.scene] || SCENE[DEFAULT_SCENE];
  if (bg.mode === 'rotate') {
    if (!favs.length) return SCENE[bg.scene] || SCENE[DEFAULT_SCENE];
    const n = bg.every === 'day' ? day : Math.floor((wv && wv.at ? wv.at : Date.now()) / 36e5);
    return SCENE[favs[n % favs.length]];
  }
  const tod = todOf(now, wv);
  if (bg.mode === 'time') return choose(SCENES.filter(s => s.tod.includes(tod)));
  // weather mode: the real condition first, the light of the day second
  if (!wv) return choose(SCENES.filter(s => s.tod.includes(tod)));
  const g = wv.group;
  if (tod === 'night' && (g === 'clear' || g === 'cloudy')) return choose(SCENES.filter(s => s.tod.includes('night')));
  if (tod === 'evening' && g === 'clear') return choose(SCENES.filter(s => s.tod.includes('evening') && s.wx.includes('clear')));
  const byWx = SCENES.filter(s => s.wx.includes(g)), both = byWx.filter(s => s.tod.includes(tod));
  return choose(both.length ? both : byWx);
}
/** Cover-crop around the photo's focus point. */
function drawCoverFocus(ctx, img, x, y, w, h, fx = .5, fy = .5) {
  const s = Math.max(w / img.width, h / img.height), iw = img.width * s, ih = img.height * s;
  ctx.drawImage(img, x - (iw - w) * fx, y - (ih - h) * fy, iw, ih);
}
