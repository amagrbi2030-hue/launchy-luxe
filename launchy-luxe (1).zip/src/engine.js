/* =========================================================
   Luxe render engine
   One canvas renderer drives the studio previews AND the Android
   widgets (the app bakes each design to an image + tap areas), so
   what you see in the studio is what lands on the home screen.
   ========================================================= */
const TAU = Math.PI * 2;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const lerp = (a, b, t) => a + (b - a) * t;
const smooth = (a, b, x) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
const frac = x => x - Math.floor(x);
const glyphCache = {};
const glyphPath = n => glyphCache[n] || (glyphCache[n] = new Path2D(GP[n] || GP.apps));
const FONT = '"IBM Plex Sans Arabic", "Noto Sans Arabic", system-ui, sans-serif';
const FONT_D = '"Readex Pro", "IBM Plex Sans Arabic", system-ui, sans-serif';

/* ---------------------------------------------------------- shapes */
function rrPath(p, x, y, w, h, r) {
  r = Math.max(0, Math.min(r, w / 2, h / 2));
  p.moveTo(x + r, y); p.lineTo(x + w - r, y); p.arcTo(x + w, y, x + w, y + r, r);
  p.lineTo(x + w, y + h - r); p.arcTo(x + w, y + h, x + w - r, y + h, r);
  p.lineTo(x + r, y + h); p.arcTo(x, y + h, x, y + h - r, r);
  p.lineTo(x, y + r); p.arcTo(x, y, x + r, y, r); p.closePath();
  return p;
}
function polyPath(p, cx, cy, rx, ry, n, rot, round) {
  const pts = [];
  for (let i = 0; i < n; i++) { const a = rot + i * TAU / n; pts.push([cx + rx * Math.cos(a), cy + ry * Math.sin(a)]); }
  const mid = (a, b) => [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2];
  const m0 = mid(pts[n - 1], pts[0]);
  p.moveTo(m0[0], m0[1]);
  for (let i = 0; i < n; i++) { const c = pts[i], m = mid(c, pts[(i + 1) % n]); p.arcTo(c[0], c[1], m[0], m[1], round); }
  p.closePath();
  return p;
}
function heartPath(p, x, y, w, h) {
  const X = u => x + u * w, Y = v => y + v * h;
  p.moveTo(X(.5), Y(.97));
  p.bezierCurveTo(X(.17), Y(.77), X(0), Y(.56), X(0), Y(.33));
  p.bezierCurveTo(X(0), Y(.14), X(.15), Y(.03), X(.3), Y(.03));
  p.bezierCurveTo(X(.4), Y(.03), X(.47), Y(.09), X(.5), Y(.18));
  p.bezierCurveTo(X(.53), Y(.09), X(.6), Y(.03), X(.7), Y(.03));
  p.bezierCurveTo(X(.85), Y(.03), X(1), Y(.14), X(1), Y(.33));
  p.bezierCurveTo(X(1), Y(.56), X(.83), Y(.77), X(.5), Y(.97));
  p.closePath();
  return p;
}
/** Shape outline inside box (x,y,w,h). */
function shapePath(shape, x, y, w, h, p = new Path2D()) {
  const m = Math.min(w, h), cx = x + w / 2, cy = y + h / 2;
  switch (shape) {
    case 'circle': p.ellipse(cx, cy, m / 2, m / 2, 0, 0, TAU); return p;
    case 'oval': p.ellipse(cx, cy, w / 2, h / 2, 0, 0, TAU); return p;
    case 'square': return rrPath(p, x, y, w, h, m * .14);
    case 'soft': return rrPath(p, x, y, w, h, m * .28);
    case 'rectH': case 'rectV': return rrPath(p, x, y, w, h, m * .2);
    case 'heart': return heartPath(p, x, y, w, h);
    case 'hexagon': return polyPath(p, cx, cy, w / 2, h / 2, 6, -Math.PI / 2, m * .07);
    case 'octagon': return polyPath(p, cx, cy, w / 2 / Math.cos(Math.PI / 8), h / 2 / Math.cos(Math.PI / 8), 8, Math.PI / 8, m * .05);
    case 'rect': return rrPath(p, x, y, w, h, m * .3);
    default: return rrPath(p, x, y, w, h, m * .3); // rounded
  }
}
/** Box (w,h) a mask occupies inside a square cell of size s. */
function maskBox(mask, s) {
  switch (mask) {
    case 'rectH': return { w: s, h: s * .74 };
    case 'rectV': return { w: s * .78, h: s };
    case 'oval': return { w: s * .8, h: s };
    case 'rect': return { w: s, h: s * .74 };
    default: return { w: s, h: s };
  }
}

/* ---------------------------------------------------------- tileable noise */
const PERM = (() => {
  const p = new Uint8Array(512); let s = 1337;
  for (let i = 0; i < 256; i++) p[i] = i;
  for (let i = 255; i > 0; i--) { s = (s * 1103515245 + 12345) & 0x7fffffff; const j = s % (i + 1); [p[i], p[j]] = [p[j], p[i]]; }
  for (let i = 0; i < 256; i++) p[i + 256] = p[i];
  return p;
})();
const TEX = 256;
function vnoise(x, y, px, py) {
  const xi = Math.floor(x), yi = Math.floor(y), xf = x - xi, yf = y - yi;
  const hx = i => ((i % px) + px) % px, hy = j => ((j % py) + py) % py;
  const H = (i, j) => PERM[PERM[hx(i) & 255] + hy(j)] / 255;
  const u = xf * xf * (3 - 2 * xf), v = yf * yf * (3 - 2 * yf);
  return lerp(lerp(H(xi, yi), H(xi + 1, yi), u), lerp(H(xi, yi + 1), H(xi + 1, yi + 1), u), v);
}
/** fractal noise over the 256 texture; base = lattice cells across the tile. */
function fbm(x, y, base, oct, gain = .5, by = base) {
  let a = 1, sum = 0, norm = 0, fx = base, fy = by;
  for (let o = 0; o < oct; o++) {
    sum += a * vnoise(x * fx / TEX + o * 3.17, y * fy / TEX + o * 5.31, fx, fy);
    norm += a; a *= gain; fx *= 2; fy *= 2;
  }
  return sum / norm;
}
const sinT = (x, k) => Math.sin(TAU * x * k / TEX);

/* ---------------------------------------------------------- materials */
function rampFn(stops) {
  const cs = stops.map(hexRgb);
  return t => {
    t = clamp(t, 0, 1) * (cs.length - 1);
    const i = Math.min(cs.length - 2, Math.floor(t)), f = t - i, a = cs[i], b = cs[i + 1];
    return [a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f, a[2] + (b[2] - a[2]) * f];
  };
}
function latticeEdge(x, y, period) {
  const u = (x + y) / period, v = (x - y) / period;
  const du = Math.abs(u - Math.round(u)), dv = Math.abs(v - Math.round(v));
  return { e: Math.min(du, dv), fu: frac(u), fv: frac(v), node: Math.hypot(du, dv) };
}
function velvetL(x, y) {
  const n1 = fbm(x, y, 4, 4), n2 = fbm(x + 50, y + 30, 16, 3);
  return .36 + .36 * n1 + .12 * (n2 - .5) + .1 * Math.sin(TAU * (x + y) * 2 / TEX + 6 * n1);
}
function leatherL(x, y) {
  const n = fbm(x, y, 32, 2);
  return .5 + .18 * (fbm(x, y, 6, 3) - .5) - .22 * Math.pow(1 - Math.abs(2 * n - 1), 7) + .06 * (fbm(x, y, 96, 2) - .5);
}
function metalL(x, y) {
  const band = Math.sin(TAU * y * 2 / TEX + 2.4 * fbm(x, y, 2, 2));
  const brush = vnoise(x * 4 / TEX, y * 128 / TEX, 4, 128);
  return .52 + .3 * band + .1 * (brush - .5);
}
function marbleF(x, y, seed) {
  const v = Math.sin(TAU * (2 * x + y) / TEX + 7 * (fbm(x + seed, y, 4, 5) - .5));
  const v2 = Math.sin(TAU * (x - 2 * y) / TEX + 9 * (fbm(x + 90 + seed, y + 40, 8, 4) - .5));
  return clamp(Math.pow(1 - Math.abs(v), 16) * .95 + Math.pow(1 - Math.abs(v), 4) * .12 + Math.pow(1 - Math.abs(v2), 34) * .55, 0, 1);
}
const MATERIALS = [
  { k: 'velvet', n: 'مخمل ناعم', g: 'fabric', tint: true, ramp: ['#050506', '#141418', '#2a2a31', '#4a4a55'], gen: (x, y) => ({ l: velvetL(x, y) }) },
  { k: 'velvetEmb', n: 'مخمل بارز', g: 'fabric', tint: true, ramp: ['#050506', '#141418', '#2a2a31', '#4a4a55'], gen: (x, y) => {
    const L = latticeEdge(x, y, 64); let l = velvetL(x, y) * (.5 + .5 * smooth(0, .3, L.e)) + .16 * (.5 - L.fu);
    return { l, f: L.node < .06 ? .8 : 0 };
  }, feat: '#000000' },
  { k: 'leather', n: 'جلد فاخر', g: 'fabric', ramp: ['#2a160b', '#5a3218', '#86502a', '#a8703f'], gen: (x, y) => ({ l: leatherL(x, y) }) },
  { k: 'leatherEmb', n: 'جلد منقوش', g: 'fabric', ramp: ['#2a160b', '#5a3218', '#86502a', '#a8703f'], gen: (x, y) => {
    const L = latticeEdge(x, y, 32), ridge = 1 - smooth(0, .06, L.e);
    const side = (L.fu < .5) === (L.fv < .5) ? 1 : -1;
    return { l: leatherL(x, y) + .2 * ridge * side - .08 * smooth(.05, .1, L.e) * 0 };
  } },
  { k: 'marbleWhite', n: 'رخام أبيض', g: 'stone', ramp: ['#d6d1c9', '#e9e5de', '#f8f6f1'], feat: '#8a857e', gen: (x, y) => ({ l: .5 + .7 * (fbm(x, y, 6, 4) - .5), f: marbleF(x, y, 0) }) },
  { k: 'marbleBlack', n: 'رخام أسود', g: 'stone', ramp: ['#08080a', '#121214', '#1e1e21'], feat: '#d9d3c4', gen: (x, y) => ({ l: .5 + .7 * (fbm(x, y, 6, 4) - .5), f: marbleF(x, y, 31) * .85 }) },
  { k: 'marbleGreen', n: 'رخام أخضر', g: 'stone', ramp: ['#062e23', '#0c4433', '#136048'], feat: '#cde6da', gen: (x, y) => ({ l: .5 + .8 * (fbm(x, y, 6, 4) - .5), f: marbleF(x, y, 77) * .9 }) },
  { k: 'goldPolished', n: 'ذهب مصقول', g: 'metal', ramp: ['#5a3d0e', '#a8771f', '#e2b850', '#fbe7a1', '#fff8dc'], gen: (x, y) => ({ l: metalL(x, y) }) },
  { k: 'goldAntique', n: 'ذهب معتق', g: 'metal', ramp: ['#33220a', '#6e4e16', '#a98234', '#d8b96f'], gen: (x, y) => ({ l: metalL(x, y) * (.72 + .3 * fbm(x, y, 4, 4)) }) },
  { k: 'silver', n: 'فضة مصقولة', g: 'metal', ramp: ['#4b5056', '#8d939a', '#d1d6db', '#f4f6f8', '#ffffff'], gen: (x, y) => ({ l: metalL(x, y) }) },
  { k: 'copperEng', n: 'نحاس محفور', g: 'metal', ramp: ['#4a2412', '#8c4a26', '#c87a4b', '#efb48a'], feat: '#2b140a', gen: (x, y) => {
    const L = latticeEdge(x, y, 32); return { l: metalL(x, y), f: (1 - smooth(0, .045, L.e)) * .85 };
  } },
  { k: 'bronze', n: 'برونز', g: 'metal', ramp: ['#2e1f0e', '#6b4a23', '#a87d45', '#d6ae72'], feat: '#4f7f6a', gen: (x, y) => ({ l: metalL(x, y) * .9 + .05, f: smooth(.62, .8, fbm(x, y, 8, 4)) * .55 }) },
  { k: 'carbon', n: 'كربون', g: 'tech', ramp: ['#060607', '#1b1c1f', '#36383c', '#5c5f65'], gen: (x, y) => {
    const c = Math.floor(x / 16) + Math.floor(y / 16), t = c % 2 ? (y % 16) / 16 : (x % 16) / 16;
    return { l: .18 + .5 * Math.sin(Math.PI * t) + .08 * (fbm(x, y, 64, 1) - .5) };
  } },
  { k: 'titanium', n: 'تيتانيوم', g: 'tech', ramp: ['#2c3036', '#5f666f', '#9aa2ac', '#ccd3db'], gen: (x, y) => ({ l: .5 + .16 * Math.sin(TAU * y / TEX + 2 * fbm(x, y, 2, 2)) + .22 * (vnoise(x * 2 / TEX, y * 192 / TEX, 2, 192) - .5) }) },
  { k: 'glassClear', n: 'زجاج شفاف', g: 'glass', ramp: ['#e9f2ff', '#ffffff'], alpha: .16, gen: (x, y) => ({ l: .5, a: .9 + .2 * (fbm(x, y, 4, 2) - .5) }) },
  { k: 'glassFrosted', n: 'زجاج مصنفر', g: 'glass', ramp: ['#dfe6ee', '#ffffff'], alpha: .5, gen: (x, y) => ({ l: vnoise(x * 128 / TEX, y * 128 / TEX, 128, 128), a: .85 + .3 * (vnoise(x * 64 / TEX, y * 64 / TEX, 64, 64) - .5) }) },
  { k: 'glassLiquid', n: 'زجاج سائل', g: 'glass', tint: true, ramp: ['#1e3a6b', '#5d8fd6', '#cfe3ff'], alpha: .62, gen: (x, y) => {
    const q = fbm(x, y, 3, 4); const l = fbm(x + 90 * q, y + 90 * q, 3, 4); return { l: .2 + 1.1 * (l - .2), a: .55 + .5 * l };
  } },
  { k: 'crystal', n: 'كريستال', g: 'glass', ramp: ['#7fa6c9', '#bcd8f0', '#eaf6ff', '#ffffff'], feat: '#ffffff', alpha: .85, gen: (x, y) => {
    const i = Math.floor(x / 32), j = Math.floor(y / 32), fx = x / 32 - i, fy = y / 32 - j, tri = fx > fy ? 1 : 0;
    const hsh = PERM[(PERM[(i % 8) * 7 & 255] + (j % 8) * 13 + tri * 101) & 511] / 255;
    const edge = Math.min(fx, fy, 1 - fx, 1 - fy, Math.abs(fx - fy) * .7);
    return { l: .25 + .7 * hsh, f: edge < .025 ? .9 : 0 };
  } },
  { k: 'porcelain', n: 'خزف فاخر', g: 'stone', ramp: ['#e3e7ec', '#f3f5f7', '#ffffff'], feat: '#3c5d9c', gen: (x, y) => {
    const L = latticeEdge(x, y, 128); const motif = (1 - smooth(.0, .012, Math.abs(L.node - .18))) * .35;
    return { l: .55 + .4 * (fbm(x, y, 4, 3) - .5), f: motif };
  } },
  { k: 'ceramic', n: 'سيراميك', g: 'stone', tint: false, ramp: ['#b9aa95', '#d2c4ae', '#e6dbc8'], feat: '#5e5446', gen: (x, y) => ({ l: .5 + .4 * (fbm(x, y, 6, 3) - .5), f: vnoise(x * 64 / TEX, y * 64 / TEX, 64, 64) > .9 ? .7 : 0 }) },
  { k: 'walnut', n: 'خشب الجوز', g: 'wood', ramp: ['#2b170c', '#4e2d18', '#6f4426', '#8e5c36'], gen: (x, y) => {
    const ring = Math.sin(TAU * (y * 6 / TEX + .9 * fbm(x, y, 2, 3) + .15 * fbm(x, y, 8, 2)));
    return { l: .5 + .26 * ring + .14 * (vnoise(x * 4 / TEX, y * 96 / TEX, 4, 96) - .5) };
  } },
  { k: 'darkWood', n: 'خشب داكن', g: 'wood', ramp: ['#100906', '#22140b', '#382213', '#4f321c'], gen: (x, y) => {
    const ring = Math.sin(TAU * (y * 5 / TEX + 1.1 * fbm(x, y, 2, 3)));
    return { l: .5 + .25 * ring + .16 * (vnoise(x * 4 / TEX, y * 96 / TEX, 4, 96) - .5) };
  } },
  { k: 'fabric', n: 'قماش فاخر', g: 'fabric', tint: true, ramp: ['#5f5446', '#9c8d76', '#d0c2a8'], gen: (x, y) => {
    const over = (Math.floor(x / 4) + Math.floor(y / 4)) % 2;
    const t = over ? .5 + .5 * Math.cos(TAU * y / 4) : .5 + .5 * Math.cos(TAU * x / 4);
    return { l: .4 + .3 * t + .12 * (fbm(x, y, 16, 2) - .5) };
  } },
  { k: 'satin', n: 'ساتان', g: 'fabric', tint: true, ramp: ['#5e4b2e', '#a88d5f', '#e6d2a6', '#fff4dc'], gen: (x, y) => ({ l: .5 + .42 * Math.sin(TAU * ((2 * x + y) / TEX + .8 * fbm(x, y, 2, 3))) + .06 * (fbm(x, y, 8, 2) - .5) }) },
  { k: 'pearl', n: 'لؤلؤ', g: 'stone', ramp: ['#e9e4f2', '#ffffff'], gen: (x, y) => {
    const hu = fbm(x, y, 3, 3), l = .84 + .1 * Math.sin(TAU * (x / TEX + 1.6 * hu));
    const c = hexRgb(fromHsl((hu * 1.3 + .55) % 1, .32, l));
    return { rgb: c };
  } },
  { k: 'matteMetal', n: 'معدن مطفي', g: 'tech', ramp: ['#2c2f33', '#45484e', '#5f6369'], gen: (x, y) => ({ l: .5 + .25 * (fbm(x, y, 48, 3) - .5) }) },
  { k: 'chrome', n: 'كروم', g: 'metal', ramp: ['#14171c', '#4c535d', '#aab3be', '#f4f7fa', '#ffffff'], gen: (x, y) => {
    const v = Math.sin(TAU * y * 1 / TEX + 1.2 * fbm(x, y, 2, 2)); return { l: .5 + .5 * Math.sign(v) * Math.pow(Math.abs(v), .45) + .04 * (vnoise(x * 2 / TEX, y * 160 / TEX, 2, 160) - .5) };
  } },
  { k: 'stone', n: 'حجر طبيعي', g: 'stone', ramp: ['#5f574d', '#857a6d', '#aa9f90', '#cbc1b2'], feat: '#3e372f', gen: (x, y) => ({ l: .5 + .55 * (fbm(x, y, 8, 6, .55) - .5) + .1 * (fbm(x + 40, y, 64, 2) - .5), f: vnoise(x * 96 / TEX, y * 96 / TEX, 96, 96) > .86 ? .5 : 0 }) },
  { k: 'matteSoft', n: 'مطفي ناعم', g: 'tech', tint: true, ramp: ['#3a3a3e', '#4a4a4f', '#58585d'], gen: (x, y) => ({ l: .5 + .12 * (fbm(x, y, 32, 3) - .5) }) },
  { k: 'quilted', n: 'قماش ثلاثي الأبعاد', g: 'fabric', tint: true, ramp: ['#050506', '#18181c', '#34343c', '#5a5a66'], gen: (x, y) => {
    const L = latticeEdge(x, y, 64), pillow = Math.sin(Math.PI * clamp(L.e * 2, 0, 1));
    return { l: .18 + .62 * Math.pow(pillow, .6) * (.8 + .2 * velvetL(x, y)) + .12 * (.5 - L.fv), f: L.node < .05 ? .9 : 0 };
  }, feat: '#000000' },
  { k: 'grain', n: 'حبيبات', g: 'fx', hidden: true, ramp: ['#000000', '#ffffff'], gen: (x, y) => ({ l: .5 + .5 * (vnoise(x * 128 / TEX, y * 128 / TEX, 128, 128) - .5) + .2 * (vnoise(x * 64 / TEX + 9, y * 64 / TEX, 64, 64) - .5) }) }
];
const MAT_DESC = {
  velvet: 'نسيج مخملي ناعم يمتص الضوء بعمق، بدرجات تتبع لون الثيم.', velvetEmb: 'مخمل منفوخ بخياطة معيّنة كوسائد بارزة.', leather: 'جلد طبيعي بمسام دقيقة ولمعة دافئة.', leatherEmb: 'جلد بنقوش معيّنة بارزة كالحقائب الفاخرة.',
  marbleWhite: 'رخام أبيض بعروق رمادية متدفقة.', marbleBlack: 'رخام أسود عميق بعروق ذهبية فاتحة.', marbleGreen: 'رخام زمردي بعروق بيضاء.',
  goldPolished: 'ذهب مصقول بانعكاسات أفقية لامعة.', goldAntique: 'ذهب معتق بلمعة هادئة وظلال مخملية.', silver: 'فضة مصقولة كالمرآة بخطوط تلميع دقيقة.',
  copperEng: 'نحاس بنقوش محفورة متقاطعة.', bronze: 'برونز دافئ بزنجار أخضر خفيف.', carbon: 'ألياف كربون منسوجة بلمعة تقنية.', titanium: 'تيتانيوم مصقول بخطوط فرشاة.',
  glassClear: 'زجاج شفاف تظهر من خلفه الخلفية.', glassFrosted: 'زجاج مصنفر بحبيبات ناعمة.', glassLiquid: 'زجاج سائل بتموجات لونية عميقة.', crystal: 'كريستال مقطّع بأوجه لامعة.',
  porcelain: 'خزف أبيض بنقش أزرق رقيق.', ceramic: 'سيراميك دافئ بحبيبات طبيعية.', walnut: 'خشب جوز طبيعي بعروق حلقية.', darkWood: 'خشب داكن فاخر بعروق عميقة.',
  fabric: 'قماش منسوج بنسيج سلّة واضح.', satin: 'ساتان لامع بانسيابية حريرية.', pearl: 'لؤلؤ قزحي بألوان متبدلة.', matteMetal: 'معدن مطفي بملمس حبيبي.',
  chrome: 'كروم عاكس بتباين قوي كالمرآة.', stone: 'حجر طبيعي بحبيبات ونقاط معدنية.', matteSoft: 'سطح مطفي ناعم بلا لمعة، بلون الثيم.', quilted: 'قماش ثلاثي الأبعاد منفوخ بخياطة عميقة.'
};
for (const m of MATERIALS) m.desc = MAT_DESC[m.k] || '';
const MAT = Object.fromEntries(MATERIALS.map(m => [m.k, m]));
const MAT_GROUPS = { fabric: 'أقمشة وجلود', stone: 'أحجار وخزف', metal: 'معادن', tech: 'تقنية', glass: 'زجاج وكريستال', wood: 'أخشاب' };
const texCache = new Map();
/** Texture canvas for a material, natural or tinted with the accent colour. */
function materialTexture(k, tintHex) {
  const m = MAT[k]; if (!m) return null;
  const key = k + '|' + (tintHex || '');
  if (texCache.has(key)) return texCache.get(key);
  const c = document.createElement('canvas'); c.width = c.height = TEX;
  const g = c.getContext('2d'), img = g.createImageData(TEX, TEX), D = img.data;
  const ramp = rampFn(tintHex ? [mix(tintHex, '#000000', .78), mix(tintHex, '#000000', .42), tintHex, mix(tintHex, '#ffffff', .45)] : m.ramp);
  const feat = hexRgb(tintHex && m.k.startsWith('marble') ? mix(tintHex, '#ffffff', .7) : (m.feat || '#000000'));
  const baseA = m.alpha ?? 1;
  for (let y = 0; y < TEX; y++) for (let x = 0; x < TEX; x++) {
    const r = m.gen(x, y), i = (y * TEX + x) * 4;
    let c3 = r.rgb || ramp(r.l);
    if (r.f) c3 = [lerp(c3[0], feat[0], r.f), lerp(c3[1], feat[1], r.f), lerp(c3[2], feat[2], r.f)];
    D[i] = c3[0]; D[i + 1] = c3[1]; D[i + 2] = c3[2]; D[i + 3] = 255 * clamp(baseA * (r.a ?? 1), 0, 1);
  }
  g.putImageData(img, 0, 0);
  texCache.set(key, c);
  return c;
}
/** A fill style that paints the material; 256 texels span `span` css px. */
function materialFill(ctx, k, tintHex, span = 128) {
  const tex = materialTexture(k, tintHex); if (!tex) return null;
  const pat = ctx.createPattern(tex, 'repeat');
  if (pat.setTransform) pat.setTransform(new DOMMatrix().scale(span / TEX));
  return pat;
}
const isMetalMat = k => !!MAT[k] && MAT[k].g === 'metal';

/* ---------------------------------------------------------- shadows */
function withShadow(ctx, S, color, blur, dx, dy, draw) {
  ctx.save();
  ctx.shadowColor = color; ctx.shadowBlur = blur * S; ctx.shadowOffsetX = dx * S; ctx.shadowOffsetY = dy * S;
  draw(); ctx.restore();
}
/** Draw a CSS-like outer shadow of `path` only outside it. */
function outerShadow(ctx, S, path, color, blur, dx = 0, dy = 0) {
  if (!color || alphaOf(color) <= 0.003) return;
  ctx.save();
  const out = new Path2D(); out.rect(-1e4, -1e4, 2e4, 2e4); out.addPath(path);
  ctx.clip(out, 'evenodd');
  ctx.shadowColor = color; ctx.shadowBlur = blur * S; ctx.shadowOffsetX = (dx + 2e4) * S; ctx.shadowOffsetY = dy * S;
  ctx.translate(-2e4, 0); ctx.fillStyle = '#000'; ctx.fill(path);
  ctx.restore();
}
/** Inset shadow inside `path`. */
function innerShadow(ctx, S, path, color, blur, dx = 0, dy = 0) {
  if (!color || alphaOf(color) <= 0.003) return;
  ctx.save(); ctx.clip(path);
  const ring = new Path2D(); ring.rect(-1e4, -1e4, 2e4, 2e4); ring.addPath(path);
  ctx.shadowColor = color; ctx.shadowBlur = blur * S; ctx.shadowOffsetX = (dx + 2e4) * S; ctx.shadowOffsetY = dy * S;
  ctx.translate(-2e4, 0); ctx.fillStyle = '#000'; ctx.fill(ring, 'evenodd');
  ctx.restore();
}
function alphaOf(c) {
  if (typeof c !== 'string') return 1;
  if (c[0] === '#' && c.length === 9) return parseInt(c.slice(7), 16) / 255;
  const m = c.match(/rgba\([^)]*,\s*([\d.]+)\)/); return m ? +m[1] : 1;
}

/* ---------------------------------------------------------- metal & gradients */
function metalStops(base) {
  return [[0, mix(base, '#ffffff', .62)], [.22, base], [.45, mix(base, '#ffffff', .4)], [.7, mix(base, '#000000', .38)], [1, mix(base, '#ffffff', .2)]];
}
function linGrad(ctx, x0, y0, x1, y1, stops) {
  const g = ctx.createLinearGradient(x0, y0, x1, y1);
  for (const [o, c] of stops) g.addColorStop(o, c);
  return g;
}
function metalFill(ctx, box, base, mat) {
  if (mat && MAT[mat]) return materialFill(ctx, mat, null, 96);
  return linGrad(ctx, box.x, box.y, box.x + box.w, box.y + box.h, metalStops(base));
}

/* ---------------------------------------------------------- ornaments (unit size ≈ 1) */
function star8(p, cx, cy, r) {
  const ri = r * .58;
  for (let i = 0; i < 16; i++) {
    const a = -Math.PI / 2 + i * TAU / 16, rr = i % 2 ? ri : r;
    i ? p.lineTo(cx + rr * Math.cos(a), cy + rr * Math.sin(a)) : p.moveTo(cx + rr * Math.cos(a), cy + rr * Math.sin(a));
  }
  p.closePath(); return p;
}
function star4(p, cx, cy, r) {
  for (let i = 0; i < 8; i++) {
    const a = -Math.PI / 2 + i * TAU / 8, rr = i % 2 ? r * .28 : r;
    i ? p.lineTo(cx + rr * Math.cos(a), cy + rr * Math.sin(a)) : p.moveTo(cx + rr * Math.cos(a), cy + rr * Math.sin(a));
  }
  p.closePath(); return p;
}
function diamond(p, cx, cy, rx, ry) { p.moveTo(cx, cy - ry); p.lineTo(cx + rx, cy); p.lineTo(cx, cy + ry); p.lineTo(cx - rx, cy); p.closePath(); return p; }
function leafAt(ctx, x, y, ang, s) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(ang);
  ctx.beginPath(); ctx.moveTo(0, 0); ctx.quadraticCurveTo(s * .55, -s * .45, s, 0); ctx.quadraticCurveTo(s * .55, s * .45, 0, 0); ctx.fill();
  ctx.restore();
}
function scrollCorner(ctx, x, y, rot, s, lw) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.lineWidth = lw;
  ctx.beginPath(); ctx.moveTo(0, s * 1.4); ctx.bezierCurveTo(0, s * .4, s * .2, s * .1, s * .6, s * .45);
  ctx.bezierCurveTo(s * .9, s * .7, s * .55, s * 1.0, s * .38, s * .78); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(s * 1.4, 0); ctx.bezierCurveTo(s * .4, 0, s * .1, s * .2, s * .45, s * .6);
  ctx.bezierCurveTo(s * .7, s * .9, s * 1.0, s * .55, s * .78, s * .38); ctx.stroke();
  ctx.beginPath(); ctx.arc(s * .26, s * .26, s * .14, 0, TAU); ctx.fill();
  ctx.restore();
}

/* ---------------------------------------------------------- frames */
const FRAMES = [
  { k: 'none', n: 'بدون إطار' },
  { k: 'islamicGeo', n: 'إطار إسلامي هندسي' },
  { k: 'arabesque', n: 'إطار أرابيسك نباتي' },
  { k: 'royalOrn', n: 'إطار ملكي مزخرف' },
  { k: 'goldDouble', n: 'إطار ذهبي مزدوج' },
  { k: 'copperEngr', n: 'إطار نحاسي محفور' },
  { k: 'geoGlow', n: 'إطار هندسي متوهج' },
  { k: 'roundOrn', n: 'إطار دائري مزخرف' },
  { k: 'corners', n: 'إطار بزخارف الزوايا' },
  { k: 'metal3d', n: 'إطار معدني ثلاثي الأبعاد' },
  { k: 'classic', n: 'إطار زخرفي كلاسيكي' },
  { k: 'repeatGeo', n: 'إطار بنقوش هندسية متكررة' },
  { k: 'crystalF', n: 'إطار كريستالي' },
  { k: 'silverF', n: 'إطار فضي' },
  { k: 'royalGold', n: 'إطار ذهبي ملكي' },
  { k: 'gradientGlow', n: 'إطار مضيء متدرج' },
  { k: 'modernArabic', n: 'إطار زخارف عربية حديثة' },
  { k: 'stitched', n: 'إطار مخيط بخياطة' }
];
const FRAME = Object.fromEntries(FRAMES.map(f => [f.k, f]));

/** Points along the straight edges of a rounded rect (corners skipped). */
function edgeWalk(b, step, fn, skipCorner = 0) {
  const r = b.r + skipCorner, sides = [
    [b.x + r, b.y, b.x + b.w - r, b.y, 0], [b.x + b.w, b.y + r, b.x + b.w, b.y + b.h - r, Math.PI / 2],
    [b.x + b.w - r, b.y + b.h, b.x + r, b.y + b.h, Math.PI], [b.x, b.y + b.h - r, b.x, b.y + r, -Math.PI / 2]];
  for (const [x0, y0, x1, y1, ang] of sides) {
    const len = Math.hypot(x1 - x0, y1 - y0); if (len <= step * .5) continue;
    const n = Math.max(1, Math.round(len / step)), d = len / n;
    for (let i = 0; i <= n; i++) { const t = (i * d) / len; fn(x0 + (x1 - x0) * t, y0 + (y1 - y0) * t, ang, i, n); }
  }
}
function boxPath(b) { return b.circle ? (p => (p.ellipse(b.x + b.w / 2, b.y + b.h / 2, b.w / 2, b.h / 2, 0, 0, TAU), p))(new Path2D()) : rrPath(new Path2D(), b.x, b.y, b.w, b.h, b.r); }
const inset = (b, d) => ({ x: b.x + d, y: b.y + d, w: b.w - 2 * d, h: b.h - 2 * d, r: Math.max(0, b.r - d), circle: b.circle });
const cornersOf = b => [[b.x, b.y, 0], [b.x + b.w, b.y, Math.PI / 2], [b.x + b.w, b.y + b.h, Math.PI], [b.x, b.y + b.h, -Math.PI / 2]];

/**
 * Draw an ornamental frame on body box `B` (css units).
 * o: {k, color, width, density, size, pos, glow, light, alpha, inset, mat}
 */
function drawFrame(ctx, S, B, o) {
  if (!o || !o.k || o.k === 'none') return;
  const C = o.color || '#c9a24a', bw = Math.max(.5, o.width ?? 3), sz = (o.size ?? 50) / 50, dens = (o.density ?? 50) / 50;
  const b = inset(B, o.inset ?? 6), glow = (o.glow ?? 0) / 100, L = o.light || '#ffd98a';
  const showEdges = o.pos !== 'corners', showCorners = o.pos !== 'edges';
  const metal = metalFill(ctx, b, C, o.mat);
  ctx.save();
  ctx.globalAlpha = (o.alpha ?? 100) / 100;
  if (glow > 0) { ctx.shadowColor = rgba(L, .25 + .6 * glow); ctx.shadowBlur = (2 + 14 * glow) * S; }
  ctx.strokeStyle = metal; ctx.fillStyle = metal; ctx.lineJoin = 'round'; ctx.lineCap = 'round';
  const line = (bb, w) => { ctx.lineWidth = w; ctx.stroke(boxPath(bb)); };
  const step = Math.max(10, 26 * sz / Math.max(.25, dens));
  const orn = 5.5 * sz;
  switch (o.k) {
    case 'islamicGeo': {
      line(b, bw * .55); line(inset(b, 4 + bw * 1.6 * sz), bw * .55);
      const mid = inset(b, 2 + bw * .8 * sz);
      if (showEdges) edgeWalk(mid, step, (x, y, a, i) => { const p = new Path2D(); if (i % 2) diamond(p, x, y, orn * .45, orn * .45); else star8(p, x, y, orn * .75); ctx.fill(p); }, orn);
      if (showCorners) for (const [x, y] of cornersOf(mid)) { if (!b.circle) { const p = new Path2D(); star8(p, x + Math.sign(b.x + b.w / 2 - x) * (b.r * .3), y + Math.sign(b.y + b.h / 2 - y) * (b.r * .3), orn * 1.25); ctx.fill(p); } }
      break;
    }
    case 'arabesque': {
      line(b, bw * .5);
      const mid = inset(b, 4.5 * sz);
      if (showEdges) {
        ctx.lineWidth = Math.max(.8, bw * .45);
        edgeWalk(mid, step * .5, (x, y, a, i, n) => {
          const amp = 2.6 * sz, ph = i % 2 ? 1 : -1;
          ctx.save(); ctx.translate(x, y); ctx.rotate(a);
          ctx.beginPath(); ctx.moveTo(-step * .25, 0); ctx.bezierCurveTo(-step * .12, amp * ph * 1.4, step * .12, amp * ph * 1.4, step * .25, 0); ctx.stroke();
          leafAt(ctx, 0, amp * ph * 1.05, ph > 0 ? .6 : -.6, orn * .9);
          ctx.restore();
        }, orn);
      }
      if (showCorners && !b.circle) cornersOf(inset(b, 2)).forEach(([x, y, r]) => scrollCorner(ctx, x, y, r, 9 * sz, Math.max(.8, bw * .45)));
      break;
    }
    case 'royalOrn': {
      line(b, bw * .7); line(inset(b, 3.5 * sz + bw), bw * .35);
      if (showEdges) edgeWalk(inset(b, (3.5 * sz + bw) / 2), step * .7, (x, y) => { ctx.beginPath(); ctx.arc(x, y, .9 * sz, 0, TAU); ctx.fill(); }, orn * 2);
      if (showEdges && !b.circle) for (const [x, y] of [[b.x + b.w / 2, b.y], [b.x + b.w / 2, b.y + b.h], [b.x, b.y + b.h / 2], [b.x + b.w, b.y + b.h / 2]]) { const p = new Path2D(); diamond(p, x, y, orn * .9, orn * .9); ctx.fill(p); }
      if (showCorners && !b.circle) cornersOf(b).forEach(([x, y, r]) => scrollCorner(ctx, x, y, r, 11 * sz, Math.max(.9, bw * .5)));
      break;
    }
    case 'goldDouble': case 'silverF': {
      if (o.k === 'silverF') ctx.strokeStyle = metalFill(ctx, b, o.color && o.color !== '#c9a24a' ? o.color : '#b9c0c8', o.mat);
      line(b, bw); line(inset(b, bw * 1.2 + 3 * sz), Math.max(.6, bw * .4));
      break;
    }
    case 'copperEngr': {
      const band = bw * 2.2 + 3 * sz, mid = inset(b, band / 2);
      line(mid, band);
      ctx.shadowColor = 'transparent'; ctx.strokeStyle = rgba(mix(C, '#000000', .7), .7); ctx.lineWidth = .7;
      edgeWalk(mid, Math.max(3, 5 * sz / dens), (x, y, a) => { ctx.save(); ctx.translate(x, y); ctx.rotate(a); ctx.beginPath(); ctx.moveTo(-band * .3, -band * .32); ctx.lineTo(band * .3, band * .32); ctx.stroke(); ctx.restore(); }, 0);
      ctx.strokeStyle = rgba('#ffffff', .25); line(inset(b, .5), .6);
      break;
    }
    case 'geoGlow': {
      ctx.shadowColor = rgba(L, .5 + .4 * glow); ctx.shadowBlur = (6 + 14 * glow) * S; ctx.strokeStyle = L; ctx.fillStyle = L;
      line(b, Math.max(.8, bw * .45));
      if (showEdges) edgeWalk(b, step, (x, y) => { const p = new Path2D(); diamond(p, x, y, orn * .55, orn * .8); ctx.fill(p); }, orn);
      if (showCorners && !b.circle) cornersOf(inset(b, b.r * .29)).forEach(([x, y]) => { const p = new Path2D(); star4(p, x, y, orn * 1.1); ctx.fill(p); });
      break;
    }
    case 'roundOrn': {
      line(b, bw * .45);
      const mid = inset(b, 3.5 * sz);
      if (b.circle) {
        const cx = b.x + b.w / 2, cy = b.y + b.h / 2, R = mid.w / 2, n = Math.max(12, Math.round(TAU * R / (step * .55)));
        for (let i = 0; i < n; i++) { const a = i * TAU / n; ctx.beginPath(); ctx.arc(cx + R * Math.cos(a), cy + R * Math.sin(a), (i % 2 ? 1.1 : 1.9) * sz, 0, TAU); ctx.fill(); }
      } else edgeWalk(mid, step * .45, (x, y, a, i) => { ctx.beginPath(); ctx.arc(x, y, (i % 2 ? 1.1 : 1.9) * sz, 0, TAU); ctx.fill(); }, 0);
      line(inset(b, 7 * sz), bw * .35);
      break;
    }
    case 'corners': {
      if (!b.circle) {
        cornersOf(b).forEach(([x, y, r]) => {
          scrollCorner(ctx, x + 1, y + 1, r, 13 * sz, Math.max(1, bw * .55));
          ctx.save(); ctx.translate(x, y); ctx.rotate(r); ctx.lineWidth = Math.max(.8, bw * .45);
          ctx.beginPath(); ctx.moveTo(18 * sz, 0); ctx.lineTo(34 * sz, 0); ctx.moveTo(0, 18 * sz); ctx.lineTo(0, 34 * sz); ctx.stroke(); ctx.restore();
        });
      } else line(b, bw * .5);
      break;
    }
    case 'metal3d': {
      const band = bw * 2 + 2;
      ctx.lineWidth = band; ctx.strokeStyle = linGrad(ctx, b.x, b.y, b.x + b.w, b.y + b.h, [[0, mix(C, '#ffffff', .7)], [.45, C], [1, mix(C, '#000000', .55)]]);
      ctx.stroke(boxPath(inset(b, band / 2)));
      ctx.shadowColor = 'transparent';
      ctx.lineWidth = .8; ctx.strokeStyle = rgba('#000000', .45); ctx.stroke(boxPath(inset(b, band)));
      ctx.strokeStyle = rgba('#ffffff', .55); ctx.stroke(boxPath(inset(b, .4)));
      break;
    }
    case 'classic': {
      line(b, bw * .6);
      const i2 = inset(b, 5 * sz);
      if (!b.circle) {
        const n = 7 * sz, p = new Path2D(), x0 = i2.x, y0 = i2.y, x1 = i2.x + i2.w, y1 = i2.y + i2.h;
        p.moveTo(x0 + n, y0); p.lineTo(x1 - n, y0); p.arc(x1, y0, n, Math.PI, Math.PI / 2, true); p.lineTo(x1, y1 - n);
        p.arc(x1, y1, n, -Math.PI / 2, Math.PI, true); p.lineTo(x0 + n, y1); p.arc(x0, y1, n, 0, -Math.PI / 2, true);
        p.lineTo(x0, y0 + n); p.arc(x0, y0, n, Math.PI / 2, 0, true); p.closePath();
        ctx.lineWidth = Math.max(.6, bw * .4); ctx.stroke(p);
        if (showCorners) cornersOf(i2).forEach(([x, y]) => { ctx.beginPath(); ctx.arc(x, y, 1.6 * sz, 0, TAU); ctx.fill(); });
        if (showEdges) for (const [x, y] of [[i2.x + i2.w / 2, i2.y], [i2.x + i2.w / 2, i2.y + i2.h]]) { const q = new Path2D(); diamond(q, x, y, orn * .9, orn * .45); ctx.fill(q); }
      } else line(i2, bw * .4);
      break;
    }
    case 'repeatGeo': {
      const band = 7 * sz + bw; line(b, bw * .45); line(inset(b, band), bw * .45);
      const mid = inset(b, band / 2);
      ctx.lineWidth = Math.max(.7, bw * .4);
      if (showEdges) edgeWalk(mid, Math.max(5, band * 1.1 / dens), (x, y, a) => {
        ctx.save(); ctx.translate(x, y); ctx.rotate(a); const h2 = band * .32;
        ctx.beginPath(); ctx.moveTo(-h2, h2); ctx.lineTo(0, -h2); ctx.lineTo(h2, h2); ctx.stroke(); ctx.restore();
      }, 0);
      break;
    }
    case 'crystalF': {
      const band = 4 + bw, mid = inset(b, band / 2);
      ctx.shadowColor = rgba('#bfe4ff', .5 + .4 * glow); ctx.shadowBlur = (3 + 10 * glow) * S;
      ctx.lineWidth = band; ctx.strokeStyle = linGrad(ctx, b.x, b.y, b.x + b.w, b.y + b.h, [[0, '#ffffff'], [.25, '#a9d3f5'], [.5, '#f2fbff'], [.75, '#7fb0dc'], [1, '#e8f6ff']]);
      ctx.stroke(boxPath(mid));
      ctx.shadowColor = 'transparent'; ctx.strokeStyle = rgba('#ffffff', .7); ctx.lineWidth = .6;
      edgeWalk(mid, Math.max(4, 8 * sz / dens), (x, y, a, i) => { ctx.save(); ctx.translate(x, y); ctx.rotate(a); ctx.beginPath(); ctx.moveTo(0, -band / 2); ctx.lineTo(i % 2 ? band * .4 : -band * .4, band / 2); ctx.stroke(); ctx.restore(); }, 0);
      if (showCorners && !b.circle) { ctx.fillStyle = '#ffffff'; cornersOf(inset(b, b.r * .29)).forEach(([x, y]) => { const p = new Path2D(); star4(p, x, y, orn * 1.3); ctx.fill(p); }); }
      break;
    }
    case 'royalGold': {
      const band = bw * 1.8 + 1.5; line(inset(b, band / 2), band); line(inset(b, band + 3 * sz), Math.max(.6, bw * .35));
      if (showCorners && !b.circle) cornersOf(inset(b, band + 3 * sz)).forEach(([x, y]) => {
        ctx.beginPath(); ctx.arc(x, y, orn * 1.25, 0, TAU); ctx.fill();
        ctx.save(); ctx.fillStyle = rgba(mix(C, '#000000', .55), .9); const p = new Path2D(); star8(p, x, y, orn * .85); ctx.fill(p); ctx.restore();
      });
      if (showEdges && !b.circle) {
        const x = b.x + b.w / 2, y = b.y + band + 3 * sz;
        const p = new Path2D(); p.moveTo(x - orn * 2.2, y); p.quadraticCurveTo(x - orn, y + orn * .2, x - orn * .7, y - orn * 1.1);
        p.lineTo(x, y - orn * .2); p.lineTo(x + orn * .7, y - orn * 1.1); p.quadraticCurveTo(x + orn, y + orn * .2, x + orn * 2.2, y); p.closePath(); ctx.fill(p);
      }
      break;
    }
    case 'gradientGlow': {
      ctx.shadowColor = rgba(L, .6); ctx.shadowBlur = (6 + 18 * glow) * S;
      ctx.lineWidth = Math.max(1.2, bw * .8);
      ctx.strokeStyle = linGrad(ctx, b.x, b.y, b.x + b.w, b.y + b.h, [[0, L], [.5, C], [1, mix(L, '#ffffff', .4)]]);
      ctx.stroke(boxPath(b));
      break;
    }
    case 'modernArabic': {
      ctx.lineWidth = Math.max(.7, bw * .45);
      if (!b.circle) {
        const cx = b.x + b.w / 2, aw = 16 * sz, ah = 13 * sz, p = new Path2D();
        p.moveTo(cx - aw, b.y); p.lineTo(b.x + b.r, b.y); p.arcTo(b.x, b.y, b.x, b.y + b.r, b.r); p.lineTo(b.x, b.y + b.h - b.r);
        p.arcTo(b.x, b.y + b.h, b.x + b.r, b.y + b.h, b.r); p.lineTo(b.x + b.w - b.r, b.y + b.h); p.arcTo(b.x + b.w, b.y + b.h, b.x + b.w, b.y + b.h - b.r, b.r);
        p.lineTo(b.x + b.w, b.y + b.r); p.arcTo(b.x + b.w, b.y, b.x + b.w - b.r, b.y, b.r); p.lineTo(cx + aw, b.y);
        p.moveTo(cx - aw, b.y); p.lineTo(cx - aw, b.y + ah * .35); p.quadraticCurveTo(cx - aw, b.y + ah, cx, b.y + ah * 1.25); p.quadraticCurveTo(cx + aw, b.y + ah, cx + aw, b.y + ah * .35); p.lineTo(cx + aw, b.y);
        ctx.stroke(p);
        const q = new Path2D(); star8(q, cx, b.y + ah * .55, 3.6 * sz); ctx.fill(q);
        const r2 = new Path2D(); star8(r2, cx, b.y + b.h, 4.5 * sz); ctx.fill(r2);
      } else line(b, bw * .45);
      break;
    }
    case 'stitched': {
      const i2 = inset(b, 4 + bw);
      ctx.lineWidth = Math.max(.9, bw * .55); ctx.setLineDash([4.2 * sz, 3.2 * sz]);
      ctx.stroke(boxPath(i2)); ctx.setLineDash([]);
      ctx.shadowColor = 'transparent'; ctx.strokeStyle = rgba('#000000', .35); ctx.lineWidth = .6;
      ctx.stroke(boxPath(inset(i2, 1.4)));
      break;
    }
  }
  ctx.restore();
}

/* ---------------------------------------------------------- dividers & titles */
const DIVIDERS = [['islamic', 'فاصل إسلامي'], ['goldLine', 'خط ذهبي'], ['stars', 'نجوم'], ['arch', 'قوس محراب'], ['dots', 'نقاط'], ['diamond', 'معيّن'], ['none', 'بدون']];
const TITLE_STYLES = [['flourish', 'زخرفة جانبية'], ['cartouche', 'خرطوشة'], ['arch', 'قوس'], ['plain', 'بسيط']];
function drawDivider(ctx, S, x, y, w, style, color, size = 1) {
  if (style === 'none') return;
  const cx = x + w / 2, s = 5 * size;
  ctx.save(); ctx.fillStyle = color; ctx.strokeStyle = color; ctx.lineCap = 'round';
  const fadeLine = (x0, x1, lw) => {
    const g = ctx.createLinearGradient(x0, y, x1, y);
    g.addColorStop(0, rgba(color, 0)); g.addColorStop(1, color);
    ctx.strokeStyle = g; ctx.lineWidth = lw; ctx.beginPath(); ctx.moveTo(x0, y); ctx.lineTo(x1, y); ctx.stroke();
  };
  const gap = s * 2.6;
  switch (style) {
    case 'islamic': {
      fadeLine(x + w * .06, cx - gap, .9); fadeLine(x + w * .94, cx + gap, .9);
      const p = new Path2D(); star8(p, cx, y, s * 1.3); ctx.fill(p);
      ctx.fillStyle = rgba(color, .7);
      for (const d of [-1, 1]) { const q = new Path2D(); diamond(q, cx + d * gap * .78, y, s * .45, s * .45); ctx.fill(q); }
      break;
    }
    case 'goldLine': fadeLine(x + w * .04, cx, 1.1); fadeLine(x + w * .96, cx, 1.1); break;
    case 'stars': {
      fadeLine(x + w * .1, cx - gap * 1.6, .7); fadeLine(x + w * .9, cx + gap * 1.6, .7);
      for (const d of [-1, 0, 1]) { const p = new Path2D(); star4(p, cx + d * s * 2.2, y, s * (d ? .7 : 1.05)); ctx.fill(p); }
      break;
    }
    case 'arch': {
      fadeLine(x + w * .06, cx - s * 2.2, .9); fadeLine(x + w * .94, cx + s * 2.2, .9);
      ctx.lineWidth = 1; ctx.strokeStyle = color; ctx.beginPath();
      ctx.moveTo(cx - s * 1.6, y + s * .7); ctx.lineTo(cx - s * 1.6, y); ctx.quadraticCurveTo(cx - s * 1.6, y - s * 1.3, cx, y - s * 1.8);
      ctx.quadraticCurveTo(cx + s * 1.6, y - s * 1.3, cx + s * 1.6, y); ctx.lineTo(cx + s * 1.6, y + s * .7); ctx.stroke();
      ctx.beginPath(); ctx.arc(cx, y - s * .2, s * .38, 0, TAU); ctx.fill();
      break;
    }
    case 'dots': for (let i = -3; i <= 3; i++) { ctx.globalAlpha = 1 - Math.abs(i) * .22; ctx.beginPath(); ctx.arc(cx + i * s * 1.5, y, s * (i ? .32 : .5), 0, TAU); ctx.fill(); } break;
    case 'diamond': {
      fadeLine(x + w * .08, cx - s * 1.4, .9); fadeLine(x + w * .92, cx + s * 1.4, .9);
      const p = new Path2D(); diamond(p, cx, y, s * .9, s * .9); ctx.lineWidth = 1; ctx.stroke(p);
      const q = new Path2D(); diamond(q, cx, y, s * .38, s * .38); ctx.fill(q);
      break;
    }
  }
  ctx.restore();
}
function drawTitle(ctx, S, x, y, w, h, text, style, size, color, accent) {
  const cx = x + w / 2, cy = y + h / 2;
  ctx.save();
  if (style === 'cartouche') {
    const tw = Math.min(w * .92, measure(ctx, text, size, 700, FONT_D) + size * 2.6), th = size * 1.85, x0 = cx - tw / 2, y0 = cy - th / 2, pt = th * .42;
    const p = new Path2D(); p.moveTo(x0 + pt, y0); p.lineTo(x0 + tw - pt, y0); p.lineTo(x0 + tw, cy); p.lineTo(x0 + tw - pt, y0 + th); p.lineTo(x0 + pt, y0 + th); p.lineTo(x0, cy); p.closePath();
    ctx.fillStyle = rgba(accent, .14); ctx.fill(p); ctx.lineWidth = 1.1; ctx.strokeStyle = accent; ctx.stroke(p);
    const q = new Path2D(); const i = 2.6; q.moveTo(x0 + pt + i * .4, y0 + i); q.lineTo(x0 + tw - pt - i * .4, y0 + i); q.lineTo(x0 + tw - i * 1.3, cy); q.lineTo(x0 + tw - pt - i * .4, y0 + th - i); q.lineTo(x0 + pt + i * .4, y0 + th - i); q.lineTo(x0 + i * 1.3, cy); q.closePath();
    ctx.lineWidth = .6; ctx.stroke(q);
  } else if (style === 'flourish') {
    const tw = measure(ctx, text, size, 700, FONT_D), gap = size * .7, s = size * .22;
    ctx.fillStyle = accent;
    for (const d of [-1, 1]) {
      const xe = cx + d * (tw / 2 + gap), xs = cx + d * Math.min(w / 2 - 4, tw / 2 + gap + size * 3.2);
      const g = ctx.createLinearGradient(xs, cy, xe, cy); g.addColorStop(0, rgba(accent, 0)); g.addColorStop(1, accent);
      ctx.strokeStyle = g; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(xs, cy); ctx.lineTo(xe, cy); ctx.stroke();
      const p = new Path2D(); diamond(p, xe + d * s * 1.4, cy, s, s); ctx.fill(p);
    }
  } else if (style === 'arch') {
    const aw = Math.min(w * .44, measure(ctx, text, size, 700, FONT_D) / 2 + size * 1.2), top = y + size * .15;
    ctx.strokeStyle = accent; ctx.lineWidth = 1.1; ctx.beginPath();
    ctx.moveTo(cx - aw, y + h - 2); ctx.lineTo(cx - aw, top + size * .9); ctx.quadraticCurveTo(cx - aw, top, cx, top - size * .25);
    ctx.quadraticCurveTo(cx + aw, top, cx + aw, top + size * .9); ctx.lineTo(cx + aw, y + h - 2); ctx.stroke();
    ctx.fillStyle = accent; const p = new Path2D(); star8(p, cx, top - size * .25, size * .22); ctx.fill(p);
  }
  ctx.restore();
  const ty = style === 'arch' ? cy + size * .25 : cy;
  fillText(ctx, text, cx, ty, w * (style === 'cartouche' ? .8 : .9), { size, weight: 700, color, align: 'center', font: FONT_D });
}

/* ---------------------------------------------------------- text */
function fontStr(size, weight = 500, fam = FONT) { return `${weight} ${size}px ${fam}`; }
function measure(ctx, text, size, weight, fam) { ctx.save(); ctx.font = fontStr(size, weight, fam); const w = ctx.measureText(text || '').width; ctx.restore(); return w; }
function ellipsize(ctx, text, maxW) {
  text = String(text || '');
  if (ctx.measureText(text).width <= maxW) return text;
  let lo = 0, hi = text.length;
  while (lo < hi) { const mid = (lo + hi + 1) >> 1; if (ctx.measureText(text.slice(0, mid) + '…').width <= maxW) lo = mid; else hi = mid - 1; }
  return lo ? text.slice(0, lo).trimEnd() + '…' : '…';
}
/** Draw one line of RTL-aware text. align: center|start|end (start = right in RTL). */
function fillText(ctx, text, x, y, maxW, o = {}) {
  if (!text) return;
  ctx.save();
  ctx.font = fontStr(o.size || 11, o.weight || 500, o.font || FONT);
  ctx.direction = o.dir || (/^[\x00-\x7F]*$/.test(text) && !o.forceRtl ? 'ltr' : 'rtl');
  ctx.textBaseline = 'middle';
  ctx.textAlign = o.align === 'start' ? 'right' : o.align === 'end' ? 'left' : 'center';
  if (o.align === 'start' && !o.dir) ctx.direction = 'rtl';
  if (o.shadow) { ctx.shadowColor = o.shadow; ctx.shadowBlur = 3 * (o.S || 1); }
  ctx.fillStyle = o.color || '#fff';
  maxW = Math.max(4, maxW);
  // show the full name when possible: shrink up to 72% before shortening it
  let size = o.size || 11;
  if (o.fit !== false) {
    const full = ctx.measureText(text).width;
    if (full > maxW) { size = Math.max(size * .72, size * maxW / full); ctx.font = fontStr(size, o.weight || 500, o.font || FONT); }
  }
  ctx.fillText(ellipsize(ctx, text, maxW), x, y);
  ctx.restore();
}

/* ---------------------------------------------------------- images */
const imgCache = new Map();
const imgWaiters = new Set();
function getImg(src) {
  if (!src) return null;
  let e = imgCache.get(src);
  if (!e) {
    const img = new Image();
    e = { img, ok: false, err: false }; imgCache.set(src, e);
    img.onload = () => { e.ok = true; for (const fn of [...imgWaiters]) fn(); };
    img.onerror = () => { e.err = true; };
    img.src = src;
  }
  return e.ok ? e.img : null;
}
function loadImgs(srcs) {
  return Promise.all(srcs.filter(Boolean).map(src => new Promise(res => {
    const e = imgCache.get(src); if (e && (e.ok || e.err)) return res();
    getImg(src); const w = imgCache.get(src);
    const prevL = w.img.onload, prevE = w.img.onerror;
    w.img.onload = ev => { prevL && prevL(ev); res(); }; w.img.onerror = ev => { prevE && prevE(ev); res(); };
    setTimeout(res, 4000);
  })));
}
function drawCover(ctx, img, x, y, w, h) {
  const s = Math.max(w / img.width, h / img.height), iw = img.width * s, ih = img.height * s;
  ctx.drawImage(img, x + (w - iw) / 2, y + (h - ih) / 2, iw, ih);
}
function drawContain(ctx, img, x, y, w, h) {
  const s = Math.min(w / img.width, h / img.height), iw = img.width * s, ih = img.height * s;
  ctx.drawImage(img, x + (w - iw) / 2, y + (h - ih) / 2, iw, ih);
}
