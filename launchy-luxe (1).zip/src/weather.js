/* =========================================================
   Weather data — Open-Meteo (free, no key). Real data only:
   the last good reading is kept for offline use with its time,
   and nothing is ever invented when a request fails.
   ========================================================= */
const WX = {
  0: ['صحو', 'Clear', 'clear'], 1: ['صحو غالباً', 'Mainly clear', 'clear'], 2: ['غائم جزئياً', 'Partly cloudy', 'partly'], 3: ['غائم', 'Overcast', 'cloudy'],
  45: ['ضباب', 'Fog', 'fog'], 48: ['ضباب متجمد', 'Rime fog', 'fog'],
  51: ['رذاذ خفيف', 'Light drizzle', 'drizzle'], 53: ['رذاذ', 'Drizzle', 'drizzle'], 55: ['رذاذ كثيف', 'Dense drizzle', 'drizzle'], 56: ['رذاذ متجمد', 'Freezing drizzle', 'drizzle'], 57: ['رذاذ متجمد', 'Freezing drizzle', 'drizzle'],
  61: ['مطر خفيف', 'Light rain', 'rain'], 63: ['مطر', 'Rain', 'rain'], 65: ['مطر غزير', 'Heavy rain', 'rain'], 66: ['مطر متجمد', 'Freezing rain', 'rain'], 67: ['مطر متجمد', 'Freezing rain', 'rain'],
  71: ['ثلج خفيف', 'Light snow', 'snow'], 73: ['ثلج', 'Snow', 'snow'], 75: ['ثلج كثيف', 'Heavy snow', 'snow'], 77: ['حبيبات ثلج', 'Snow grains', 'snow'],
  80: ['زخات مطر', 'Rain showers', 'showers'], 81: ['زخات مطر', 'Rain showers', 'showers'], 82: ['زخات غزيرة', 'Violent showers', 'showers'], 85: ['زخات ثلج', 'Snow showers', 'snow'], 86: ['زخات ثلج', 'Snow showers', 'snow'],
  95: ['عاصفة رعدية', 'Thunderstorm', 'storm'], 96: ['عاصفة رعدية مع برَد', 'Thunderstorm, hail', 'storm'], 99: ['عاصفة رعدية مع برَد', 'Thunderstorm, hail', 'storm']
};
const wxDesc = (code, lang) => (WX[code] || WX[3])[lang === 'en' ? 1 : 0];
const wxIcon = code => (WX[code] || WX[3])[2];
/** Weather group used by the smart backgrounds. */
function wxGroup(code) {
  const k = wxIcon(code);
  return { clear: 'clear', partly: 'cloudy', cloudy: 'cloudy', fog: 'fog', drizzle: 'rain', rain: 'rain', showers: 'rain', storm: 'rain', snow: 'snow' }[k] || 'clear';
}
const AQI_LEVELS = [[50, 'جيدة', 'Good', '#3fbf6f'], [100, 'مقبولة', 'Moderate', '#d9c23a'], [150, 'غير صحية للحساسين', 'Unhealthy (sensitive)', '#ec8a2c'], [200, 'غير صحية', 'Unhealthy', '#e0473c'], [300, 'غير صحية جداً', 'Very unhealthy', '#8f3fb5'], [1e9, 'خطرة', 'Hazardous', '#7e1f2e']];
const aqiLevel = v => AQI_LEVELS.find(l => v <= l[0]);
const DIRS_AR = ['شمال', 'شمال شرق', 'شرق', 'جنوب شرق', 'جنوب', 'جنوب غرب', 'غرب', 'شمال غرب'];
const DIRS_EN = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
const windDir = (deg, lang) => (lang === 'en' ? DIRS_EN : DIRS_AR)[Math.round(((deg || 0) % 360) / 45) % 8];

/* Ready cities (coordinates + time zone); any other city can be searched. */
const CITIES = [
  ['جدة', 'Jeddah', 21.4858, 39.1925, 'Asia/Riyadh', 'sa'], ['مكة المكرمة', 'Makkah', 21.3891, 39.8579, 'Asia/Riyadh', 'sa'], ['المدينة المنورة', 'Madinah', 24.5247, 39.5692, 'Asia/Riyadh', 'sa'],
  ['الرياض', 'Riyadh', 24.7136, 46.6753, 'Asia/Riyadh', 'sa'], ['الدمام', 'Dammam', 26.4207, 50.0888, 'Asia/Riyadh', 'sa'], ['الخبر', 'Khobar', 26.2172, 50.1971, 'Asia/Riyadh', 'sa'],
  ['الطائف', 'Taif', 21.2703, 40.4158, 'Asia/Riyadh', 'sa'], ['أبها', 'Abha', 18.2164, 42.5053, 'Asia/Riyadh', 'sa'], ['خميس مشيط', 'Khamis Mushait', 18.3, 42.7333, 'Asia/Riyadh', 'sa'],
  ['تبوك', 'Tabuk', 28.3835, 36.5662, 'Asia/Riyadh', 'sa'], ['حائل', 'Hail', 27.5114, 41.7208, 'Asia/Riyadh', 'sa'], ['بريدة', 'Buraydah', 26.326, 43.975, 'Asia/Riyadh', 'sa'],
  ['جازان', 'Jazan', 16.8892, 42.5511, 'Asia/Riyadh', 'sa'], ['نجران', 'Najran', 17.5656, 44.2289, 'Asia/Riyadh', 'sa'], ['الباحة', 'Al Bahah', 20.0129, 41.4677, 'Asia/Riyadh', 'sa'],
  ['العلا', 'AlUla', 26.6085, 37.9232, 'Asia/Riyadh', 'sa'], ['ينبع', 'Yanbu', 24.0895, 38.0618, 'Asia/Riyadh', 'sa'], ['الأحساء', 'Al Ahsa', 25.3833, 49.5833, 'Asia/Riyadh', 'sa'],
  ['الجبيل', 'Jubail', 27.0174, 49.6225, 'Asia/Riyadh', 'sa'], ['القطيف', 'Qatif', 26.5196, 50.0115, 'Asia/Riyadh', 'sa'], ['عرعر', 'Arar', 30.9753, 41.0381, 'Asia/Riyadh', 'sa'],
  ['سكاكا', 'Sakaka', 29.9697, 40.2064, 'Asia/Riyadh', 'sa'], ['القنفذة', 'Al Qunfudhah', 19.1264, 41.0789, 'Asia/Riyadh', 'sa'], ['رابغ', 'Rabigh', 22.7986, 39.0349, 'Asia/Riyadh', 'sa'],
  ['دبي', 'Dubai', 25.2048, 55.2708, 'Asia/Dubai', 'w'], ['أبوظبي', 'Abu Dhabi', 24.4539, 54.3773, 'Asia/Dubai', 'w'], ['الدوحة', 'Doha', 25.2854, 51.531, 'Asia/Qatar', 'w'],
  ['الكويت', 'Kuwait City', 29.3759, 47.9774, 'Asia/Kuwait', 'w'], ['المنامة', 'Manama', 26.2285, 50.586, 'Asia/Bahrain', 'w'], ['مسقط', 'Muscat', 23.588, 58.3829, 'Asia/Muscat', 'w'],
  ['القاهرة', 'Cairo', 30.0444, 31.2357, 'Africa/Cairo', 'w'], ['عمّان', 'Amman', 31.9454, 35.9284, 'Asia/Amman', 'w'], ['إسطنبول', 'Istanbul', 41.0082, 28.9784, 'Europe/Istanbul', 'w'],
  ['لندن', 'London', 51.5074, -0.1278, 'Europe/London', 'w'], ['باريس', 'Paris', 48.8566, 2.3522, 'Europe/Paris', 'w'], ['زيورخ', 'Zurich', 47.3769, 8.5417, 'Europe/Zurich', 'w'],
  ['إنترلاكن', 'Interlaken', 46.6863, 7.8632, 'Europe/Zurich', 'w'], ['فيينا', 'Vienna', 48.2082, 16.3738, 'Europe/Vienna', 'w'], ['أوسلو', 'Oslo', 59.9139, 10.7522, 'Europe/Oslo', 'w'],
  ['طوكيو', 'Tokyo', 35.6762, 139.6503, 'Asia/Tokyo', 'w'], ['كيوتو', 'Kyoto', 35.0116, 135.7681, 'Asia/Tokyo', 'w'], ['ماليه (المالديف)', 'Malé', 4.1755, 73.5093, 'Indian/Maldives', 'w'],
  ['بالي', 'Bali', -8.6705, 115.2126, 'Asia/Makassar', 'w'], ['كوالالمبور', 'Kuala Lumpur', 3.139, 101.6869, 'Asia/Kuala_Lumpur', 'w'], ['كوينزتاون', 'Queenstown', -45.0312, 168.6626, 'Pacific/Auckland', 'w'],
  ['بانف', 'Banff', 51.1784, -115.5708, 'America/Edmonton', 'w'], ['نيويورك', 'New York', 40.7128, -74.006, 'America/New_York', 'w'], ['باكو', 'Baku', 40.4093, 49.8671, 'Asia/Baku', 'w'],
  ['تبليسي', 'Tbilisi', 41.7151, 44.8271, 'Asia/Tbilisi', 'w'], ['سراييفو', 'Sarajevo', 43.8563, 18.4131, 'Europe/Sarajevo', 'w'], ['سيدني', 'Sydney', -33.8688, 151.2093, 'Australia/Sydney', 'w']
].map(([n, en, lat, lon, tz, g]) => ({ n, en, lat, lon, tz, g }));
const cityLoc = c => ({ mode: 'city', name: c.n, en: c.en, lat: c.lat, lon: c.lon, tz: c.tz });
const DEFAULT_LOC = cityLoc(CITIES[0]);

/* ---------------------------------------------------------- network */
const netWaiters = {};
/** GET JSON — through the app on Android (no CORS limits), fetch() on the web. */
async function httpJson(url, timeout = 15000) {
  if (NATIVE && window.LaunchyNative.httpGet) {
    const id = uid();
    const r = await new Promise(res => {
      netWaiters[id] = res;
      setTimeout(() => { if (netWaiters[id]) { delete netWaiters[id]; res(null); } }, timeout);
      try { window.LaunchyNative.httpGet(id, url); } catch (e) { delete netWaiters[id]; res(null); }
    });
    if (!r || !r.ok) throw new Error(r ? 'HTTP ' + r.status : 'timeout');
    return JSON.parse(r.body);
  }
  const ctl = 'AbortController' in window ? new AbortController() : null;
  const t = ctl && setTimeout(() => ctl.abort(), timeout);
  try {
    const res = await fetch(url, ctl ? { signal: ctl.signal } : {});
    if (!res.ok) throw new Error('HTTP ' + res.status);
    return await res.json();
  } finally { clearTimeout(t); }
}
function netResult(data) { const w = data && netWaiters[data.id]; if (w) { delete netWaiters[data.id]; w(data); return true; } return false; }

/* ---------------------------------------------------------- cache */
const wxKey = loc => loc ? (+loc.lat).toFixed(2) + ',' + (+loc.lon).toFixed(2) : '';
const wxAll = () => store.get('llx.wx', {}) || {};
function wxCached(loc) { return loc ? wxAll()[wxKey(loc)] || null : null; }
function wxSave(loc, entry) {
  const all = wxAll(); all[wxKey(loc)] = entry;
  const keys = Object.keys(all).sort((a, b) => (all[b].at || 0) - (all[a].at || 0));
  for (const k of keys.slice(12)) delete all[k];
  store.set('llx.wx', all);
}
const wxInflight = new Map();
/**
 * Fetch fresh weather for a location (unless the cached copy is younger than maxAgeMin).
 * Resolves to the cache entry; on failure the old entry is returned with .err set.
 */
function refreshWx(loc, maxAgeMin = 0) {
  if (!loc || loc.lat == null) return Promise.resolve(null);
  const key = wxKey(loc), old = wxCached(loc);
  if (old && old.cur && maxAgeMin > 0 && Date.now() - old.at < maxAgeMin * 6e4) return Promise.resolve(old);
  if (wxInflight.has(key)) return wxInflight.get(key);
  const lat = (+loc.lat).toFixed(4), lon = (+loc.lon).toFixed(4);
  const p = (async () => {
    try {
      const f = await httpJson(`https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,weather_code,wind_speed_10m,wind_direction_10m&hourly=temperature_2m,weather_code,is_day,precipitation_probability&daily=weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset,uv_index_max,precipitation_probability_max&timezone=auto&forecast_days=6`);
      if (!f || !f.current || typeof f.current.temperature_2m !== 'number') throw new Error('bad data');
      let aqi = null;
      try { const q = await httpJson(`https://air-quality-api.open-meteo.com/v1/air-quality?latitude=${lat}&longitude=${lon}&current=us_aqi,pm2_5&timezone=auto`, 10000); if (q && q.current && typeof q.current.us_aqi === 'number') aqi = { v: Math.round(q.current.us_aqi), pm25: q.current.pm2_5 }; } catch (e) { aqi = old && old.aqi || null; }
      const entry = { at: Date.now(), off: f.utc_offset_seconds || 0, tz: f.timezone || '', cur: f.current, hourly: f.hourly, daily: f.daily, aqi, err: '' };
      wxSave(loc, entry);
      return entry;
    } catch (e) {
      const ent = old ? Object.assign({}, old, { err: String(e && e.message || e), errAt: Date.now() }) : { err: String(e && e.message || e), errAt: Date.now() };
      wxSave(loc, ent);
      return ent;
    } finally { wxInflight.delete(key); }
  })();
  wxInflight.set(key, p);
  return p;
}
/** City search (Open-Meteo geocoding). */
async function geocodeSearch(q) {
  const lang = /[A-Za-z]/.test(q) && !/[؀-ۿ]/.test(q) ? 'en' : 'ar';
  const r = await httpJson(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(q)}&count=10&language=${lang}&format=json`);
  return (r && r.results || []).map(x => ({ mode: 'city', name: x.name, sub: [x.admin1, x.country].filter(Boolean).join('، '), lat: x.latitude, lon: x.longitude, tz: x.timezone || '' }));
}
/** Current device position (asks for permission). Resolves {lat, lon, name} or {err}. */
async function deviceLocation() {
  if (NATIVE && window.LaunchyNative.requestLocation) {
    const r = await nativeRequest('location', () => window.LaunchyNative.requestLocation());
    if (!r || !r.ok) return { err: r && r.denied ? 'denied' : 'unavailable' };
    store.set('llx.myloc', r);
    return r;
  }
  if (!navigator.geolocation) return { err: 'unavailable' };
  const pos = await new Promise(res => navigator.geolocation.getCurrentPosition(p => res(p), e => res({ e }), { timeout: 15000, maximumAge: 600000 }));
  if (!pos || pos.e) return { err: pos && pos.e && pos.e.code === 1 ? 'denied' : 'unavailable' };
  const r = { ok: true, lat: pos.coords.latitude, lon: pos.coords.longitude, name: '' };
  try { const g = await httpJson(`https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${r.lat}&longitude=${r.lon}&localityLanguage=ar`, 8000); r.name = g.city || g.locality || g.principalSubdivision || ''; } catch (e) {}
  store.set('llx.myloc', r);
  return r;
}
/** Location a weather design uses right now (device mode uses the last known position). */
function locOf(d) {
  const L = d.weather.loc || DEFAULT_LOC;
  if (L.mode !== 'device') return L;
  let my = store.get('llx.myloc', null);
  if (NATIVE && window.LaunchyNative.lastLocation) { try { const n = JSON.parse(window.LaunchyNative.lastLocation() || 'null'); if (n && n.lat != null) my = n; } catch (e) {} }
  return my && my.lat != null ? { mode: 'device', name: my.name || 'موقعي الحالي', lat: my.lat, lon: my.lon, tz: '' } : null;
}

/* ---------------------------------------------------------- reading the data */
const cToF = c => c * 9 / 5 + 32;
function tempStr(c, unit, digits, deg = true) {
  if (c == null || isNaN(c)) return '—';
  const v = Math.round(unit === 'F' ? cToF(c) : c);
  return toDigits((v === 0 ? 0 : v) + (deg ? '°' : ''), digits);
}
/** Location-local "now" as minutes (same frame as Open-Meteo's local time strings). */
const locNowMin = e => Math.floor((Date.now() / 1000 + (e.off || 0)) / 60);
const locStrMin = s => { const m = /^(\d+)-(\d+)-(\d+)T(\d+):(\d+)/.exec(s || ''); return m ? Date.UTC(+m[1], m[2] - 1, +m[3], +m[4], +m[5]) / 6e4 : 0; };
/** Everything the layouts need, or null when there is no reading at all. */
function wxView(e, d) {
  if (!e || !e.cur) return null;
  const o = d.weather, lang = o.lang === 'en' ? 'en' : 'ar', dg = o.digits || 'latn', u = o.unit;
  const cur = e.cur, now = locNowMin(e);
  const hours = [];
  if (e.hourly && e.hourly.time) {
    let i0 = e.hourly.time.findIndex(t => locStrMin(t) + 60 > now);
    if (i0 < 0) i0 = e.hourly.time.length;
    for (let i = i0; i < Math.min(e.hourly.time.length, i0 + 12); i++) {
      const hh = +e.hourly.time[i].slice(11, 13);
      hours.push({ t: i === i0 ? (lang === 'en' ? 'Now' : 'الآن') : toDigits(o.h12 === false ? pad2(hh) : ((hh % 12) || 12) + (hh < 12 ? (lang === 'en' ? 'a' : 'ص') : (lang === 'en' ? 'p' : 'م')), dg), temp: tempStr(e.hourly.temperature_2m[i], u, dg), code: e.hourly.weather_code[i], day: e.hourly.is_day ? !!e.hourly.is_day[i] : true, pop: e.hourly.precipitation_probability ? e.hourly.precipitation_probability[i] : null });
    }
  }
  const days = [];
  if (e.daily && e.daily.time) {
    const todayStr = new Date((now) * 6e4).toISOString().slice(0, 10);
    let i0 = e.daily.time.indexOf(todayStr); if (i0 < 0) i0 = 0;
    for (let i = i0; i < Math.min(e.daily.time.length, i0 + 6); i++) {
      const dt = new Date(e.daily.time[i] + 'T12:00:00Z');
      days.push({ n: i === i0 ? (lang === 'en' ? 'Today' : 'اليوم') : WEEKDAYS[lang + 'Short'][dt.getUTCDay()], hi: tempStr(e.daily.temperature_2m_max[i], u, dg), lo: tempStr(e.daily.temperature_2m_min[i], u, dg), hiC: e.daily.temperature_2m_max[i], loC: e.daily.temperature_2m_min[i], code: e.daily.weather_code[i], pop: e.daily.precipitation_probability_max ? e.daily.precipitation_probability_max[i] : null });
    }
  }
  const today = e.daily && e.daily.time ? e.daily.time.findIndex(t => t === new Date(now * 6e4).toISOString().slice(0, 10)) : -1;
  const tIdx = today >= 0 ? today : 0;
  const hm = s => { const m = /T(\d+):(\d+)/.exec(s || ''); if (!m) return '—'; const hh = +m[1]; return toDigits(o.h12 === false ? pad2(hh) + ':' + m[2] : ((hh % 12) || 12) + ':' + m[2] + ' ' + (hh < 12 ? (lang === 'en' ? 'AM' : 'ص') : (lang === 'en' ? 'PM' : 'م')), dg); };
  const upd = new Date(e.at);
  const ageMin = Math.round((Date.now() - e.at) / 6e4);
  const aq = e.aqi && aqiLevel(e.aqi.v);
  return {
    temp: tempStr(cur.temperature_2m, u, dg), tempC: cur.temperature_2m, feels: tempStr(cur.apparent_temperature, u, dg),
    code: cur.weather_code, day: !!cur.is_day, desc: wxDesc(cur.weather_code, lang), group: wxGroup(cur.weather_code),
    hum: toDigits(Math.round(cur.relative_humidity_2m) + '%', dg), wind: toDigits(Math.round(cur.wind_speed_10m) + (lang === 'en' ? ' km/h' : ' كم/س'), dg), windDir: windDir(cur.wind_direction_10m, lang),
    hi: days[0] ? days[0].hi : '—', lo: days[0] ? days[0].lo : '—', hiC: days[0] ? days[0].hiC : null, loC: days[0] ? days[0].loC : null,
    sunrise: e.daily ? hm(e.daily.sunrise[tIdx]) : '—', sunset: e.daily ? hm(e.daily.sunset[tIdx]) : '—',
    uv: e.daily && e.daily.uv_index_max ? toDigits(Math.round(e.daily.uv_index_max[tIdx] || 0), dg) : '—',
    aqi: e.aqi ? toDigits(e.aqi.v, dg) : null, aqiText: aq ? aq[lang === 'en' ? 2 : 1] : '', aqiColor: aq ? aq[3] : '#888',
    hours, days, updated: toDigits(pad2(upd.getHours()) + ':' + pad2(upd.getMinutes()), dg), ageMin, stale: ageMin > 180, err: e.err || '', at: e.at
  };
}
