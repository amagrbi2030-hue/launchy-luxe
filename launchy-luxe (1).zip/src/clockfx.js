/* =========================================================
   Interactive clocks — pendulum, glass pill, digital+analog,
   motion styles, material packs and the alarm "ringing" look.

   Two separate worlds:
   • In the app the preview animates smoothly (requestAnimationFrame
     over a cached still image of the design).
   • On the home screen Android draws RemoteViews: the studio bakes a
     short loop of pendulum frames (normal + ringing) that the
     launcher plays with a ViewFlipper. No high-frequency updates.
   ========================================================= */
const CLOCK_FACES = [['analog', 'عقارب'], ['digital', 'رقمية'], ['pendulum', 'ساعة بندول'], ['pill', 'كبسولة زجاجية'], ['combo', 'رقمية + عقارب']];
const MOTIONS = [
  { k: 'classic', n: 'عقارب كلاسيكية', d: 'عقرب الثواني يقفز كل ثانية' },
  { k: 'pendulum', n: 'بندول متأرجح', d: 'تأرجح طبيعي هادئ' },
  { k: 'slowLux', n: 'بندول فاخر بطيء', d: 'دورة أطول بحركة وقورة' },
  { k: 'fastAlarm', n: 'بندول سريع عند المنبه', d: 'هادئ عادةً ويتسارع بوضوح عند الرنين' },
  { k: 'lightHands', n: 'عقارب بتأثير ضوئي', d: 'توهّج ناعم يتنفس حول العقارب' },
  { k: 'smooth', n: 'دوران ناعم', d: 'عقرب ثوانٍ ينساب دون قفز' },
  { k: 'mechanical', n: 'ميكانيكية عتيقة', d: 'قفزة مع ارتداد خفيف كالآلات القديمة' },
  { k: 'glass', n: 'زجاجية مع انعكاسات', d: 'وميض ضوء يعبر الزجاج ببطء' },
  { k: 'goldHands', n: 'عقارب ذهبية', d: 'عقارب ذهبية مصقولة بلمعة' },
  { k: 'pulse', n: 'نابضة عند المنبه', d: 'هالة ذهبية تنبض مع الرنين' }];
const MOTION = Object.fromEntries(MOTIONS.map(m => [m.k, m]));
const CAPS = [['dome', 'قبة مصقولة'], ['ring', 'حلقة'], ['jewel', 'جوهرة'], ['flat', 'قرص مسطح'], ['star', 'نجمة'], ['none', 'بدون']];
const SEC_STYLES = [['line', 'خط بثقل موازن'], ['lollipop', 'بقرص دائري'], ['arrow', 'سهم'], ['thin', 'رفيع جداً']];
const PEND_FACES = [['digital', 'وقت رقمي'], ['analog', 'ميناء بعقارب']];
const CLOCK_TAPS = [['clockApp', 'منبهات الجهاز (عرض المنبهات)'], ['setAlarm', 'إنشاء منبه جديد في الجهاز'], ['appAlarms', 'منبهات تطبيق الاختصارات'], ['calendarApp', 'فتح التقويم'], ['studio', 'فتح الاستوديو'], ['none', 'بدون']];

/** Material packs: one tap changes case, dial, hands and pendulum together (each stays editable). */
const CLOCK_PACKS = [
  { k: 'royalGold', n: 'ذهب ملكي', sw: ['#3a2410', '#d4af37'], theme: 'brown', a: { mat: 'leather', matTint: false, frame: 'royalGold', frameColor: '#d4af37', lightColor: '#ffd98a', fx: { soft: 55, golden: 35 } }, c: { bezel: 'goldMulti', dial: 'ivory', handColor: 'gold', glowHands: '', rod: '#d4af37', inner: '#140b05' } },
  { k: 'brownLux', n: 'بني فاخر', sw: ['#4a2c17', '#d9b25a'], theme: 'brown', a: { mat: 'darkWood', matTint: false, frame: 'none', lightColor: '#ffcf7a', fx: { soft: 60, reflect: 30, edge: 25 } }, c: { bezel: 'woodDark', dial: 'black', handColor: 'gold', rod: '#d9b25a', inner: '#120a05' } },
  { k: 'emeraldGlass', n: 'زجاج زمردي', sw: ['#0f5f45', '#8ff5c9'], theme: 'emerald', a: { mat: 'glassLiquid', matTint: true, frame: 'none', lightColor: '#8ff5c9', fx: { soft: 40, reflect: 55, edge: 45 } }, c: { bezel: 'glass', dial: 'glass', handColor: 'white', glowHands: '#8ff5c9', rod: '#e9fff5', inner: '#04140e' } },
  { k: 'purpleGlass', n: 'زجاج بنفسجي', sw: ['#4b2a86', '#d6b8ff'], theme: 'purple', a: { mat: 'glassLiquid', matTint: true, frame: 'none', lightColor: '#d6b8ff', fx: { soft: 40, reflect: 60, edge: 55 } }, c: { bezel: 'glass', dial: 'glass', handColor: 'white', glowHands: '#d6b8ff', rod: '#f1e8ff', inner: '#0e0718' } },
  { k: 'liquidGlass', n: 'زجاج سائل', sw: ['#1d3c8a', '#9ef3ff'], theme: 'royal', a: { mat: 'glassLiquid', matTint: true, frame: 'none', lightColor: '#9ef3ff', fx: { soft: 40, reflect: 60, edge: 55 } }, c: { bezel: 'glass', dial: 'glass', handColor: 'glass', glowHands: '#9ef3ff', rod: '#e6f6ff', inner: '#050b1a' } },
  { k: 'velvet', n: 'مخمل فاخر', sw: ['#1b2440', '#c9a24a'], theme: 'navy', a: { mat: 'velvet', matTint: true, frame: 'none', fx: { soft: 55, elev: 60, emboss: 35 } }, c: { bezel: 'velvet3d', dial: 'material', dialMat: 'velvet', handColor: 'gold', raised: true, rod: '#d4af37', inner: '#070912' } },
  { k: 'marble', n: 'رخام ملكي', sw: ['#ece8e1', '#b8933a'], theme: 'ivory', a: { mat: 'marbleWhite', matTint: false, frame: 'goldDouble', frameColor: '#b8933a', fx: { soft: 50 } }, c: { bezel: 'marble', dial: 'white', handColor: 'black', rod: '#b8933a', inner: '#1a1a1c' } },
  { k: 'bronze', n: 'برونز معتق', sw: ['#5a3a1c', '#c08a4a'], theme: 'brown', a: { mat: 'bronze', matTint: false, frame: 'copperEngr', frameColor: '#c08a4a', lightColor: '#ffbf80', fx: { soft: 55, emboss: 30 } }, c: { bezel: 'gold', dial: 'ivory', handColor: 'copper', rod: '#c08a4a', inner: '#140b06' } },
  { k: 'crystal', n: 'كريستال', sw: ['#cfe3f5', '#ffffff'], theme: 'sky', a: { mat: 'crystal', matTint: false, frame: 'crystalF', frameColor: '#e8f4ff', lightColor: '#e8f6ff', fx: { soft: 40, reflect: 70, edge: 50 } }, c: { bezel: 'glass', dial: 'glass', handColor: 'silver', glowHands: '#e8f6ff', rod: '#ffffff', inner: '#0b1320' } },
  { k: 'midnight', n: 'أسود منتصف الليل', sw: ['#08080b', '#c9ced6'], theme: 'onyx', a: { mat: 'velvet', matTint: false, frame: 'silverF', frameColor: '#c9ced6', lightColor: '#cfe0ff', fx: { soft: 60 } }, c: { bezel: 'chrome', dial: 'black', handColor: 'silver', rod: '#d9dde4', inner: '#030305' } },
  { k: 'neon', n: 'نيون', sw: ['#0b0b14', '#ff3fd2'], theme: 'purple', a: { mat: 'none', frame: 'gradientGlow', lightColor: '#ff3fd2', fx: { soft: 30, neon: 70, edge: 60 } }, c: { bezel: 'thin', dial: 'black', handColor: 'luminous', glowHands: '#ff3fd2', rod: '#ff8ae6', inner: '#07030c' } },
  { k: 'champagne', n: 'ذهبي شمباني', sw: ['#e9d7b4', '#c8a45a'], theme: 'gold', a: { mat: 'satin', matTint: false, frame: 'goldDouble', frameColor: '#c8a45a', lightColor: '#fff0c8', fx: { soft: 50, reflect: 30 } }, c: { bezel: 'gold', dial: 'ivory', handColor: 'rose', rod: '#c8a45a', inner: '#1a130a' } }];
const CLOCK_PACK = Object.fromEntries(CLOCK_PACKS.map(p => [p.k, p]));
/** Apply a pack to a design in place (only the look; content and options stay). */
function applyClockPack(d, k) {
  const p = CLOCK_PACK[k]; if (!p) return;
  Object.assign(d.a, clone(p.a)); if (p.a.fx) d.a.fx = fxOf(p.a.fx);
  d.theme = p.theme; Object.assign(d.clock, clone(p.c)); d.clock.pack = k;
}

/* ---------------------------------------------------------- effective options */
/** Clock options with the motion style's look applied (gold hands, light hands…). */
function effClock(o) {
  const m = o.motion || 'classic';
  if (m === 'goldHands') return Object.assign({}, o, { handColor: 'gold', glowHands: o.glowHands || '' });
  if (m === 'lightHands') return Object.assign({}, o, { glowHands: o.glowHands || '#ffe7a8' });
  return o;
}
const isPendMotion = m => m === 'pendulum' || m === 'slowLux' || m === 'fastAlarm';

/* ---------------------------------------------------------- alarm look (preview) */
const CLOCK_ALERT = { on: false, t0: 0, t1: 0, from: 0 };
/** 0…1: how strongly the "ringing" look shows right now (ramps up, then settles back gently). */
function alertLevel(now = performance.now()) {
  const A = CLOCK_ALERT;
  if (A.on) return Math.min(1, (now - A.t0) / 450);
  if (!A.t1) return 0;
  const k = 1 - (now - A.t1) / 2600;
  return k <= 0 ? 0 : A.from * k * k;
}
function setClockAlert(on) {
  const now = performance.now();
  if (on && !CLOCK_ALERT.on) Object.assign(CLOCK_ALERT, { on: true, t0: now });
  else if (!on && CLOCK_ALERT.on) Object.assign(CLOCK_ALERT, { on: false, from: alertLevel(now), t1: now });
  for (const w of $$('.wcv')) if (w._redraw) w._redraw();
}
const alertMaybe = () => CLOCK_ALERT.on || alertLevel() > 0;

/* ---------------------------------------------------------- next alarm */
/** {at (ms), label, own} for the next alarm on the device (or this app's alarms in the browser). */
let NEXT_ALARM = null;
function refreshNextAlarm() {
  try {
    if (NATIVE && window.LaunchyNative.nextAlarm) { const j = JSON.parse(window.LaunchyNative.nextAlarm() || 'null'); NEXT_ALARM = j && j.at ? j : null; return NEXT_ALARM; }
  } catch (e) {}
  NEXT_ALARM = typeof nextOwnAlarm === 'function' ? nextOwnAlarm() : null;
  return NEXT_ALARM;
}
function nextAlarmText(o, now = new Date()) {
  const n = NEXT_ALARM; const en = o.lang === 'en';
  if (!n || !n.at || n.at < now.getTime()) return en ? 'No alarm' : 'لا يوجد منبه';
  const t = new Date(n.at), tt = timeText({ h: t.getHours(), m: t.getMinutes(), s: 0 }, o.fmt || 'system', o.digits) + ((o.fmt === '12' || (o.fmt !== '24' && !is24System())) ? ' ' + ampmText({ h: t.getHours() }, o.lang) : '');
  const days = Math.round((dayOnly(t) - dayOnly(now)) / 864e5);
  const when = days === 0 ? '' : days === 1 ? (en ? 'tomorrow ' : 'غداً ') : (WEEKDAYS[en ? 'en' : 'ar'][t.getDay()] + ' ');
  return (en ? 'Alarm ' : 'المنبه ') + when + tt;
}
function remainText(ms, o) {
  if (ms <= 0) return '';
  const m = Math.floor(ms / 60000), hh = Math.floor(m / 60), mm = m % 60, en = o.lang === 'en';
  const s = hh ? (en ? `${hh}h ${mm}m` : `${hh} س ${mm} د`) : (en ? `${mm} min` : `${mm} دقيقة`);
  return toDigits((en ? 'in ' : 'بعد ') + s, o.digits);
}

/* ---------------------------------------------------------- shared painters */
const PEND_N = 12;  // frames in one swing loop on the home screen
/** Period (ms) and amplitude (rad) of the pendulum for an alert level. */
function pendParams(o, level = 0) {
  const m = o.motion || 'pendulum';
  let P = 2000 * (m === 'slowLux' ? 1.55 : 1) * 100 / clamp(o.speed || 100, 40, 250);
  let A = clamp(o.swing ?? 10, 2, 24) * (m === 'slowLux' ? 1.1 : 1) * Math.PI / 180;
  if (o.alarmFx !== false && level > 0) {
    const boost = m === 'fastAlarm' ? 1 : .75;
    P *= 1 - .42 * boost * level; A *= 1 + .55 * boost * level;
  }
  return { P, A: Math.min(A, 30 * Math.PI / 180) };
}
const pendState = new Map();
/** Angle now, keeping the phase continuous while speed changes (alarm ramps). */
function pendAngle(key, o, level, now) {
  const { P, A } = pendParams(o, level);
  let st = pendState.get(key);
  if (!st) pendState.set(key, st = { ph: 0, t: now });
  st.ph += Math.min(100, now - st.t) * TAU / P; st.t = now;
  return A * Math.sin(st.ph);
}
/** The pendulum window: dark glass, pivot, gold rod and bob, glass reflection. */
function paintPendulumWin(ctx, S, L, el, ang, level = 0) {
  const o = el.o, { x, y, w, h } = el, r = el.r;
  const P = new Path2D(); rrPath(P, x, y, w, h, r);
  const gold = o.rod || '#d4af37', light = o.light ?? 60, shK = (o.shadowK ?? 50) / 50;
  ctx.save(); ctx.clip(P);
  // inner background: deep, slightly warm, with a soft spotlight behind the pivot
  const inner = o.inner || '#120a05';
  ctx.fillStyle = linGrad(ctx, x, y, x, y + h, [[0, mix(inner, '#000000', .2)], [.5, inner], [1, mix(inner, '#000000', .45)]]); ctx.fill(P);
  const sp = ctx.createRadialGradient(x + w / 2, y + h * .2, 0, x + w / 2, y + h * .2, h * .8);
  sp.addColorStop(0, rgba(mix(inner, gold, .35), .55 * light / 100 + .1)); sp.addColorStop(1, rgba(inner, 0)); ctx.fillStyle = sp; ctx.fill(P);
  // fine vertical lines of the back plate
  ctx.strokeStyle = rgba(gold, .06); ctx.lineWidth = .6;
  for (let i = 1; i < 9; i++) { const xx = x + w * i / 9; ctx.beginPath(); ctx.moveTo(xx, y); ctx.lineTo(xx, y + h); ctx.stroke(); }
  // the pendulum
  const px = el.px, py = el.py, len = el.len, bob = el.bob, rw = Math.max(1.2, w * .03);
  const draw = (shadow) => {
    ctx.save(); ctx.translate(px, py); ctx.rotate(ang);
    if (shadow) { ctx.translate(w * .025, h * .02); ctx.filter = `blur(${Math.max(1, w * .03) * S}px)`; ctx.fillStyle = `rgba(0,0,0,${clamp(.5 * shK, 0, .85)})`; }
    const rod = new Path2D(); rod.rect(-rw / 2, 0, rw, len - bob * .9);
    const dm = new Path2D(); diamond(dm, 0, len * .42, rw * 1.8, rw * 3);
    const b = new Path2D(); b.arc(0, len, bob, 0, TAU);
    if (shadow) { ctx.fill(rod); ctx.fill(dm); ctx.fill(b); ctx.restore(); ctx.filter = 'none'; return; }
    ctx.fillStyle = linGrad(ctx, -rw, 0, rw, 0, [[0, mix(gold, '#ffffff', .5)], [.5, gold], [1, mix(gold, '#000000', .45)]]); ctx.fill(rod); ctx.fill(dm);
    const glow = (light / 100) * .6 + level * .8;
    if (glow > .02) { ctx.shadowColor = rgba(L.a.lightColor || '#ffd98a', Math.min(1, glow)); ctx.shadowBlur = bob * (1.1 + level) * S; }
    const g = ctx.createRadialGradient(-bob * .35, len - bob * .35, bob * .05, 0, len, bob);
    g.addColorStop(0, mix(gold, '#ffffff', .75)); g.addColorStop(.45, gold); g.addColorStop(1, mix(gold, '#000000', .55));
    ctx.fillStyle = g; ctx.fill(b); ctx.shadowBlur = 0;
    ctx.lineWidth = Math.max(.6, bob * .08); ctx.strokeStyle = rgba(mix(gold, '#000000', .5), .8); ctx.stroke(b);
    const ring = new Path2D(); ring.arc(0, len, bob * .62, 0, TAU); ctx.lineWidth = Math.max(.5, bob * .05); ctx.strokeStyle = rgba(mix(gold, '#ffffff', .4), .7); ctx.stroke(ring);
    ctx.restore();
  };
  draw(true); draw(false);
  // pivot bracket
  ctx.fillStyle = linGrad(ctx, px - rw * 3, py, px + rw * 3, py, [[0, mix(gold, '#ffffff', .4)], [1, mix(gold, '#000000', .4)]]);
  const br = new Path2D(); rrPath(br, px - rw * 3.2, y - 2, rw * 6.4, py - y + rw * 1.2, rw); ctx.fill(br);
  ctx.beginPath(); ctx.arc(px, py, rw * 1.6, 0, TAU); ctx.fillStyle = mix(gold, '#000000', .3); ctx.fill();
  ctx.beginPath(); ctx.arc(px, py, rw * .7, 0, TAU); ctx.fillStyle = mix(gold, '#ffffff', .6); ctx.fill();
  // glass: inner shadow + diagonal reflection
  ctx.lineWidth = w * .08; ctx.strokeStyle = 'rgba(0,0,0,.35)'; ctx.filter = `blur(${w * .04 * S}px)`; ctx.stroke(P); ctx.filter = 'none';
  const rf = new Path2D(); rf.moveTo(x - w * .1, y + h * .45); rf.lineTo(x + w * .55, y - h * .05); rf.lineTo(x + w * .75, y - h * .05); rf.lineTo(x - w * .1, y + h * .62); rf.closePath();
  ctx.fillStyle = linGrad(ctx, x, y, x + w * .5, y + h * .5, [[0, 'rgba(255,255,255,0)'], [.5, 'rgba(255,255,255,.13)'], [1, 'rgba(255,255,255,0)']]); ctx.fill(rf);
  if (level > 0) { ctx.lineWidth = w * .05; ctx.strokeStyle = rgba(L.a.lightColor || '#ffd98a', .55 * level); ctx.shadowColor = rgba(L.a.lightColor || '#ffd98a', level); ctx.shadowBlur = w * .2 * S; ctx.stroke(P); }
  ctx.restore();
}
/** Gold rim around the pendulum window (static part, baked with the design). */
function paintWindowRim(ctx, S, L, el) {
  const { x, y, w, h, r } = el, o = el.o, gold = o.rod || '#d4af37', t = Math.max(2, w * .045);
  const outer = new Path2D(); rrPath(outer, x - t, y - t, w + 2 * t, h + 2 * t, r + t);
  const inner = new Path2D(); rrPath(inner, x, y, w, h, r);
  ctx.save();
  outerShadow(ctx, S, outer, `rgba(0,0,0,${.45 * (o.shadowK ?? 50) / 50})`, t * 2.5, 0, t * .8);
  const ring = new Path2D(); ring.addPath(outer); ring.addPath(inner);
  ctx.fillStyle = linGrad(ctx, x, y - t, x + w, y + h + t, [[0, mix(gold, '#ffffff', .55)], [.3, gold], [.55, mix(gold, '#000000', .35)], [.8, gold], [1, mix(gold, '#ffffff', .35)]]);
  ctx.fill(ring, 'evenodd');
  ctx.lineWidth = .7; ctx.strokeStyle = rgba(mix(gold, '#000000', .6), .7); ctx.stroke(outer); ctx.stroke(inner);
  const lt = (o.light ?? 60) / 100;
  if (lt > .05) { ctx.shadowColor = rgba(L.a.lightColor || '#ffd98a', .7 * lt); ctx.shadowBlur = t * 3 * S; ctx.lineWidth = .8; ctx.strokeStyle = rgba(L.a.lightColor || '#ffd98a', .5 * lt); ctx.stroke(outer); }
  ctx.restore();
}
/** 3D case edges for the tall clocks: light top-left bevel, dark bottom-right. */
function paintCaseBevel(ctx, S, L, B, o) {
  const P = boxPath(B), k = (o.shadowK ?? 50) / 50;
  ctx.save(); ctx.clip(P);
  ctx.lineWidth = Math.max(2, Math.min(B.w, B.h) * .04);
  ctx.strokeStyle = linGrad(ctx, B.x, B.y, B.x + B.w, B.y + B.h, [[0, 'rgba(255,255,255,.28)'], [.45, 'rgba(255,255,255,.04)'], [.55, 'rgba(0,0,0,.08)'], [1, `rgba(0,0,0,${.45 * k})`]]);
  ctx.stroke(P);
  ctx.restore();
}
/** Ringing look over the whole widget: gold halo + pulsing bell badge. */
function paintAlertFx(ctx, S, L, LY, level, tms = 0) {
  if (level <= 0) return;
  const B = LY.B, c = L.a.lightColor || '#ffd98a', pulse = .75 + .25 * Math.sin(tms / 180);
  ctx.save();
  const P = boxPath(B);
  ctx.shadowColor = rgba(c, .95 * level * pulse); ctx.shadowBlur = Math.min(B.w, B.h) * .12 * S;
  ctx.lineWidth = 2.2; ctx.strokeStyle = rgba(c, .85 * level); ctx.stroke(P);
  ctx.shadowBlur = 0;
  const s = Math.min(B.w, B.h) * .16, bx = B.x + B.w - s * .45, by = B.y + s * .45;
  ctx.globalAlpha = level;
  ctx.beginPath(); ctx.arc(bx, by, s * .48 * (1 + .06 * Math.sin(tms / 120)), 0, TAU);
  ctx.fillStyle = linGrad(ctx, bx - s / 2, by - s / 2, bx + s / 2, by + s / 2, [[0, mix(c, '#ffffff', .4)], [1, mix(c, '#000000', .35)]]); ctx.fill();
  ctx.save(); ctx.translate(bx, by); ctx.rotate(Math.sin(tms / 70) * .25 * level); paintGlyph(ctx, S, 'bell', 0, 0, s * .58, '#2a1a05'); ctx.restore();
  ctx.restore();
}

/* ---------------------------------------------------------- layouts */
function timeLines(d, now, max) { return clockInfoLines(d, now).slice(0, max); }
function layPendulum(d, LY, C, now, o) {
  const B = LY.B, lines = timeLines(d, now, 3);
  const showPend = o.pendulum !== false;
  const topH = C.h * (o.pendFace === 'analog' ? .42 : (lines.length > 1 ? .34 : .3));
  const tc = o.timeColor || L_textOf(d);
  LY.nodes.push({ k: 'draw', fn: (ctx, S, L) => paintCaseBevel(ctx, S, L, B, o) });
  if (o.pendFace === 'analog') {
    const R = Math.min(C.w * .44, topH * .5), cx = C.x + C.w / 2, cy = C.y + R;
    LY.nodes.push({ k: 'draw', fn: (ctx, S, L) => paintAnalogFace(ctx, S, L, cx, cy, R, o) });
    addLive(LY, { kind: 'analog', cx, cy, R: R * (1 - ({ goldMulti: .16, gold: .09, woodDark: .15, velvet3d: .17, chrome: .1, silver: .08, glass: .1, marble: .14, thin: .025, none: 0 }[o.bezel] ?? .1) * (o.bezelW ?? 100) / 100), o: Object.assign({}, o), tz: o.tz, x: cx - R, y: cy - R, w: 2 * R, h: 2 * R });
    if (lines.length) LY.nodes.push({ k: 'draw', fn: (ctx, S, L) => drawInfoLines(ctx, S, L, lines.slice(0, 1), C.x, cy + R, C.w, topH - 2 * R + C.h * .02, o, 'center') });
  } else {
    useClockFont(o.font, o.digits);
    const ampmOn = o.ampm && o.fmt !== '24' && !(o.fmt === 'system' && is24System());
    const th = topH * (lines.length ? .62 : .9);
    addLive(LY, { kind: 'time', font: o.font, digits: o.digits, mode: o.fmt, color: tc, tz: o.tz, lang: o.lang, lead: o.lead, grad: o.gradient || '', x: C.x + C.w * .04, y: C.y, w: C.w * (ampmOn ? .8 : .92), h: th });
    if (ampmOn) addLive(LY, { kind: 'ampm', font: 'medium', digits: o.digits, mode: o.fmt, color: L_subOf(d), tz: o.tz, lang: o.lang, x: C.x, y: C.y + th * .5, w: C.w * .14, h: th * .35, size: th * .2, align: 'left' });
    if (lines.length) LY.nodes.push({ k: 'draw', fn: (ctx, S, L) => drawInfoLines(ctx, S, L, lines, C.x, C.y + th, C.w, topH - th, o, 'center') });
  }
  const gap = C.h * .035, wx = C.x + C.w * .1, ww = C.w * .8, wy = C.y + topH + gap, wh = C.y + C.h - wy;
  const el = { kind: 'pendulum', x: wx, y: wy, w: ww, h: wh, r: Math.min(ww * .22, wh * .2), px: wx + ww / 2, py: wy + wh * .07, len: wh * .7, bob: Math.min(ww * .19, wh * .16), o: Object.assign({}, o), swing: showPend };
  LY.nodes.push({ k: 'draw', fn: (ctx, S, L) => paintWindowRim(ctx, S, L, el) });
  LY.live.push(el);
  if (showPend) LY.anim = true;
  tapHit(LY, d, B);
}
function layPill(d, LY, C, now, o) {
  const B = LY.B; B.r = B.h / 2;
  const di = dateInfo(now, { calc: o.calc, offset: o.offset, lang: o.lang, digits: o.digits });
  const tc = o.timeColor || L_textOf(d), H2 = C.h, bd = H2 * .9, gap = H2 * .16;
  const bcx = C.x + C.w - bd / 2, bcy = C.y + C.h / 2;               // alarm button at the start (RTL: right)
  const bw = Math.min(C.w * .2, H2 * 1.02), bh = H2 * .9, bx = C.x, by = C.y + (C.h - bh) / 2;  // date badge at the end
  const tx = bx + bw + gap, tw = bcx - bd / 2 - gap - tx;
  const nx = o.nextAlarm ? nextAlarmText(o, now) : '';
  LY.nodes.push({ k: 'draw', fn: (ctx, S, L) => {
    const glass = (x, y, w, h, r) => { const p = new Path2D(); rrPath(p, x, y, w, h, r); ctx.save(); ctx.fillStyle = 'rgba(255,255,255,.13)'; ctx.fill(p); ctx.lineWidth = 1; ctx.strokeStyle = 'rgba(255,255,255,.32)'; ctx.stroke(p);
      ctx.clip(p); ctx.fillStyle = linGrad(ctx, x, y, x, y + h, [[0, 'rgba(255,255,255,.18)'], [.5, 'rgba(255,255,255,0)']]); ctx.fillRect(x, y, w, h); ctx.restore(); };
    glass(bcx - bd / 2, bcy - bd / 2, bd, bd, bd / 2);
    const on = !!(NEXT_ALARM && NEXT_ALARM.at > now.getTime());
    paintGlyph(ctx, S, 'bell', bcx, bcy - (nx ? bd * .06 : 0), bd * .44, tc, on ? { c: rgba(L.a.lightColor || '#ffd98a', .9), r: bd * .1 } : null);
    if (on) { ctx.beginPath(); ctx.arc(bcx + bd * .2, bcy - bd * .2, bd * .06, 0, TAU); ctx.fillStyle = L.a.lightColor || '#ffd98a'; ctx.fill(); }
    glass(bx, by, bw, bh, Math.min(bh * .32, 18));
    const day = o.lang === 'en' ? String(now.getDate()) : di.gDay, mon = o.lang === 'en' ? GREG_MONTHS.en[now.getMonth()].slice(0, 3).toUpperCase() : di.gMonth;
    drawClockText(ctx, day, bx + bw / 2, by + bh * .4, bh * .42, o.font === 'thin' ? 'medium' : o.font, o.digits, tc);
    fillText(ctx, mon, bx + bw / 2, by + bh * .77, bw * .9, { size: bh * .17, weight: 700, color: L.sub, font: textFam(o.tfont) });
    if (nx) fillText(ctx, nx, tx + tw / 2, C.y + C.h * .86, tw, { size: C.h * .13, weight: 500, color: L.sub, font: textFam(o.tfont) });
  } });
  useClockFont(o.font, o.digits);
  const ampmOn = o.ampm && o.fmt !== '24' && !(o.fmt === 'system' && is24System());
  const th = C.h * (nx ? .7 : .86), ty = C.y + (nx ? 0 : C.h * .07);
  addLive(LY, { kind: 'time', font: o.font, digits: o.digits, mode: o.fmt, color: tc, tz: o.tz, lang: o.lang, lead: o.lead, grad: o.gradient || '', x: tx + (ampmOn ? tw * .14 : 0), y: ty, w: tw * (ampmOn ? .86 : 1), h: th });
  if (ampmOn) addLive(LY, { kind: 'ampm', font: 'medium', digits: o.digits, mode: o.fmt, color: L_subOf(d), tz: o.tz, lang: o.lang, x: tx, y: ty + th * .45, w: tw * .14, h: th * .35, size: th * .22, align: 'left' });
  const alarmTap = o.alarmTap || 'clockApp';
  LY.hits.push({ x: bcx - bd / 2, y: bcy - bd / 2, w: bd, h: bd, act: 'tap', tap: alarmTap === 'appAlarms' ? { k: 'open', v: 'alarms' } : { k: alarmTap, v: '' } });
  LY.hits.push({ x: bx, y: by, w: bw, h: bh, act: 'tap', tap: { k: 'calendarApp', v: '' } });
  const k = o.tap || 'clockApp';
  if (k !== 'none') LY.hits.push({ x: tx, y: C.y, w: tw, h: C.h, act: 'tap', tap: k === 'studio' ? { k: 'open', v: 'time' } : k === 'appAlarms' ? { k: 'open', v: 'alarms' } : { k, v: '' } });
}
function layCombo(d, LY, C, now, o) {
  const B = LY.B, lines = timeLines(d, now, 2), tc = o.timeColor || L_textOf(d);
  let R, cx, cy, box;
  if (C.w >= C.h * 1.25) { R = C.h / 2; cx = C.x + C.w - R; cy = C.y + R; box = { x: C.x, y: C.y, w: C.w - 2 * R - C.h * .1, h: C.h }; }
  else { R = Math.min(C.w, C.h * .6) / 2; cx = C.x + C.w / 2; cy = C.y + R; box = { x: C.x, y: C.y + 2 * R + C.h * .03, w: C.w, h: C.h - 2 * R - C.h * .03 }; }
  LY.nodes.push({ k: 'draw', fn: (ctx, S, L) => paintAnalogFace(ctx, S, L, cx, cy, R, o) });
  addLive(LY, { kind: 'analog', cx, cy, R: R * (1 - ({ goldMulti: .16, gold: .09, woodDark: .15, velvet3d: .17, chrome: .1, silver: .08, glass: .1, marble: .14, thin: .025, none: 0 }[o.bezel] ?? .1) * (o.bezelW ?? 100) / 100), o: Object.assign({}, o), tz: o.tz, x: cx - R, y: cy - R, w: 2 * R, h: 2 * R });
  useClockFont(o.font, o.digits);
  const th = box.h * (lines.length ? .58 : .8), ty = box.y + (lines.length ? 0 : box.h * .1);
  addLive(LY, { kind: 'time', font: o.font, digits: o.digits, mode: o.fmt, color: tc, tz: o.tz, lang: o.lang, lead: o.lead, grad: o.gradient || '', x: box.x, y: ty, w: box.w, h: th });
  if (lines.length) LY.nodes.push({ k: 'draw', fn: (ctx, S, L) => drawInfoLines(ctx, S, L, lines, box.x, ty + th, box.w, box.h - th, o, 'center') });
  tapHit(LY, d, B);
}
/** Countdown to the next alarm as a live element (Chronometer on the home screen). */
function addCountdown(LY, d, o, x, y, w, h) {
  if (!o.countdown || !NEXT_ALARM || !(NEXT_ALARM.at > Date.now())) return;
  LY.live.push({ kind: 'chrono', at: NEXT_ALARM.at, x, y, w, h, size: h * .7, color: o.timeColor || L_subOf(d), lang: o.lang, digits: o.digits });
}

/* ---------------------------------------------------------- live painting (preview) */
function paintLiveFx(ctx, S, L, el, now, d, mode) {
  const lv = mode.bake ? (mode.alert || 0) : alertLevel();
  if (el.kind === 'pendulum') {
    let ang = 0;
    if (mode.phase != null) ang = pendParams(el.o, lv).A * Math.sin(mode.phase * TAU);
    else if (el.swing && !mode.bake) ang = matchMedia('(prefers-reduced-motion: reduce)').matches ? 0 : pendAngle((mode.key || '') + '|' + Math.round(el.x), el.o, lv, performance.now());
    paintPendulumWin(ctx, S, L, el, ang, lv);
    return true;
  }
  if (el.kind === 'chrono') {
    const ms = el.at - now.getTime(); if (ms <= 0) return true;
    const s = Math.floor(ms / 1000), str = toDigits(`${Math.floor(s / 3600)}:${pad2(Math.floor(s / 60) % 60)}:${pad2(s % 60)}`, el.digits);
    fillText(ctx, (el.lang === 'en' ? '⏰ ' : '⏰ ') + str, el.x + el.w / 2, el.y + el.h / 2, el.w, { size: el.size, weight: 600, color: el.color, dir: 'ltr' });
    return true;
  }
  return false;
}
/** Overlays drawn on top of an analog face while animating (glass glint, light pulse, alarm ring). */
function paintAnalogFx(ctx, S, L, el, tms, lv) {
  const o = el.o, m = o.motion || 'classic', { cx, cy, R } = el;
  if (m === 'glass') {
    const p = ((tms / 4200) % 1) * 2.4 - .7;
    ctx.save(); ctx.beginPath(); ctx.arc(cx, cy, R, 0, TAU); ctx.clip();
    const x0 = cx - R + p * 2 * R;
    ctx.fillStyle = linGrad(ctx, x0 - R * .4, cy - R, x0 + R * .4, cy + R, [[0, 'rgba(255,255,255,0)'], [.5, 'rgba(255,255,255,.22)'], [1, 'rgba(255,255,255,0)']]);
    ctx.fillRect(cx - R, cy - R, 2 * R, 2 * R); ctx.restore();
  }
  if ((m === 'pulse' && lv > 0) || (lv > 0 && o.alarmFx !== false)) {
    const c = L.a.lightColor || '#ffd98a', k = lv * (.6 + .4 * Math.sin(tms / 160));
    ctx.save(); ctx.beginPath(); ctx.arc(cx, cy, R * (1.01 + .03 * k), 0, TAU); ctx.lineWidth = R * .04; ctx.strokeStyle = rgba(c, .8 * k); ctx.shadowColor = rgba(c, k); ctx.shadowBlur = R * .25 * S; ctx.stroke(); ctx.restore();
  }
}
/** Does this layout need continuous animation in the preview? */
function needsAnim(LY, d) {
  if (LY.anim) return true;
  if (!LY.live || !LY.live.length) return false;
  const o = d.clock || {};
  if (d.type === 'clock' && o.alarmFx !== false && alertMaybe()) return true;
  return LY.live.some(el => el.kind === 'chrono' || (el.kind === 'analog' && (['glass', 'lightHands', 'pulse'].includes(el.o.motion) || (el.o.seconds && ['smooth', 'mechanical'].includes(el.o.motion)))));
}

/* ---------------------------------------------------------- animation loop (one rAF for all previews) */
const ANIMS = new Set();
let animRAF = 0, animLast = 0;
function animLoop(t) {
  animRAF = 0;
  if (t - animLast >= 30) { // ~33 fps is plenty for a widget preview
    animLast = t;
    const vh = innerHeight, vw = innerWidth;
    for (const w of ANIMS) {
      if (!w.isConnected) { ANIMS.delete(w); continue; }
      const r = w.getBoundingClientRect();
      if (r.bottom < 0 || r.top > vh || r.right < 0 || r.left > vw || !r.width) continue;
      try { w._frame(t); } catch (e) { ANIMS.delete(w); }
    }
  }
  if (ANIMS.size) animRAF = requestAnimationFrame(animLoop);
}
function animAdd(w) { ANIMS.add(w); if (!animRAF) animRAF = requestAnimationFrame(animLoop); }

/* ---------------------------------------------------------- bake helpers (home screen) */
/** Pendulum loops for Android: PEND_N frames of the window (normal and ringing). */
function bakePendulum(d, L, el, scale) {
  const fr = (lv) => {
    const out = [];
    for (let i = 0; i < PEND_N; i++) {
      const c = document.createElement('canvas'); c.width = Math.max(2, Math.round(el.w * scale)); c.height = Math.max(2, Math.round(el.h * scale));
      const g = c.getContext('2d'); g.scale(scale, scale); g.translate(-el.x, -el.y);
      const A = pendParams(el.o, lv).A;
      paintPendulumWin(g, scale, L, el, A * Math.sin(i / PEND_N * TAU), lv);
      out.push(c.toDataURL('image/webp', .86).startsWith('data:image/webp') ? c.toDataURL('image/webp', .86) : c.toDataURL('image/png'));
    }
    return out;
  };
  const r1 = v => Math.round(v * 10) / 10;
  const o = el.o, res = { k: 'pendulum', x: r1(el.x), y: r1(el.y), w: r1(el.w), h: r1(el.h), n: PEND_N,
    ms: Math.round(pendParams(o, 0).P / PEND_N), ams: Math.round(pendParams(o, 1).P / PEND_N), swing: !!el.swing,
    geo: { px: r1(el.px - el.x), py: r1(el.py - el.y), len: r1(el.len), bob: r1(el.bob), r: r1(el.r), rod: o.rod || '#d4af37', inner: o.inner || '#120a05', light: L.a.lightColor || '#ffd98a', swing: o.swing ?? 10, speed: o.speed || 100, motion: o.motion || 'pendulum' } };
  if (el.swing) res.pf = fr(0);
  if (o.alarmFx !== false) res.pa = fr(1);
  return res;
}
