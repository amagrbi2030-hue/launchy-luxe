/* =========================================================
   Ready-made time designs (the "show all styles" gallery).
   Each preset is a complete design: type, style, material,
   frame, colours, size and the clock/date/weather settings.
   ========================================================= */
const TIME_COLLS = [
  ['classic', 'كلاسيكية', 'clock'], ['plush', 'مخملية ثلاثية الأبعاد', 'clock'], ['royal', 'الذهب الملكي', 'clock'], ['glass', 'الزجاج السائل', 'clock'],
  ['digital', 'رقمية', 'clock'], ['info', 'ساعات معلوماتية', 'clock'],
  ['pendulums', 'ساعات البندول التفاعلية', 'clock'], ['interactive', 'ساعات تفاعلية وزجاجية', 'clock'], ['library', 'مكتبة الخامات والأنماط', 'clock'], ['dates', 'التاريخ', 'date'], ['weathers', 'الطقس', 'weather']
];
const TP = (k, n, coll, type, style, theme, size, o = {}) => Object.assign({ k, n, coll, type, style, theme, size }, o);
const VELVET = (k, n, theme, shape, size, extra = {}) => TP(k, n, 'plush', 'clock', 'plush3d', theme, size, {
  a: { mat: 'velvet', matTint: true, frame: 'none', fx: fxOf({ soft: 55, elev: 60, emboss: 35, inner: 0 }), radius: 40 },
  clock: Object.assign({ shape, dial: 'material', dialMat: 'velvet', bezel: 'velvet3d', numerals: 'western', numFont: 'medium', indices: 'dots', hands: 'baton', handColor: 'white', raised: true, ticks: false, date: 'none', weekday: false }, extra) });
/** A clock preset built on a material pack (pack first, then the preset's own touches). */
const PK = (k, n, coll, pack, style, size, o = {}) => {
  const p = CLOCK_PACK[pack], a = Object.assign(clone(p.a), o.a || {}); if (a.fx && !o.a?.fx) a.fx = fxOf(a.fx);
  return TP(k, n, coll, 'clock', style, p.theme, size, { a, clock: Object.assign({ pack }, clone(p.c), o.clock || {}) });
};
const CLOCK_HOME_P = 'pendBrown';
const TIME_PRESETS = [
  // ---- pendulum clocks (interactive: swing in the app, frame loop on the home screen, faster while ringing)
  PK('pendBrown', 'بندول بني زجاجي فاخر', 'pendulums', 'brownLux', 'leather', [2, 3], { a: { radius: 30, fx: fxOf({ soft: 60, reflect: 35, edge: 30 }) }, clock: { face: 'pendulum', font: 'medium', fmt: '24', weekday: true, date: 'none', motion: 'pendulum', timeColor: '#f6ead2', swing: 10 } }),
  PK('pendGold', 'بندول ذهبي ملكي بميناء روماني', 'pendulums', 'royalGold', 'royalGold', [2, 4], { clock: { face: 'pendulum', pendFace: 'analog', numerals: 'roman', hands: 'royal', indices: 'none', motion: 'slowLux', weekday: true, date: 'hijri', ornaments: true } }),
  PK('pendMidnight', 'بندول طولي ليلي مع العد التنازلي', 'pendulums', 'midnight', 'midnight', [2, 4], { clock: { face: 'pendulum', font: 'thin', weekday: true, date: 'greg', nextAlarm: true, countdown: true, motion: 'pendulum', timeColor: '#eef2f8' } }),
  PK('pendEmerald', 'بندول زجاج زمردي يتسارع مع المنبه', 'pendulums', 'emeraldGlass', 'holo', [2, 3], { clock: { face: 'pendulum', font: 'light', weekday: true, date: 'none', motion: 'fastAlarm', timeColor: '#ffffff' } }),
  PK('pendPurple', 'بندول زجاجي بنفسجي', 'pendulums', 'purpleGlass', 'holo', [2, 3], { clock: { face: 'pendulum', font: 'light', weekday: true, date: 'none', motion: 'pendulum', timeColor: '#ffffff', nextAlarm: true } }),
  PK('pendBronze', 'بندول برونزي عتيق', 'pendulums', 'bronze', 'bronze', [2, 4], { clock: { face: 'pendulum', pendFace: 'analog', numerals: 'arabic', numFont: 'serif', hands: 'spade', indices: 'none', motion: 'slowLux', weekday: true, date: 'none' } }),
  // ---- glass & interactive
  PK('pillGlass', 'كبسولة زجاجية بزر المنبه', 'interactive', 'liquidGlass', 'glass', [4, 1], { a: { mat: 'glassFrosted', matTint: true }, clock: { face: 'pill', font: 'light', fmt: '24', nextAlarm: true, timeColor: '#ffffff', lang: 'en' } }),
  PK('pillGold', 'كبسولة ذهبية فاخرة', 'interactive', 'royalGold', 'royalGold', [4, 1], { a: { frame: 'goldDouble' }, clock: { face: 'pill', font: 'serif', nextAlarm: true } }),
  PK('squirclePurple', 'مربع زجاجي بنفسجي بنقاط', 'interactive', 'purpleGlass', 'holo', [2, 2], { a: { radius: 60 }, clock: { face: 'analog', shape: 'rounded', numerals: 'none', indices: 'dots', hands: 'modern', motion: 'glass', bezel: 'none', date: 'none', weekday: false } }),
  PK('comboLux', 'رقمية + عقارب فاخرة', 'interactive', 'champagne', 'champagne', [4, 2], { clock: { face: 'combo', font: 'light', numerals: 'roman', hands: 'dauphine', indices: 'bars', weekday: true, date: 'both', nextAlarm: true } }),
  PK('luxDigital', 'رقمية فاخرة بتدرج ذهبي', 'interactive', 'midnight', 'midnight', [4, 2], { clock: { face: 'digital', layout: 'stack', font: 'xlight', timeColor: '#f6e3b0', gradient: '#b8862e', weekday: true, date: 'both', nextAlarm: true } }),
  PK('luxuryGlass', 'Luxury Glass بعقرب ناعم', 'interactive', 'liquidGlass', 'holo', [2, 2], { clock: { face: 'analog', shape: 'circle', numerals: 'indices', indices: 'lines', hands: 'geometric', seconds: true, secStyle: 'thin', secColor: '#9ef3ff', motion: 'smooth', date: 'none', weekday: false } }),
  PK('neonGlow', 'نيون متوهج', 'interactive', 'neon', 'neon', [2, 2], { clock: { face: 'analog', shape: 'circle', numerals: 'cardinal', numFont: 'thin', indices: 'dots', hands: 'baton', motion: 'lightHands', date: 'none', weekday: false } }),
  PK('velvetPulse', 'مخمل نابض عند المنبه', 'interactive', 'velvet', 'plush3d', [2, 2], { clock: { face: 'analog', shape: 'circle', numerals: 'western', numFont: 'medium', indices: 'dots', hands: 'baton', motion: 'pulse', date: 'none', weekday: false } }),
  // ---- the material & style library
  PK('libClassicRound', 'دائرية كلاسيكية', 'library', 'royalGold', 'royalGold', [2, 2], { a: { frame: 'none' }, clock: { shape: 'circle', numerals: 'roman', hands: 'breguet', handColor: 'black', indices: 'none', date: 'none', weekday: false, motion: 'classic', seconds: true, secStyle: 'lollipop' } }),
  PK('libTallRect', 'مستطيلة طولية مع التاريخ', 'library', 'champagne', 'champagne', [2, 3], { clock: { shape: 'rect', numerals: 'roman', hands: 'breguet', indices: 'none', date: 'both', weekday: true } }),
  PK('libSilver', 'فضية', 'library', 'midnight', 'carbon', [2, 2], { a: { frame: 'none' }, clock: { shape: 'circle', bezel: 'silver', dial: 'white', handColor: 'black', numerals: 'indices', indices: 'bars', hands: 'baton', seconds: true, secColor: '#c0392b', motion: 'smooth', date: 'none', weekday: false } }),
  PK('libMarble', 'رخامية ملكية', 'library', 'marble', 'marble', [2, 2], { clock: { shape: 'circle', numerals: 'roman', hands: 'breguet', indices: 'none', date: 'none', weekday: false } }),
  PK('libBronze', 'نحاسية عتيقة ميكانيكية', 'library', 'bronze', 'bronze', [2, 2], { clock: { shape: 'circle', numerals: 'arabic', numFont: 'serif', hands: 'spade', indices: 'none', seconds: true, motion: 'mechanical', cap: 'jewel', date: 'none', weekday: false } }),
  PK('libCrystal', 'كريستالية', 'library', 'crystal', 'crystal', [2, 2], { clock: { shape: 'circle', numerals: 'indices', indices: 'diamonds', hands: 'dauphine', motion: 'glass', date: 'none', weekday: false } }),
  PK('libIslamic', 'بإطار هندسي إسلامي', 'library', 'royalGold', 'heritage', [3, 3], { a: { frame: 'islamicGeo', frameColor: '#d4af37' }, clock: { shape: 'rounded', numerals: 'arabic', numFont: 'serif', hands: 'royal', indices: 'none', ornaments: true, date: 'hijri', weekday: true, cap: 'star' } }),
  PK('libMinimal', 'بسيطة', 'library', 'midnight', 'minimal', [2, 2], { a: { mat: 'none', frame: 'none' }, clock: { shape: 'circle', bezel: 'thin', dial: 'white', handColor: 'black', numerals: 'none', indices: 'lines', hands: 'baton', cap: 'flat', date: 'none', weekday: false } }),
  PK('libVelvet', 'مخملية', 'library', 'velvet', 'plush3d', [2, 2], { clock: { shape: 'rounded', numerals: 'arabic', numFont: 'medium', indices: 'dots', hands: 'baton', date: 'none', weekday: false } }),

  // ---- classic
  TP('romanIvory', 'رومانية عاجية بإطار ذهبي', 'classic', 'clock', 'royalGold', 'brown', [2, 2], { a: { mat: 'walnut', frame: 'none', radius: 40 }, clock: { shape: 'circle', dial: 'ivory', bezel: 'goldMulti', numerals: 'roman', hands: 'breguet', handColor: 'black', indices: 'none', date: 'none', weekday: false } }),
  TP('arabicBrown', 'أرقام عربية بإطار بني داكن', 'classic', 'clock', 'leather', 'brown', [2, 2], { a: { mat: 'darkWood', frame: 'none' }, clock: { shape: 'circle', dial: 'ivory', bezel: 'woodDark', numerals: 'arabic', numFont: 'serif', hands: 'spade', handColor: 'black', indices: 'none', date: 'none', weekday: false } }),
  TP('goldIndices', 'مؤشرات ذهبية على أسود', 'classic', 'clock', 'royalGold', 'onyx', [2, 2], { a: { mat: 'velvet', matTint: false, frame: 'none' }, clock: { shape: 'circle', dial: 'black', bezel: 'gold', numerals: 'indices', indices: 'bars', hands: 'dauphine', handColor: 'gold', date: 'none', weekday: false } }),
  TP('swiss', 'مستوحاة من الساعات السويسرية', 'classic', 'clock', 'minimal', 'graphite', [2, 2], { a: { frame: 'none', mat: 'none' }, clock: { shape: 'circle', dial: 'white', bezel: 'chrome', numerals: 'indices', indices: 'lines', hands: 'baton', handColor: 'black', seconds: true, secColor: '#d0312d', date: 'none', weekday: false } }),
  TP('classicSquare', 'كلاسيكية مربعة بالجلد', 'classic', 'clock', 'leather', 'brown', [2, 2], { a: { mat: 'leatherEmb', frame: 'stitched', radius: 26 }, clock: { shape: 'rounded', dial: 'ivory', bezel: 'gold', numerals: 'roman', hands: 'breguet', handColor: 'gold', indices: 'none', date: 'none', weekday: false } }),
  TP('classicBlue', 'ميناء أزرق بأشعة شمسية', 'classic', 'clock', 'sapphire', 'navy', [2, 2], { a: { frame: 'none' }, clock: { shape: 'circle', dial: 'sunburst', dialColor: '#1d3b7a', bezel: 'silver', numerals: 'indices', indices: 'bars', hands: 'dauphine', handColor: 'silver', date: 'none', weekday: false } }),
  // ---- plush velvet
  VELVET('plushBlack', 'مخمل أسود دائري', 'onyx', 'circle', [2, 2]),
  VELVET('plushNavy', 'مخمل كحلي مربع', 'navy', 'rounded', [2, 2], { handColor: 'gold', numerals: 'arabic', numFont: 'medium' }),
  VELVET('plushOlive', 'مخمل زيتوني', 'olive', 'circle', [2, 2], { handColor: 'gold', indices: 'bars', numerals: 'indices' }),
  VELVET('plushBrown', 'مخمل بني مع التاريخ', 'brown', 'rect', [4, 2], { handColor: 'gold', date: 'both', weekday: true, tfont: 'messiri' }),
  VELVET('plushGrey', 'مخمل رمادي ناعم', 'graphite', 'rounded', [2, 2], { numerals: 'cardinal', numFont: 'light' }),
  VELVET('plushMidnightBig', 'مخمل منتصف الليل الكبير', 'navy', 'circle', [3, 3], { numerals: 'roman', numFont: 'royal', handColor: 'silver', hands: 'breguet' }),
  // ---- royal gold
  TP('royalSmall', 'الذهب الملكي الصغير', 'royal', 'clock', 'royalGold', 'brown', [2, 2], { a: { mat: 'leather', frame: 'none' }, clock: { shape: 'circle', dial: 'ivory', bezel: 'goldMulti', numerals: 'roman', hands: 'royal', handColor: 'gold', ornaments: true, indices: 'none', date: 'none', weekday: false } }),
  TP('royalLarge', 'الذهب الملكي الكبير', 'royal', 'clock', 'royalGold', 'brown', [4, 4], { a: { mat: 'leather', frame: 'royalGold', frameColor: '#d4af37' }, clock: { shape: 'rounded', dial: 'ivory', bezel: 'goldMulti', numerals: 'roman', hands: 'royal', handColor: 'brown', ornaments: true, indices: 'diamonds', date: 'both', weekday: true, tfont: 'amiri' } }),
  TP('royalWide', 'الذهب الملكي الأفقي', 'royal', 'clock', 'royalGold', 'brown', [4, 2], { a: { mat: 'leather', frame: 'goldDouble', frameColor: '#d4af37' }, clock: { shape: 'rect', dial: 'ivory', bezel: 'goldMulti', numerals: 'roman', hands: 'royal', handColor: 'gold', ornaments: true, indices: 'none', date: 'both', weekday: true, tfont: 'amiri' } }),
  // ---- liquid glass
  TP('glassBlue', 'زجاج سائل أزرق', 'glass', 'clock', 'holo', 'royal', [2, 2], { a: { mat: 'glassLiquid', matTint: true, frame: 'none', fx: fxOf({ soft: 40, reflect: 60, edge: 55 }), lightColor: '#9ef3ff' }, clock: { shape: 'circle', dial: 'glass', bezel: 'glass', numerals: 'indices', indices: 'lines', hands: 'modern', handColor: 'white', glowHands: '#9ef3ff', ink: '#ffffff', date: 'none', weekday: false } }),
  TP('glassPurple', 'زجاج سائل بنفسجي', 'glass', 'clock', 'holo', 'purple', [2, 2], { a: { mat: 'glassLiquid', matTint: true, frame: 'none', fx: fxOf({ soft: 40, reflect: 60, edge: 55 }), lightColor: '#d6b8ff' }, clock: { shape: 'rounded', dial: 'glass', bezel: 'glass', numerals: 'cardinal', numFont: 'thin', indices: 'dots', hands: 'modern', handColor: 'white', glowHands: '#d6b8ff', ink: '#ffffff', date: 'none', weekday: false } }),
  TP('glassDigital', 'زجاج سائل رقمي', 'glass', 'clock', 'holo', 'lavender', [4, 2], { a: { mat: 'glassLiquid', matTint: true, frame: 'gradientGlow', fx: fxOf({ soft: 40, reflect: 55, edge: 50 }) }, clock: { face: 'digital', layout: 'stack', font: 'thin', timeColor: '#ffffff', date: 'both', weekday: true } }),
  // ---- digital
  TP('digitalBig', 'أرقام كبيرة', 'digital', 'clock', 'amoled', 'onyx', [2, 2], { a: { frame: 'none' }, clock: { face: 'digital', layout: 'big', font: 'black', timeColor: '#ffffff', date: 'none', weekday: true } }),
  TP('digitalLed', 'شاشة LED', 'digital', 'clock', 'amoled', 'coral', [4, 1], { a: { frame: 'none', radius: 18 }, clock: { face: 'digital', layout: 'led', timeColor: '#ff4d3a', glow: 70, date: 'none', weekday: false } }),
  TP('digitalMinimal', 'بسيطة', 'digital', 'clock', 'minimal', 'royal', [4, 1], { clock: { face: 'digital', layout: 'minimal', font: 'light', date: 'hijri', weekday: true } }),
  TP('digitalGradient', 'أرقام متدرجة', 'digital', 'clock', 'midnight', 'navy', [4, 2], { a: { frame: 'none' }, clock: { face: 'digital', layout: 'stack', font: 'bold', timeColor: '#00d2ff', gradient: '#a26bff', date: 'both', weekday: true } }),
  TP('digitalFlip', 'الساعة القلابة', 'digital', 'clock', 'carbon', 'graphite', [4, 2], { a: { frame: 'none' }, clock: { face: 'digital', layout: 'flip', font: 'bold', date: 'greg', weekday: true } }),
  TP('digital24', 'رقمية 24 ساعة مع التاريخ', 'digital', 'clock', 'glass', 'emerald', [4, 2], { clock: { face: 'digital', layout: 'stack', font: 'medium', fmt: '24', date: 'both', weekday: true } }),
  // ---- info clocks
  TP('infoAnalog', 'عقارب مع التاريخين', 'info', 'clock', 'champagne', 'gold', [4, 2], { a: { frame: 'goldDouble' }, clock: { shape: 'rect', dial: 'white', bezel: 'gold', numerals: 'indices', indices: 'bars', hands: 'dauphine', handColor: 'gold', date: 'both', weekday: true } }),
  TP('infoWorld', 'ساعة عالمية مع المدينة', 'info', 'clock', 'glass', 'royal', [4, 2], { clock: { face: 'digital', layout: 'side', font: 'light', tz: 'Europe/London', tzName: 'لندن', city: true, date: 'greg', weekday: true } }),
  TP('infoPhrase', 'ساعة مع عبارة يومية', 'info', 'clock', 'heritage', 'turquoise', [4, 3], { clock: { face: 'digital', layout: 'stack', font: 'royal', date: 'hijri', weekday: true, phrase: true } }),
  TP('infoWeather', 'عقارب مع الطقس', 'info', 'clock', 'midnight', 'navy', [4, 2], { a: { frame: 'silverF' }, clock: { shape: 'rect', dial: 'black', bezel: 'silver', numerals: 'indices', indices: 'dots', hands: 'sword', handColor: 'silver', date: 'hijri', weekday: true, wx: true } }),
  // ---- dates
  TP('dateDual', 'بطاقة التاريخ المزدوج', 'dates', 'date', 'royalGold', 'gold', [2, 2], { date: { variant: 'dual' } }),
  TP('dateDualWide', 'التاريخ المزدوج الأفقي', 'dates', 'date', 'champagne', 'gold', [4, 2], { date: { variant: 'dual', tfont: 'messiri' } }),
  TP('dateCalendar', 'التقويم الهجري الفاخر', 'dates', 'date', 'midnight', 'navy', [4, 4], { date: { variant: 'calendar', primary: 'hijri', tfont: 'plex', numFont: 'medium' } }),
  TP('dateCalGreg', 'التقويم الميلادي بالمناسبات', 'dates', 'date', 'pearl', 'lavender', [4, 3], { date: { variant: 'calendar', primary: 'greg', tfont: 'plex', numFont: 'medium' } }),
  TP('dateMini', 'التاريخ المصغر', 'dates', 'date', 'glass', 'emerald', [2, 1], { date: { variant: 'mini', tfont: 'plex', numFont: 'light' } }),
  TP('dateMiniSq', 'التاريخ المصغر المربع', 'dates', 'date', 'quiet', 'gold', [1, 1], { date: { variant: 'mini', numFont: 'royal' } }),
  TP('dateBig', 'التاريخ الكبير مع عبارة', 'dates', 'date', 'marble', 'gold', [2, 3], { date: { variant: 'big', numFont: 'royal' } }),
  TP('dateBigWide', 'التاريخ الكبير الأفقي', 'dates', 'date', 'heritage', 'turquoise', [4, 2], { date: { variant: 'big', numFont: 'serif' } }),
  TP('dateCombo', 'الساعة والتاريخ', 'dates', 'date', 'obsidian', 'onyx', [4, 2], { date: { variant: 'combo', font: 'thin', tfont: 'plex' } }),
  TP('dateIslamic', 'التاريخ الإسلامي المزخرف', 'dates', 'date', 'emerald', 'emerald', [2, 3], { date: { variant: 'islamic', tfont: 'amiri', numFont: 'serif' } }),
  TP('dateIslamicRoyal', 'التاريخ الإسلامي الملكي', 'dates', 'date', 'royalOrn', 'navy', [3, 3], { date: { variant: 'islamic', tfont: 'amiri', numFont: 'royal' } }),
  // ---- weather
  TP('wxMedium', 'الطقس المتوسط — القمة الخضراء', 'weathers', 'weather', 'glass', 'royal', [4, 2], { a: { frame: 'none' }, weather: { variant: 'medium', bg: { mode: 'weather', scene: 'greenPeak' } } }),
  TP('wxMini', 'الطقس المصغر', 'weathers', 'weather', 'glass', 'sky', [2, 2], { a: { frame: 'none' }, weather: { variant: 'mini', bg: { mode: 'weather', scene: 'mountainStream' } } }),
  TP('wxLarge', 'الطقس الكبير بالتفاصيل', 'weathers', 'weather', 'glass', 'royal', [4, 4], { a: { frame: 'none' }, weather: { variant: 'large', bg: { mode: 'weather', scene: 'lakeHouse', overlayAmt: 40 } } }),
  TP('wxPanorama', 'بانورامي — غروب الساحل', 'weathers', 'weather', 'glass', 'turquoise', [4, 2], { a: { frame: 'none' }, weather: { variant: 'panorama', bg: { mode: 'fixed', scene: 'coastSunset' } } }),
  TP('wxRound', 'دائري بحلقة الحرارة', 'weathers', 'weather', 'holo', 'royal', [2, 2], { a: { mat: 'glassLiquid', matTint: true, frame: 'none' }, weather: { variant: 'round', bg: { mode: 'none' } } }),
  TP('wxRice', 'حقول الأرز الذهبية', 'weathers', 'weather', 'royalGold', 'gold', [4, 2], { a: { frame: 'goldDouble', frameColor: '#d4af37' }, weather: { variant: 'medium', bg: { mode: 'fixed', scene: 'riceFields' }, tfont: 'messiri' } }),
  TP('wxFalls', 'وادي الشلالات', 'weathers', 'weather', 'glass', 'turquoise', [4, 2], { a: { frame: 'none' }, weather: { variant: 'panorama', bg: { mode: 'fixed', scene: 'fallsValley' } } }),
  TP('wxRotate', 'تبديل بين مشاهدي المفضلة', 'weathers', 'weather', 'glass', 'royal', [4, 3], { a: { frame: 'none' }, weather: { variant: 'large', bg: { mode: 'rotate', every: 'update' } } }),
  TP('wxGolden', 'القمة الذهبية', 'weathers', 'weather', 'midnight', 'navy', [4, 2], { a: { frame: 'silverF' }, weather: { variant: 'medium', bg: { mode: 'fixed', scene: 'goldenPeak' } } }),
  TP('wxGlassPlain', 'طقس زجاجي بلا صورة', 'weathers', 'weather', 'glass', 'royal', [4, 2], { weather: { variant: 'medium', iconStyle: 'mono', bg: { mode: 'none' } } })
];
const TIME_PRESET = Object.fromEntries(TIME_PRESETS.map(p => [p.k, p]));
/** A complete design from a preset (content-free, ready to edit and save). */
function presetDesign(p, base) {
  if (typeof p === 'string') p = TIME_PRESET[p];
  const d = newDesign({ type: p.type, style: p.style, theme: p.theme });
  Object.assign(d.a, styleLook(p.style));
  if (p.a) { const fx = p.a.fx; Object.assign(d.a, clone(p.a)); if (fx) d.a.fx = Object.assign(defaultFx(), fx); }
  d.sizes[p.type] = p.size.slice();
  for (const k of ['clock', 'date']) if (p[k]) Object.assign(d[k], clone(p[k]));
  if (p.weather) { const w = clone(p.weather); Object.assign(d.weather, w, { show: Object.assign(d.weather.show, w.show || {}), bg: Object.assign(d.weather.bg, w.bg || {}) }); }
  if (base) { // keep the user's own data choices (location, language, calendar…)
    if (base.weather && p.type === 'weather') { d.weather.loc = clone(base.weather.loc); d.weather.unit = base.weather.unit; }
    for (const k of ['lang', 'digits', 'calc', 'offset']) { if (base[p.type] && base[p.type][k] != null) d[p.type][k] = base[p.type][k]; }
  }
  d.name = p.n; d.preset = p.k;
  return normalize(d);
}
