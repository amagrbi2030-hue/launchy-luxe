/* =========================================================
   Internal app shortcuts («اختصارات التطبيقات الداخلية»)
   and the Smart App Collections widget type.
   Shortcuts come only from what Android really exposes to this
   app (see AppShortcuts.kt); nothing here invents a shortcut.
   ========================================================= */
KIND.ishort = { n: 'اختصار داخلي', g: 'link', lab: 'الاختصار', ph: '', mode: 'text' };
Object.assign(TYPES, {
  collections: { n: 'مجموعات التطبيقات الذكية', en: 'Smart App Collections', short: 'مجموعات', g: 'layers',
    sizes: [[2, 2], [3, 2], [4, 2], [2, 3], [3, 3], [4, 3], [2, 4], [3, 4], [4, 4], [4, 5], [4, 6], [4, 1]],
    desc: 'اختصارات داخلية من تطبيقاتك (البحث، Shorts، علامة تبويب خاصة…) في بطاقات فاخرة، تطبيق واحد أو عدة تطبيقات.' }
});
GP.search = 'M 4 11 A 7 7 0 1 0 18 11 A 7 7 0 1 0 4 11 Z M 16.2 16.2 L 21 21';
G.search = '<circle cx="11" cy="11" r="7"/><path d="M16.2 16.2 21 21"/>';

const COLL_LAYOUTS = [
  ['grid', 'شبكة مربعة'], ['circles', 'شبكة دائرية'], ['radial', 'توزيع دائري حول المركز'], ['hex', 'شبكة سداسية'],
  ['rect', 'تخطيط مستطيل'], ['row', 'تخطيط أفقي'], ['column', 'تخطيط عمودي'], ['cards', 'بطاقات صغيرة متجاورة'],
  ['list', 'قائمة اختصارات رأسية'], ['ring', 'داخل إطار دائري كبير']];
const CHIP_STYLES = [
  ['auto', 'حسب النمط'], ['circle', 'داخل دوائر'], ['glass', 'مربعات زجاجية'], ['velvet', 'بطاقات مخملية'], ['gold', 'إطارات ذهبية'],
  ['glow', 'دائرية متوهجة'], ['wide', 'داخل مستطيل كبير'], ['hexagon', 'سداسية'], ['islamic', 'إطار زخرفي إسلامي'], ['plush', 'ثلاثية الأبعاد'], ['bare', 'الأيقونة فقط']];
const COLL_LOOKS = [
  { k: 'glass', n: 'Premium Glass', ar: 'الزجاج الفاخر', style: 'glass', theme: 'royal', chip: 'glass' },
  { k: 'quiet', n: 'Quiet Luxury', ar: 'الفخامة الهادئة', style: 'quiet', theme: 'gold', chip: 'auto' },
  { k: 'neon', n: 'Modern Neon', ar: 'النيون العصري', style: 'neon', theme: 'turquoise', chip: 'glow' },
  { k: 'royalGold', n: 'Royal Gold', ar: 'الذهب الملكي', style: 'royalGold', theme: 'gold', chip: 'gold' },
  { k: 'plush', n: 'Plush 3D', ar: 'المخمل ثلاثي الأبعاد', style: 'plush3d', theme: 'purple', chip: 'plush' },
  { k: 'emerald', n: 'Emerald Glow', ar: 'التوهج الزمردي', style: 'emerald', theme: 'emerald', chip: 'glow' },
  { k: 'midnight', n: 'Midnight Luxury', ar: 'فخامة منتصف الليل', style: 'midnight', theme: 'navy', chip: 'velvet' },
  { k: 'orn', n: 'Ornamental Frames', ar: 'الإطارات الزخرفية', style: 'royalOrn', theme: 'navy', chip: 'islamic', frame: 'islamicGeo' }];
const GROUP_BG = [['auto', 'تلقائي'], ['none', 'بدون'], ['soft', 'ناعمة'], ['tint', 'بلون المجموعة'], ['glass', 'زجاج'], ['dark', 'داكنة']];
const defaultCollections = () => ({ layout: 'grid', cols: 3, rows: 0, gap: 10, icon: 100, align: 'center', dir: 'rtl', labels: false, head: true, headSize: 100,
  chip: 'auto', tint: false, badge: false, flow: 'stack', descs: true, iconFill: 66, groups: [] });
const DEMO_INNER = [['الرئيسية', 'home'], ['Shorts', 'play'], ['الاشتراكات', 'video'], ['البحث', 'search'], ['المكتبة', 'bookmark'], ['حسابي', 'user']]
  .map(([label, g], i) => ({ id: 'dq' + i, kind: 'ishort', label, glyph: g, color: '#c4302b', value: '', emoji: '', photo: '', desc: 'معاينة' }));
const DEMO_GROUP = { id: '_demo', name: 'YouTube', glyph: 'play', color: '#c4302b', bg: 'auto' };

/* ---------------------------------------------------------- painting */
function chipFace(ctx, S, L, it, x, y, w, h, P, st, fill, dark) {
  const img = getImg(it.photo), m = Math.min(w, h);
  if (it.photo && img) {
    const s = st === 'bare' ? 1 : fill;
    if (it.fit === 'cover') { ctx.save(); ctx.clip(P); drawCover(ctx, img, x, y, w, h); ctx.restore(); }
    else drawContain(ctx, img, x + w * (1 - s) / 2, y + h * (1 - s) / 2, w * s, h * s);
    return;
  }
  const col = dark ? '#ffffff' : L.sp.tile.glyph;
  if (it.emoji) fillText(ctx, it.emoji, x + w / 2, y + h / 2 + 1, w, { size: m * .46, weight: 700, color: col, dir: 'ltr' });
  else paintGlyph(ctx, S, it.glyph || 'link', x + w / 2, y + h / 2, Math.max(11, m * .46), col, null);
}
/** One shortcut icon in the chosen chip style («داخل دوائر»، «زجاجية»، «مخملية»، «ذهبية»…). */
function paintChip(ctx, S, L, n) {
  const it = n.it, x = n.x, y = n.y, w = n.w, h = n.h, m = Math.min(w, h), k = m / 56;
  const base = n.color || it.color || L.A, st = n.style;
  let P, dark = false;
  ctx.save();
  if (n.dim) ctx.globalAlpha = .45;
  switch (st) {
    case 'bare': P = shapePath('circle', x, y, w, h); break;
    case 'glass': {
      P = shapePath(n.shape === 'circle' ? 'circle' : 'soft', x, y, w, h);
      outerShadow(ctx, S, P, 'rgba(0,0,0,.28)', 8 * k, 0, 3 * k);
      ctx.save(); ctx.fillStyle = linGrad(ctx, x, y, x + w, y + h, [[0, n.tint ? rgba(base, .42) : 'rgba(255,255,255,.30)'], [1, n.tint ? rgba(base, .14) : 'rgba(255,255,255,.07)']]); ctx.fill(P);
      ctx.clip(P); ctx.fillStyle = 'rgba(255,255,255,.16)'; ctx.beginPath(); ctx.ellipse(x + w * .5, y - h * .05, w * .7, h * .42, 0, 0, TAU); ctx.fill(); ctx.restore();
      ctx.save(); ctx.lineWidth = Math.max(1, 1.1 * k); ctx.strokeStyle = 'rgba(255,255,255,.5)'; ctx.stroke(P); ctx.restore();
      dark = true; break;
    }
    case 'velvet': {
      P = shapePath('soft', x, y, w, h);
      outerShadow(ctx, S, P, 'rgba(0,0,0,.42)', 9 * k, 0, 4 * k);
      ctx.save(); ctx.fillStyle = materialFill(ctx, 'velvet', n.tint ? base : L.A, Math.max(48, m * 1.6)); ctx.fill(P);
      ctx.fillStyle = linGrad(ctx, 0, y, 0, y + h, [[0, 'rgba(255,255,255,.18)'], [.5, 'rgba(255,255,255,0)'], [1, 'rgba(0,0,0,.25)']]); ctx.fill(P); ctx.restore();
      ctx.save(); ctx.setLineDash([2.2 * k, 2.2 * k]); ctx.lineWidth = Math.max(.8, k); ctx.strokeStyle = rgba(L.frameColor, .7); ctx.stroke(shapePath('soft', x + 3.5 * k, y + 3.5 * k, w - 7 * k, h - 7 * k)); ctx.restore();
      dark = true; break;
    }
    case 'gold': {
      P = tileSkin(ctx, S, L, x, y, w, h, n.shape || 'circle', it, n.tint);
      const r = shapePath(n.shape || 'circle', x + 1.2 * k, y + 1.2 * k, w - 2.4 * k, h - 2.4 * k);
      ctx.save(); ctx.lineWidth = Math.max(1.6, 2.8 * k); ctx.strokeStyle = linGrad(ctx, x, y, x + w, y + h, [[0, '#fff1b8'], [.3, '#d4af37'], [.55, '#8a6a1f'], [.8, '#f3d27a'], [1, '#a8822c']]); ctx.stroke(r);
      ctx.lineWidth = Math.max(.6, .8 * k); ctx.strokeStyle = 'rgba(255,240,190,.55)'; ctx.stroke(shapePath(n.shape || 'circle', x + 4.4 * k, y + 4.4 * k, w - 8.8 * k, h - 8.8 * k)); ctx.restore();
      dark = n.tint; break;
    }
    case 'glow': {
      P = shapePath('circle', x, y, w, h); const N = neonize(n.tint ? base : L.A);
      outerShadow(ctx, S, P, rgba(N, .85), 4 * k); outerShadow(ctx, S, P, rgba(N, .55), 12 * k);
      ctx.save(); ctx.fillStyle = 'rgba(8,10,14,.62)'; ctx.fill(P); ctx.lineWidth = Math.max(1.2, 1.8 * k); ctx.strokeStyle = N; ctx.stroke(P); ctx.restore();
      innerShadow(ctx, S, P, rgba(N, .55), 6 * k);
      dark = true; break;
    }
    case 'plush': {
      P = shapePath(n.shape === 'circle' ? 'circle' : 'soft', x, y, w, h);
      outerShadow(ctx, S, P, 'rgba(0,0,0,.38)', 10 * k, 0, 5 * k);
      const c = n.tint ? base : L.A;
      ctx.save(); const g = ctx.createRadialGradient(x + w * .32, y + h * .26, m * .05, x + w * .5, y + h * .5, m * .75);
      g.addColorStop(0, mix(c, '#ffffff', .42)); g.addColorStop(.55, c); g.addColorStop(1, mix(c, '#000000', .42));
      ctx.fillStyle = g; ctx.fill(P); ctx.restore();
      innerShadow(ctx, S, P, 'rgba(255,255,255,.35)', 3 * k, 0, 1.5 * k);
      dark = true; break;
    }
    case 'islamic': {
      const cx = x + w / 2, cy = y + h / 2; P = new Path2D(); star8(P, cx, cy, m / 2);
      outerShadow(ctx, S, P, 'rgba(0,0,0,.35)', 6 * k, 0, 2 * k);
      ctx.save(); ctx.fillStyle = n.tint ? linGrad(ctx, x, y, x + w, y + h, [[0, mix(base, '#ffffff', .1)], [1, mix(base, '#000000', .35)]]) : L.sp.tile.bg[0]; ctx.fill(P);
      ctx.lineWidth = Math.max(1.2, 1.6 * k); ctx.strokeStyle = L.frameColor; ctx.stroke(P);
      ctx.lineWidth = Math.max(.6, .8 * k); ctx.beginPath(); ctx.arc(cx, cy, m * .33, 0, TAU); ctx.stroke(); ctx.restore();
      dark = n.tint || !L.darkText; break;
    }
    case 'wide': case 'hexagon': case 'circle': case 'auto': default: {
      const shape = st === 'circle' ? 'circle' : st === 'hexagon' ? 'hexagon' : (n.shape || 'rounded');
      P = tileSkin(ctx, S, L, x, y, w, h, shape, it, n.tint);
      dark = n.tint;
    }
  }
  chipFace(ctx, S, L, it, x, y, w, h, P, st, n.fill || .66, dark);
  ctx.restore();
  if (n.badge && it.appIcon) {
    const img = getImg(it.appIcon), bs = Math.max(10, m * .36), bx = n.rtl === false ? x + w - bs * .8 : x - bs * .2, by = y + h - bs * .8;
    if (img) { const bp = shapePath('circle', bx, by, bs, bs); ctx.save(); outerShadow(ctx, S, bp, 'rgba(0,0,0,.35)', 3, 0, 1); ctx.fillStyle = '#ffffff'; ctx.fill(bp); ctx.clip(bp); drawContain(ctx, img, bx + bs * .1, by + bs * .1, bs * .8, bs * .8); ctx.restore(); }
  }
  if (n.label) fillText(ctx, it.label, n.label.x != null ? n.label.x : x + w / 2, n.label.y, n.label.w, { size: n.label.size, color: L.text, weight: 500, align: n.label.align });
}
function paintBigRing(ctx, S, L, n) {
  const P = new Path2D(); P.arc(n.cx, n.cy, n.r, 0, TAU);
  ctx.save(); ctx.fillStyle = surfaceColors(L).bg; ctx.fill(P);
  ctx.lineWidth = Math.max(1.4, n.r * .025); ctx.strokeStyle = linGrad(ctx, n.cx - n.r, n.cy - n.r, n.cx + n.r, n.cy + n.r, [[0, rgba(L.frameColor, .95)], [.5, rgba(L.frameColor, .45)], [1, rgba(L.frameColor, .95)]]); ctx.stroke(P);
  ctx.lineWidth = .8; ctx.strokeStyle = rgba(L.frameColor, .35); ctx.beginPath(); ctx.arc(n.cx, n.cy, n.r * .9, 0, TAU); ctx.stroke(); ctx.restore();
}

/* ---------------------------------------------------------- layout */
function collGroupsOf(d, items, demo) {
  if (demo) return [{ g: DEMO_GROUP, list: items }];
  const o = d.collections, byId = new Map(items.map(i => [i.id, i])), used = new Set();
  const gs = (o.groups || []).filter(g => g.show !== false).map(g => {
    const list = (g.ids || []).map(id => byId.get(id)).filter(Boolean); list.forEach(i => used.add(i.id)); return { g, list };
  }).filter(x => x.list.length);
  (o.groups || []).forEach(g => (g.ids || []).forEach(id => used.add(id)));
  const rest = items.filter(i => !used.has(i.id));
  if (rest.length) gs.push({ g: { id: '_rest', name: gs.length ? 'أخرى' : '', glyph: 'apps', bg: 'auto' }, list: rest });
  return gs;
}
const collWeight = (o, n) => (o.head ? .9 : 0) + ({ row: 1, column: n * .55, list: n * .62, radial: 3, ring: 3.2, rect: Math.ceil(n / 2) * .7 }[o.layout] ?? Math.ceil(n / Math.max(1, o.cols)));
function layCollections(d, LY, C, items) {
  const o = d.collections, demo = !!(items[0] && String(items[0].id).startsWith('dq'));
  const G = collGroupsOf(d, items, demo);
  LY.imgs = G.map(x => x.g.icon).filter(Boolean).concat(items.map(i => i.appIcon).filter(Boolean));
  if (!G.length) { LY.info = { shown: 0, total: 0 }; return; }
  const gapG = Math.max(6, d.a.gap);
  const nc = o.flow === 'columns' && G.length > 1 ? Math.min(G.length, C.w >= 230 ? 3 : 2) : 1;
  const rowsG = Math.ceil(G.length / nc);
  let shown = 0;
  const rowW = [];
  for (let r = 0; r < rowsG; r++) rowW.push(Math.max(...G.slice(r * nc, r * nc + nc).map(x => collWeight(o, x.list.length))));
  const tw = rowW.reduce((a, b) => a + b, 0) || 1, availH = C.h - gapG * (rowsG - 1);
  let y = C.y;
  for (let r = 0; r < rowsG; r++) {
    const hh = availH * rowW[r] / tw, row = G.slice(r * nc, r * nc + nc), cw = (C.w - gapG * (nc - 1)) / nc;
    row.forEach((grp, c) => {
      const x = o.dir === 'ltr' ? C.x + c * (cw + gapG) : C.x + C.w - (c + 1) * cw - c * gapG;
      shown += layGroup(d, LY, { x, y, w: cw, h: hh }, grp, G.length);
      if (c > 0) LY.nodes.push({ k: 'vrule', x: o.dir === 'ltr' ? x - gapG / 2 : x + cw + gapG / 2, y0: y + hh * .12, y1: y + hh * .88, size: .9 });
    });
    if (r < rowsG - 1 && !G.some(x => (x.g.bg || 'auto') !== 'none' && groupBgKind(d, x.g, G.length) !== 'none')) LY.nodes.push({ k: 'divider', x: C.x + C.w * .1, y: y + hh + gapG / 2, w: C.w * .8, style: 'goldLine' });
    y += hh + gapG;
  }
  // backgrounds first
  LY.nodes.sort((a, b) => (a.k === 'section' ? 0 : 1) - (b.k === 'section' ? 0 : 1));
  LY.info = { shown, total: items.length, demo };
}
function groupBgKind(d, g, count) {
  const k = g.bg || 'auto';
  if (k !== 'auto') return k;
  return count > 1 ? 'soft' : 'none';
}
function layGroup(d, LY, R, grp, count) {
  const o = d.collections, a = d.a, g = grp.g, list = grp.list, rtl = o.dir !== 'ltr';
  const fs = a.font, bgK = groupBgKind(d, g, count);
  if (bgK !== 'none') {
    LY.nodes.push({ k: 'section', x: R.x, y: R.y, w: R.w, h: R.h, r: Math.min(18, Math.max(8, a.radius * .62)), bgKind: bgK, color: g.color || null, frameKind: g.frame || 'none' });
    const p = Math.max(5, Math.min(10, a.padding * .55)); R = { x: R.x + p, y: R.y + p, w: R.w - 2 * p, h: R.h - 2 * p };
  }
  let y = R.y;
  const hasHead = o.head && (g.name || g.icon) && R.h > 60;
  if (hasHead) {
    const hs = clamp(fs * 2 * o.headSize / 100, 14, Math.min(40, R.h * .28));
    const ix = rtl ? R.x + R.w - hs : R.x;
    const it = g.icon ? { id: '_h' + g.id, kind: 'app', label: g.name, photo: g.icon, iconSrc: 'appicon', fit: 'full', glyph: g.glyph || 'apps', color: g.color }
      : { id: '_h' + g.id, kind: 'app', label: g.name, glyph: g.glyph || 'apps', color: g.color || lookOf(d).A, photo: '', emoji: '' };
    LY.nodes.push({ k: 'chip', x: ix, y, w: hs, h: hs, it, style: g.icon ? 'bare' : 'circle', shape: 'circle', tint: true, fill: .66 });
    LY.nodes.push({ k: 'text', text: g.name, x: rtl ? ix - 7 : ix + hs + 7, y: y + hs / 2, w: R.w - hs - 8, size: Math.max(10, fs * 1.22 * o.headSize / 100), weight: 700, align: rtl ? 'start' : 'end', font: FONT_D });
    if (g.pkg) LY.hits.push({ x: R.x, y, w: R.w, h: hs, it: { kind: 'app', value: g.pkg, label: g.name }, act: 'item' });
    y += hs + Math.max(6, a.gap * .7);
  }
  const B = { x: R.x, y, w: R.w, h: R.y + R.h - y };
  if (B.h < 16 || !list.length) return 0;
  const s = { cols: Math.max(1, o.cols), rows: o.rows || 0, gap: Math.max(2, o.gap), k: o.icon / 100, labels: o.labels, fs, rtl, align: o.align,
    style: o.chip, tint: o.tint, badge: o.badge, fill: (o.iconFill || 66) / 100, color: g.color };
  const lay = o.layout;
  if (lay === 'radial' || lay === 'ring') return layRadial(d, LY, B, list, s, g, lay === 'ring', hasHead);
  if (lay === 'list' || lay === 'column') return layListC(d, LY, B, list, s, lay === 'list' && o.descs);
  if (lay === 'rect') return layRectC(d, LY, B, list, s);
  if (lay === 'row') return layGridC(d, LY, B, list, Object.assign({}, s, { cols: list.length, rows: 1 }), 'grid');
  return layGridC(d, LY, B, list, s, lay);
}
function chipNode(LY, s, it, x, y, t, shape, extra = {}) {
  const n = Object.assign({ k: 'chip', x, y, w: t, h: t, it, style: s.style === 'auto' && shape === 'circle' ? 'circle' : s.style, shape, tint: s.tint, badge: s.badge, fill: s.fill, color: s.tint ? (it.color || s.color) : null, rtl: s.rtl }, extra);
  if (s.style === 'auto' && shape === 'hexagon') n.style = 'hexagon';
  if (s.style === 'wide') { n.x -= t * .22; n.w = t * 1.44; n.h = t * .9; n.y += t * .05; n.shape = 'rect'; }
  LY.nodes.push(n);
  return n;
}
const alignK = (al, rtl) => al === 'center' ? .5 : al === 'start' ? 0 : 1;
function layGridC(d, LY, B, list, s, kind) {
  const gap = s.gap, labels = s.labels || kind === 'cards', labelH = labels ? labelHOf(s.fs) : 0, hex = kind === 'hex', cards = kind === 'cards';
  const shape = kind === 'circles' ? 'circle' : hex ? 'hexagon' : 'rounded';
  let cols = Math.max(1, Math.min(s.cols, list.length));
  cols = Math.max(1, Math.min(cols, Math.floor((B.w + gap) / (22 + gap))));
  const vy = hex ? .82 : 1, pad = cards ? 6 : 0;
  const rowsFit = Math.max(1, Math.floor((B.h + gap * vy) / ((22 + labelH + 2 * pad) * vy + gap * vy)));
  let rows = Math.ceil(list.length / cols); if (s.rows) rows = Math.min(rows, s.rows); rows = Math.min(rows, rowsFit);
  const n = Math.min(list.length, rows * cols);
  const cellW = (B.w - gap * (cols - 1)) / (cols + (hex && rows > 1 ? .5 : 0));
  const rowAvail = (B.h - gap * (rows - 1) * vy) / (rows === 1 ? 1 : (1 + (rows - 1) * vy)) - labelH - 2 * pad;
  const t = Math.max(18, Math.floor(Math.min(cellW - 2 * pad, rowAvail, 110) * s.k));
  const rowH = t + labelH + 2 * pad, step = (rowH + gap) * vy;
  const total = rowH + (rows - 1) * step, y0 = B.y + Math.max(0, (B.h - total) / 2);
  const gridW = cols * cellW + (cols - 1) * gap + (hex && rows > 1 ? cellW / 2 : 0);
  for (let i = 0; i < n; i++) {
    const r = Math.floor(i / cols), c = i % cols, inRow = Math.min(cols, n - r * cols);
    const off = (cols - inRow) * (cellW + gap) * alignK(s.align) + (hex && r % 2 ? (cellW + gap) / 2 : 0) + (B.w - gridW) / 2;
    const cx = s.rtl ? B.x + B.w - off - c * (cellW + gap) - cellW / 2 : B.x + off + c * (cellW + gap) + cellW / 2;
    const top = y0 + r * step, it = list[i];
    if (cards) LY.nodes.push({ k: 'card', x: cx - cellW / 2, y: top, w: cellW, h: rowH, r: Math.min(14, cellW * .2), mat: true });
    const node = chipNode(LY, s, it, cx - t / 2, top + pad, t, shape);
    if (labels) node.label = { y: top + pad + t + 2 + labelHOf(s.fs) / 2, w: cellW - 4, size: s.fs };
    itemHit(LY, cx - cellW / 2, top, cellW, rowH, it);
  }
  return n;
}
function layRectC(d, LY, B, list, s) {
  const gap = s.gap, cols = Math.max(1, Math.min(s.cols > 2 ? 2 : s.cols, Math.floor((B.w + gap) / (110 + gap)) || 1));
  const rowsWant = Math.ceil(list.length / cols), minH = 30;
  const rows = Math.max(1, Math.min(rowsWant, s.rows || 99, Math.floor((B.h + gap) / (minH + gap))));
  const n = Math.min(list.length, rows * cols);
  const cw = (B.w - gap * (cols - 1)) / cols, rh = Math.min(64, (B.h - gap * (rows - 1)) / rows);
  const total = rows * rh + (rows - 1) * gap, y0 = B.y + (B.h - total) / 2;
  const t = Math.max(16, Math.min(rh - 10, 44) * s.k);
  for (let i = 0; i < n; i++) {
    const r = Math.floor(i / cols), c = i % cols, it = list[i];
    const x = s.rtl ? B.x + B.w - (c + 1) * cw - c * gap : B.x + c * (cw + gap), y = y0 + r * (rh + gap);
    LY.nodes.push({ k: 'card', x, y, w: cw, h: rh, r: Math.min(16, rh * .35), mat: true });
    const ix = s.rtl ? x + cw - 6 - t : x + 6;
    chipNode(LY, s, it, ix, y + (rh - t) / 2, t, 'rounded');
    LY.nodes.push({ k: 'text', text: it.label, x: s.rtl ? ix - 8 : ix + t + 8, y: y + rh / 2, w: cw - t - 20, size: s.fs * 1.05, weight: 600, align: s.rtl ? 'start' : 'end' });
    itemHit(LY, x, y, cw, rh, it);
  }
  return n;
}
function layListC(d, LY, B, list, s, descs) {
  const gap = Math.max(2, s.gap * .6);
  const rowsFit = Math.max(1, Math.floor((B.h + gap) / ((descs ? 34 : 26) + gap)));
  const n = Math.min(list.length, rowsFit, s.rows || 99);
  const rh = Math.min(descs ? 58 : 50, (B.h - gap * (n - 1)) / n), t = Math.max(16, Math.min(rh - 6, 42) * s.k);
  const total = n * rh + (n - 1) * gap, y0 = B.y + (B.h - total) / 2;
  for (let i = 0; i < n; i++) {
    const it = list[i], y = y0 + i * (rh + gap);
    const ix = s.rtl ? B.x + B.w - t - 2 : B.x + 2, tx = s.rtl ? ix - 9 : ix + t + 9, tw = B.w - t - 14;
    chipNode(LY, s, it, ix, y + (rh - t) / 2, t, 'circle');
    const sub = descs ? (it.desc || it.app || '') : '';
    LY.nodes.push({ k: 'text', text: it.label, x: tx, y: y + rh / 2 - (sub ? s.fs * .62 : 0), w: tw, size: s.fs * 1.08, weight: 600, align: s.rtl ? 'start' : 'end' });
    if (sub) LY.nodes.push({ k: 'text', text: sub, x: tx, y: y + rh / 2 + s.fs * .72, w: tw, size: s.fs * .86, color: 'sub', align: s.rtl ? 'start' : 'end' });
    if (descs && i < n - 1) LY.nodes.push({ k: 'draw', fn: (ctx, S, L) => { ctx.strokeStyle = rgba(L.frameColor, .22); ctx.lineWidth = .7; ctx.beginPath(); ctx.moveTo(B.x + 6, y + rh + gap / 2); ctx.lineTo(B.x + B.w - 6, y + rh + gap / 2); ctx.stroke(); } });
    itemHit(LY, B.x, y, B.w, rh, it);
  }
  return n;
}
function layRadial(d, LY, B, list, s, g, ring, hasHead) {
  const cx = B.x + B.w / 2, cy = B.y + B.h / 2, Rb = Math.min(B.w, B.h) / 2;
  const n = Math.min(list.length, 12);
  if (ring) LY.nodes.push({ k: 'draw', fn: (ctx, S, L) => paintBigRing(ctx, S, L, { cx, cy, r: Rb - 1 }) });
  const Rin = ring ? Rb * .92 : Rb;
  const ss = Math.sin(Math.PI / Math.max(3, n)), kk = .78;
  let t = Math.min(Rin * .46, 2 * kk * Rin * ss / (1 + kk * ss)) * s.k;
  const labelH = s.labels ? labelHOf(s.fs) : 0;
  const R = Rin - t / 2 - (ring ? 4 : 1) - labelH / 2;
  // centre: the app itself (opens it) or the group name
  if (!hasHead || ring) {
    const cs = Math.min(R * 1.05 - t * .5, Rin * .5);
    if (g.icon && cs > 16) {
      const it = { kind: 'app', label: g.name, photo: g.icon, iconSrc: 'appicon', fit: 'full', glyph: 'apps' };
      LY.nodes.push({ k: 'chip', x: cx - cs / 2, y: cy - cs / 2 - (ring && g.name ? cs * .18 : 0), w: cs, h: cs, it, style: 'bare', shape: 'circle', fill: 1 });
      if (g.pkg) LY.hits.push({ x: cx - cs / 2, y: cy - cs / 2, w: cs, h: cs, it: { kind: 'app', value: g.pkg, label: g.name }, act: 'item' });
    } else if (g.name) LY.nodes.push({ k: 'center', text: g.name, cx, cy, w: R * 1.3, size: Math.max(11, R * .26) });
  }
  for (let i = 0; i < n; i++) {
    const ang = -Math.PI / 2 + (s.rtl ? 1 : -1) * i * TAU / n, it = list[i];
    const px = cx + R * Math.cos(ang), py = cy + R * Math.sin(ang) - labelH / 2;
    const node = chipNode(LY, s, it, px - t / 2, py - t / 2, t, 'circle');
    if (s.labels) node.label = { y: py + t / 2 + 2 + labelH / 2, w: Math.min(t * 1.6, 2 * R * Math.sin(Math.PI / Math.max(2, n)) * .92), size: s.fs * .86 };
    itemHit(LY, px - t / 2, py - t / 2, t, t + labelH, it);
  }
  return n;
}

/* ---------------------------------------------------------- native data */
const INNER = { apps: null, host: false, cache: {}, mode: 'new', sel: new Set(), all: false, q: '', tab: 'style', grp: 0 };
const hasInnerNative = () => NATIVE && typeof window.LaunchyNative.requestInnerApps === 'function';
function scCount(n) { return n === 0 ? 'لا توجد اختصارات' : n === 1 ? 'اختصار واحد' : n === 2 ? 'اختصاران' : n <= 10 ? n + ' اختصارات' : n + ' اختصاراً'; }
async function innerLoadApps(force) {
  if (!hasInnerNative()) return null;
  if (INNER.apps && !force) return INNER.apps;
  const r = await nativeRequest('innerApps', () => window.LaunchyNative.requestInnerApps());
  if (r && Array.isArray(r.apps)) { INNER.apps = r.apps; INNER.host = !!r.host; }
  return INNER.apps;
}
async function innerLoadApp(pkg, force) {
  if (!hasInnerNative()) return null;
  if (INNER.cache[pkg] && !force) return INNER.cache[pkg];
  const r = await nativeRequest('innerShortcuts', () => window.LaunchyNative.requestInnerShortcuts(pkg));
  if (r && r.pkg === pkg && !r.error && !r.missing) INNER.cache[pkg] = r;
  return r;
}
function shrinkIcon(src, px) {
  return new Promise(res => {
    if (!src) return res('');
    const im = new Image();
    im.onload = () => { try { const c = document.createElement('canvas'); c.width = c.height = px; c.getContext('2d').drawImage(im, 0, 0, px, px); res(c.toDataURL('image/png')); } catch (e) { res(''); } };
    im.onerror = () => res(''); im.src = src;
  });
}
/** Dominant colour of an app icon (for tinted chips and the group colour). */
function iconColor(src) {
  return new Promise(res => {
    if (!src) return res('#8a7f6d');
    const im = new Image();
    im.onload = () => {
      try {
        const c = document.createElement('canvas'); c.width = c.height = 24; const g = c.getContext('2d'); g.drawImage(im, 0, 0, 24, 24);
        const px = g.getImageData(0, 0, 24, 24).data; let r = 0, gg = 0, b = 0, n = 0;
        for (let i = 0; i < px.length; i += 4) { const a = px[i + 3], mx = Math.max(px[i], px[i + 1], px[i + 2]), mn = Math.min(px[i], px[i + 1], px[i + 2]); if (a < 200 || mx - mn < 40 || mx < 50) continue; r += px[i]; gg += px[i + 1]; b += px[i + 2]; n++; }
        res(n ? rgbHex(r / n, gg / n, b / n) : '#5b6470');
      } catch (e) { res('#8a7f6d'); }
    };
    im.onerror = () => res('#8a7f6d'); im.src = src;
  });
}
function scItem(app, s, color, appSmall) {
  return { kind: 'ishort', label: s.label, value: s.value, pkg: app.pkg, app: app.label, sid: s.id, desc: s.desc || '',
    photo: s.icon || app.icon || '', iconSrc: 'scicon', fit: 'contain', glyph: 'link', emoji: '', color, appIcon: appSmall || '' };
}
function appOpenItem(app, color) {
  return { kind: 'app', label: app.label, value: app.pkg, photo: app.icon || '', iconSrc: 'appicon', fit: '', glyph: 'apps', emoji: '', color };
}
const sameSc = (it, pkg, s) => it.kind === 'ishort' && it.pkg === pkg && (it.sid === s.id || it.value === s.value);
const GROUP_KITS = [
  { k: 'google', n: 'مجموعة Google', glyph: 'search', color: '#4285f4', pkgs: ['com.google.android.googlequicksearchbox', 'com.google.android.apps.maps', 'com.google.android.apps.photos', 'com.android.chrome', 'com.google.android.gm', 'com.google.android.youtube'] },
  { k: 'social', n: 'مجموعة التواصل', glyph: 'chat', color: '#1f9d55', pkgs: ['com.whatsapp', 'com.whatsapp.w4b', 'com.google.android.youtube', 'com.instagram.android', 'com.twitter.android', 'org.telegram.messenger', 'com.snapchat.android', 'com.facebook.katana', 'com.zhiliaoapp.musically'] },
  { k: 'work', n: 'مجموعة العمل', glyph: 'note', color: '#2a6b9c', pkgs: ['com.google.android.gm', 'com.google.android.calendar', 'com.google.android.apps.docs', 'com.google.android.apps.docs.editors.docs', 'com.google.android.apps.docs.editors.sheets', 'com.microsoft.office.outlook', 'com.microsoft.teams', 'us.zoom.videomeetings', 'com.Slack', 'com.microsoft.office.officehubrow', 'com.google.android.keep'] }];

/** New Smart App Collection draft from one or more apps (their available shortcuts, up to 6 each). */
async function innerStartFromApps(apps, oneGroup) {
  if (!(await guardDirty())) return;
  toast('جارٍ تجهيز الاختصارات…');
  const d = newDesign({ type: 'collections', style: 'quiet', theme: 'gold' });
  Object.assign(d.a, styleLook('quiet'));
  d.name = apps.length === 1 ? apps[0].label : 'مجموعة تطبيقاتي';
  const mixed = oneGroup && apps.length > 1 ? { id: uid(), name: 'مجموعتي', pkg: '', apps: [], icon: '', glyph: 'layers', color: '#c8a45a', bg: 'auto', ids: [], show: true } : null;
  for (const app of apps) {
    const info = await innerLoadApp(app.pkg);
    const color = await iconColor(app.icon), small = await shrinkIcon(app.icon, 48);
    const ok = (info && info.items || []).filter(s => s.ok).slice(0, mixed ? 3 : 6);
    const ids = [];
    if (mixed) { const it = Object.assign({ id: uid() }, appOpenItem(app, color)); d.items.push(it); ids.push(it.id); }
    for (const s of ok) { const it = Object.assign({ id: uid() }, scItem(app, s, color, small)); d.items.push(it); ids.push(it.id); }
    if (!mixed && !ids.length) { const it = Object.assign({ id: uid() }, appOpenItem(app, color)); d.items.push(it); ids.push(it.id); }
    if (mixed) { mixed.ids.push(...ids); mixed.apps.push(app.pkg); }
    else d.collections.groups.push({ id: uid(), name: app.label, pkg: app.pkg, apps: [app.pkg], icon: app.icon || '', glyph: 'apps', color, bg: 'auto', ids, show: true });
  }
  if (mixed) { d.collections.groups.push(mixed); d.collections.layout = 'grid'; d.collections.cols = 4; d.collections.labels = true; }
  const ng = d.collections.groups.length, most = Math.max(...d.collections.groups.map(g => g.ids.length));
  d.sizes.collections = ng === 1 ? (most <= 6 ? [2, 2] : [3, 3]) : ng === 2 ? [4, 3] : [4, 4];
  if (ng === 1 && most > 6) d.collections.cols = 4;
  draft = normalize(d);
  meta = { editingId: null, savedJSON: JSON.stringify(draft) };
  resetHist(); saveDraftNow();
  INNER.tab = 'style'; INNER.grp = 0;
  location.hash = '#/inner-edit';
}
/** Adds shortcuts of an app to the current draft (any widget type). */
async function innerAddApp(app) {
  const info = await innerLoadApp(app.pkg);
  const color = await iconColor(app.icon), small = await shrinkIcon(app.icon, 48);
  if (draft.type === 'collections') {
    const ok = (info && info.items || []).filter(s => s.ok).slice(0, 6);
    const ids = [];
    update(d => {
      for (const s of ok) { const it = Object.assign({ id: uid() }, scItem(app, s, color, small)); d.items.push(it); ids.push(it.id); }
      if (!ids.length) { const it = Object.assign({ id: uid() }, appOpenItem(app, color)); d.items.push(it); ids.push(it.id); }
      d.collections.groups.push({ id: uid(), name: app.label, pkg: app.pkg, apps: [app.pkg], icon: app.icon || '', glyph: 'apps', color, bg: 'auto', ids, show: true });
    });
    INNER.grp = draft.collections.groups.length - 1; INNER.tab = 'shortcuts';
    location.hash = '#/inner-edit';
    return;
  }
  const picked = await pickShortcutsDialog(app, info);
  if (!picked || !picked.length) { location.hash = '#/editor'; return; }
  update(d => picked.forEach(s => d.items.push(Object.assign({ id: uid() }, s === 'app' ? appOpenItem(app, color) : scItem(app, s, color, small)))), { rebuild: true });
  toast(`أُضيف ${picked.length} اختصار من ${app.label}`);
  location.hash = '#/editor';
}
function pickShortcutsDialog(app, info) {
  return new Promise(res => {
    let done = false;
    const sel = new Set();
    const items = (info && info.items) || [];
    const rows = [{ app: true }].concat(items).map(s => {
      if (s.app) {
        const row = h('div', { class: 'sc-row', role: 'button', tabindex: 0, onclick: () => { sel.has('app') ? sel.delete('app') : sel.add('app'); row.classList.toggle('on', sel.has('app')); } },
          h('i', { class: 'sc-check' }, icon('check', 13)), h('img', { src: app.icon, alt: '' }), h('span', { class: 'sc-t' }, h('b', {}, 'فتح ' + app.label), h('small', {}, 'التطبيق نفسه')));
        return row;
      }
      const row = h('div', { class: 'sc-row' + (s.ok ? '' : ' off'), role: 'button', tabindex: 0, onclick: () => { if (!s.ok) return; sel.has(s) ? sel.delete(s) : sel.add(s); row.classList.toggle('on', sel.has(s)); } },
        h('i', { class: 'sc-check' }, icon('check', 13)), s.icon ? h('img', { src: s.icon, alt: '' }) : h('span', { class: 'sc-ph' }, icon('link', 18)),
        h('span', { class: 'sc-t' }, h('b', {}, s.label), h('small', {}, s.ok ? (s.desc || 'جاهز') : s.why)));
      return row;
    });
    openDialog(`اختصارات ${app.label}`, h('div', { class: 'form' }, h('div', { class: 'sc-list' }, rows),
      !items.length ? h('p', { class: 'fine' }, 'هذا التطبيق لا يوفّر اختصارات داخلية يمكن لتطبيق آخر فتحها.') : null), [
      { label: 'إضافة المحدد', cls: 'btn-gold', onClick: () => { done = true; res([...sel]); } },
      { label: 'إلغاء', cls: 'btn-ghost', onClick: () => { done = true; res(null); } }]);
    $('#dlg').addEventListener('close', () => { if (!done) res(null); }, { once: true });
  });
}

/* ---------------------------------------------------------- page: choose app */
function innerHonestNote() {
  return h('div', { class: 'note' }, icon('eye', 16), h('span', {},
    'تُعرض فقط الاختصارات التي يسمح Android لهذا التطبيق بفتحها: الاختصارات الثابتة التي يعلنها كل تطبيق، وشاشات «إنشاء اختصار» التقليدية. الاختصارات الديناميكية والمثبتة (مثل آخر المحادثات) لا يمنحها Android إلا لتطبيق الشاشة الرئيسية الافتراضي',
    INNER.host ? ' — وهذا التطبيق هو الشاشة الرئيسية الآن، فتظهر أيضاً.' : '، لذلك لا تظهر هنا. كل اختصار يُفحص قبل عرضه على أنه جاهز.'));
}
function viewInner() {
  const v = $('#view');
  const params = new URLSearchParams(location.hash.split('?')[1] || '');
  INNER.mode = params.get('add') ? 'add' : 'new';
  const list = h('div', { class: 'ia-list' });
  const q = h('input', { type: 'search', class: 'inp ia-search', placeholder: 'البحث عن التطبيقات', 'aria-label': 'البحث عن التطبيقات', value: INNER.q });
  const allBox = h('input', { type: 'checkbox', class: 'ia-cb' }); allBox.checked = INNER.all;
  const bar = h('div', { class: 'ia-bar', hidden: true });
  const status = h('p', { class: 'fine' });
  const draw = () => {
    const apps = INNER.apps || [], t = INNER.q.trim().toLowerCase();
    let L = apps.filter(a => INNER.all || a.n > 0 || a.legacy > 0);
    if (t) L = L.filter(a => (a.label + ' ' + a.pkg).toLowerCase().includes(t));
    L.sort((a, b) => (b.n > 0) - (a.n > 0));
    list.replaceChildren(...L.map((a, i) => {
      const on = INNER.sel.has(a.pkg);
      const sub = a.n > 0 ? scCount(a.n) : a.legacy ? 'إنشاء اختصار مخصص' : 'لا يوفّر اختصارات قابلة للفتح';
      const extra = [a.off ? `${a.off} للشاشة الرئيسية فقط` : '', a.n > 0 && a.legacy ? '+ اختصار مخصص' : ''].filter(Boolean).join(' · ');
      const cb = h('input', { type: 'checkbox', class: 'ia-cb', 'aria-label': 'تحديد ' + a.label, onclick: e => { e.stopPropagation(); }, onchange: e => { e.target.checked ? INNER.sel.add(a.pkg) : INNER.sel.delete(a.pkg); drawBar(); e.target.closest('.ia-row').classList.toggle('on', e.target.checked); } });
      cb.checked = on;
      return h('div', { class: 'ia-row' + (on ? ' on' : '') + (a.n ? '' : ' dim'), style: { '--i': Math.min(i, 12) }, role: 'button', tabindex: 0, onclick: () => openApp(a) },
        h('img', { src: a.icon, alt: '', loading: 'lazy', class: 'ia-ico' }),
        h('span', { class: 'ia-t' }, h('b', {}, a.label), h('small', {}, sub), extra ? h('small', { class: 'ia-x' }, extra) : null),
        INNER.mode === 'add' ? h('span', { class: 'ia-go' }, icon('arrowL', 16)) : cb);
    }));
    if (!L.length && INNER.apps) list.append(h('div', { class: 'empty' }, icon('search', 30), h('h3', {}, 'لا توجد نتائج'), h('p', {}, INNER.all ? 'جرّب اسماً آخر.' : 'فعّل «عرض جميع التطبيقات» لرؤية التطبيقات التي لا توفّر اختصارات.')));
    status.textContent = INNER.apps ? `${apps.filter(a => a.n > 0).length} تطبيقاً يوفّر اختصارات داخلية من أصل ${apps.length}` : '';
    drawBar();
  };
  const drawBar = () => {
    const n = INNER.sel.size; bar.hidden = !n || INNER.mode === 'add';
    if (bar.hidden) return;
    const apps = () => (INNER.apps || []).filter(a => INNER.sel.has(a.pkg));
    bar.replaceChildren(h('span', {}, `${n} محدد`),
      h('button', { type: 'button', class: 'btn btn-sm', onclick: () => { INNER.sel.clear(); route(false); } }, 'إلغاء'),
      h('button', { type: 'button', class: 'btn btn-sm', onclick: () => innerStartFromApps(apps(), true) }, icon('layers', 15), 'مجموعة واحدة'),
      h('button', { type: 'button', class: 'btn btn-gold btn-sm', onclick: () => innerStartFromApps(apps(), false) }, icon('plus', 15), n > 1 ? 'مجموعة لكل تطبيق' : 'إنشاء الويدجت'));
  };
  const openApp = async a => {
    if (INNER.mode === 'add') return innerAddApp(a);
    if (a.n > 0) return innerStartFromApps([a], false);
    appDetails(a);
  };
  q.addEventListener('input', debounce(() => { INNER.q = q.value; draw(); }, 150));
  allBox.addEventListener('change', () => { INNER.all = allBox.checked; draw(); });
  const kits = h('div', { class: 'chips' }, GROUP_KITS.map(k => h('button', { type: 'button', class: 'chip', onclick: () => {
    const apps = (INNER.apps || []).filter(a => k.pkgs.includes(a.pkg)).slice(0, 6);
    if (!apps.length) return toast('لا توجد تطبيقات مثبتة من هذه المجموعة');
    innerStartFromApps(apps, true).then(() => update(d => { const g = d.collections.groups[0]; if (g) Object.assign(g, { name: k.n, glyph: k.glyph, color: k.color }); d.name = k.n; }));
  } }, glyph(k.glyph, 15), k.n)));
  const tpls = store.get('llx.collTpl', []) || [];
  v.replaceChildren(h('div', { class: 'wrap ia-wrap' },
    h('div', { class: 'ia-head' },
      h('a', { class: 'btn icon-btn btn-ghost', href: INNER.mode === 'add' ? (draft.type === 'collections' ? '#/inner-edit' : '#/editor') : '#/', 'aria-label': 'رجوع' }, icon('arrowR', 20)),
      h('div', {}, h('div', { class: 'eyebrow' }, 'App Shortcuts · الاختصارات الداخلية'), h('h1', { class: 'page-t' }, 'اختيار تطبيق'))),
    h('p', { class: 'page-d' }, INNER.mode === 'add' ? 'اختر تطبيقاً لإضافة اختصاراته إلى التصميم الحالي.' : 'اختر تطبيقاً لاستعراض وظائفه السريعة (البحث، علامة تبويب جديدة، الاتجاهات…) ثم صمّمها في ويدجت فاخرة. حدّد عدة تطبيقات لإنشاء مجموعة واحدة.'),
    hasInnerNative() ? h('div', { class: 'ia-tools' }, q, h('label', { class: 'ia-all' }, allBox, h('span', {}, 'عرض جميع التطبيقات'))) : null,
    hasInnerNative() && INNER.mode !== 'add' ? h('div', { class: 'ia-kits' }, h('span', { class: 'fine' }, 'مجموعات جاهزة من تطبيقاتك:'), kits) : null,
    tpls.length && INNER.mode !== 'add' ? h('div', { class: 'ia-kits' }, h('span', { class: 'fine' }, 'قوالبي:'), h('div', { class: 'chips' }, tpls.map(t => h('button', { type: 'button', class: 'chip', onclick: async () => { if (!(await guardDirty())) return; draft = normalize(Object.assign(clone(t.d), { id: null })); meta = { editingId: null, savedJSON: '' }; resetHist(); saveDraftNow(); location.hash = '#/inner-edit'; } }, icon('template', 14), t.n)))) : null,
    hasInnerNative() ? status : null,
    hasInnerNative() ? list : h('div', { class: 'empty ia-web' }, icon('apps', 34), h('h3', {}, 'اكتشاف الاختصارات يعمل في تطبيق Android'),
      h('p', {}, 'قراءة اختصارات التطبيقات المثبتة وفحصها تتم داخل تطبيق Android فقط. في المتصفح يمكنك تجربة التصميم ببيانات تجريبية واضحة — دون أن تُعرض على أنها اختصارات حقيقية.'),
      h('button', { type: 'button', class: 'btn btn-gold', onclick: async () => { if (!(await guardDirty())) return; draft = newDesign({ type: 'collections', style: 'quiet', theme: 'gold' }); meta = { editingId: null, savedJSON: JSON.stringify(draft) }; resetHist(); saveDraftNow(); location.hash = '#/inner-edit'; } }, icon('eye', 18), 'معاينة التصميم ببيانات تجريبية')),
    hasInnerNative() ? innerHonestNote() : null, bar));
  if (!hasInnerNative()) return;
  if (!INNER.apps) {
    list.replaceChildren(...[0, 1, 2, 3, 4].map(() => h('div', { class: 'ia-row ia-skel' }, h('i', { class: 'ia-ico' }), h('span', { class: 'ia-t' }, h('b', {}), h('small', {})))));
    status.textContent = 'جارٍ قراءة اختصارات التطبيقات المثبتة وفحصها…';
    innerLoadApps().then(() => { if (curRoute() === 'inner') { if (!INNER.apps) { status.textContent = 'تعذّر تحميل قائمة التطبيقات'; return; } draw(); } });
  } else draw();
}
/** Details of an app without ready shortcuts: blocked ones with reasons, legacy creators, or the app itself. */
async function appDetails(a) {
  const info = await innerLoadApp(a.pkg);
  const items = (info && info.items) || [], cr = (info && info.creators) || [];
  const body = h('div', { class: 'form' },
    h('div', { class: 'it-prev' }, h('img', { src: a.icon, alt: '', style: { width: '52px', height: '52px' } }), h('div', { class: 'it-txt' }, h('strong', {}, a.label), h('small', { dir: 'ltr' }, a.pkg))),
    items.length ? h('div', { class: 'sc-list' }, items.map(s => h('div', { class: 'sc-row off' }, s.icon ? h('img', { src: s.icon, alt: '' }) : h('span', { class: 'sc-ph' }, icon('link', 18)), h('span', { class: 'sc-t' }, h('b', {}, s.label), h('small', {}, s.why))))) :
      h('p', { class: 'fine' }, 'هذا التطبيق لا يعلن اختصارات داخلية ثابتة.'),
    cr.length ? h('div', { class: 'form' }, h('div', { class: 'sub-h' }, 'إنشاء اختصار مخصص من التطبيق نفسه'), ...cr.map(c => h('button', { type: 'button', class: 'btn', onclick: () => { $('#dlg').close(); legacyFlow(a, c); } }, c.icon ? h('img', { src: c.icon, alt: '', style: { width: '22px', height: '22px' } }) : icon('plus', 18), c.label))) : null,
    h('button', { type: 'button', class: 'btn btn-gold', onclick: () => { $('#dlg').close(); innerStartFromApps([a], false); } }, icon('apps', 18), 'إنشاء ويدجت بأيقونة التطبيق نفسه'));
  openDialog(a.label, body);
}
/** Legacy ACTION_CREATE_SHORTCUT: the app shows its own screen and returns a shortcut (checked natively). */
async function legacyFlow(app, c, intoDraft) {
  const r = await nativeRequest('innerLegacy', () => window.LaunchyNative.createInnerShortcut(app.pkg, c.cls));
  if (!r || r.why === 'cancel') return toast('أُلغي إنشاء الاختصار');
  if (!r.ok) {
    const msg = { pinOnly: 'هذا التطبيق ينشئ الاختصار بطريقة Android 8 الحديثة التي لا يقبلها إلا تطبيق الشاشة الرئيسية الافتراضي، لذلك لا يمكن إضافته هنا.', empty: 'لم يُرجع التطبيق اختصاراً.', start: 'تعذّر فتح شاشة إنشاء الاختصار في التطبيق.' }[r.why] || ('لا يمكن فتح هذا الاختصار من تطبيق آخر: ' + r.why);
    return openDialog('تعذّر إضافة الاختصار', h('p', {}, msg), [{ label: 'حسناً', cls: 'btn-gold' }]);
  }
  const color = await iconColor(app.icon), small = await shrinkIcon(app.icon, 48);
  const it = Object.assign({ id: uid() }, scItem(app, { id: 'legacy_' + uid(), label: r.label || c.label, value: r.value, icon: r.icon, desc: 'اختصار مخصص · ' + (r.to || '') }, color, small));
  if (intoDraft && draft.type === 'collections') {
    update(d => { d.items.push(it); const g = d.collections.groups[INNER.grp]; if (g) g.ids.push(it.id); });
    ieRebuild(); toast(`أُضيف «${it.label}»`); return;
  }
  if (!(await guardDirty())) return;
  const d = newDesign({ type: 'collections', style: 'quiet', theme: 'gold' }); Object.assign(d.a, styleLook('quiet'));
  d.name = app.label; d.items.push(it);
  d.collections.groups.push({ id: uid(), name: app.label, pkg: app.pkg, apps: [app.pkg], icon: app.icon || '', glyph: 'apps', color, bg: 'auto', ids: [it.id], show: true });
  draft = normalize(d); meta = { editingId: null, savedJSON: JSON.stringify(draft) }; resetHist(); saveDraftNow();
  INNER.tab = 'shortcuts'; INNER.grp = 0; location.hash = '#/inner-edit';
}

/* ---------------------------------------------------------- page: edit the widget («تعديل الأداة») */
function ieRebuild() { if (curRoute() === 'inner-edit') ieBody(); }
function ieGroup() { const gs = draft.collections.groups; if (INNER.grp >= gs.length) INNER.grp = Math.max(0, gs.length - 1); return gs[INNER.grp] || null; }
function viewInnerEdit() {
  const v = $('#view');
  if (draft.type !== 'collections') {
    v.replaceChildren(h('div', { class: 'wrap' }, h('div', { class: 'empty' }, icon('layers', 30), h('h3', {}, 'التصميم المفتوح ليس مجموعة تطبيقات'),
      h('p', {}, 'افتح «اختيار تطبيق» لإنشاء مجموعة جديدة، أو بدّل نوع التصميم الحالي إلى «مجموعات التطبيقات الذكية».'),
      h('div', { class: 'chips', style: { justifyContent: 'center' } },
        h('a', { class: 'btn btn-gold', href: '#/inner' }, icon('apps', 18), 'اختيار تطبيق'),
        h('button', { type: 'button', class: 'btn', onclick: () => { update(d => d.type = 'collections'); route(false); } }, 'تبديل النوع')))));
    return;
  }
  const tabs = [['style', 'النمط'], ['space', 'التباعد'], ['shortcuts', 'الاختصارات']];
  const n = native();
  v.replaceChildren(h('div', { class: 'wrap ie-wrap' },
    h('div', { class: 'ie-top' },
      h('a', { class: 'btn icon-btn btn-ghost', href: '#/inner', 'aria-label': 'رجوع إلى اختيار تطبيق' }, icon('arrowR', 20)),
      h('h1', { class: 'ie-title' }, 'تعديل الأداة'),
      h('button', { type: 'button', class: 'btn icon-btn btn-ghost', 'aria-label': 'فتح في المحرر الكامل', title: 'المحرر الكامل', onclick: () => { ui.step = 2; location.hash = '#/editor'; } }, icon('sliders', 19))),
    h('div', { class: 'ie-grid' },
      h('div', { class: 'ie-stagecol' },
        h('div', { class: 'stage ie-stage wp-' + wall, id: 'stage' },
          h('div', { class: 'stage-slot', id: 'stage-widget' })),
        h('div', { class: 'stage-meta ie-meta' }, h('span', { class: 'demo-tag', id: 'demo-tag', hidden: true }, 'بيانات تجريبية'), h('div', { class: 'stage-info', id: 'stage-info' }),
          h('button', { type: 'button', class: 'btn btn-sm btn-ghost icon-btn', 'aria-label': 'تغيير خلفية المعاينة', onclick: () => cycleWall(() => { $('#stage').className = 'stage ie-stage wp-' + wall; renderPreview(); }) }, icon('image', 16)))),
      h('div', { class: 'ie-panel' },
        h('div', { class: 'ie-tabs', role: 'tablist' }, tabs.map(([k, t]) => h('button', { type: 'button', role: 'tab', class: INNER.tab === k ? 'on' : '', 'aria-selected': String(INNER.tab === k), onclick: e => { INNER.tab = k; $$('.ie-tabs button').forEach(b => { b.classList.toggle('on', b === e.currentTarget); b.setAttribute('aria-selected', String(b === e.currentTarget)); }); ieBody(); } }, t))),
        h('div', { class: 'ie-body', id: 'ie-body' }))),
    h('div', { class: 'ie-foot' },
      h('button', { type: 'button', class: 'btn btn-gold ie-save', onclick: () => saveDesign() }, icon('check', 18), 'حفظ'),
      h('button', { type: 'button', class: 'btn', onclick: async () => { const saved = saveDesign({ silent: true }); if (!saved) return; if (n) await pinNative(saved); else openDialog('أضف الويدجت يدوياً', manualAddSteps(), [{ label: 'حسناً', cls: 'btn-gold' }]); } }, icon('download', 18), 'إضافة إلى الشاشة الرئيسية'))));
  ieBody(); renderPreview();
}
function ieBody() {
  const b = $('#ie-body'); if (!b) return;
  const fn = { style: ieStyleTab, space: ieSpaceTab, shortcuts: ieShortcutsTab }[INNER.tab] || ieStyleTab;
  const y = window.scrollY;
  b.replaceChildren(...fn().flat().filter(x => x != null && x !== false));
  window.scrollTo(0, y);
}
function groupChips() {
  const gs = draft.collections.groups;
  if (gs.length < 2) return null;
  return h('div', { class: 'chips ie-gchips' }, gs.map((g, i) => h('button', { type: 'button', class: 'chip' + (i === INNER.grp ? ' on' : ''), onclick: () => { INNER.grp = i; ieBody(); } },
    g.icon ? h('img', { src: g.icon, alt: '', class: 'chip-img' }) : h('i', { class: 'chip-dot', style: { background: g.color } }), g.name || 'مجموعة')));
}
function setGroup(fn, rebuild = true) { update(d => { const g = d.collections.groups[INNER.grp]; if (g) fn(g, d); }); if (rebuild) ieBody(); }
function groupInfoCard() {
  const g = ieGroup();
  if (!g) return h('p', { class: 'fine' }, 'لا توجد مجموعات بعد — أضف تطبيقاً من تبويب «الاختصارات».');
  const name = h('input', { type: 'text', class: 'inp', value: g.name || '', maxlength: 30, 'aria-label': 'اسم المجموعة' });
  name.addEventListener('input', () => { g.name = name.value; renderPreview(); saveDraftSoon(); });
  name.addEventListener('change', () => { commitHist(); });
  const icoBox = h('button', { type: 'button', class: 'ie-appico', 'aria-label': 'تغيير أيقونة المجموعة', onclick: () => pickGroupIcon(g) }, g.icon ? h('img', { src: g.icon, alt: '' }) : h('span', { style: { color: g.color } }, glyph(g.glyph || 'apps', 30)));
  const col = h('input', { type: 'color', value: g.color || '#c8a45a', 'aria-label': 'لون المجموعة' });
  col.addEventListener('input', () => { g.color = col.value; draft.items.filter(i => (g.ids || []).includes(i.id)).forEach(i => i.color = col.value); renderPreview(); saveDraftSoon(); });
  col.addEventListener('change', () => commitHist());
  return h('div', { class: 'form' },
    h('div', { class: 'ie-sub' }, h('span', {}, g.pkg ? 'معلومات التطبيق' : 'معلومات المجموعة'), h('button', { type: 'button', class: 'ie-link', onclick: () => pickGroupIcon(g) }, 'تغيير')),
    h('div', { class: 'ie-info' }, name, icoBox),
    h('div', { class: 'ctl-row' }, h('span', {}, 'لون المجموعة'), col),
    h('div', { class: 'ctl' }, h('span', { class: 'ctl-top' }, h('span', {}, 'خلفية المجموعة')),
      h('div', { class: 'seg' }, GROUP_BG.map(([k, t]) => h('button', { type: 'button', class: (g.bg || 'auto') === k ? 'on' : '', onclick: () => setGroup(x => x.bg = k) }, t)))));
}
function pickGroupIcon(g) {
  const body = h('div', { class: 'form' },
    g.pkg ? h('button', { type: 'button', class: 'btn', onclick: async () => { const info = await innerLoadApp(g.pkg); if (info && info.icon) setGroup(x => x.icon = info.icon); $('#dlg').close(); } }, icon('apps', 18), 'أيقونة التطبيق الأصلية') : null,
    h('div', { class: 'sub-h' }, 'رمز'),
    h('div', { class: 'glyph-grid' }, GLYPH_KEYS.concat(['search', 'layers']).map(k => h('button', { type: 'button', class: !g.icon && g.glyph === k ? 'on' : '', 'aria-label': k, onclick: () => { setGroup(x => { x.icon = ''; x.glyph = k; }); $('#dlg').close(); } }, glyph(k, 20)))));
  openDialog('أيقونة المجموعة', body);
}
function ieStyleTab() {
  const o = draft.collections;
  const looks = h('div', { class: 'ie-looks' }, COLL_LOOKS.map(l => {
    const prev = h('div', { class: 'ie-look-prev wp-' + wall });
    const on = draft.style === l.style && o.chip === l.chip;
    const btn = h('button', { type: 'button', class: 'ie-look' + (on ? ' on' : ''), onclick: () => {
      update(d => { d.style = l.style; Object.assign(d.a, styleLook(l.style)); d.theme = l.theme; d.collections.chip = l.chip; if (l.frame) d.a.frame = l.frame; });
      ieBody();
    } }, prev, h('b', {}, l.ar), h('small', {}, l.n));
    lazy(prev, () => { const dd = clone(draft); dd.style = l.style; Object.assign(dd.a, styleLook(l.style)); dd.theme = l.theme; dd.collections.chip = l.chip; if (l.frame) dd.a.frame = l.frame; dd.sizes.collections = [2, 2]; prev.append(fitScaled(dd, 116, 92, {}, 1).el); });
    return btn;
  }));
  const chips = h('div', { class: 'ie-chipstyles' }, CHIP_STYLES.map(([k, n]) => h('button', { type: 'button', class: 'ie-cs' + (o.chip === k ? ' on' : ''), onclick: () => { update(d => d.collections.chip = k); ieBody(); } },
    h('i', { class: 'cs-' + k }), h('span', {}, n))));
  return [groupChips(), groupInfoCard(),
    h('div', { class: 'ie-sub' }, h('span', {}, 'السمة الجاهزة')), looks,
    h('div', { class: 'ie-sub' }, h('span', {}, 'شكل الأيقونات الداخلية')), chips,
    toggle('تلوين الأيقونات بلون التطبيق', 'collections.tint'),
    slider('حجم الأيقونة داخل الإطار', 'collections.iconFill', 40, 96, 1, '%'),
    toggle('شارة التطبيق الصغيرة على كل اختصار', 'collections.badge', 'مفيدة في المجموعات المختلطة'),
    group('ie-card', 'نمط البطاقة والألوان', h('button', { type: 'button', class: 'btn btn-sm', onclick: openStyleLibrary }, icon('palette', 15), 'مكتبة الأنماط (' + STYLE_ORDER.length + ')'), ...themePicker()),
    group('ie-mat', 'الخامة', ...materialPanel()),
    group('ie-frame', 'شكل الإطار', ...framePanel()),
    group('ie-fx', 'الزوايا والظلال', slider('استدارة الزوايا', 'a.radius', 0, 44, 1, 'px'), slider('الشفافية', 'a.transp', 0, 90, 1, '%'), ...fxPanel())];
}
function ieSpaceTab() {
  const o = draft.collections;
  const lays = h('div', { class: 'ie-lays' }, COLL_LAYOUTS.map(([k, n]) => {
    const prev = h('div', { class: 'ie-lay-prev' });
    const btn = h('button', { type: 'button', class: 'ie-lay' + (o.layout === k ? ' on' : ''), onclick: () => { update(d => { d.collections.layout = k; if (k === 'row') d.collections.labels = false; }); ieBody(); } }, prev, h('span', {}, n));
    lazy(prev, () => { const dd = clone(draft); dd.collections.layout = k; dd.collections.head = false; dd.a.frame = 'none'; dd.sizes.collections = k === 'row' ? [4, 1] : [2, 2]; prev.append(fitScaled(dd, 92, 74, {}, 1).el); });
    return btn;
  }));
  const grid = !['radial', 'ring', 'list', 'column'].includes(o.layout);
  return [h('div', { class: 'ie-sub' }, h('span', {}, 'التخطيط')), lays,
    sizeCtl(),
    grid ? slider('عدد الأعمدة', 'collections.cols', 1, 8) : null,
    !['radial', 'ring', 'row'].includes(o.layout) ? slider('عدد الصفوف (0 = تلقائي)', 'collections.rows', 0, 8) : null,
    slider('المسافة بين الأيقونات', 'collections.gap', 2, 28, 1, 'px'),
    slider('حجم الأيقونات', 'collections.icon', 50, 130, 1, '%'),
    slider('الهوامش الداخلية', 'a.padding', 6, 26, 1, 'px'),
    seg('محاذاة الأيقونات', 'collections.align', [['start', 'البداية'], ['center', 'الوسط'], ['end', 'النهاية']]),
    seg('اتجاه التخطيط', 'collections.dir', [['rtl', 'من اليمين'], ['ltr', 'من اليسار']]),
    toggle('إظهار أسماء الاختصارات', 'collections.labels'),
    o.layout === 'list' ? toggle('الوصف تحت الاسم', 'collections.descs') : null,
    slider('حجم الأسماء', 'a.font', 8, 16, .5, 'px'),
    toggle('رأس المجموعة (أيقونة التطبيق واسمه)', 'collections.head'),
    o.head ? slider('حجم الرأس', 'collections.headSize', 60, 150, 1, '%') : null,
    draft.collections.groups.length > 1 ? seg('توزيع المجموعات', 'collections.flow', [['stack', 'فوق بعضها'], ['columns', 'أعمدة متجاورة']]) : null];
}
function moveGroup(i, dir) { update(d => { const gs = d.collections.groups, j = i + dir; if (j < 0 || j >= gs.length) return; [gs[i], gs[j]] = [gs[j], gs[i]]; }); INNER.grp = Math.max(0, Math.min(draft.collections.groups.length - 1, i + dir)); ieBody(); }
async function removeGroup(i) {
  const g = draft.collections.groups[i]; if (!g) return;
  if (!(await confirmBox('حذف المجموعة', `حذف «${g.name || 'المجموعة'}» واختصاراتها من هذه الأداة؟`, 'حذف', true))) return;
  update(d => { const gg = d.collections.groups.splice(i, 1)[0]; d.items = d.items.filter(it => !(gg.ids || []).includes(it.id)); });
  INNER.grp = 0; ieBody();
}
function ieShortcutsTab() {
  const g = ieGroup();
  const els = [groupChips()];
  if (!g) {
    els.push(h('div', { class: 'empty' }, icon('apps', 28), h('h3', {}, 'لا توجد اختصارات بعد'), h('p', {}, hasInnerNative() ? 'أضف تطبيقاً لاستعراض اختصاراته الداخلية.' : 'المعاينة الحالية تجريبية. اختيار الاختصارات الحقيقية متاح في تطبيق Android.'),
      hasInnerNative() ? h('a', { class: 'btn btn-gold', href: '#/inner?add=1' }, icon('plus', 18), 'إضافة تطبيق') : null));
    return els;
  }
  const byId = new Map(draft.items.map(i => [i.id, i]));
  const chosen = (g.ids || []).map(id => byId.get(id)).filter(Boolean);
  // chosen, in order (drag to reorder)
  const list = h('ul', { class: 'it-list', id: 'ie-list' });
  chosen.forEach((it, i) => list.append(h('li', { class: 'it-row', 'data-id': it.id },
    h('button', { type: 'button', class: 'grip', 'aria-label': 'اسحب لإعادة الترتيب' }, icon('grip')),
    itemIcon(it, 40),
    h('div', { class: 'it-txt' }, h('strong', {}, it.label), h('small', {}, it.kind === 'ishort' ? (it.app || '') + (it.desc ? ' · ' + it.desc : '') : KIND[it.kind].n + (it.kind === 'app' ? ' · فتح التطبيق' : ''))),
    h('div', { class: 'it-act' },
      h('button', { type: 'button', class: 'btn', 'aria-label': 'تحريك لأعلى', disabled: i === 0, onclick: () => { setGroup(x => { const j = x.ids.indexOf(it.id); if (j > 0) [x.ids[j - 1], x.ids[j]] = [x.ids[j], x.ids[j - 1]]; }); } }, icon('up', 16)),
      it.kind === 'ishort' && hasInnerNative() ? h('button', { type: 'button', class: 'btn', 'aria-label': 'تجربة', title: 'تجربة الاختصار الآن', onclick: () => testShortcut(it) }, icon('play', 16)) : null,
      h('button', { type: 'button', class: 'btn', 'aria-label': 'تعديل الاسم', onclick: () => editIShort(it) }, icon('edit', 16)),
      h('button', { type: 'button', class: 'btn btn-danger', 'aria-label': 'إزالة', onclick: () => { update(d => { d.items = d.items.filter(x => x.id !== it.id); d.collections.groups.forEach(x => x.ids = (x.ids || []).filter(id => id !== it.id)); }); ieBody(); } }, icon('trash', 16))))));
  enableDrag(list, ids => { const gg = draft.collections.groups[INNER.grp]; if (gg) gg.ids = ids; });
  els.push(h('div', { class: 'ie-sub' }, h('span', {}, `الاختصارات في «${g.name || 'المجموعة'}» (${chosen.length})`)),
    chosen.length ? list : h('p', { class: 'fine' }, 'لم تحدد اختصارات بعد — اختر من القائمة التالية.'));
  // available shortcuts from each source app
  const srcs = [...new Set([g.pkg, ...(g.apps || []), ...chosen.map(i => i.pkg || (i.kind === 'app' ? i.value : ''))].filter(Boolean))];
  const avail = h('div', { class: 'form' });
  els.push(h('div', { class: 'ie-sub' }, h('span', {}, 'الاختصارات المتاحة')), avail);
  if (!hasInnerNative()) avail.append(h('p', { class: 'fine' }, 'استعراض الاختصارات المتاحة يعمل داخل تطبيق Android.'));
  else if (!srcs.length) avail.append(h('p', { class: 'fine' }, 'أضف تطبيقاً لهذه المجموعة.'));
  else (async () => {
    for (const pkg of srcs) {
      const box = h('div', { class: 'ie-src' }, h('p', { class: 'fine' }, 'جارٍ التحميل…'));
      avail.append(box);
      const info = await innerLoadApp(pkg);
      if (!info || info.missing || info.error) { box.replaceChildren(h('p', { class: 'fine' }, pkg + ': التطبيق غير مثبت أو تعذّر قراءته.')); continue; }
      box.replaceChildren(availBox(g, info));
    }
  })();
  els.push(h('div', { class: 'ie-acts' },
    hasInnerNative() ? h('a', { class: 'btn btn-sm', href: '#/inner?add=1' }, icon('plus', 15), 'إضافة تطبيق') : null,
    h('button', { type: 'button', class: 'btn btn-sm', onclick: newEmptyGroup }, icon('layers', 15), 'مجموعة جديدة'),
    draft.collections.groups.length > 1 ? h('button', { type: 'button', class: 'btn btn-sm', onclick: () => moveGroup(INNER.grp, -1) }, icon('up', 15), 'نقل المجموعة لأعلى') : null,
    h('button', { type: 'button', class: 'btn btn-sm', onclick: saveCollTemplate }, icon('template', 15), 'حفظ كقالب'),
    h('button', { type: 'button', class: 'btn btn-sm btn-danger', onclick: () => removeGroup(INNER.grp) }, icon('trash', 15), 'حذف المجموعة')),
    hasInnerNative() ? innerHonestNote() : null);
  return els;
}
function availBox(g, info) {
  const app = { pkg: info.pkg, label: info.label, icon: info.icon };
  const items = info.items || [];
  const isOn = s => (g.ids || []).some(id => { const it = draft.items.find(x => x.id === id); return it && sameSc(it, info.pkg, s); });
  const appOn = (g.ids || []).some(id => { const it = draft.items.find(x => x.id === id); return it && it.kind === 'app' && it.value === info.pkg; });
  const toggleSc = async (s, on) => {
    const color = g.color || await iconColor(app.icon), small = await shrinkIcon(app.icon, 48);
    update(d => {
      const gg = d.collections.groups[INNER.grp]; if (!gg) return;
      if (on) { const it = Object.assign({ id: uid() }, s === 'app' ? appOpenItem(app, color) : scItem(app, s, color, small)); d.items.push(it); gg.ids.push(it.id); if (!(gg.apps || []).includes(app.pkg)) gg.apps = (gg.apps || []).concat(app.pkg); }
      else { const rm = d.items.filter(it => (gg.ids || []).includes(it.id) && (s === 'app' ? it.kind === 'app' && it.value === app.pkg : sameSc(it, app.pkg, s))).map(it => it.id); d.items = d.items.filter(it => !rm.includes(it.id)); gg.ids = gg.ids.filter(id => !rm.includes(id)); }
    });
    ieBody();
  };
  const chipPrev = src => h('span', { class: 'sc-mini cs-' + draft.collections.chip }, src ? h('img', { src, alt: '' }) : icon('link', 14));
  const rows = items.map(s => h('div', { class: 'sc-row' + (isOn(s) ? ' on' : '') + (s.ok ? '' : ' off'), role: 'button', tabindex: 0, 'aria-disabled': String(!s.ok), onclick: () => { if (s.ok) toggleSc(s, !isOn(s)); } },
    h('i', { class: 'sc-check' }, icon('check', 13)),
    s.icon ? h('img', { src: s.icon, alt: '' }) : h('span', { class: 'sc-ph' }, icon('link', 18)),
    h('span', { class: 'sc-t' }, h('b', {}, s.label), h('small', {}, s.ok ? (s.desc || (s.src === 'dynamic' ? 'اختصار ديناميكي' : 'جاهز — تحقّق النظام من إمكانية فتحه')) : s.why), s.ok && s.to ? h('small', { class: 'sc-to', dir: 'ltr' }, s.to) : null),
    s.ok ? chipPrev(s.icon || app.icon) : h('span', { class: 'sc-badge' }, 'غير متاح')));
  const appRow = h('div', { class: 'sc-row' + (appOn ? ' on' : ''), role: 'button', tabindex: 0, onclick: () => toggleSc('app', !appOn) },
    h('i', { class: 'sc-check' }, icon('check', 13)), h('img', { src: app.icon, alt: '' }), h('span', { class: 'sc-t' }, h('b', {}, 'فتح ' + app.label), h('small', {}, 'أيقونة التطبيق نفسه')), chipPrev(app.icon));
  const okList = items.filter(s => s.ok);
  return h('div', { class: 'ie-srcbox' },
    h('div', { class: 'ie-srch' }, h('img', { src: app.icon, alt: '' }), h('b', {}, app.label), h('small', {}, scCount(okList.length) + (items.length > okList.length ? ` · ${items.length - okList.length} غير متاح` : ''))),
    h('div', { class: 'chips' },
      okList.length ? h('button', { type: 'button', class: 'chip', onclick: () => selectAll(g, app, okList) }, 'تحديد الكل') : null,
      h('button', { type: 'button', class: 'chip', onclick: () => clearApp(app.pkg) }, 'إلغاء التحديد'),
      okList.length ? h('button', { type: 'button', class: 'chip', onclick: async () => { await clearApp(app.pkg); await selectAll(g, app, okList.slice(0, 6)); } }, 'استعادة الاختصارات الأصلية') : null,
      (info.creators || []).map(c => h('button', { type: 'button', class: 'chip', onclick: () => legacyFlow(app, c, true) }, icon('plus', 13), c.label))),
    h('div', { class: 'sc-list' }, appRow, ...rows),
    !items.length ? h('p', { class: 'fine' }, (info.creators || []).length ? 'لا يعلن هذا التطبيق اختصارات ثابتة، لكن يمكنك إنشاء اختصار مخصص من الأزرار أعلاه.' : 'هذا التطبيق لا يوفّر اختصارات داخلية يمكن لتطبيق آخر فتحها. يمكنك إضافة التطبيق نفسه.') : null);
}
async function selectAll(g, app, list) {
  const color = g.color || await iconColor(app.icon), small = await shrinkIcon(app.icon, 48);
  update(d => {
    const gg = d.collections.groups[INNER.grp]; if (!gg) return;
    for (const s of list) { if (gg.ids.some(id => { const it = d.items.find(x => x.id === id); return it && sameSc(it, app.pkg, s); })) continue; const it = Object.assign({ id: uid() }, scItem(app, s, color, small)); d.items.push(it); gg.ids.push(it.id); }
  });
  ieBody();
}
async function clearApp(pkg) {
  update(d => { const gg = d.collections.groups[INNER.grp]; if (!gg) return; const rm = d.items.filter(it => gg.ids.includes(it.id) && it.kind === 'ishort' && it.pkg === pkg).map(it => it.id); d.items = d.items.filter(it => !rm.includes(it.id)); gg.ids = gg.ids.filter(id => !rm.includes(id)); });
  ieBody();
}
async function newEmptyGroup() {
  const name = await promptBox('مجموعة جديدة', 'اسم المجموعة', 'مجموعة');
  if (!name) return;
  update(d => d.collections.groups.push({ id: uid(), name, pkg: '', apps: [], icon: '', glyph: 'layers', color: PALETTE[d.collections.groups.length % PALETTE.length], bg: 'auto', ids: [], show: true }));
  INNER.grp = draft.collections.groups.length - 1; ieBody();
  if (hasInnerNative()) toast('اختر «إضافة تطبيق» لإضافة مصادر الاختصارات إلى المجموعة');
}
async function saveCollTemplate() {
  const name = await promptBox('حفظ كقالب', 'اسم القالب', draft.name || 'قالبي');
  if (!name) return;
  const list = store.get('llx.collTpl', []) || [];
  list.unshift({ id: uid(), n: name, d: clone(draft) });
  store.set('llx.collTpl', list.slice(0, 20));
  toast(`حُفظ القالب «${name}»`);
}
function testShortcut(it) {
  nativeRequest('innerTest', () => window.LaunchyNative.testInnerShortcut(it.value)).then(r => {
    if (r && r.ok) return;
    openDialog('الاختصار لم يُفتح', h('p', {}, (r && r.why) || 'لم يعد التطبيق يوفّر هذا الاختصار — ربما تغيّر بعد تحديثه. احذفه وأضفه من جديد.'), [{ label: 'حسناً', cls: 'btn-gold' }]);
  });
}
function editIShort(it) {
  const inp = h('input', { type: 'text', class: 'inp', value: it.label, maxlength: 40 });
  openDialog('تعديل الاختصار', h('div', { class: 'form' },
    h('div', { class: 'it-prev' }, itemIcon(it, 52), h('div', { class: 'it-txt' }, h('strong', {}, it.label), h('small', {}, it.kind === 'ishort' ? (it.app || '') + ' · اختصار داخلي' : KIND[it.kind].n))),
    h('label', { class: 'field' }, h('span', {}, 'الاسم الظاهر'), inp),
    it.kind === 'ishort' && NATIVE && window.LaunchyNative.verifyInnerShortcut ? (() => { let w = ''; try { w = window.LaunchyNative.verifyInnerShortcut(it.value); } catch (e) {} return h('p', { class: 'fine' }, w ? '⚠ ' + w : '✓ ما زال الاختصار متاحاً في التطبيق المثبت'); })() : null), [
    { label: 'حفظ', cls: 'btn-gold', onClick: () => { const v = inp.value.trim(); if (!v) return false; update(d => { const x = d.items.find(i => i.id === it.id); if (x) x.label = v; }, { rebuild: true }); ieRebuild(); } },
    { label: 'إلغاء', cls: 'btn-ghost' }]);
}

/* ---------------------------------------------------------- editor integration */
function collectionsPanel() {
  const o = draft.collections;
  return [
    h('div', { class: 'note' }, icon('layers', 16), h('span', {}, 'تبويبات «النمط» و«التباعد» و«الاختصارات» الكاملة في محرر الأداة.')),
    h('a', { class: 'btn btn-gold btn-sm', href: '#/inner-edit' }, icon('edit', 15), 'فتح محرر الأداة'),
    h('div', { class: 'sub-h' }, 'التخطيط'),
    h('div', { class: 'chips' }, COLL_LAYOUTS.map(([k, n]) => h('button', { type: 'button', class: 'chip' + (o.layout === k ? ' on' : ''), onclick: () => update(d => d.collections.layout = k, { rebuild: true }) }, n))),
    h('div', { class: 'sub-h' }, 'شكل الأيقونات'),
    h('div', { class: 'chips' }, CHIP_STYLES.map(([k, n]) => h('button', { type: 'button', class: 'chip' + (o.chip === k ? ' on' : ''), onclick: () => update(d => d.collections.chip = k, { rebuild: true }) }, n))),
    slider('عدد الأعمدة', 'collections.cols', 1, 8), slider('المسافة بين الأيقونات', 'collections.gap', 2, 28, 1, 'px'),
    slider('حجم الأيقونات', 'collections.icon', 50, 130, 1, '%'),
    toggle('إظهار الأسماء', 'collections.labels'), toggle('رأس المجموعة', 'collections.head'), toggle('تلوين الأيقونات بلون التطبيق', 'collections.tint')];
}
/** Home-card preview: a demo collection in the reference look (clearly a preview, not a real widget). */
function innerHomeDesign() {
  const d = newDesign({ type: 'collections', style: 'quiet', theme: 'gold' });
  Object.assign(d.a, styleLook('quiet'));
  d.collections.chip = 'auto'; d.sizes.collections = [2, 2];
  return d;
}

/* ---------------------------------------------------------- typing on a phone
   While the keyboard is open the sticky preview and the bottom bars would cover the field
   being typed in; they step aside and the field is scrolled into view. */
(function keyboardAware() {
  const isField = el => !!el && (el.tagName === 'TEXTAREA' || el.isContentEditable ||
    (el.tagName === 'INPUT' && !['range', 'checkbox', 'radio', 'color', 'button', 'submit', 'file', 'reset'].includes(el.type)));
  const touch = () => window.matchMedia('(pointer:coarse)').matches || window.innerWidth < 980;
  const reveal = () => { const el = document.activeElement; if (isField(el)) try { el.scrollIntoView({ block: 'center', behavior: 'smooth' }); } catch (e) {} };
  const sync = () => {
    const on = isField(document.activeElement) && touch();
    document.body.classList.toggle('kb-open', on);
    if (on) { setTimeout(reveal, 80); setTimeout(reveal, 420); }
  };
  document.addEventListener('focusin', e => { if (isField(e.target)) sync(); });
  document.addEventListener('focusout', () => setTimeout(sync, 120));
  if (window.visualViewport) window.visualViewport.addEventListener('resize', () => { if (document.body.classList.contains('kb-open')) reveal(); });
})();
