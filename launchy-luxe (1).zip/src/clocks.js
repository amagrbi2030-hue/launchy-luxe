/* =========================================================
   Luxury clock painter: bezels, dials, indices, numerals and
   hands. The same hand drawings become the hand images of the
   live Android clock, so the home screen matches the preview.
   ========================================================= */
const clockFontsReady = new Set();
/** Register the bundled digit fonts (data URLs) once; resolves when `key` is usable. */
function useClockFont(key, digits) {
  const name = clockFontName(key, digits);
  if (clockFontsReady.has(name)) return Promise.resolve();
  const file = 'llx_' + key + '_' + (digits === 'arab' && key !== 'led' ? 'a' : 'l');
  const src = CLOCK_FONT_DATA[file]; if (!src) return Promise.resolve();
  clockFontsReady.add(name);
  try {
    const ff = new FontFace(name, `url(${src})`);
    document.fonts.add(ff);
    return ff.load().then(() => { for (const fn of [...imgWaiters]) fn(); for (const el of document.querySelectorAll('.wcv')) if (el._redraw) el._redraw(); }).catch(() => {});
  } catch (e) { return Promise.resolve(); }
}
const clockFontName = (key, digits) => 'LLX ' + key + ' ' + (digits === 'arab' && key !== 'led' ? 'a' : 'l');
const clockFontMeta = key => CLOCK_FONTS.find(f => f.k === key) || CLOCK_FONTS[0];
/** Draw text like an Android TextView centred in a box (same metrics as TextClock). */
function drawClockText(ctx, text, cx, cy, size, font, digits, color, align = 'center', x0, w) {
  const m = clockFontMeta(font), k = size / 1000;
  ctx.save();
  ctx.font = `${size}px "${clockFontName(font, digits)}", sans-serif`;
  ctx.textBaseline = 'alphabetic'; ctx.direction = 'ltr';
  ctx.textAlign = align === 'center' ? 'center' : align === 'left' ? 'left' : 'right';
  ctx.fillStyle = color;
  const x = align === 'center' ? cx : align === 'left' ? x0 : x0 + w;
  ctx.fillText(text, x, cy + (m.asc + m.desc) * k / 2);
  ctx.restore();
}
function measureClockText(ctx, text, size, font, digits) {
  ctx.save(); ctx.font = `${size}px "${clockFontName(font, digits)}", sans-serif`; const w = ctx.measureText(text).width; ctx.restore(); return w;
}

/* ---------------------------------------------------------- catalogues */
const HAND_STYLES = [['breguet', 'بريغيه الكلاسيكية'], ['geometric', 'هندسية'], ['dauphine', 'دوفين المشطوفة'], ['baton', 'العصا'], ['sword', 'السيف'], ['spade', 'البستوني الفيكتورية'], ['royal', 'الملكية المزخرفة'], ['modern', 'الحديثة الرفيعة']];
const NUMERALS = [['roman', 'رومانية'], ['arabic', 'عربية مشرقية ١٢'], ['western', 'لاتينية 12'], ['cardinal', 'أربعة أرقام رئيسية'], ['indices', 'مؤشرات بلا أرقام'], ['none', 'بدون']];
const INDEX_STYLES = [['bars', 'قضبان مطبقة'], ['dots', 'نقاط'], ['diamonds', 'ماسات'], ['lines', 'خطوط رفيعة'], ['none', 'بدون']];
const DIALS = [['ivory', 'عاجي'], ['white', 'أبيض نقي'], ['black', 'أسود لامع'], ['sunburst', 'أشعة شمسية'], ['material', 'من مكتبة الخامات'], ['glass', 'زجاجي شفاف'], ['solid', 'لون موحد'], ['none', 'بدون (تظهر الخلفية)']];
const BEZELS = [['goldMulti', 'ذهبي متعدد الطبقات'], ['gold', 'ذهبي بسيط'], ['woodDark', 'خشب بني داكن'], ['velvet3d', 'مخمل بارز'], ['chrome', 'كروم'], ['silver', 'فضي'], ['glass', 'زجاج سائل مضيء'], ['marble', 'رخام'], ['thin', 'خط رفيع'], ['none', 'بدون']];
const HAND_COLORS = [['gold', 'ذهبي', '#d4af37'], ['rose', 'ذهبي وردي', '#d9a08a'], ['silver', 'فضي', '#c9ced6'], ['black', 'أسود', '#16161a'], ['brown', 'بني', '#5a3818'], ['blued', 'فولاذ أزرق', '#2a4f9e'], ['white', 'أبيض', '#f6f6f2'], ['copper', 'نحاسي', '#b87333'], ['luminous', 'مضيء', '#d8fff0'], ['glass', 'زجاجي', '#ffffff'], ['theme', 'لون الثيم', '']];
const METAL_HANDS = new Set(['gold', 'rose', 'silver', 'copper']);
const handBase = (o, L) => { const c = HAND_COLORS.find(x => x[0] === o.handColor); return c && c[2] ? c[2] : (o.handColor && o.handColor[0] === '#' ? o.handColor : L.acc); };
const ROMAN = ['XII', 'I', 'II', 'III', 'IIII', 'V', 'VI', 'VII', 'VIII', 'IX', 'X', 'XI'];

/* ---------------------------------------------------------- bezel & dial */
/** Returns the dial radius after drawing the bezel ring. */
function paintBezel(ctx, S, L, cx, cy, R, o) {
  const kind = o.bezel || 'none', w = R * (o.bezelW ?? 100) / 100 * ({ goldMulti: .16, gold: .09, woodDark: .15, velvet3d: .17, chrome: .1, silver: .08, glass: .1, marble: .14, thin: .025, none: 0 }[kind] ?? .1);
  if (kind === 'none' || w <= 0) return R;
  const ring = new Path2D(); ring.arc(cx, cy, R, 0, TAU); ring.arc(cx, cy, R - w, 0, TAU, true);
  const outer = new Path2D(); outer.arc(cx, cy, R, 0, TAU);
  const box = { x: cx - R, y: cy - R, w: 2 * R, h: 2 * R };
  outerShadow(ctx, S, outer, 'rgba(0,0,0,.45)', R * .08, 0, R * .03);
  ctx.save();
  const metal = base => { const g = ctx.createLinearGradient(cx - R, cy - R, cx + R, cy + R); for (const [t, c] of metalStops(base)) g.addColorStop(t, c); return g; };
  switch (kind) {
    case 'goldMulti': case 'gold': ctx.fillStyle = metal(o.bezelColor || '#d4af37'); break;
    case 'silver': ctx.fillStyle = metal('#c9ced6'); break;
    case 'chrome': ctx.fillStyle = materialFill(ctx, 'chrome', null, R * 1.6); break;
    case 'woodDark': ctx.fillStyle = materialFill(ctx, 'darkWood', null, R * 1.4); break;
    case 'marble': ctx.fillStyle = materialFill(ctx, o.bezelMat || 'marbleBlack', null, R * 1.6); break;
    case 'velvet3d': ctx.fillStyle = materialFill(ctx, 'velvet', L.A, R * .9); break;
    case 'glass': { const g = ctx.createLinearGradient(cx - R, cy - R, cx + R, cy + R); g.addColorStop(0, 'rgba(255,255,255,.55)'); g.addColorStop(.45, 'rgba(255,255,255,.08)'); g.addColorStop(1, 'rgba(255,255,255,.35)'); ctx.fillStyle = g; break; }
    case 'thin': ctx.fillStyle = L.frameColor; break;
  }
  ctx.fill(ring, 'evenodd');
  ctx.restore();
  // depth: rounded profile + edges
  ctx.save(); ctx.clip(ring, 'evenodd');
  const prof = ctx.createRadialGradient(cx, cy, R - w, cx, cy, R);
  if (kind === 'velvet3d') { prof.addColorStop(0, 'rgba(0,0,0,.55)'); prof.addColorStop(.45, 'rgba(255,255,255,.10)'); prof.addColorStop(1, 'rgba(0,0,0,.6)'); }
  else if (kind === 'glass') { prof.addColorStop(0, 'rgba(255,255,255,.0)'); prof.addColorStop(.8, 'rgba(255,255,255,.18)'); prof.addColorStop(1, 'rgba(255,255,255,.55)'); }
  else { prof.addColorStop(0, 'rgba(0,0,0,.35)'); prof.addColorStop(.35, 'rgba(255,255,255,.18)'); prof.addColorStop(.7, 'rgba(0,0,0,.05)'); prof.addColorStop(1, 'rgba(0,0,0,.4)'); }
  ctx.fillStyle = prof; ctx.fillRect(box.x, box.y, box.w, box.h);
  ctx.restore();
  ctx.save(); ctx.lineWidth = Math.max(.5, R * .006);
  if (kind === 'goldMulti') {
    // grooves, beading and a fine inner gold ring
    ctx.strokeStyle = 'rgba(70,45,5,.75)'; ctx.beginPath(); ctx.arc(cx, cy, R - w * .32, 0, TAU); ctx.stroke(); ctx.beginPath(); ctx.arc(cx, cy, R - w * .66, 0, TAU); ctx.stroke();
    const n = Math.max(24, Math.round(R * .55)), rb = R - w * .49;
    for (let i = 0; i < n; i++) { const a = i * TAU / n, x = cx + Math.cos(a) * rb, y = cy + Math.sin(a) * rb; const g = ctx.createRadialGradient(x - w * .04, y - w * .04, 0, x, y, w * .12); g.addColorStop(0, '#fff6cf'); g.addColorStop(.5, '#d9b24c'); g.addColorStop(1, '#6b4a10'); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, w * .1, 0, TAU); ctx.fill(); }
  }
  if (kind === 'velvet3d') { ctx.setLineDash([R * .025, R * .02]); ctx.strokeStyle = rgba(mix(L.A, '#ffffff', .55), .5); ctx.beginPath(); ctx.arc(cx, cy, R - w * .5, 0, TAU); ctx.stroke(); ctx.setLineDash([]); }
  if (kind === 'woodDark') { ctx.strokeStyle = metal('#d4af37'); ctx.lineWidth = Math.max(1, R * .018); ctx.beginPath(); ctx.arc(cx, cy, R - w + R * .01, 0, TAU); ctx.stroke(); }
  if (kind === 'glass') { ctx.shadowColor = rgba(L.a.lightColor || '#9ef3ff', .9); ctx.shadowBlur = R * .08 * S; ctx.strokeStyle = rgba('#ffffff', .8); ctx.lineWidth = Math.max(1, R * .012); ctx.beginPath(); ctx.arc(cx, cy, R - R * .006, -2.6, -.6); ctx.stroke(); ctx.beginPath(); ctx.arc(cx, cy, R - w, .6, 2.4); ctx.stroke(); }
  ctx.strokeStyle = 'rgba(0,0,0,.35)'; ctx.lineWidth = Math.max(.5, R * .006); ctx.beginPath(); ctx.arc(cx, cy, R - w, 0, TAU); ctx.stroke();
  ctx.restore();
  return R - w;
}
function paintDial(ctx, S, L, cx, cy, r, o) {
  const P = new Path2D(); P.arc(cx, cy, r, 0, TAU);
  const kind = o.dial || 'ivory';
  ctx.save();
  if (kind === 'ivory' || kind === 'white') {
    const g = ctx.createRadialGradient(cx - r * .25, cy - r * .3, r * .05, cx, cy, r * 1.05);
    if (kind === 'ivory') { g.addColorStop(0, '#fffaf0'); g.addColorStop(.65, '#f3e9d2'); g.addColorStop(1, '#dccaa4'); } else { g.addColorStop(0, '#ffffff'); g.addColorStop(.7, '#f4f5f7'); g.addColorStop(1, '#d9dce1'); }
    ctx.fillStyle = g; ctx.fill(P);
    ctx.globalAlpha = .18; ctx.fillStyle = materialFill(ctx, 'porcelain', null, r * 1.2) || g; ctx.fill(P); ctx.globalAlpha = 1;
  } else if (kind === 'black') {
    const g = ctx.createRadialGradient(cx - r * .3, cy - r * .35, r * .05, cx, cy, r * 1.1); g.addColorStop(0, '#3a3a40'); g.addColorStop(.5, '#121214'); g.addColorStop(1, '#050506');
    ctx.fillStyle = g; ctx.fill(P);
  } else if (kind === 'sunburst') {
    const base = o.dialColor || L.A;
    ctx.fillStyle = base; ctx.fill(P);
    if (ctx.createConicGradient) { const cg = ctx.createConicGradient(-Math.PI / 4, cx, cy); for (let i = 0; i <= 8; i++) cg.addColorStop(i / 8, i % 2 ? rgba('#ffffff', .22) : rgba('#000000', .25)); ctx.fillStyle = cg; ctx.fill(P); }
    ctx.save(); ctx.clip(P); ctx.strokeStyle = rgba('#ffffff', .05); ctx.lineWidth = Math.max(.4, r * .004);
    for (let i = 0; i < 180; i++) { const a = i * TAU / 180; ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r); ctx.stroke(); }
    ctx.restore();
  } else if (kind === 'material' && o.dialMat && MAT[o.dialMat]) {
    ctx.fillStyle = materialFill(ctx, o.dialMat, MAT[o.dialMat].tint ? (o.dialTint || L.A) : null, r * 1.1); ctx.fill(P);
    const g = ctx.createRadialGradient(cx - r * .3, cy - r * .35, 0, cx, cy, r); g.addColorStop(0, 'rgba(255,255,255,.12)'); g.addColorStop(1, 'rgba(0,0,0,.18)'); ctx.fillStyle = g; ctx.fill(P);
  } else if (kind === 'solid') { ctx.fillStyle = o.dialColor || L.A; ctx.fill(P); }
  else if (kind === 'glass') {
    const g = ctx.createLinearGradient(cx - r, cy - r, cx + r, cy + r); g.addColorStop(0, 'rgba(255,255,255,.22)'); g.addColorStop(.5, 'rgba(255,255,255,.04)'); g.addColorStop(1, 'rgba(255,255,255,.14)');
    ctx.fillStyle = g; ctx.fill(P);
    ctx.save(); ctx.clip(P); const hl = new Path2D(); hl.ellipse(cx - r * .2, cy - r * .55, r * .9, r * .45, -.35, 0, TAU); ctx.fillStyle = 'rgba(255,255,255,.10)'; ctx.fill(hl); ctx.restore();
  }
  ctx.restore();
  if (kind !== 'none' && kind !== 'glass') innerShadow(ctx, S, P, 'rgba(0,0,0,.45)', r * .07, 0, r * .02);
  if (o.ornaments) paintDialOrnament(ctx, S, L, cx, cy, r, o);
}
/** Fine engraved rings + small stars (royal dials). */
function paintDialOrnament(ctx, S, L, cx, cy, r, o) {
  const col = dialInk(o, L, .5);
  ctx.save(); ctx.strokeStyle = col; ctx.lineWidth = Math.max(.4, r * .006);
  ctx.beginPath(); ctx.arc(cx, cy, r * .62, 0, TAU); ctx.stroke();
  ctx.beginPath(); ctx.arc(cx, cy, r * .58, 0, TAU); ctx.stroke();
  for (let i = 0; i < 48; i++) { const a = i * TAU / 48; ctx.beginPath(); ctx.arc(cx + Math.cos(a) * r * .6, cy + Math.sin(a) * r * .6, r * .055, a + 1.2, a + 2.0); ctx.stroke(); }
  ctx.fillStyle = col;
  const st = new Path2D(); star8(st, cx, cy, r * .14); ctx.globalAlpha = .55; ctx.stroke(st);
  ctx.restore();
}
/** Ink colour on the dial (numerals/indices). */
function dialInk(o, L, a = 1) {
  if (o.ink) return rgba(o.ink, a);
  const k = o.dial || 'ivory';
  if (k === 'ivory' || k === 'white') return rgba(o.bezel === 'woodDark' ? '#3a2412' : '#1d1a16', a);
  if (k === 'black') return rgba(METAL_HANDS.has(o.handColor) ? '#e6c56a' : '#f2f2f2', a);
  if (k === 'material' && o.dialMat && MAT[o.dialMat] && (MAT[o.dialMat].g === 'metal' || o.dialMat.startsWith('marbleWhite') || o.dialMat === 'porcelain' || o.dialMat === 'pearl')) return rgba('#2a1d08', a);
  return rgba(L.text.slice(0, 7), a);
}
function paintIndices(ctx, S, L, cx, cy, r, o) {
  const ink = dialInk(o, L), style = o.indices || 'bars', num = o.numerals || 'roman';
  ctx.save();
  if (o.ticks !== false) { // minute track
    ctx.strokeStyle = dialInk(o, L, .55); ctx.lineWidth = Math.max(.4, r * .008);
    for (let i = 0; i < 60; i++) { if (i % 5 === 0 && style !== 'none') continue; const a = i * TAU / 60; ctx.beginPath(); ctx.moveTo(cx + Math.sin(a) * r * .95, cy - Math.cos(a) * r * .95); ctx.lineTo(cx + Math.sin(a) * r * .9, cy - Math.cos(a) * r * .9); ctx.stroke(); }
  }
  const skip = i => num !== 'indices' && num !== 'none' && (num !== 'cardinal' || i % 3 === 0);
  for (let i = 0; i < 12; i++) {
    if (skip(i) && style !== 'lines') continue;
    const a = i * TAU / 12, sx = Math.sin(a), sy = -Math.cos(a);
    if (style === 'bars') {
      const len = r * (i % 3 === 0 ? .17 : .12), wd = r * (i % 3 === 0 ? .05 : .035), mid = r * .86 - len / 2;
      ctx.save(); ctx.translate(cx + sx * mid, cy + sy * mid); ctx.rotate(a);
      const p = new Path2D(); rrPath(p, -wd / 2, -len / 2, wd, len, wd * .3);
      outerShadow(ctx, S, p, 'rgba(0,0,0,.4)', r * .015, r * .006, r * .01);
      const base = METAL_HANDS.has(o.handColor) ? handBase(o, L) : ink.startsWith('rgba') ? L.frameColor : ink;
      const g = ctx.createLinearGradient(-wd / 2, 0, wd / 2, 0); g.addColorStop(0, mix(base, '#ffffff', .5)); g.addColorStop(.5, base); g.addColorStop(1, mix(base, '#000000', .45));
      ctx.fillStyle = g; ctx.fill(p); ctx.restore();
    } else if (style === 'dots') { ctx.fillStyle = ink; ctx.beginPath(); ctx.arc(cx + sx * r * .85, cy + sy * r * .85, r * (i % 3 === 0 ? .04 : .028), 0, TAU); ctx.fill(); }
    else if (style === 'diamonds') { ctx.fillStyle = METAL_HANDS.has(o.handColor) ? handBase(o, L) : ink; const p = new Path2D(); diamond(p, cx + sx * r * .85, cy + sy * r * .85, r * .03, r * .05); ctx.save(); ctx.translate(0, 0); ctx.fill(p); ctx.restore(); }
    else if (style === 'lines') { ctx.strokeStyle = ink; ctx.lineWidth = Math.max(.6, r * (i % 3 === 0 ? .022 : .012)); ctx.beginPath(); ctx.moveTo(cx + sx * r * .95, cy + sy * r * .95); ctx.lineTo(cx + sx * r * (i % 3 === 0 ? .8 : .86), cy + sy * r * (i % 3 === 0 ? .8 : .86)); ctx.stroke(); }
  }
  ctx.restore();
  if (num === 'none' || num === 'indices') return;
  const font = o.numFont || (num === 'roman' ? 'royal' : 'serif');
  const digits = num === 'arabic' ? 'arab' : 'latn';
  const R2 = r * (style === 'none' || style === 'lines' ? .8 : (num === 'roman' ? .7 : .72));
  for (let i = 0; i < 12; i++) {
    if (num === 'cardinal' && i % 3) continue;
    const a = i * TAU / 12, t = num === 'roman' ? ROMAN[i] : String(i === 0 ? 12 : i);
    const size = r * (num === 'roman' ? (t.length > 3 ? .15 : .19) : num === 'cardinal' ? .26 : .2) * (o.numScale || 1);
    const x = cx + Math.sin(a) * R2, y = cy - Math.cos(a) * R2;
    if (o.raised) { // embossed numerals on velvet & leather
      drawClockText(ctx, t, x + r * .008, y + r * .012, size, font, digits, 'rgba(0,0,0,.55)');
      drawClockText(ctx, t, x - r * .006, y - r * .008, size, font, digits, 'rgba(255,255,255,.35)');
    }
    drawClockText(ctx, t, x, y, size, font, digits, ink);
  }
}

/* ---------------------------------------------------------- hands */
const HAND_LEN = { h: .5, m: .76, s: .84 };
function handPath(style, which, R, o = {}) {
  const p = new Path2D(), len = R * HAND_LEN[which] * clamp((o.handL || 100) / 100, .7, 1.2), tail = R * (which === 's' ? .18 : .1);
  const w = R * ({ h: .055, m: .04, s: .012 }[which]) * (style === 'modern' ? .6 : style === 'baton' ? 1.05 : 1) * clamp((o.handW || 100) / 100, .5, 1.8);
  if (which === 's') {
    switch (o.secStyle) {
      case 'lollipop': p.rect(-w / 2, -len, w, len + tail * .6); p.moveTo(R * .045, -len * .78); p.arc(0, -len * .78, R * .045, 0, TAU); p.moveTo(R * .03, -len * .78); p.arc(0, -len * .78, R * .03, 0, TAU, true); break;
      case 'arrow': p.rect(-w / 2, -len * .86, w, len * .86 + tail * .5); p.moveTo(0, -len); p.lineTo(R * .03, -len * .84); p.lineTo(-R * .03, -len * .84); p.closePath(); break;
      case 'thin': p.rect(-w * .3, -len, w * .6, len + tail * .3); break;
      default: p.rect(-w / 2, -len, w, len + tail); p.arc(0, tail * .85, R * .035, 0, TAU);
    }
    return p;
  }
  switch (style) {
    case 'geometric': p.moveTo(0, -len); p.lineTo(w * 1.1, -len * .8); p.lineTo(w * .75, tail); p.lineTo(-w * .75, tail); p.lineTo(-w * 1.1, -len * .8); p.closePath();
      p.moveTo(0, -len * .78); p.lineTo(w * .45, -len * .66); p.lineTo(0, -len * .2); p.lineTo(-w * .45, -len * .66); p.closePath(); break;
    case 'baton': rrPath(p, -w / 2, -len, w, len + tail, w / 2); break;
    case 'modern': rrPath(p, -w / 2, -len, w, len + tail * .6, w / 2); break;
    case 'dauphine': p.moveTo(0, -len); p.lineTo(w * 1.2, -len * .12); p.lineTo(w * .35, tail); p.lineTo(-w * .35, tail); p.lineTo(-w * 1.2, -len * .12); p.closePath(); break;
    case 'sword': p.moveTo(0, -len); p.bezierCurveTo(w * .9, -len * .8, w * 1.15, -len * .35, w * .5, tail * .4); p.lineTo(w * .3, tail); p.lineTo(-w * .3, tail); p.lineTo(-w * .5, tail * .4); p.bezierCurveTo(-w * 1.15, -len * .35, -w * .9, -len * .8, 0, -len); break;
    case 'spade': {
      const sw = w * .45; p.rect(-sw / 2, -len * .72, sw, len * .72 + tail);
      const y0 = -len * .72; p.moveTo(0, y0 + w * .6); p.bezierCurveTo(w * 2, y0 + w * .2, w * 1.4, y0 - w * 2.2, 0, y0 - w * 2.6); p.bezierCurveTo(-w * 1.4, y0 - w * 2.2, -w * 2, y0 + w * .2, 0, y0 + w * .6);
      p.moveTo(-sw / 2, y0 - w * 2.4); p.lineTo(0, -len); p.lineTo(sw / 2, y0 - w * 2.4); p.closePath(); break;
    }
    case 'royal': {
      const sw = w * .42; p.rect(-sw / 2, -len * .55, sw, len * .55 + tail);
      const y0 = -len * .55; diamond(p, 0, y0 - w * 1.1, w * 1.05, w * 1.6);
      p.moveTo(-sw / 2, y0 - w * 2.4); p.lineTo(-w * .5, -len * .86); p.lineTo(0, -len); p.lineTo(w * .5, -len * .86); p.lineTo(sw / 2, y0 - w * 2.4); p.closePath();
      p.moveTo(w * .9, tail * .4); p.arc(0, tail * .4, w * .9, 0, TAU); break;
    }
    default: { // breguet: slim shaft, hollow moon near the tip
      const sw = w * .38, rr = w * (which === 'h' ? 1.35 : 1.05), yc = -len * (which === 'h' ? .7 : .78);
      p.rect(-sw / 2, yc + rr * .9, sw, -yc - rr * .9 + tail);
      p.moveTo(rr, yc); p.arc(0, yc, rr, 0, TAU); p.moveTo(rr * .55, yc); p.arc(0, yc, rr * .55, 0, TAU, true);
      p.moveTo(-sw / 2, yc - rr * .9); p.lineTo(0, -len); p.lineTo(sw / 2, yc - rr * .9); p.closePath();
    }
  }
  return p;
}
/** One hand pointing at angle `ang` (radians, 0 = 12 o'clock). */
function paintHand(ctx, S, L, cx, cy, R, o, which, ang) {
  const style = which === 's' ? 's' : ((which === 'h' ? o.hourStyle : o.minStyle) || o.hands || 'breguet');
  const p = handPath(style, which, R, o);
  const shK = (o.shadowK ?? 50) / 50;
  ctx.save(); ctx.translate(cx, cy); ctx.rotate(ang);
  const base = which === 's' ? (o.secColor || '#c0392b') : handBase(o, L);
  const dy = R * (o.raised ? .045 : .022);
  // shadow drawn in screen space below the hand
  // the shadow lives in the hand's own frame, so the live Android hands carry it identically
  ctx.save(); ctx.translate(dy * .35, dy * .5);
  ctx.filter = `blur(${Math.max(.5, R * (o.raised ? .03 : .018)) * S}px)`; ctx.fillStyle = `rgba(0,0,0,${Math.min(.9, (o.raised ? .5 : .35) * shK)})`; ctx.fill(p, 'evenodd'); ctx.restore();
  ctx.filter = 'none';
  const metal = METAL_HANDS.has(o.handColor) && which !== 's';
  const w = R * .06;
  let fill;
  if (o.handColor === 'glass' && which !== 's') { ctx.fillStyle = 'rgba(255,255,255,.3)'; ctx.fill(p, 'evenodd'); ctx.lineWidth = Math.max(.5, R * .008); ctx.strokeStyle = 'rgba(255,255,255,.9)'; ctx.stroke(p); if (o.glowHands) { ctx.shadowColor = rgba(o.glowHands, .8 * (o.glowA ?? 1)); ctx.shadowBlur = R * .05 * S; ctx.stroke(p); } ctx.restore(); return; }
  if (o.handColor === 'luminous' && which !== 's') { ctx.shadowColor = rgba(o.glowHands || '#9effd0', .95 * (o.glowA ?? 1)); ctx.shadowBlur = R * .07 * S; }
  if (metal || style === 'dauphine' || style === 'geometric') { const g = ctx.createLinearGradient(-w, 0, w, 0); g.addColorStop(0, mix(base, '#ffffff', .55)); g.addColorStop(.49, mix(base, '#ffffff', .15)); g.addColorStop(.51, mix(base, '#000000', .3)); g.addColorStop(1, mix(base, '#000000', .5)); fill = g; }
  else { const g = ctx.createLinearGradient(-w, 0, w, 0); g.addColorStop(0, mix(base, '#ffffff', .18)); g.addColorStop(1, mix(base, '#000000', .2)); fill = g; }
  ctx.fillStyle = fill; ctx.fill(p, 'evenodd');
  ctx.shadowBlur = 0;
  if (style === 'modern' && which !== 's') { ctx.fillStyle = rgba(o.lume || '#e9f7ea', .85); const lp = new Path2D(); rrPath(lp, -R * .006, -R * HAND_LEN[which] * .92, R * .012, R * HAND_LEN[which] * .6, R * .006); ctx.fill(lp); }
  ctx.lineWidth = Math.max(.3, R * .004); ctx.strokeStyle = rgba(mix(base, '#000000', .6), .6); ctx.stroke(p);
  if (o.glowHands) { const ga = o.glowA ?? 1; ctx.shadowColor = rgba(o.glowHands, .9 * ga); ctx.shadowBlur = R * .05 * S * (.5 + ga); ctx.fillStyle = rgba(o.glowHands, .25 * ga); ctx.fill(p, 'evenodd'); }
  ctx.restore();
}
function paintCap(ctx, S, L, cx, cy, R, o) {
  const base = o.seconds ? (o.secColor || '#c0392b') : handBase(o, L), r = R * .045, cap = o.cap || 'dome';
  if (cap === 'none') return;
  ctx.save();
  if (cap !== 'dome') {
    const g2 = ctx.createRadialGradient(cx - r * .35, cy - r * .35, 0, cx, cy, r * 1.3); g2.addColorStop(0, mix(base, '#ffffff', .7)); g2.addColorStop(.6, base); g2.addColorStop(1, mix(base, '#000000', .5));
    ctx.fillStyle = g2;
    if (cap === 'ring') { ctx.beginPath(); ctx.arc(cx, cy, r * 1.15, 0, TAU); ctx.arc(cx, cy, r * .55, 0, TAU, true); ctx.fill('evenodd'); }
    else if (cap === 'flat') { ctx.beginPath(); ctx.arc(cx, cy, r * 1.25, 0, TAU); ctx.fill(); ctx.lineWidth = r * .15; ctx.strokeStyle = rgba(mix(base, '#000000', .5), .8); ctx.stroke(); }
    else if (cap === 'jewel') { ctx.beginPath(); ctx.arc(cx, cy, r * 1.2, 0, TAU); ctx.fill(); const j = ctx.createRadialGradient(cx - r * .2, cy - r * .2, 0, cx, cy, r * .6); j.addColorStop(0, '#ffd1dc'); j.addColorStop(1, '#a3123a'); ctx.fillStyle = j; ctx.beginPath(); ctx.arc(cx, cy, r * .6, 0, TAU); ctx.fill(); }
    else if (cap === 'star') { const p = new Path2D(); for (let i = 0; i < 16; i++) { const a = i * Math.PI / 8, rr = i % 2 ? r * .7 : r * 1.5; i ? p.lineTo(cx + Math.sin(a) * rr, cy - Math.cos(a) * rr) : p.moveTo(cx, cy - rr); } p.closePath(); ctx.fill(p); }
    ctx.restore(); return;
  }
  const g = ctx.createRadialGradient(cx - r * .35, cy - r * .35, 0, cx, cy, r); g.addColorStop(0, mix(base, '#ffffff', .7)); g.addColorStop(.6, base); g.addColorStop(1, mix(base, '#000000', .5));
  ctx.fillStyle = g; ctx.beginPath(); ctx.arc(cx, cy, r, 0, TAU); ctx.fill();
  ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.beginPath(); ctx.arc(cx, cy, r * .3, 0, TAU); ctx.fill();
  ctx.restore();
}
/** Hand angles for a time {h,m,s,ms}. */
function handAngles(t, motion) {
  const s = t.s + (t.ms || 0) / 1000;
  let sa = Math.floor(s);
  if (motion === 'smooth') sa = s;
  else if (motion === 'mechanical') { const f = (t.ms || 0) / 1000; sa = Math.floor(s) + (f < .22 ? .22 * Math.sin(f / .22 * Math.PI) : 0); }
  return { h: ((t.h % 12) + t.m / 60 + s / 3600) * TAU / 12, m: (t.m + s / 60) * TAU / 60, s: sa * TAU / 60 };
}
function paintHands(ctx, S, L, cx, cy, R, o, t, motion) {
  const a = handAngles(t, motion);
  paintHand(ctx, S, L, cx, cy, R, o, 'h', a.h);
  paintHand(ctx, S, L, cx, cy, R, o, 'm', a.m);
  if (o.seconds) paintHand(ctx, S, L, cx, cy, R, o, 's', a.s);
  paintCap(ctx, S, L, cx, cy, R, o);
}
/** Image of one hand pointing at 12, sized for Android's AnalogClock (data URL). */
function handImage(L, R, o, which, px, withCap) {
  const c = document.createElement('canvas'); c.width = c.height = px;
  const g = c.getContext('2d'), k = px / (2 * R);
  g.scale(k, k);
  if (which) paintHand(g, k, L, R, R, R, o, which, 0);
  if (withCap) paintCap(g, k, L, R, R, R, o);
  return c.toDataURL('image/png');
}
/** Whole analog face (no hands). Returns the dial radius. */
function paintAnalogFace(ctx, S, L, cx, cy, R, o) {
  const r = paintBezel(ctx, S, L, cx, cy, R, o);
  paintDial(ctx, S, L, cx, cy, r, o);
  paintIndices(ctx, S, L, cx, cy, r, o);
  return r;
}
