/* =========================================================
   Widget element (canvas + tap areas) and baking for Android
   ========================================================= */
const DPR = () => Math.min(3, window.devicePixelRatio || 1);
function appSettings() { return Object.assign({ cc: '966' }, store.get('llx.settings', {})); }
/** International digits for WhatsApp: +966… / 00966… / 05… (with the default country code). */
function intlNumber(v) {
  let s = String(v || '').trim().replace(/[^\d+]/g, '');
  if (s.startsWith('+')) return s.slice(1).replace(/\D/g, '');
  s = s.replace(/\D/g, '');
  if (s.startsWith('00')) return s.slice(2);
  const cc = String(appSettings().cc || '').replace(/\D/g, '');
  if (cc && s.startsWith('0')) return cc + s.replace(/^0+/, '');
  if (cc && s.length <= 9 && !s.startsWith(cc)) return cc + s;
  return s;
}
const dialNumber = v => String(v || '').replace(/[^\d+]/g, '');
function urlOf(v) {
  v = String(v || '').trim();
  const m = v.match(/^([a-z][a-z0-9+.-]*):/i);
  if (m) return ['http', 'https', 'mailto', 'sms', 'geo', 'tel'].includes(m[1].toLowerCase()) ? v : '';
  return v ? 'https://' + v : '';
}
/** Resolved tap action for a hit (shared by the web screen and the Android bake). */
function hitAction(hit) {
  if (hit.act === 'open') return { k: 'open', v: hit.route || 'screen' };
  if (hit.act === 'tap') return hit.tap && hit.tap.k !== 'none' ? Object.assign({}, hit.tap) : null;
  const it = hit.it; if (!it) return null;
  const kind = hit.act === 'item' ? it.kind : hit.act;
  switch (kind) {
    case 'app': return { k: 'app', v: it.value };
    case 'ishort': return { k: 'ishort', v: it.value || '', p: it.pkg || '' };
    case 'url': return { k: 'url', v: urlOf(it.value), p: it.openWith || '' };
    case 'call': return { k: 'call', v: dialNumber(it.value) };
    case 'sms': return { k: 'sms', v: dialNumber(it.value) };
    case 'wa': return { k: 'wa', v: intlNumber(it.value), b: it.waApp || 'auto' };
    case 'contact': return { k: 'contact', v: dialNumber(it.value), wn: intlNumber(it.value), n: it.label, b: it.waApp || 'auto' };
  }
  return null;
}
function actionHrefOf(a) {
  if (!a) return '#';
  switch (a.k) {
    case 'app': return `intent://#Intent;action=android.intent.action.MAIN;category=android.intent.category.LAUNCHER;package=${encodeURIComponent(a.v)};S.browser_fallback_url=${encodeURIComponent('https://play.google.com/store/apps/details?id=' + a.v)};end`;
    case 'url': return NATIVE && a.p ? `launchy://url?u=${encodeURIComponent(a.v)}&p=${encodeURIComponent(a.p)}` : (a.v || '#');
    case 'call': return 'tel:' + a.v;
    case 'sms': return 'sms:' + a.v;
    case 'wa': return NATIVE && a.b !== 'auto' ? `launchy://wa?n=${a.v}&b=${a.b}` : 'https://wa.me/' + a.v;
    case 'contact': return '#contact';
    case 'ishort': return NATIVE && a.v ? 'launchy://ishort?v=' + encodeURIComponent(a.v) : '#ishort';
    case 'open': return '#/' + a.v;
    case 'clockApp': case 'calendarApp': case 'refresh': case 'setAlarm': return '#time-' + a.k;
  }
  return '#';
}
/** Kept for older code paths: href for an item. */
function actionHref(it) { return actionHrefOf(hitAction({ act: 'item', it })); }
function contactSheet(a) {
  const btn = (label, href, g, col) => h('a', { class: 'btn', href, target: /^https?:/.test(href) ? '_blank' : null, rel: 'noopener', style: { justifyContent: 'flex-start' }, onclick: () => setTimeout(() => $('#dlg').close(), 50) }, h('span', { class: 'gl', style: { color: col } }, glyph(g, 18)), label);
  const box = h('div', { class: 'form' },
    btn('اتصال هاتفي', 'tel:' + a.v, 'phone', ACT_COL.call),
    btn('محادثة واتساب', a.b === 'wab' && NATIVE ? `launchy://wa?n=${a.wn}&b=wab` : 'https://wa.me/' + a.wn, 'chat', ACT_COL.wa),
    NATIVE ? btn('واتساب للأعمال', `launchy://wa?n=${a.wn}&b=wab`, 'chat', '#128c7e') : null,
    btn('رسالة SMS', 'sms:' + a.v, 'mail', ACT_COL.sms));
  openDialog(a.n || 'خيارات التواصل', box);
}

function itemsFor(d) {
  if (isTimeType(d)) return { items: [], demo: false };
  if (d.items.length) return { items: d.items, demo: false };
  let items = DEMO_ITEMS;
  if (d.type === 'people') items = DEMO_PEOPLE;
  else if (d.type === 'vertical' || d.type === 'free' || d.type === 'card') items = DEMO_MIX;
  else if (d.type === 'collections') items = DEMO_INNER;
  else if (d.type === 'circle') items = ['hero', 'overlap'].includes(d.circle.layout) ? DEMO_PEOPLE : DEMO_ITEMS;
  return { items, demo: true };
}
function hasGlassBlur(d) { const mode = d.a.bgMode === 'style' ? STYLES[d.style].mode : d.a.bgMode; return mode === 'glass' && (!d.a.mat || d.a.mat === 'none' || MAT[d.a.mat].g === 'glass'); }

/**
 * Render a design at zoom k. opts.interactive adds real links over each tap area.
 * Returns { el, W, H, info, LY, redraw }.
 */
function renderWidget(d, opts = {}) {
  const { W, H } = sizeOf(d), k = opts.k || 1, dpr = opts.dpr || DPR();
  const src = itemsFor(d), interactive = !!opts.interactive && !src.demo;
  const wrap = h('div', { class: 'wscale wcv', role: 'group', 'aria-label': d.name || TYPES[d.type].n });
  wrap.style.width = W * k + 'px'; wrap.style.height = H * k + 'px';
  const cv = document.createElement('canvas');
  cv.width = Math.max(1, Math.round(W * k * dpr)); cv.height = Math.max(1, Math.round(H * k * dpr));
  cv.style.width = W * k + 'px'; cv.style.height = H * k + 'px';
  let LY, base = null, animKey = (d.id || d.name || '') + '|' + Math.random().toString(36).slice(2, 6);
  const S = k * dpr;
  // animated clocks: the still design is cached once, each frame only repaints the moving parts
  const frame = t => {
    const ctx = cv.getContext('2d'); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.clearRect(0, 0, cv.width, cv.height);
    const lv = alertLevel(t);
    if (lv > 0) { const sh = (t % 2400 < 900) ? Math.sin(t / 22) * 1.1 * lv * S : 0; ctx.translate(sh, 0); }
    ctx.drawImage(base, 0, 0); ctx.scale(S, S);
    const L = lookOf(d), mode = { anim: true, key: animKey, redraw: () => {} };
    for (const el of LY.live) { ctx.save(); paintLive(ctx, S, L, el, new Date(), d, mode); ctx.restore(); }
    if (lv > 0 && LY.alertFx) paintAlertFx(ctx, S, L, LY, lv, t);
    if (!needsAnim(LY, d)) { ANIMS.delete(wrap); draw(); }
  };
  const draw = () => {
    LY = layoutDesign(d, W, H, src.items);
    if (needsAnim(LY, d)) {
      if (!base) { base = document.createElement('canvas'); base.width = cv.width; base.height = cv.height; }
      const b = base.getContext('2d'); b.setTransform(1, 0, 0, 1, 0, 0); b.clearRect(0, 0, base.width, base.height); b.scale(S, S);
      paintDesign(b, S, d, LY, { still: true });
      frame(performance.now()); wrap._frame = frame; animAdd(wrap);
      return LY;
    }
    ANIMS.delete(wrap);
    const ctx = cv.getContext('2d'); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.clearRect(0, 0, cv.width, cv.height);
    ctx.scale(S, S);
    paintDesign(ctx, S, d, LY, { redraw: () => requestAnimationFrame(draw), key: d.id || d.name });
    return LY;
  };
  draw();
  wrap._redraw = draw;
  if (LY.live && LY.live.length) {
    // live widgets repaint each second (seconds shown) or when the minute changes
    wrap.dataset.live = '1';
    const secs = LY.live.some(e => e.kind === 'sec' || (e.kind === 'analog' && e.o.seconds));
    let last = '';
    wrap._tick = now => { const key = secs && !ANIMS.has(wrap) ? now.getSeconds() + ':' + now.getMinutes() : now.getHours() + ':' + now.getMinutes(); if (key !== last) { last = key; draw(); } };
    wrap._tick(new Date());
  }
  if (hasGlassBlur(d) && opts.blur !== false) {
    const B = LY.B, bl = h('div', { class: 'wblur' });
    Object.assign(bl.style, { left: B.x * k + 'px', top: B.y * k + 'px', width: B.w * k + 'px', height: B.h * k + 'px', borderRadius: (B.circle ? '50%' : B.r * k + 'px') });
    bl.style.setProperty('--blur', d.a.blur + 'px');
    wrap.append(bl);
  }
  wrap.append(cv);
  const pending = imagesOf(src.items).concat(LY.imgs || []).filter(s => !getImg(s));
  if (pending.length) {
    const fn = () => { draw(); if (pending.every(s => { const e = imgCache.get(s); return e && (e.ok || e.err); })) imgWaiters.delete(fn); };
    imgWaiters.add(fn); setTimeout(() => imgWaiters.delete(fn), 10000);
  }
  if (interactive) {
    for (const ht of LY.hits) {
      const a = hitAction(ht); if (!a) continue;
      const href = actionHrefOf(a), ext = /^https?:/i.test(href) && !NATIVE;
      const el = h('a', { class: 'hit', href, 'aria-label': (ht.it ? ht.it.label + ' — ' : '') + ({ call: 'اتصال', wa: 'واتساب', sms: 'رسالة', open: 'المزيد' }[ht.act] || (ht.it ? KIND[ht.it.kind].n : '')), target: ext ? '_blank' : null, rel: ext ? 'noopener' : null });
      Object.assign(el.style, { left: ht.x * k + 'px', top: ht.y * k + 'px', width: ht.w * k + 'px', height: ht.h * k + 'px' });
      if (a.k === 'contact') el.addEventListener('click', e => { e.preventDefault(); contactSheet(a); });
      if (a.k === 'ishort' && (!NATIVE || !a.v)) el.addEventListener('click', e => { e.preventDefault(); toast(a.v ? 'الاختصارات الداخلية تُفتح من تطبيق Android' : 'هذا عنصر تجريبي للمعاينة فقط'); });
      if (a.k === 'open') el.addEventListener('click', e => { e.preventDefault(); location.hash = '#/' + a.v; });
      if (['clockApp', 'calendarApp', 'refresh', 'setAlarm'].includes(a.k)) el.addEventListener('click', e => { e.preventDefault(); timeTap(d, a); });
      wrap.append(el);
    }
  }
  return { el: wrap, W, H, info: Object.assign({ demo: src.demo }, LY.info), LY, redraw: draw, canvas: cv };
}
function renderScaled(d, k, opts = {}) { return renderWidget(d, Object.assign({}, opts, { k })); }
function fitScaled(d, bw, bh, opts = {}, maxK = 1.25) {
  const { W, H } = sizeOf(d);
  return renderScaled(d, Math.max(.2, Math.min(bw / W, bh / H, maxK)), opts);
}

/* ---------------------------------------------------------- baking (Android) */
/**
 * Draw a design at an exact size into an image + tap areas for the native widget.
 * W,H are studio px; scale is device px per studio px.
 */
async function bakeDesign(d, W, H, scale) {
  const items = d.items;
  if (isTimeType(d)) { await ensureTimeFonts(d); const pre = layoutDesign(d, W, H, items); if (pre.imgs) await loadImgs(pre.imgs); }
  try { await document.fonts.ready; } catch (e) {}
  await loadImgs(imagesOf(items));
  if (d.type === 'collections') await loadImgs((d.collections.groups || []).map(g => g.icon).filter(Boolean));
  const cv = document.createElement('canvas');
  cv.width = Math.round(W * scale); cv.height = Math.round(H * scale);
  const ctx = cv.getContext('2d'); ctx.scale(scale, scale);
  // the dock keeps its chosen bar height inside a taller home-screen cell
  let H2 = H, oy = 0;
  if (d.type === 'dock') { H2 = Math.min(H, Math.round((d.sizes.dock[1] * CELL_H - 8) * d.a.dockH / 100)); oy = (H - H2) / 2; ctx.translate(0, oy); }
  const LY = layoutDesign(d, W, H2, items); paintDesign(ctx, scale, d, LY, { bake: true });
  if (oy) { for (const ht of LY.hits) ht.y += oy; LY.B = Object.assign({}, LY.B, { y: LY.B.y + oy }); }
  let img = cv.toDataURL('image/webp', .9);
  if (!img.startsWith('data:image/webp')) img = cv.toDataURL('image/png');
  const r1 = v => Math.round(v * 10) / 10;
  const hits = LY.hits.map(ht => { const a = hitAction(ht); return a && (a.v || ['open', 'clockApp', 'calendarApp', 'refresh', 'setAlarm'].includes(a.k)) ? Object.assign({ x: r1(ht.x), y: r1(ht.y), w: r1(ht.w), h: r1(ht.h) }, a) : null; }).filter(Boolean);
  const out = { w: W, h: H, s: scale, img, hits, body: { x: r1(LY.B.x), y: r1(LY.B.y), w: r1(LY.B.w), h: r1(LY.B.h), r: r1(LY.B.r), c: !!LY.B.circle } };
  if (LY.live) {
    // live parts for Android: AnalogClock hand images and TextClock boxes
    const L = lookOf(d);
    out.live = LY.live.map(el => {
      if (el.kind === 'pendulum') return bakePendulum(d, L, el, scale);
      if (el.kind === 'chrono') return { k: 'chrono', x: r1(el.x), y: r1(el.y + oy), w: r1(el.w), h: r1(el.h), size: r1(el.size), color: cssHex8(el.color) };
      if (el.kind === 'analog') {
        const px = Math.round(clamp(2 * el.R * scale * 1.15, 64, 720)), sec = !!el.o.seconds;
        return { k: 'analog', x: r1(el.cx - el.R), y: r1(el.cy - el.R + oy), w: r1(2 * el.R), h: r1(2 * el.R), tz: el.tz || '', px,
          hh: handImage(L, el.R, el.o, 'h', px, false), mm: handImage(L, el.R, el.o, 'm', px, !sec), ss: sec ? handImage(L, el.R, el.o, 's', px, true) : '' };
      }
      return { k: 'text', x: r1(el.x), y: r1(el.y + oy), w: r1(el.w), h: r1(el.h), f12: el.f12, f24: el.f24, size: r1(el.size), font: 'llx_' + el.font + '_' + (el.digits === 'arab' && el.font !== 'led' ? 'a' : 'l'),
        color: cssHex8(el.color), align: el.align || 'center', tz: el.tz || '' };
    });
    out.day = isoDay(new Date());
    out.time = d.type;
    // the ringing look (only for clocks that use the alarm effects)
    if (LY.alertFx && LY.live.some(e => e.kind === 'pendulum' || e.kind === 'analog')) {
      const c2 = document.createElement('canvas'); c2.width = cv.width; c2.height = cv.height;
      const g2 = c2.getContext('2d'); g2.scale(scale, scale); if (oy) g2.translate(0, oy);
      paintDesign(g2, scale, d, layoutDesign(d, W, H2, items), { bake: true, alert: 1 });
      out.alert = c2.toDataURL('image/webp', .9).startsWith('data:image/webp') ? c2.toDataURL('image/webp', .9) : c2.toDataURL('image/png');
    }
  }
  return out;
}

/** CSS colour (#rgb, #rrggbb, #rrggbbaa, rgba()) → #rrggbbaa for Android. */
function cssHex8(c) {
  c = String(c || '#ffffff').trim();
  const m = /^rgba?\(([^)]+)\)/.exec(c);
  if (m) { const p = m[1].split(',').map(x => parseFloat(x)); return rgbHex(p[0], p[1], p[2]) + Math.round((p[3] == null ? 1 : p[3]) * 255).toString(16).padStart(2, '0'); }
  if (/^#[0-9a-f]{8}$/i.test(c)) return c;
  return rgbHex(...hexRgb(c)) + 'ff';
}
