package com.launchy.luxe

import android.graphics.Color
import org.json.JSONArray
import org.json.JSONObject

/** Parses "#RRGGBB" or "#RRGGBBAA" (CSS order) into an Android ARGB int. */
fun parseCssColor(s: String?, fallback: Int = Color.TRANSPARENT): Int {
    if (s.isNullOrEmpty() || s[0] != '#') return fallback
    return try {
        val h = s.substring(1)
        when (h.length) {
            6 -> (0xFF shl 24) or h.toLong(16).toInt()
            8 -> {
                val rgb = h.substring(0, 6).toLong(16).toInt()
                val a = h.substring(6, 8).toInt(16)
                (a shl 24) or (rgb and 0xFFFFFF)
            }
            else -> fallback
        }
    } catch (e: Exception) {
        fallback
    }
}

fun mixColor(a: Int, b: Int, t: Float): Int {
    fun ch(x: Int, y: Int) = (x + (y - x) * t).toInt().coerceIn(0, 255)
    return Color.argb(
        ch(Color.alpha(a), Color.alpha(b)), ch(Color.red(a), Color.red(b)),
        ch(Color.green(a), Color.green(b)), ch(Color.blue(a), Color.blue(b))
    )
}

private fun JSONObject.color(key: String): Int? =
    if (!has(key) || isNull(key)) null else parseCssColor(optString(key))

private fun JSONObject.colors(key: String): IntArray {
    val arr = optJSONArray(key) ?: return intArrayOf(Color.TRANSPARENT)
    return IntArray(arr.length()) { parseCssColor(arr.optString(it)) }
}

class Shadow(val color: Int, val r: Float, val dy: Float)
class Glow(val color: Int, val r: Float, val innerColor: Int, val innerR: Float)
class Neu(val light: Int, val dark: Int, val d: Float, val r: Float)

private fun JSONObject.shadow(key: String): Shadow? {
    val o = optJSONObject(key) ?: return null
    return Shadow(parseCssColor(o.optString("c")), o.optDouble("r", 0.0).toFloat(), o.optDouble("dy", 0.0).toFloat())
}

private fun JSONObject.glow(key: String): Glow? {
    val o = optJSONObject(key) ?: return null
    return Glow(
        parseCssColor(o.optString("c")), o.optDouble("r", 0.0).toFloat(),
        parseCssColor(o.optString("ic")), o.optDouble("ir", 0.0).toFloat()
    )
}

/** Tile look, resolved by the studio (see buildSpec in index.html). */
class TileSpec(o: JSONObject) {
    val bg: IntArray = o.colors("bg")
    val border: Int = parseCssColor(o.optString("border"))
    val bw: Float = o.optDouble("bw", 1.0).toFloat()
    val glyph: Int = parseCssColor(o.optString("glyph"), Color.WHITE)
    val hi: Int? = o.color("hi")
    val lo: Int? = o.color("lo")
    val drop: Shadow? = o.shadow("drop")
    val glow: Glow? = o.glow("glow")
    val neu: Neu? = o.optJSONObject("neu")?.let {
        Neu(parseCssColor(it.optString("light")), parseCssColor(it.optString("dark")),
            it.optDouble("d", 4.0).toFloat(), it.optDouble("r", 9.0).toFloat())
    }
    val glyphGlowColor: Int? = o.optJSONObject("glyphGlow")?.let { parseCssColor(it.optString("c")) }
    val glyphGlowR: Float = o.optJSONObject("glyphGlow")?.optDouble("r", 0.0)?.toFloat() ?: 0f
}

/** Widget look, resolved by the studio. */
class Spec(o: JSONObject) {
    val style: String = o.optString("style", "glass")
    val bw: Float = o.optDouble("bw", 1.0).toFloat()
    val radius: Float = o.optDouble("radius", 26.0).toFloat()
    val bg: IntArray = o.colors("bg")
    val sheen: Boolean = o.optBoolean("sheen", false)
    val border: Int = parseCssColor(o.optString("border"))
    val drop: Shadow? = o.shadow("drop")
    val glow: Glow? = o.glow("glow")
    val hi: Int? = o.color("hi")
    val text: Int = parseCssColor(o.optString("text"), Color.WHITE)
    val sub: Int = parseCssColor(o.optString("sub"), Color.LTGRAY)
    val acc: Int = parseCssColor(o.optString("acc"), Color.WHITE)
    val accGlow: Int = parseCssColor(o.optString("accGlow"), Color.WHITE)
    val gold: Int? = o.color("gold")
    val dot: Boolean = o.optBoolean("dot", false)
    val tile = TileSpec(o.optJSONObject("tile") ?: JSONObject())
}

/** Thin view over a design saved by the studio. */
class Design(val json: JSONObject) {
    val id: String = json.optString("id")
    val name: String = json.optString("name", "Launchy")
    val type: String = json.optString("type", "grid")
    val style: String = json.optString("style", "glass")
    val a: JSONObject = json.optJSONObject("a") ?: JSONObject()
    val spec = Spec(json.optJSONObject("spec") ?: JSONObject())
    val items: List<JSONObject> = json.optJSONArray("items").toObjects()

    fun opts(key: String): JSONObject = json.optJSONObject(key) ?: JSONObject()
    fun num(key: String, def: Double): Float = a.optDouble(key, def).toFloat()

    /** Columns × rows chosen in the studio for the current type. */
    fun cells(): Pair<Int, Int> {
        val arr = json.optJSONObject("sizes")?.optJSONArray(type)
        val def = when (type) { "people", "dock" -> 4 to 1; "card" -> 4 to 3; else -> 4 to 2 }
        return if (arr != null && arr.length() == 2) arr.optInt(0, def.first) to arr.optInt(1, def.second) else def
    }
}

fun JSONArray?.toObjects(): List<JSONObject> {
    if (this == null) return emptyList()
    val out = ArrayList<JSONObject>(length())
    for (i in 0 until length()) optJSONObject(i)?.let { out.add(it) }
    return out
}

val TYPE_NAMES = mapOf("grid" to "شبكة الاختصارات", "people" to "شريط الأشخاص", "card" to "البطاقة الكبيرة", "dock" to "الشريط العائم")
val STYLE_NAMES = mapOf(
    "glass" to "الزجاج الفاخر", "quiet" to "الفخامة الهادئة", "neon" to "النيون العصري", "mono" to "الأحادي الناعم",
    "aurora" to "تدرّج الشفق", "neumorph" to "البروز الناعم", "outline" to "الخطوط الرفيعة",
    "amoled" to "الأسود النقي", "clay" to "الطين ثلاثي الأبعاد"
)
