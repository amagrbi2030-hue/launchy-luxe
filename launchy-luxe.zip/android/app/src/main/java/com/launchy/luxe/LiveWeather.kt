package com.launchy.luxe

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.appwidget.AppWidgetManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.PowerManager
import android.util.Log
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Calendar

/**
 * «التحديث المباشر للطقس – كل دقيقة».
 *
 * WorkManager cannot go below 15 minutes and exact alarms are rationed in Doze, so a per-minute update
 * needs a foreground service (with its permanent notification). It is OFF by default; the user turns it on
 * (and off) in the weather settings, or with «إيقاف» in the notification.
 *
 * What it does every 60 s while the screen is ON:
 *  - one small request per weather location (current temperature / condition / humidity / wind);
 *  - Android then re-draws the weather widgets from the stored picture, only replacing the temperature and
 *    the «تحديث HH:MM» line (TextClock views with the same fonts) — the background, natural photo and
 *    layout are not touched;
 *  - when the condition or day/night changes, the full widget is re-drawn once (hidden renderer).
 * While the screen is OFF nobody sees the widget and Doze blocks the network anyway, so it pauses and
 * refreshes the moment the screen turns on. One request at a time (no overlapping / duplicate fetches).
 */
object LiveWx {
    private const val P = "launchy_livewx"
    fun prefs(ctx: Context) = ctx.getSharedPreferences(P, Context.MODE_PRIVATE)
    fun isOn(ctx: Context) = prefs(ctx).getBoolean("on", false)

    /** Locations the weather widgets show, written by the studio when it draws them: [{lat, lon, u}] */
    fun setTargets(ctx: Context, json: String) { prefs(ctx).edit().putString("targets", json).apply() }
    fun targets(ctx: Context): List<Triple<Double, Double, String>> = try {
        val a = org.json.JSONArray(prefs(ctx).getString("targets", "[]"))
        (0 until a.length()).map { val o = a.getJSONObject(it); Triple(o.getDouble("lat"), o.getDouble("lon"), o.optString("u", "C")) }.distinct()
    } catch (_: Exception) { emptyList() }

    fun key(lat: Double, lon: Double, u: String) = String.format(java.util.Locale.US, "%.3f,%.3f,%s", lat, lon, u)
    fun get(ctx: Context, key: String): JSONObject? = try { JSONObject(prefs(ctx).getString("v_$key", "") ?: "") } catch (_: Exception) { null }

    fun state(ctx: Context): String {
        val p = prefs(ctx)
        return JSONObject().put("on", isOn(ctx)).put("at", p.getLong("lastOk", 0L)).put("err", p.getString("lastErr", "")).put("errAt", p.getLong("lastErrAt", 0L)).toString()
    }

    fun start(ctx: Context) {
        prefs(ctx).edit().putBoolean("on", true).apply()
        val i = Intent(ctx, LiveWeatherService::class.java)
        if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
    }
    fun stop(ctx: Context) {
        prefs(ctx).edit().putBoolean("on", false).apply()
        ctx.stopService(Intent(ctx, LiveWeatherService::class.java))
        Widgets.updateAll(ctx)
    }

    private fun digits(s: String, dg: String): String = if (dg != "arab") s else s.map { if (it in '0'..'9') ('٠' + (it - '0')) else it }.joinToString("")

    /**
     * The text for one live box, or null to keep the baked text (live data missing or older than the
     * picture). For the update line, a failed last attempt shows «آخر جلب HH:MM» — never presented as live.
     */
    fun text(ctx: Context, wx: JSONObject): String? {
        if (!isOn(ctx)) return null
        val v = get(ctx, key(wx.optDouble("lat"), wx.optDouble("lon"), wx.optString("u", "C"))) ?: return null
        val at = v.optLong("at")
        if (at <= wx.optLong("at", 0L)) return null
        val dg = wx.optString("dg", "latn"); val en = wx.optString("lang") == "en"
        return when (wx.optString("f")) {
            "temp" -> { val t = Math.round(v.optDouble("t")).toInt(); digits((if (t == 0) 0 else t).toString() + "°", dg) }
            "upd" -> {
                val c = Calendar.getInstance().apply { timeInMillis = at }
                val hm = String.format(java.util.Locale.US, "%02d:%02d", c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE))
                val failedSince = prefs(ctx).getLong("lastErrAt", 0L) > at
                val old = System.currentTimeMillis() - at > 10 * 60_000L
                digits((if (failedSince || old) (if (en) "Last fetch " else "آخر جلب ") else (if (en) "Updated " else "تحديث ")) + hm + (if (old) (if (en) " · old" else " · قديم") else ""), dg)
            }
            else -> null
        }
    }
}

class LiveWeatherService : Service() {
    private var thread: HandlerThread? = null
    private var h: Handler? = null
    @Volatile private var busy = false
    private val screen = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { if (i.action == Intent.ACTION_SCREEN_ON || i.action == Intent.ACTION_USER_PRESENT) kick() }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        thread = HandlerThread("live-weather").also { it.start(); h = Handler(it.looper) }
        val f = IntentFilter().apply { addAction(Intent.ACTION_SCREEN_ON); addAction(Intent.ACTION_USER_PRESENT) }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(screen, f, Context.RECEIVER_NOT_EXPORTED) else registerReceiver(screen, f)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { LiveWx.stop(this); stopSelf(); return START_NOT_STICKY }
        if (!LiveWx.isOn(this)) { stopSelf(); return START_NOT_STICKY }
        val n = notification("يعمل — يُحدَّث كل دقيقة والشاشة مفتوحة")
        if (Build.VERSION.SDK_INT >= 34) startForeground(NOTE_ID, n, 0x40000000 /* FOREGROUND_SERVICE_TYPE_SPECIAL_USE */)
        else startForeground(NOTE_ID, n)
        kick()
        return START_STICKY
    }

    override fun onDestroy() {
        try { unregisterReceiver(screen) } catch (_: Exception) { }
        h?.removeCallbacksAndMessages(null); thread?.quitSafely()
        super.onDestroy()
    }

    private fun kick() { h?.removeCallbacks(tick); h?.post(tick) }

    private val tick = object : Runnable {
        override fun run() {
            try {
                val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
                if (pm.isInteractive && !busy) { busy = true; try { fetchAll() } finally { busy = false } }
            } catch (e: Exception) { Log.w("LiveWx", "tick", e) }
            h?.postDelayed(this, 60_000L)      // paused by the system while the phone sleeps; SCREEN_ON restarts it at once
        }
    }

    private fun fetchAll() {
        val targets = LiveWx.targets(this)
        if (targets.isEmpty()) return
        val p = LiveWx.prefs(this)
        var changed = false; var redraw = false; var ok = 0L
        for ((lat, lon, u) in targets) {
            val key = LiveWx.key(lat, lon, u)
            try {
                val url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,weather_code,is_day,relative_humidity_2m,wind_speed_10m&timezone=auto" +
                    (if (u == "F") "&temperature_unit=fahrenheit" else "")
                val c = (URL(url).openConnection() as HttpURLConnection).apply { connectTimeout = 10_000; readTimeout = 10_000; setRequestProperty("Accept", "application/json") }
                val body = try { if (c.responseCode != 200) throw RuntimeException("HTTP ${c.responseCode}"); c.inputStream.bufferedReader().readText() } finally { c.disconnect() }
                val cur = JSONObject(body).getJSONObject("current")
                val prev = LiveWx.get(this, key)
                val now = System.currentTimeMillis()
                val v = JSONObject().put("t", cur.optDouble("temperature_2m")).put("c", cur.optInt("weather_code")).put("d", cur.optInt("is_day"))
                    .put("h", cur.optDouble("relative_humidity_2m")).put("w", cur.optDouble("wind_speed_10m")).put("at", now)
                p.edit().putString("v_$key", v.toString()).apply()
                changed = true; ok = now
                if (prev != null && (prev.optInt("c") != v.optInt("c") || prev.optInt("d") != v.optInt("d"))) redraw = true
            } catch (e: Exception) {
                p.edit().putString("lastErr", e.message ?: "network").putLong("lastErrAt", System.currentTimeMillis()).apply()
                changed = true
            }
        }
        if (ok > 0) p.edit().putLong("lastOk", ok).apply()
        if (changed) {
            // only the weather widgets, from their stored pictures (fast, no hidden renderer)
            val m = AppWidgetManager.getInstance(this)
            for (id in Widgets.allIds(this)) {
                val d = Store.designFor(this, id)?.let { Store.design(this, it) } ?: continue
                if (d.type == "weather") WidgetRenderer.update(this, m, id)
            }
        }
        // a new condition (rain / clouds / night…) changes icons and the natural background: full redraw, at most every 10 min
        if (redraw) { getSharedPreferences("launchy_time", Context.MODE_PRIVATE).edit().putBoolean("forceWx", true).apply(); TimeJobs.bakeSoonThrottled(this, "livewx", 10 * 60_000L) }
        if (ok > 0) (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(NOTE_ID, notification("آخر تحديث " + String.format(java.util.Locale.US, "%tR", ok)))
    }

    private fun notification(text: String): Notification {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel(CHANNEL, "التحديث المباشر للطقس", NotificationManager.IMPORTANCE_LOW).apply { setShowBadge(false) })
        val stop = PendingIntent.getService(this, 1, Intent(this, LiveWeatherService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val open = PendingIntent.getActivity(this, 2, Intent(this, MainActivity::class.java).putExtra("route", "weather").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else @Suppress("DEPRECATION") Notification.Builder(this)
        return b.setSmallIcon(android.R.drawable.ic_popup_sync)
            .setContentTitle("التحديث المباشر للطقس")
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(null as android.graphics.drawable.Icon?, "إيقاف", stop).build())
            .build()
    }

    companion object {
        const val CHANNEL = "live_weather"
        const val NOTE_ID = 7302
        const val ACTION_STOP = "com.launchy.luxe.LIVEWX_STOP"
    }
}
