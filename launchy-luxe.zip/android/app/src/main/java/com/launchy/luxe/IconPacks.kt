package com.launchy.luxe

import android.content.Context
import android.content.Intent
import android.content.res.Resources
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.util.Base64
import android.util.Xml
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayOutputStream

/**
 * Reads icon packs that follow the common Nova / ADW / Apex format
 * (appfilter.xml maps app components to drawables, drawable.xml lists all icons).
 */
object IconPacks {
    private val ACTIONS = listOf(
        "org.adw.launcher.THEMES", "com.novalauncher.THEME", "com.teslacoilsw.launcher.THEME",
        "com.anddoes.launcher.THEME", "com.gau.go.launcherex.theme", "com.fede.launcher.THEME_ICONPACK"
    )

    class Pack(val pkg: String, val res: Resources, val filter: Map<String, String>, val icons: List<String>)

    private val cache = HashMap<String, Pack>()

    fun drawableToBitmap(d: Drawable, size: Int): Bitmap {
        val b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        d.setBounds(0, 0, size, size)
        d.draw(c)
        return b
    }

    fun png(b: Bitmap): String {
        val out = ByteArrayOutputStream()
        b.compress(Bitmap.CompressFormat.PNG, 100, out)
        return "data:image/png;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    /** Installed icon packs: [{pkg,label,icon}] */
    fun list(ctx: Context): JSONArray {
        val pm = ctx.packageManager
        val seen = LinkedHashMap<String, JSONObject>()
        for (a in ACTIONS) {
            @Suppress("DEPRECATION")
            val found = try { pm.queryIntentActivities(Intent(a), 0) } catch (e: Exception) { emptyList() }
            for (ri in found) {
                val pkg = ri.activityInfo.packageName
                if (seen.containsKey(pkg)) continue
                val icon = try { png(drawableToBitmap(ri.loadIcon(pm), 48)) } catch (e: Exception) { "" }
                seen[pkg] = JSONObject().put("pkg", pkg).put("label", ri.loadLabel(pm).toString()).put("icon", icon)
            }
        }
        val arr = JSONArray()
        seen.values.sortedBy { it.optString("label").lowercase() }.forEach { arr.put(it) }
        return arr
    }

    private fun parser(res: Resources, pkg: String, name: String): XmlPullParser? {
        try {
            val p = Xml.newPullParser()
            p.setInput(res.assets.open("$name.xml"), "UTF-8")
            return p
        } catch (_: Exception) { }
        val id = res.getIdentifier(name, "xml", pkg)
        return if (id != 0) try { res.getXml(id) } catch (_: Exception) { null } else null
    }

    @Synchronized
    fun load(ctx: Context, pkg: String): Pack? {
        cache[pkg]?.let { return it }
        val res = try { ctx.packageManager.getResourcesForApplication(pkg) } catch (e: Exception) { return null }
        val filter = HashMap<String, String>()
        val icons = LinkedHashSet<String>()
        parser(res, pkg, "appfilter")?.let { p ->
            try {
                var ev = p.eventType
                while (ev != XmlPullParser.END_DOCUMENT) {
                    if (ev == XmlPullParser.START_TAG && p.name == "item") {
                        val comp = p.getAttributeValue(null, "component")
                        val dr = p.getAttributeValue(null, "drawable")
                        if (comp != null && dr != null) { filter[comp] = dr; icons.add(dr) }
                    }
                    ev = p.next()
                }
            } catch (_: Exception) { }
        }
        parser(res, pkg, "drawable")?.let { p ->
            val listed = LinkedHashSet<String>()
            try {
                var ev = p.eventType
                while (ev != XmlPullParser.END_DOCUMENT) {
                    if (ev == XmlPullParser.START_TAG && p.name == "item") p.getAttributeValue(null, "drawable")?.let { listed.add(it) }
                    ev = p.next()
                }
            } catch (_: Exception) { }
            if (listed.isNotEmpty()) { icons.clear(); icons.addAll(listed) }
        }
        val pack = Pack(pkg, res, filter, icons.toList())
        cache[pkg] = pack
        return pack
    }

    private fun drawable(pack: Pack, name: String): Drawable? {
        val id = pack.res.getIdentifier(name, "drawable", pack.pkg).takeIf { it != 0 }
            ?: pack.res.getIdentifier(name, "mipmap", pack.pkg).takeIf { it != 0 } ?: return null
        return try { pack.res.getDrawable(id, null) } catch (e: Exception) { null }
    }

    fun icon(ctx: Context, pkg: String, name: String, size: Int = 192): String {
        val pack = load(ctx, pkg) ?: return ""
        val d = drawable(pack, name) ?: return ""
        return png(drawableToBitmap(d, size))
    }

    /** The pack's icon for an installed app (by its launcher component), or "". */
    fun match(ctx: Context, pkg: String, appPkg: String): String {
        val pack = load(ctx, pkg) ?: return ""
        val comp = ctx.packageManager.getLaunchIntentForPackage(appPkg)?.component
        var name: String? = null
        if (comp != null) name = pack.filter["ComponentInfo{${comp.packageName}/${comp.className}}"]
        if (name == null) name = pack.filter.entries.firstOrNull { it.key.startsWith("ComponentInfo{$appPkg/") }?.value
        return name?.let { icon(ctx, pkg, it) } ?: ""
    }

    /** One page of icons (64px previews), filtered by name. */
    fun page(ctx: Context, pkg: String, query: String, offset: Int, limit: Int): JSONObject {
        val pack = load(ctx, pkg) ?: return JSONObject().put("total", 0).put("items", JSONArray())
        val q = query.trim().lowercase().replace(' ', '_')
        val names = if (q.isEmpty()) pack.icons else pack.icons.filter { it.lowercase().contains(q) }
        val items = JSONArray()
        var i = offset
        while (i < names.size && items.length() < limit) {
            val n = names[i++]
            val d = drawable(pack, n) ?: continue
            try { items.put(JSONObject().put("name", n).put("icon", png(drawableToBitmap(d, 64)))) } catch (_: Exception) { }
        }
        return JSONObject().put("total", names.size).put("items", items).put("next", i)
    }
}
