package com.launchy.luxe

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.Intent
import android.graphics.RectF
import android.net.Uri
import android.util.Log
import android.util.TypedValue
import android.view.View
import android.widget.RemoteViews
import org.json.JSONObject
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Turns a saved studio design into RemoteViews. Layout math is a port of
 * renderGrid / renderPeople / renderCard / renderDock in index.html, run on the
 * widget's real size so the grid adapts to whatever space the launcher gives it.
 */
object WidgetRenderer {
    const val ROWS = 5
    const val COLS = 8
    private const val TAG = "LaunchyWidget"

    // --------------------------------------------------------------- layout plan (studio px units)
    class PCell(val item: JSONObject, val size: Float, val shape: String)
    class PRow(val slots: Int, val cells: List<PCell?>, val title: String? = null)
    class Plan(
        val rows: List<PRow>, val featured: PCell?, val featCols: Int,
        val pad: Float, val gap: Float, val font: Float, val labels: Boolean, val perIcon: Boolean,
        val title: String? = null, val subtitle: String? = null, val headGap: Float = 0f,
        val people: Boolean = false, val soft: Boolean = false, val frame: String = "none",
        val side: Boolean = false, val nameW: Float = 0f, val call: Boolean = false, val wa: Boolean = false,
        val radius: Float, val vInset: Float = 0f
    )

    private fun grid(d: Design, W: Float, H: Float, items: List<JSONObject>): Plan {
        val o = d.opts("grid")
        val pad = d.num("padding", 14.0); val gap = d.num("gap", 10.0); val font = d.num("font", 11.0)
        val labels = o.optBoolean("labels", true)
        val shape = o.optString("shape", "rounded")
        val labelH = if (labels) (font * 1.3f).roundToInt() + 4f else 0f
        val aw = W - 2 * pad; val ah = H - 2 * pad
        val ratio = if (shape == "rect") .74f else 1f
        val minT = 30f
        val cols = max(1, min(o.optInt("cols", 4), floor((aw + gap) / (minT + gap)).toInt()))
        val rowsFit = max(1, min(ROWS, floor((ah + gap) / (minT * ratio + labelH + gap)).toInt()))
        val n = minOf(o.optInt("count", 8), items.size, cols * rowsFit)
        val rows = max(1, ceil(n / cols.toFloat()).toInt())
        val cellW = (aw - gap * (cols - 1)) / cols
        val cellH = (ah - gap * (rows - 1)) / rows - labelH
        val t = max(22f, floor(min(cellW, cellH / ratio) * d.num("iconScale", 88.0) / 100f))
        val out = ArrayList<PRow>()
        for (r in 0 until rows) {
            out.add(PRow(cols, List(cols) { c -> val i = r * cols + c; if (i < n) PCell(items[i], t, shape) else null }))
        }
        return Plan(out, null, 4, pad, gap, font, labels, o.optBoolean("perIcon", false), radius = d.num("radius", 26.0))
    }

    private fun people(d: Design, W: Float, H: Float, items: List<JSONObject>): Plan {
        val o = d.opts("people")
        val pad = d.num("padding", 14.0); val gap = d.num("gap", 10.0); val fs = d.num("font", 11.0)
        val side = o.optString("namePos") == "side"
        val frame = o.optString("frame", "ring")
        val nameH = (fs * 1.35f).roundToInt() + 4f
        val aw = W - 2 * pad; val ah = H - 2 * pad
        val gp = if (frame == "glass") 12f else 0f
        var av = if (side) ah - gp else ah - nameH - 6 - gp
        av = max(24f, floor(min(av, if (side) 72f else 84f) * d.num("iconScale", 88.0) / 100f))
        val nameW = if (side) (fs * 5).roundToInt().toFloat() else 0f
        val unit = (if (side) av + 8 + nameW else max(av + (if (frame == "ring") 8 else 0), fs * 4.4f)) + gp
        val fit = max(1, floor((aw + gap) / (unit + gap)).toInt())
        val n = minOf(o.optInt("count", 5), items.size, fit, COLS)
        val row = PRow(n, List(n) { PCell(items[it], av, if (o.optString("shape") == "soft") "soft" else "circle") })
        return Plan(listOf(row), null, 4, pad, gap, fs, !side, false, people = true,
            soft = o.optString("shape") == "soft", frame = frame, side = side, nameW = nameW,
            call = o.optBoolean("call", true), wa = o.optBoolean("wa", true), radius = d.num("radius", 26.0))
    }

    private fun card(d: Design, W: Float, H: Float, items: List<JSONObject>): Plan {
        val o = d.opts("card")
        val pad = max(12f, d.num("padding", 14.0)); val gap = d.num("gap", 10.0); val fs = max(12f, d.num("font", 11.0))
        val title = o.optString("title").takeIf { it.isNotBlank() }
        val sub = o.optString("subtitle").takeIf { it.isNotBlank() }
        var headH = 0f
        if (title != null) headH += (fs * 1.45f * 1.35f).roundToInt()
        if (sub != null) headH += (fs * .95f * 1.4f).roundToInt()
        val gapB = max(8f, (gap * .9f).roundToInt().toFloat())
        if (headH > 0) headH += gapB
        val aw = W - 2 * pad; val bh = H - 2 * pad - headH
        val cols = max(2, min(o.optInt("cols", 4), floor((aw + gap) / (40 + gap)).toInt()))
        val labels = o.optBoolean("labels", true)
        val shape = o.optString("shape", "rounded")
        val labelH = if (labels) (fs * 1.3f).roundToInt() + 4f else 0f
        val cellW = (aw - gap * (cols - 1)) / cols
        val iconBase = max(26f, floor(min(cellW, 64f) * d.num("iconScale", 88.0) / 100f))
        val rowH = iconBase + labelH
        val rows = ArrayList<PRow>()
        var featured: PCell? = null
        if (!o.optBoolean("sections", false)) {
            val rowsFit = max(1, min(ROWS, floor((bh + gap) / (rowH + gap)).toInt()))
            val feat = o.optBoolean("featured", true) && rowsFit >= 2 && cols >= 3 && items.size > 1
            val perRow = if (feat) cols - 2 else cols
            var idx = 0
            if (feat) {
                val big = floor(min(cellW * 2 + gap, rowsFit * rowH + (rowsFit - 1) * gap - labelH) * .88f)
                featured = PCell(items[0], big, shape); idx = 1
            }
            for (r in 0 until rowsFit) {
                if (idx >= items.size) break
                rows.add(PRow(perRow, List(perRow) { if (idx < items.size) PCell(items[idx++], iconBase, shape) else null }))
            }
            return Plan(rows, featured, cols, pad, gap, fs, labels, o.optBoolean("perIcon", false),
                title, sub, gapB, radius = d.num("radius", 26.0))
        }
        val groups = listOf("app" to "التطبيقات", "url" to "المواقع", "call" to "الاتصال", "wa" to "واتساب")
            .map { (k, n) -> n to items.filter { it.optString("kind") == k } }.filter { it.second.isNotEmpty() }
        val secH = (fs * .88f * 1.4f).roundToInt() + 6f
        var remaining = bh
        for ((name, list) in groups) {
            if (remaining < secH + rowH || rows.size >= ROWS) break
            val need = ceil(list.size / cols.toFloat()).toInt()
            val fitRows = floor((remaining - secH + gap) / (rowH + gap)).toInt()
            val rcount = minOf(need, fitRows, ROWS - rows.size)
            if (rcount < 1) break
            var idx = 0
            for (r in 0 until rcount) {
                rows.add(PRow(cols, List(cols) { if (idx < list.size) PCell(list[idx++], iconBase, shape) else null }, if (r == 0) name else null))
            }
            remaining -= secH + rcount * rowH + (rcount - 1) * gap + gap
        }
        return Plan(rows, null, cols, pad, gap, fs, labels, o.optBoolean("perIcon", false), title, sub, gapB, radius = d.num("radius", 26.0))
    }

    private fun dock(d: Design, W: Float, H: Float, items: List<JSONObject>, targetH: Float): Plan {
        val o = d.opts("dock")
        val gap = max(4f, (d.num("gap", 10.0) * .8f).roundToInt().toFloat())
        val pad = max(6f, (d.num("padding", 14.0) * .6f).roundToInt().toFloat())
        val vInset = max(0f, (H - targetH) / 2f)
        val h = H - 2 * vInset
        var labels = o.optBoolean("labels", false)
        val font = d.num("font", 11.0)
        val aw = W - 2 * pad; val ah = h - 2 * pad
        var labelH = if (labels) (font * 1.3f).roundToInt() + 3f else 0f
        if (labels && ah - labelH < 24) { labels = false; labelH = 0f }
        var n = minOf(o.optInt("count", 5), items.size, COLS)
        var t = 0f
        while (n > 0) { t = min((aw - gap * (n - 1)) / n, ah - labelH); if (t >= 26) break; n-- }
        t = max(20f, floor(t * d.num("iconScale", 88.0) / 100f))
        val shape = o.optString("shape", "circle")
        val row = PRow(n, List(n) { PCell(items[it], t, shape) })
        return Plan(listOf(row), null, 4, pad, gap, font, labels, o.optBoolean("perIcon", false),
            radius = min(d.num("radius", 26.0), h / 2f), vInset = vInset)
    }

    // --------------------------------------------------------------- RemoteViews

    private var idCache: IntArray? = null
    private fun idx(r: Int, c: Int, part: Int) = ((r * COLS + c) * 6) + part
    private fun ids(ctx: Context): IntArray {
        idCache?.let { return it }
        val res = ctx.resources
        val pkg = ctx.packageName
        val arr = IntArray(ROWS * COLS * 6)
        val parts = listOf("cell", "ho", "ic", "bc", "bw", "lb")
        for (r in 0 until ROWS) for (c in 0 until COLS) for ((p, name) in parts.withIndex())
            arr[idx(r, c, p)] = res.getIdentifier("${name}_${r}_$c", "id", pkg)
        idCache = arr
        return arr
    }
    private fun rowId(ctx: Context, r: Int) = ctx.resources.getIdentifier("row_$r", "id", ctx.packageName)
    private fun rowTitleId(ctx: Context, r: Int) = ctx.resources.getIdentifier("rowt_$r", "id", ctx.packageName)

    fun actionIntent(ctx: Context, widgetId: Int, slot: Int, kind: String, value: String): PendingIntent {
        val i = Intent(ctx, ActionActivity::class.java).apply {
            action = "com.launchy.luxe.RUN"
            data = Uri.parse("launchy://w/$widgetId/$slot")
            putExtra("kind", kind)
            putExtra("value", value)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
        }
        return PendingIntent.getActivity(ctx, widgetId * 1000 + slot, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun configureIntent(ctx: Context, widgetId: Int): PendingIntent {
        val i = Intent(ctx, ConfigureActivity::class.java).apply {
            data = Uri.parse("launchy://configure/$widgetId")
            putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return PendingIntent.getActivity(ctx, 900000 + widgetId, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun appIntent(ctx: Context, widgetId: Int, route: String): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java).apply {
            data = Uri.parse("launchy://open/$widgetId/$route")
            putExtra("route", route)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return PendingIntent.getActivity(ctx, 800000 + widgetId, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    fun placeholder(ctx: Context, widgetId: Int, text: String, openApp: Boolean = false): RemoteViews {
        val rv = RemoteViews(ctx.packageName, R.layout.widget_placeholder)
        rv.setTextViewText(R.id.ph_text, text)
        rv.setOnClickPendingIntent(R.id.ph_root, if (openApp) appIntent(ctx, widgetId, "designs") else configureIntent(ctx, widgetId))
        return rv
    }

    fun update(ctx: Context, mgr: AppWidgetManager, widgetId: Int) {
        val designId = Store.designFor(ctx, widgetId)
        val design = designId?.let { Store.design(ctx, it) }
        val views = when {
            design == null -> placeholder(ctx, widgetId, if (designId == null) "اضغط لاختيار تصميم من Launchy" else "التصميم غير موجود — اضغط لاختيار غيره")
            design.items.isEmpty() -> placeholder(ctx, widgetId, "«${design.name}» بلا عناصر — اضغط لإضافتها", openApp = true)
            else -> try { build(ctx, mgr, widgetId, design) } catch (e: Exception) {
                Log.e(TAG, "render failed", e)
                placeholder(ctx, widgetId, "تعذّر رسم الويدجت — اضغط لإعادة الاختيار")
            }
        }
        try { mgr.updateAppWidget(widgetId, views) } catch (e: Exception) {
            Log.e(TAG, "update failed", e)
            mgr.updateAppWidget(widgetId, placeholder(ctx, widgetId, "الويدجت أكبر من المسموح — صغّر الحجم"))
        }
    }

    private fun build(ctx: Context, mgr: AppWidgetManager, widgetId: Int, d: Design): RemoteViews {
        val den = ctx.resources.displayMetrics.density
        val (cCells, rCells) = d.cells()
        val opts = mgr.getAppWidgetOptions(widgetId)
        var wDp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH)
        var hDp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT)
        if (wDp <= 0) wDp = cCells * 76
        if (hDp <= 0) hDp = rCells * 88

        // Studio geometry: 4 cells = 328 css px; the widget keeps the studio's width and adapts its height.
        val designW = cCells * 82f - 8f
        val k = wDp / designW          // dp per studio px
        val W = designW
        val H = hDp / k
        val items = d.items
        val dockTargetH = (rCells * 96f - 8f) * d.num("dockH", 80.0) / 100f
        val plan = when (d.type) {
            "people" -> people(d, W, H, items)
            "card" -> card(d, W, H, items)
            "dock" -> dock(d, W, H, items, dockTargetH)
            else -> grid(d, W, H, items)
        }
        val px = k * den                // device px per studio px

        val layout = if (plan.featured != null) when (plan.featCols) { 3 -> R.layout.widget_c3; 5 -> R.layout.widget_c5; else -> R.layout.widget_c4 } else R.layout.widget_c4
        val rv = RemoteViews(ctx.packageName, layout)
        val sp = d.spec

        // ---- background (scaled down if very large to respect the RemoteViews bitmap budget)
        val fullW = (wDp * den).roundToInt()
        val fullH = (hDp * den).roundToInt()
        val scale = min(1f, 1000f / max(fullW, fullH))
        val bW = max(1, (fullW * scale).roundToInt())
        val bH = max(1, (fullH * scale).roundToInt())
        val margin = Painter.bgMargin(sp, px, min(fullW, fullH) * 0.06f)
        val vIn = plan.vInset * px
        val box = RectF(margin * scale, (margin + vIn) * scale, bW - margin * scale, bH - (margin + vIn) * scale)
        rv.setImageViewBitmap(R.id.bg, Painter.background(sp, bW, bH, box, plan.radius * px * scale, px * scale))

        val gapPx = plan.gap * px
        val padPx = plan.pad * px
        val hPad = (margin + padPx - gapPx / 2f).roundToInt().coerceAtLeast(0)
        val vPad = (margin + vIn + padPx - gapPx / 2f).roundToInt().coerceAtLeast(0)
        rv.setViewPadding(R.id.content, hPad, vPad, hPad, vPad)

        // ---- header (big card only)
        if (plan.title != null || plan.subtitle != null) {
            rv.setViewVisibility(R.id.head, View.VISIBLE)
            rv.setViewPadding(R.id.head, (gapPx / 2).roundToInt(), (gapPx / 2).roundToInt(), (gapPx / 2).roundToInt(), (plan.headGap * px - gapPx / 2).roundToInt().coerceAtLeast(0))
            if (plan.title != null) {
                rv.setViewVisibility(R.id.title, View.VISIBLE)
                rv.setTextViewText(R.id.title, plan.title)
                rv.setTextViewTextSize(R.id.title, TypedValue.COMPLEX_UNIT_PX, plan.font * 1.45f * px)
                rv.setTextColor(R.id.title, sp.text)
            } else rv.setViewVisibility(R.id.title, View.GONE)
            if (plan.subtitle != null) {
                rv.setViewVisibility(R.id.subtitle, View.VISIBLE)
                rv.setTextViewText(R.id.subtitle, plan.subtitle)
                rv.setTextViewTextSize(R.id.subtitle, TypedValue.COMPLEX_UNIT_PX, plan.font * .95f * px)
                rv.setTextColor(R.id.subtitle, sp.sub)
            } else rv.setViewVisibility(R.id.subtitle, View.GONE)
        } else rv.setViewVisibility(R.id.head, View.GONE)

        // ---- featured shortcut (big card)
        val tileMarginOf = { size: Float -> Painter.tileMargin(sp, px, size) }
        var slot = 0
        val f = plan.featured
        if (f != null) {
            rv.setViewVisibility(R.id.feat, View.VISIBLE)
            rv.setViewPadding(R.id.feat, (gapPx / 2).roundToInt(), 0, (gapPx / 2).roundToInt(), 0)
            val size = f.size * px
            rv.setImageViewBitmap(R.id.ic_f, Painter.tile(sp, f.item, size, f.shape, plan.perIcon, px, tileMarginOf(size)))
            setLabel(rv, R.id.lb_f, f.item, plan, sp, px)
            rv.setOnClickPendingIntent(R.id.feat, actionIntent(ctx, widgetId, 999, f.item.optString("kind"), f.item.optString("value")))
        } else rv.setViewVisibility(R.id.feat, View.GONE)

        // ---- rows
        val id = ids(ctx)
        for (r in 0 until ROWS) {
            val row = plan.rows.getOrNull(r)
            val rid = rowId(ctx, r)
            val tid = rowTitleId(ctx, r)
            if (row == null) {
                rv.setViewVisibility(rid, View.GONE); rv.setViewVisibility(tid, View.GONE)
                continue
            }
            rv.setViewVisibility(rid, View.VISIBLE)
            rv.setViewPadding(rid, 0, (gapPx / 2).roundToInt(), 0, (gapPx / 2).roundToInt())
            if (row.title != null) {
                rv.setViewVisibility(tid, View.VISIBLE)
                rv.setTextViewText(tid, row.title)
                rv.setTextViewTextSize(tid, TypedValue.COMPLEX_UNIT_PX, plan.font * .88f * px)
                rv.setTextColor(tid, sp.sub)
                rv.setViewPadding(tid, (gapPx / 2).roundToInt(), (gapPx / 2).roundToInt(), (gapPx / 2).roundToInt(), 0)
            } else rv.setViewVisibility(tid, View.GONE)

            for (c in 0 until COLS) {
                val cellId = id[idx(r, c, 0)]
                if (c >= row.slots) { rv.setViewVisibility(cellId, View.GONE); continue }
                val cell = row.cells.getOrNull(c)
                if (cell == null) { rv.setViewVisibility(cellId, View.INVISIBLE); continue }
                rv.setViewVisibility(cellId, View.VISIBLE)
                rv.setViewPadding(cellId, (gapPx / 2).roundToInt(), 0, (gapPx / 2).roundToInt(), 0)
                val icId = id[idx(r, c, 2)]
                val kind = cell.item.optString("kind")
                val value = cell.item.optString("value")
                val size = cell.size * px
                if (plan.people) {
                    val m = max(tileMarginOf(size), when (plan.frame) { "glow" -> 8f; "glass" -> 7f; "ring" -> 4.5f; else -> 1f } * px)
                    rv.setImageViewBitmap(icId, Painter.avatar(sp, cell.item, size, plan.soft, plan.frame, px, m,
                        if (plan.side) plan.nameW * px else 0f, plan.font * px))
                    val phone = if ((kind == "call" || kind == "wa") && value.count { it.isDigit() } >= 6) value else null
                    val bs = max(16f, cell.size * .34f) * px
                    val bc = id[idx(r, c, 3)]
                    val bwId = id[idx(r, c, 4)]
                    if (phone != null && plan.call) {
                        rv.setViewVisibility(bc, View.VISIBLE)
                        rv.setImageViewBitmap(bc, Painter.badge("call", bs, px))
                        rv.setOnClickPendingIntent(bc, actionIntent(ctx, widgetId, 300 + slot, "call", phone))
                    } else rv.setViewVisibility(bc, View.GONE)
                    if (phone != null && plan.wa) {
                        rv.setViewVisibility(bwId, View.VISIBLE)
                        rv.setImageViewBitmap(bwId, Painter.badge("wa", bs, px))
                        rv.setOnClickPendingIntent(bwId, actionIntent(ctx, widgetId, 600 + slot, "wa", phone))
                    } else rv.setViewVisibility(bwId, View.GONE)
                } else {
                    rv.setImageViewBitmap(icId, Painter.tile(sp, cell.item, size, cell.shape, plan.perIcon, px, tileMarginOf(size)))
                    rv.setViewVisibility(id[idx(r, c, 3)], View.GONE)
                    rv.setViewVisibility(id[idx(r, c, 4)], View.GONE)
                }
                setLabel(rv, id[idx(r, c, 5)], cell.item, plan, sp, px)
                rv.setOnClickPendingIntent(cellId, actionIntent(ctx, widgetId, slot, kind, value))
                slot++
            }
        }
        return rv
    }

    private fun setLabel(rv: RemoteViews, lid: Int, item: JSONObject, plan: Plan, sp: Spec, px: Float) {
        if (!plan.labels) { rv.setViewVisibility(lid, View.GONE); return }
        rv.setViewVisibility(lid, View.VISIBLE)
        rv.setTextViewText(lid, item.optString("label"))
        rv.setTextViewTextSize(lid, TypedValue.COMPLEX_UNIT_PX, plan.font * px)
        rv.setTextColor(lid, sp.text)
    }
}
