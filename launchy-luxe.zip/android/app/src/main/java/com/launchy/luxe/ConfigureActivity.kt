package com.launchy.luxe

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.min

/** Shown when a Launchy widget is added from the launcher: pick which saved design it shows. */
class ConfigureActivity : Activity() {
    private var widgetId = AppWidgetManager.INVALID_APPWIDGET_ID

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setResult(RESULT_CANCELED)
        widgetId = intent?.extras?.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
            ?: AppWidgetManager.INVALID_APPWIDGET_ID
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) { finish(); return }
        window.statusBarColor = 0xFF0C0C0E.toInt()
        window.navigationBarColor = 0xFF0C0C0E.toInt()
    }

    override fun onResume() {
        super.onResume()
        if (widgetId != AppWidgetManager.INVALID_APPWIDGET_ID) build()
    }

    private fun dp(v: Float) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, resources.displayMetrics)

    private fun text(s: String, sp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
        textAlignment = View.TEXT_ALIGNMENT_VIEW_START
    }

    private fun rounded(color: Int, stroke: Int, r: Float) = GradientDrawable().apply {
        setColor(color); cornerRadius = r; setStroke(dp(1f).toInt(), stroke)
    }

    /** Small preview: the design background with its first shortcuts. */
    private fun preview(d: Design, wPx: Int, hPx: Int): Bitmap {
        val k = wPx / 320f
        val sp = d.spec
        val box = RectF(0f, 0f, wPx.toFloat(), hPx.toFloat())
        val bmp = Painter.background(sp, wPx, hPx, box, min(sp.radius * k, hPx / 2f), k)
        val c = Canvas(bmp)
        val items = d.items.take(4)
        if (items.isEmpty()) return bmp
        val size = min(hPx * 0.55f, wPx / (items.size + 1.2f))
        val gap = (wPx - size * items.size) / (items.size + 1)
        val per = d.opts(d.type).optBoolean("perIcon", false)
        items.forEachIndexed { i, item ->
            val t = Painter.tile(sp, item, size, "rounded", per, k, 0f)
            c.drawBitmap(t, wPx - gap - (i + 1) * size - i * gap, (hPx - size) / 2f, null)
        }
        return bmp
    }

    private fun build() {
        val mgr = AppWidgetManager.getInstance(this)
        val provider = mgr.getAppWidgetInfo(widgetId)?.provider?.className ?: ""
        val wantType = Widgets.typeOf(provider)
        val designs = Store.designs(this).sortedBy { if (it.type == wantType) 0 else 1 }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(20f).toInt(), dp(28f).toInt(), dp(20f).toInt(), dp(28f).toInt())
            setBackgroundColor(0xFF0C0C0E.toInt())
        }
        root.addView(text("Launchy Luxe", 13f, 0xFFD9C08C.toInt()))
        root.addView(text("اختر تصميماً لهذا الويدجت", 22f, 0xFFF2EDE3.toInt(), true).apply { setPadding(0, dp(4f).toInt(), 0, dp(4f).toInt()) })
        root.addView(text("نوع الويدجت: ${TYPE_NAMES[wantType] ?: ""}. التصاميم من النوع نفسه تظهر أولاً، ويمكنك اختيار أي تصميم.", 14f, 0xFFA39D92.toInt())
            .apply { setPadding(0, 0, 0, dp(16f).toInt()) })

        if (designs.isEmpty()) {
            root.addView(text("لا توجد تصاميم محفوظة بعد. أنشئ تصميماً في الاستوديو واحفظه، ثم عُد إلى هنا.", 15f, 0xFFF2EDE3.toInt()))
        }
        for (d in designs) {
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = rounded(0xFF17171B.toInt(), 0x22FFFFFF, dp(18f))
                setPadding(dp(12f).toInt(), dp(12f).toInt(), dp(12f).toInt(), dp(12f).toInt())
                isClickable = true
                isFocusable = true
                setOnClickListener { choose(d) }
            }
            val pw = resources.displayMetrics.widthPixels - dp(64f).toInt()
            val ph = dp(84f).toInt()
            val bgHolder = LinearLayout(this).apply {
                background = rounded(0xFF1E1A33.toInt(), Color.TRANSPARENT, dp(12f))
                gravity = Gravity.CENTER
                setPadding(dp(10f).toInt(), dp(10f).toInt(), dp(10f).toInt(), dp(10f).toInt())
            }
            bgHolder.addView(ImageView(this).apply { setImageBitmap(preview(d, pw - dp(20f).toInt(), ph)) })
            card.addView(bgHolder, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            card.addView(text(d.name, 16f, 0xFFF2EDE3.toInt(), true).apply { setPadding(0, dp(10f).toInt(), 0, 0) })
            card.addView(text("${TYPE_NAMES[d.type] ?: d.type} · ${STYLE_NAMES[d.style] ?: d.style} · ${d.items.size} عنصر", 13f, 0xFFA39D92.toInt()))
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = dp(12f).toInt()
            root.addView(card, lp)
        }
        root.addView(Button(this).apply {
            text = "فتح الاستوديو لإنشاء تصميم جديد"
            isAllCaps = false
            setOnClickListener {
                startActivity(Intent(this@ConfigureActivity, MainActivity::class.java).putExtra("route", "editor").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        })
        setContentView(ScrollView(this).apply { setBackgroundColor(0xFF0C0C0E.toInt()); addView(root) })
    }

    private fun choose(d: Design) {
        Store.bind(this, widgetId, d.id)
        WidgetRenderer.update(this, AppWidgetManager.getInstance(this), widgetId)
        setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))
        finish()
    }
}
