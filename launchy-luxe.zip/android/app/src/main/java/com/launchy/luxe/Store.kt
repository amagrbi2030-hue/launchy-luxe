package com.launchy.luxe

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.abs
import kotlin.math.roundToInt

/** Designs synced from the studio + which design each home-screen widget shows. */
object Store {
    private val lock = Any()
    private var cache: List<Design>? = null

    private fun file(ctx: Context) = File(ctx.filesDir, "designs.json")
    fun prefs(ctx: Context) = ctx.getSharedPreferences("launchy_widgets", Context.MODE_PRIVATE)
    private fun bakeDir(ctx: Context) = File(ctx.filesDir, "bakes").apply { mkdirs() }

    fun saveDesigns(ctx: Context, json: String) = synchronized(lock) {
        // validate before replacing the stored copy
        val arr = JSONArray(json)
        val tmp = File(ctx.filesDir, "designs.json.tmp")
        tmp.writeText(arr.toString())
        tmp.renameTo(file(ctx))
        cache = null
        // drop bakes of designs that no longer exist
        val ids = HashSet<String>()
        for (i in 0 until arr.length()) arr.optJSONObject(i)?.optString("id")?.let { ids.add(it) }
        bakeDir(ctx).listFiles()?.forEach { f -> if (ids.none { f.name.startsWith(safe(it) + "_") }) f.delete() }
    }

    fun designs(ctx: Context): List<Design> = synchronized(lock) {
        cache?.let { return it }
        val list = try {
            val f = file(ctx)
            if (f.exists()) JSONArray(f.readText()).toObjects().map { Design(it) } else emptyList()
        } catch (e: Exception) {
            emptyList()
        }
        cache = list
        list
    }

    fun design(ctx: Context, id: String): Design? = designs(ctx).firstOrNull { it.id == id }

    fun designFor(ctx: Context, widgetId: Int): String? = prefs(ctx).getString("w_$widgetId", null)
    fun bind(ctx: Context, widgetId: Int, designId: String) = prefs(ctx).edit().putString("w_$widgetId", designId).apply()
    fun unbind(ctx: Context, widgetId: Int) = prefs(ctx).edit().remove("w_$widgetId").apply()

    // ------------------------------------------------------------ baked widget images

    class Bake(val w: Float, val h: Float, val hits: List<JSONObject>, val imgFile: File, val body: JSONObject?,
               val live: List<JSONObject> = emptyList(), val day: String = "", val base: File? = null, val scroll: JSONObject? = null) {
        /** Complete picture (app icons included) for previews; the widget itself draws icons natively. */
        val previewFile: File get() = base?.let { File(it.parentFile, it.name + ".prev.img") }?.takeIf { it.exists() } ?: imgFile
        /** Picture of row j of a scrolling widget. */
        fun rowFile(j: Int): File? = base?.let { File(it.parentFile, it.name + ".row$j.img") }?.takeIf { it.exists() }
        /** File of a live clock hand image saved next to the bake ("hh", "mm", "ss" + index). */
        fun part(name: String): File? = base?.let { File(it.parentFile, it.name + "." + name + ".png") }?.takeIf { it.exists() }
        /** The "ringing" variant of the whole picture (clocks with alarm effects). */
        val alertFile: File? get() = base?.let { File(it.parentFile, it.name + ".alert.img") }?.takeIf { it.exists() }
    }

    private fun safe(id: String) = id.replace(Regex("[^A-Za-z0-9_-]"), "_")

    /** Stores one bake sent by the studio: {w,h,s,img(dataURL),hits[],body}. */
    fun saveBake(ctx: Context, designId: String, w: Int, h: Int, hash: String, json: String) = synchronized(lock) {
        val o = JSONObject(json)
        val img = o.optString("img")
        val comma = img.indexOf(',')
        val bytes = Base64.decode(if (comma >= 0) img.substring(comma + 1) else img, Base64.DEFAULT)
        val base = "${safe(designId)}_${w}x$h"
        File(bakeDir(ctx), "$base.img").writeBytes(bytes)
        o.remove("img")
        // live clock hands arrive as images: keep them as files, the JSON keeps only positions
        bakeDir(ctx).listFiles()?.filter { it.name.startsWith("$base.") && it.name.endsWith(".png") }?.forEach { it.delete() }
        File(bakeDir(ctx), "$base.alert.img").delete()
        bakeDir(ctx).listFiles()?.filter { it.name.startsWith("$base.row") && it.name.endsWith(".img") }?.forEach { it.delete() }
        // scrolling content: one picture per row, the JSON keeps sizes, tap areas and icon boxes
        o.optJSONObject("scroll")?.optJSONArray("rows")?.let { rows ->
            for (j in 0 until rows.length()) {
                val r = rows.optJSONObject(j) ?: continue
                val data = r.optString("img")
                if (data.startsWith("data:")) File(bakeDir(ctx), "$base.row$j.img").writeBytes(dataBytes(data))
                r.remove("img")
            }
        }
        File(bakeDir(ctx), "$base.prev.img").delete()
        val prev = o.optString("prev")
        if (prev.startsWith("data:")) File(bakeDir(ctx), "$base.prev.img").writeBytes(dataBytes(prev))
        o.remove("prev")
        val alert = o.optString("alert")
        if (alert.startsWith("data:")) File(bakeDir(ctx), "$base.alert.img").writeBytes(dataBytes(alert))
        o.remove("alert")
        val live = o.optJSONArray("live")
        if (live != null) for (i in 0 until live.length()) {
            val el = live.optJSONObject(i) ?: continue
            for (k in listOf("hh", "mm", "ss")) {
                val data = el.optString(k)
                if (data.startsWith("data:")) {
                    File(bakeDir(ctx), "$base.$k$i.png").writeBytes(dataBytes(data))
                }
                el.remove(k)
            }
            // pendulum frame loops: pf = normal swing, pa = while ringing → files "<base>.pf<i>_<j>.png"
            for (k in listOf("pf", "pa")) {
                val arr = el.optJSONArray(k) ?: continue
                for (j in 0 until arr.length()) {
                    val data = arr.optString(j)
                    if (data.startsWith("data:")) File(bakeDir(ctx), "$base.$k${i}_$j.png").writeBytes(dataBytes(data))
                }
                el.put(k, arr.length())
            }
        }
        o.put("hash", hash)
        File(bakeDir(ctx), "$base.json").writeText(o.toString())
    }

    private fun dataBytes(data: String): ByteArray = Base64.decode(data.substring(data.indexOf(',') + 1), Base64.DEFAULT)

    /** A bake of a clock design that has a pendulum (prefer the given design), for the alarm screen. */
    fun pendulumBake(ctx: Context, prefer: String?): Pair<Bake, JSONObject>? {
        val files = bakeDir(ctx).listFiles()?.filter { it.name.endsWith(".json") } ?: return null
        val ordered = files.sortedBy { f -> if (prefer != null && f.name.startsWith(safe(prefer) + "_")) 0 else 1 }
        for (f in ordered) {
            try {
                val o = JSONObject(f.readText())
                val live = o.optJSONArray("live").toObjects()
                val el = live.firstOrNull { it.optString("k") == "pendulum" } ?: continue
                val img = File(f.parentFile, f.name.removeSuffix(".json") + ".img")
                if (!img.exists()) continue
                return Bake(o.optDouble("w", 0.0).toFloat(), o.optDouble("h", 0.0).toFloat(), o.optJSONArray("hits").toObjects(), img, o.optJSONObject("body"),
                    live, o.optString("day"), File(f.parentFile, f.name.removeSuffix(".json"))) to el
            } catch (_: Exception) { }
        }
        return null
    }

    /** key ("id_WxH") → hash, so the studio only re-bakes what changed. */
    fun bakeKeys(ctx: Context): JSONObject {
        val out = JSONObject()
        bakeDir(ctx).listFiles()?.filter { it.name.endsWith(".json") }?.forEach { f ->
            try { out.put(f.name.removeSuffix(".json"), JSONObject(f.readText()).optString("hash")) } catch (_: Exception) { }
        }
        return out
    }

    /** Best bake for a design at css size (w,h): exact size, else the closest aspect ratio. */
    fun bakeFor(ctx: Context, designId: String, w: Float, h: Float): Bake? {
        val prefix = safe(designId) + "_"
        val files = bakeDir(ctx).listFiles()?.filter { it.name.startsWith(prefix) && it.name.endsWith(".json") } ?: return null
        if (files.isEmpty()) return null
        val want = w / h
        val best = files.minByOrNull { f ->
            val m = Regex("_(\\d+)x(\\d+)\\.json$").find(f.name)
            if (m == null) Float.MAX_VALUE else {
                val bw = m.groupValues[1].toFloat(); val bh = m.groupValues[2].toFloat()
                abs(bw / bh - want) * 10f + abs(bw - w) / 1000f + abs(bh - h) / 1000f
            }
        } ?: return null
        return try {
            val o = JSONObject(best.readText())
            val img = File(best.parentFile, best.name.removeSuffix(".json") + ".img")
            if (!img.exists()) null else Bake(o.optDouble("w", 0.0).toFloat(), o.optDouble("h", 0.0).toFloat(), o.optJSONArray("hits").toObjects(), img, o.optJSONObject("body"),
                o.optJSONArray("live").toObjects(), o.optString("day"), File(best.parentFile, best.name.removeSuffix(".json")), o.optJSONObject("scroll"))
        } catch (e: Exception) { null }
    }

    fun decodeFile(f: File, maxSide: Int): Bitmap? {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, opts)
        var sample = 1
        while (maxOf(opts.outWidth, opts.outHeight) / sample > maxSide) sample *= 2
        return BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = sample })
    }

    /**
     * Decodes an image at exactly the pixels it will occupy on screen (fit into tw×th), never below them.
     * The old power-of-two subsampling could halve a bake to well under the widget's real resolution,
     * which is what made the vertical widgets and the clocks look soft on the home screen.
     */
    fun decodeFit(f: File, tw: Int, th: Int): Bitmap? {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, opts)
        if (opts.outWidth <= 0 || opts.outHeight <= 0) return null
        val k = minOf(tw.toFloat() / opts.outWidth, th.toFloat() / opts.outHeight)
        var sample = 1
        while (opts.outWidth / (sample * 2) >= opts.outWidth * k && opts.outHeight / (sample * 2) >= opts.outHeight * k) sample *= 2
        val bm = BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = Bitmap.Config.ARGB_8888 }) ?: return null
        val w = (opts.outWidth * k).roundToInt().coerceAtLeast(2); val h = (opts.outHeight * k).roundToInt().coerceAtLeast(2)
        if (k >= 1f || (bm.width <= w * 1.04f && bm.height <= h * 1.04f)) return bm
        val out = Bitmap.createScaledBitmap(bm, w, h, true)
        if (out !== bm) bm.recycle()
        return out
    }

    fun decodeBake(b: Bake, maxSide: Int): Bitmap? {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(b.imgFile.path, opts)
        var sample = 1
        while (maxOf(opts.outWidth, opts.outHeight) / sample > maxSide) sample *= 2
        return BitmapFactory.decodeFile(b.imgFile.path, BitmapFactory.Options().apply { inSampleSize = sample })
    }

    // ------------------------------------------------------------ recent apps (opened from widgets)

    fun recordRecent(ctx: Context, pkg: String) {
        val p = prefs(ctx)
        val list = (p.getString("recent", "") ?: "").split(',').filter { it.isNotBlank() && it != pkg }
        p.edit().putString("recent", (listOf(pkg) + list).take(30).joinToString(",")).apply()
    }

    fun recent(ctx: Context): JSONArray = JSONArray((prefs(ctx).getString("recent", "") ?: "").split(',').filter { it.isNotBlank() })

    fun cc(ctx: Context): String = prefs(ctx).getString("cc", "966") ?: "966"
    fun setCc(ctx: Context, v: String) = prefs(ctx).edit().putString("cc", v.filter { it.isDigit() }).apply()
}

object Widgets {
    val providers: List<Class<*>> = listOf(
        GridWidget::class.java, PeopleWidget::class.java, CardWidget::class.java, DockWidget::class.java,
        VerticalWidget::class.java, CircleWidget::class.java, FreeWidget::class.java, CollectionsWidget::class.java, ProfileWidget::class.java,
        ClockWidget::class.java, DateWidget::class.java, WeatherWidget::class.java
    ) + (1..5).flatMap { c -> (1..8).mapNotNull { r -> try { Class.forName("com.launchy.luxe.Sized_${c}x$r") } catch (_: Exception) { null } } }

    /** The hidden provider whose default size is the design's chosen size (Android 12+), else the type's provider. */
    fun pinProviderFor(d: Design): Class<*> {
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            val (c, r) = d.cells()
            try { return Class.forName("com.launchy.luxe.Sized_${c.coerceIn(1, 5)}x${r.coerceIn(1, 8)}") } catch (_: Exception) { }
        }
        return providerFor(d.type)
    }
    val TIME_TYPES = setOf("clock", "date", "weather")
    /** designs that carry their own content instead of shortcut items (profile links, app collections) */
    val OWN_DATA_TYPES = setOf("profile", "collections")

    fun providerFor(type: String): Class<*> = when (type) {
        "people" -> PeopleWidget::class.java
        "card" -> CardWidget::class.java
        "dock" -> DockWidget::class.java
        "vertical" -> VerticalWidget::class.java
        "circle" -> CircleWidget::class.java
        "free" -> FreeWidget::class.java
        "collections" -> CollectionsWidget::class.java
        "profile" -> ProfileWidget::class.java
        "clock" -> ClockWidget::class.java
        "date" -> DateWidget::class.java
        "weather" -> WeatherWidget::class.java
        else -> GridWidget::class.java
    }

    fun typeOf(className: String): String = when {
        className.endsWith("PeopleWidget") -> "people"
        className.endsWith("CardWidget") -> "card"
        className.endsWith("DockWidget") -> "dock"
        className.endsWith("VerticalWidget") -> "vertical"
        className.endsWith("CircleWidget") -> "circle"
        className.endsWith("FreeWidget") -> "free"
        className.endsWith("CollectionsWidget") -> "collections"
        className.endsWith("ProfileWidget") -> "profile"
        className.endsWith("ClockWidget") -> "clock"
        className.endsWith("DateWidget") -> "date"
        className.endsWith("WeatherWidget") -> "weather"
        className.contains("Sized_") -> ""
        else -> "grid"
    }

    fun allIds(ctx: Context): List<Int> {
        val m = AppWidgetManager.getInstance(ctx)
        return providers.flatMap { p -> m.getAppWidgetIds(ComponentName(ctx, p)).toList() }
    }

    /** Placed widgets that show a clock, date or weather design. */
    fun timeTypesPlaced(ctx: Context): Set<String> {
        val out = HashSet<String>()
        for (id in allIds(ctx)) { val d = Store.designFor(ctx, id)?.let { Store.design(ctx, it) } ?: continue; if (d.type in TIME_TYPES) out.add(d.type) }
        return out
    }

    /** Shortest weather refresh interval (minutes) among placed weather widgets, or 0 when none. */
    fun weatherInterval(ctx: Context): Int {
        var best = 0
        for (id in allIds(ctx)) {
            val d = Store.designFor(ctx, id)?.let { Store.design(ctx, it) } ?: continue
            val iv = when (d.type) { "weather" -> d.opts("weather").optInt("interval", 30); "clock" -> if (d.opts("clock").optBoolean("wx")) 30 else 0; else -> 0 }
            if (iv > 0 && (best == 0 || iv < best)) best = iv
        }
        return best
    }

    fun updateAll(ctx: Context) {
        val m = AppWidgetManager.getInstance(ctx)
        for (id in allIds(ctx)) WidgetRenderer.update(ctx, m, id)
    }

    /** Placed widgets with their design and css size, for the studio to bake exactly. */
    fun slots(ctx: Context): JSONArray {
        val m = AppWidgetManager.getInstance(ctx)
        val out = JSONArray()
        for (id in allIds(ctx)) {
            val did = Store.designFor(ctx, id) ?: continue
            val d = Store.design(ctx, did) ?: continue
            val (w, h) = WidgetRenderer.cssSize(m, id, d)
            out.put(JSONObject().put("widgetId", id).put("designId", did).put("w", w.toDouble()).put("h", h.toDouble()))
        }
        return out
    }
}
