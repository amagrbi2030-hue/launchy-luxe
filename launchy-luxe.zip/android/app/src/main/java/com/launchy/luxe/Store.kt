package com.launchy.luxe

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import org.json.JSONArray
import java.io.File

/** Designs synced from the studio + which design each home-screen widget shows. */
object Store {
    private val lock = Any()
    private var cache: List<Design>? = null

    private fun file(ctx: Context) = File(ctx.filesDir, "designs.json")
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("launchy_widgets", Context.MODE_PRIVATE)

    fun saveDesigns(ctx: Context, json: String) = synchronized(lock) {
        // validate before replacing the stored copy
        val arr = JSONArray(json)
        val tmp = File(ctx.filesDir, "designs.json.tmp")
        tmp.writeText(arr.toString())
        tmp.renameTo(file(ctx))
        cache = null
    }

    fun designs(ctx: Context): List<Design> = synchronized(lock) {
        cache?.let { return it }
        val list = try {
            val f = file(ctx)
            if (f.exists()) JSONArray(f.readText()).toObjects().map { Design(it) } else emptyList()
        } catch (e: Exception) {
            emptyList()
        }
        cache = list
        list
    }

    fun design(ctx: Context, id: String): Design? = designs(ctx).firstOrNull { it.id == id }

    fun designFor(ctx: Context, widgetId: Int): String? = prefs(ctx).getString("w_$widgetId", null)
    fun bind(ctx: Context, widgetId: Int, designId: String) = prefs(ctx).edit().putString("w_$widgetId", designId).apply()
    fun unbind(ctx: Context, widgetId: Int) = prefs(ctx).edit().remove("w_$widgetId").apply()
}

object Widgets {
    val providers: List<Class<*>> = listOf(GridWidget::class.java, PeopleWidget::class.java, CardWidget::class.java, DockWidget::class.java)

    fun providerFor(type: String): Class<*> = when (type) {
        "people" -> PeopleWidget::class.java
        "card" -> CardWidget::class.java
        "dock" -> DockWidget::class.java
        else -> GridWidget::class.java
    }

    fun typeOf(className: String): String = when {
        className.endsWith("PeopleWidget") -> "people"
        className.endsWith("CardWidget") -> "card"
        className.endsWith("DockWidget") -> "dock"
        else -> "grid"
    }

    fun updateAll(ctx: Context) {
        val m = AppWidgetManager.getInstance(ctx)
        for (p in providers) for (id in m.getAppWidgetIds(ComponentName(ctx, p))) WidgetRenderer.update(ctx, m, id)
    }
}
