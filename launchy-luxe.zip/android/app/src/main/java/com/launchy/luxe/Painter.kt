package com.launchy.luxe

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.TextPaint
import android.text.TextUtils
import android.util.Base64
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Draws widget backgrounds and tiles to bitmaps, mirroring the studio's CSS. */
object Painter {

    private fun blur(r: Float): BlurMaskFilter? = if (r < 0.6f) null else BlurMaskFilter(r * 0.85f, BlurMaskFilter.Blur.NORMAL)

    private fun gradient(rect: RectF, c0: Int, c1: Int, deg: Float, pos: FloatArray? = null): Shader {
        val rad = Math.toRadians(deg.toDouble())
        val vx = sin(rad).toFloat()
        val vy = (-cos(rad)).toFloat()
        val half = (abs(rect.width() * vx) + abs(rect.height() * vy)) / 2f
        val cx = rect.centerX()
        val cy = rect.centerY()
        return LinearGradient(cx - vx * half, cy - vy * half, cx + vx * half, cy + vy * half,
            intArrayOf(c0, c1), pos, Shader.TileMode.CLAMP)
    }

    private fun fillPaint(rect: RectF, colors: IntArray, deg: Float): Paint {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        if (colors.size >= 2 && colors[0] != colors[1]) p.shader = gradient(rect, colors[0], colors[1], deg)
        else p.color = if (colors.isNotEmpty()) colors[0] else Color.TRANSPARENT
        return p
    }

    fun shapePath(rect: RectF, radius: Float): Path =
        Path().apply { addRoundRect(rect, radius, radius, Path.Direction.CW) }

    /** CSS box-shadow drawn outside the shape only. */
    private fun outerShadow(c: Canvas, shape: Path, color: Int, r: Float, dx: Float, dy: Float) {
        if (Color.alpha(color) == 0) return
        c.save()
        c.clipOutPath(shape)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color; maskFilter = blur(r) }
        val s = Path(shape)
        s.offset(dx, dy)
        c.drawPath(s, p)
        c.restore()
    }

    /** CSS inset box-shadow (blurred, offset) drawn inside the shape only. */
    private fun innerShadow(c: Canvas, shape: Path, bounds: RectF, color: Int, r: Float, dx: Float, dy: Float) {
        if (Color.alpha(color) == 0) return
        c.save()
        c.clipPath(shape)
        val frame = Path()
        val big = RectF(bounds)
        big.inset(-(r * 3 + 20f), -(r * 3 + 20f))
        frame.addRect(big, Path.Direction.CW)
        val hole = Path(shape)
        hole.offset(dx, dy)
        frame.op(hole, Path.Op.DIFFERENCE)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color; maskFilter = blur(r) }
        c.drawPath(frame, p)
        c.restore()
    }

    /** CSS "inset 0 1px 0 color": a crisp highlight along the top inner edge. */
    private fun insetTop(c: Canvas, shape: Path, color: Int, px: Float) {
        c.save()
        c.clipPath(shape)
        val s = Path(shape)
        s.offset(0f, px)
        c.clipOutPath(s)
        c.drawPath(shape, Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color })
        c.restore()
    }

    private fun stroke(c: Canvas, rect: RectF, radius: Float, color: Int, w: Float) {
        if (w <= 0f || Color.alpha(color) == 0) return
        val r = RectF(rect)
        r.inset(w / 2f, w / 2f)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = w; this.color = color }
        c.drawRoundRect(r, max(0f, radius - w / 2f), max(0f, radius - w / 2f), p)
    }

    /** Extra room (px) needed around the widget box for its outer shadow/glow. */
    fun bgMargin(sp: Spec, k: Float, maxPx: Float): Float {
        val g = sp.glow?.r ?: 0f
        val d = sp.drop?.let { it.r * 0.45f + it.dy } ?: 0f
        return min(max(g * 0.8f, d) * k, maxPx)
    }

    /**
     * Widget background. [box] is the visible widget rectangle in px inside a w×h bitmap;
     * [k] converts studio (CSS) pixels to bitmap pixels.
     */
    fun background(sp: Spec, w: Int, h: Int, box: RectF, radiusPx: Float, k: Float): Bitmap {
        val bmp = Bitmap.createBitmap(max(1, w), max(1, h), Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val rad = min(radiusPx, min(box.width(), box.height()) / 2f)
        val shape = shapePath(box, rad)
        sp.drop?.let { if (it.r > 0f || it.dy > 0f) outerShadow(c, shape, it.color, it.r * k * 0.5f, 0f, it.dy * k) }
        sp.glow?.let { outerShadow(c, shape, it.color, it.r * k * 0.5f, 0f, 0f) }
        c.drawPath(shape, fillPaint(box, sp.bg, 150f))
        if (sp.sheen) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            p.shader = gradient(box, 0x24FFFFFF, 0x00FFFFFF, 150f, floatArrayOf(0f, 0.55f))
            c.drawPath(shape, p)
        }
        sp.glow?.let { innerShadow(c, shape, box, it.innerColor, it.innerR * k * 0.5f, 0f, 0f) }
        sp.hi?.let { insetTop(c, shape, it, max(1f, k)) }
        stroke(c, box, rad, sp.border, sp.bw * k)
        if (sp.sheen) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = max(1f, k) }
            p.shader = LinearGradient(box.left, box.top, box.right, box.bottom,
                intArrayOf(0x99FFFFFF.toInt(), 0x00FFFFFF, 0x00FFFFFF, 0x38FFFFFF),
                floatArrayOf(0f, 0.38f, 0.7f, 1f), Shader.TileMode.CLAMP)
            val r = RectF(box)
            r.inset(k / 2f, k / 2f)
            c.drawRoundRect(r, rad, rad, p)
        }
        sp.gold?.let { gold ->
            if (sp.style == "quiet") {
                val lw = box.width() * 0.3f
                val l = box.centerX() - lw / 2f
                val p = Paint(Paint.ANTI_ALIAS_FLAG)
                p.shader = LinearGradient(l, 0f, l + lw, 0f, intArrayOf(Color.TRANSPARENT, gold, Color.TRANSPARENT),
                    floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
                c.drawRect(l, box.top, l + lw, box.top + 1.5f * k, p)
            }
        }
        if (sp.dot) {
            val cx = box.left + 11f * k
            val cy = box.top + 9f * k
            c.drawCircle(cx, cy, 2f * k, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = sp.acc; maskFilter = blur(3f * k) })
            c.drawCircle(cx, cy, 2f * k, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = sp.acc })
        }
        return bmp
    }

    // ---------------------------------------------------------------- photos & text

    private val photoCache = android.util.LruCache<String, Bitmap>(24)

    fun decodeDataUrl(data: String?): Bitmap? {
        if (data.isNullOrEmpty()) return null
        val key = data.length.toString() + ":" + data.hashCode()
        photoCache.get(key)?.let { return it }
        return try {
            val comma = data.indexOf(',')
            val bytes = Base64.decode(if (comma >= 0) data.substring(comma + 1) else data, Base64.DEFAULT)
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.also { photoCache.put(key, it) }
        } catch (e: Exception) {
            null
        }
    }

    private fun drawPhoto(c: Canvas, shape: Path, rect: RectF, photo: Bitmap) {
        c.save()
        c.clipPath(shape)
        val side = min(photo.width, photo.height)
        val src = Rect((photo.width - side) / 2, (photo.height - side) / 2, (photo.width + side) / 2, (photo.height + side) / 2)
        val sr = max(rect.width(), rect.height())
        val dst = RectF(rect.centerX() - sr / 2f, rect.centerY() - sr / 2f, rect.centerX() + sr / 2f, rect.centerY() + sr / 2f)
        c.drawBitmap(photo, src, dst, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
        c.restore()
    }

    private fun drawCenteredText(c: Canvas, text: String, cx: Float, cy: Float, size: Float, color: Int, bold: Boolean = true) {
        val p = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = size; this.color = color; textAlign = Paint.Align.CENTER
            typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        }
        val fm = p.fontMetrics
        c.drawText(text, cx, cy - (fm.ascent + fm.descent) / 2f, p)
    }

    private fun drawGlyph(c: Canvas, name: String, cx: Float, cy: Float, size: Float, color: Int, glowColor: Int?, glowR: Float) {
        val m = Matrix()
        val s = size / 24f
        m.setScale(s, s)
        m.postTranslate(cx - size / 2f, cy - size / 2f)
        val path = Path()
        path.addPath(Glyphs.path(name), m)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = 1.9f * s; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
        }
        if (glowColor != null && glowR > 0.5f) {
            p.color = glowColor
            p.maskFilter = blur(glowR)
            c.drawPath(path, p)
            p.maskFilter = null
        }
        p.color = color
        c.drawPath(path, p)
    }

    private fun firstGrapheme(s: String): String {
        val t = s.trim()
        if (t.isEmpty()) return "؟"
        if (t[0].isLetter() && t[0].code < 0x250) {
            return t.split(Regex("\\s+")).take(2).mapNotNull { it.firstOrNull()?.uppercaseChar() }.joinToString("")
        }
        val end = Character.charCount(t.codePointAt(0))
        return t.substring(0, end)
    }

    // ---------------------------------------------------------------- tiles

    /** Room (px) around a tile for its glow/shadow, capped relative to the tile size. */
    fun tileMargin(sp: Spec, k: Float, tilePx: Float): Float {
        val t = sp.tile
        var e = 0f
        t.glow?.let { e = max(e, it.r * 0.6f) }
        t.drop?.let { e = max(e, it.r * 0.4f + it.dy) }
        t.neu?.let { e = max(e, it.d + it.r * 0.5f) }
        return min(e * k, tilePx * 0.22f)
    }

    /**
     * One shortcut tile: [size] is the visible tile width in px (rect tiles are 0.74× tall).
     * Returns a bitmap with [margin] px of room on every side.
     */
    fun tile(sp: Spec, item: JSONObject, size: Float, shape: String, perIcon: Boolean, k: Float, margin: Float): Bitmap {
        val w = size
        val hgt = if (shape == "rect") size * 0.74f else size
        val bmp = Bitmap.createBitmap(ceil(w + 2 * margin).toInt().coerceAtLeast(1), ceil(hgt + 2 * margin).toInt().coerceAtLeast(1), Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val rect = RectF(margin, margin, margin + w, margin + hgt)
        val m = min(w, hgt)
        val rad = when (shape) { "square" -> m * 0.14f; "circle" -> m / 2f; else -> m * 0.3f }
        val path = shapePath(rect, rad)
        val t = sp.tile
        t.neu?.let {
            outerShadow(c, path, it.light, it.r * k * 0.5f, -it.d * k, -it.d * k)
            outerShadow(c, path, it.dark, it.r * k * 0.5f, it.d * k, it.d * k)
        }
        t.glow?.let { outerShadow(c, path, it.color, it.r * k * 0.5f, 0f, 0f) }
        t.drop?.let { outerShadow(c, path, it.color, it.r * k * 0.5f, 0f, it.dy * k) }

        val decoded = decodeDataUrl(item.optString("photo"))
        val contain = decoded != null && item.optString("fit") == "contain"
        val photo = if (contain) null else decoded
        val itemColor = parseCssColor(item.optString("color"), Color.GRAY)
        if (photo != null) {
            drawPhoto(c, path, rect, photo)
        } else if (perIcon) {
            c.drawPath(path, fillPaint(rect, intArrayOf(mixColor(itemColor, Color.WHITE, .14f), mixColor(itemColor, Color.BLACK, .24f)), 155f))
        } else {
            c.drawPath(path, fillPaint(rect, t.bg, 160f))
        }
        t.glow?.let { innerShadow(c, path, rect, it.innerColor, it.innerR * k * 0.5f, 0f, 0f) }
        t.hi?.let { insetTop(c, path, it, max(1f, k)) }
        t.lo?.let { innerShadow(c, path, rect, it, 5f * k * 0.5f, 0f, -2f * k) }
        if (photo == null) stroke(c, rect, rad, t.border, t.bw * k)

        if (contain && decoded != null) {
            val s = m * 0.62f
            val dst = RectF(rect.centerX() - s / 2f, rect.centerY() - s / 2f, rect.centerX() + s / 2f, rect.centerY() + s / 2f)
            c.drawBitmap(decoded, null as Rect?, dst, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
        } else if (photo == null) {
            val glyphColor = if (perIcon) Color.WHITE else t.glyph
            val gsz = max(12f * k, m * 0.5f)
            val emoji = item.optString("emoji").trim()
            if (emoji.isNotEmpty()) {
                val n = emoji.codePointCount(0, emoji.length)
                val f = when { n > 2 -> 0.6f; n == 2 -> 0.78f; else -> 1f }
                drawCenteredText(c, emoji, rect.centerX(), rect.centerY(), gsz * f, glyphColor)
            } else {
                drawGlyph(c, item.optString("glyph", "apps"), rect.centerX(), rect.centerY(), gsz, glyphColor,
                    if (perIcon) null else t.glyphGlowColor, t.glyphGlowR * k)
            }
        }
        return bmp
    }

    // ---------------------------------------------------------------- people

    /**
     * Avatar for the people strip. When [nameW] > 0 the name is drawn beside the avatar
     * (RTL: avatar on the right).
     */
    fun avatar(
        sp: Spec, item: JSONObject, av: Float, soft: Boolean, frame: String, k: Float, margin: Float,
        nameW: Float, fontPx: Float
    ): Bitmap {
        val gap = 8f * k
        val totalW = av + 2 * margin + if (nameW > 0f) gap + nameW else 0f
        val bmp = Bitmap.createBitmap(ceil(totalW).toInt().coerceAtLeast(1), ceil(av + 2 * margin).toInt().coerceAtLeast(1), Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val left = totalW - margin - av
        val rect = RectF(left, margin, left + av, margin + av)
        val rad = if (soft) av * 0.28f else av / 2f
        val path = shapePath(rect, rad)
        val t = sp.tile
        when (frame) {
            "glass" -> {
                val r = RectF(rect)
                r.inset(-6f * k, -6f * k)
                val p = shapePath(r, if (soft) rad + 6f * k else r.height() / 2f)
                c.drawPath(p, fillPaint(r, t.bg, 160f))
                stroke(c, r, if (soft) rad + 6f * k else r.height() / 2f, t.border, max(1f, t.bw * k))
            }
            "glow" -> outerShadow(c, path, sp.accGlow, 16f * k * 0.5f, 0f, 0f)
        }
        val photo = decodeDataUrl(item.optString("photo"))
        if (photo != null) drawPhoto(c, path, rect, photo)
        else {
            val col = parseCssColor(item.optString("color"), Color.GRAY)
            c.drawPath(path, fillPaint(rect, intArrayOf(mixColor(col, Color.WHITE, .16f), mixColor(col, Color.BLACK, .22f)), 150f))
            val emoji = item.optString("emoji").trim()
            drawCenteredText(c, if (emoji.isNotEmpty()) emoji else firstGrapheme(item.optString("label")),
                rect.centerX(), rect.centerY(), av * 0.4f, Color.WHITE)
        }
        when (frame) {
            "ring" -> {
                val r = RectF(rect)
                val off = 2.5f * k + 0.75f * k
                r.inset(-off, -off)
                stroke(c, r, if (soft) rad + off else r.height() / 2f, sp.acc, 1.5f * k)
            }
            "glow" -> {
                val r = RectF(rect)
                r.inset(-0.75f * k, -0.75f * k)
                stroke(c, r, if (soft) rad else r.height() / 2f, sp.acc, 1.5f * k)
            }
        }
        if (nameW > 0f) {
            val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = fontPx; color = sp.text; typeface = Typeface.DEFAULT_BOLD }
            val name = TextUtils.ellipsize(item.optString("label"), tp, nameW, TextUtils.TruncateAt.END).toString()
            tp.textAlign = Paint.Align.RIGHT
            val fm = tp.fontMetrics
            c.drawText(name, left - gap, rect.centerY() - (fm.ascent + fm.descent) / 2f, tp)
        }
        return bmp
    }

    /** Small round call / WhatsApp badge. */
    fun badge(kind: String, size: Float, k: Float): Bitmap {
        val s = ceil(size).toInt().coerceAtLeast(8)
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val r = s / 2f
        val bw = max(1f, 1.5f * k)
        c.drawCircle(r, r, r, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xE6FFFFFF.toInt() })
        c.drawCircle(r, r, r - bw, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = if (kind == "call") 0xFF2F6FD6.toInt() else 0xFF1F9D55.toInt() })
        drawGlyph(c, if (kind == "call") "phone" else "chat", r, r, s * 0.56f, Color.WHITE, null, 0f)
        return bmp
    }
}
