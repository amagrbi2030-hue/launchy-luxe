package com.launchy.luxe

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Rect
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.ContactsContract
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import kotlin.math.min

/** Hosts the studio (assets/web/index.html) and exposes the LaunchyNative bridge. */
class MainActivity : Activity() {
    private lateinit var web: WebView
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var pendingExport: String? = null
    private var pendingCall: String? = null

    companion object {
        const val REQ_FILE = 11
        const val REQ_EXPORT = 12
        const val REQ_CALL = 13
        const val REQ_CONTACTS = 14
        const val REQ_CALL_PERMISSION = 15
        private const val BG = 0xFF0C0C0E.toInt()
        private const val BASE = "file:///android_asset/web/index.html"
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        web = WebView(this)
        web.setBackgroundColor(BG)
        setContentView(web)
        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            textZoom = 100
        }
        web.addJavascriptInterface(Bridge(), "LaunchyNative")
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean = handleUrl(request.url)
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(view: WebView, cb: ValueCallback<Array<Uri>>, params: FileChooserParams): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = cb
                return try {
                    startActivityForResult(params.createIntent(), REQ_FILE); true
                } catch (e: Exception) {
                    fileCallback = null; false
                }
            }
        }
        if (savedInstanceState != null) web.restoreState(savedInstanceState)
        else web.loadUrl(BASE + "#/" + (intent?.getStringExtra("route") ?: "screen"))
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        intent.getStringExtra("route")?.let { web.evaluateJavascript("location.hash='#/$it'", null) }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else @Suppress("DEPRECATION") super.onBackPressed()
    }

    /** Links tapped inside "شاشتي" behave exactly like widget taps. */
    private fun handleUrl(uri: Uri): Boolean {
        val scheme = uri.scheme?.lowercase() ?: return false
        if (scheme == "file" || scheme == "about" || scheme == "data" || scheme == "blob") return false
        val host = uri.host?.lowercase() ?: ""
        try {
            when {
                scheme == "tel" -> callNumber(uri.schemeSpecificPart ?: "")
                scheme == "intent" -> Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME).`package`?.let { Actions.openApp(this, it) }
                (scheme == "http" || scheme == "https") && host == "wa.me" -> Actions.whatsapp(this, uri.path ?: "")
                (scheme == "http" || scheme == "https") && host.endsWith("whatsapp.com") -> Actions.whatsapp(this, uri.getQueryParameter("phone") ?: "")
                scheme == "http" || scheme == "https" -> Actions.openUrl(this, uri.toString())
                else -> startActivity(Intent(Intent.ACTION_VIEW, uri))
            }
        } catch (_: Exception) { }
        return true
    }

    private fun callNumber(n: String) {
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) Actions.call(this, n)
        else { pendingCall = n; requestPermissions(arrayOf(Manifest.permission.CALL_PHONE), REQ_CALL) }
    }

    private fun sendToJs(kind: String, json: String) = runOnUiThread {
        web.evaluateJavascript("window.LaunchyStudio&&LaunchyStudio.onNative(${JSONObject.quote(kind)},${JSONObject.quote(json)})", null)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        val ok = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
        when (requestCode) {
            REQ_CALL -> { pendingCall?.let { Actions.call(this, it) }; pendingCall = null }
            REQ_CONTACTS -> if (ok) loadContacts() else sendToJs("contacts", "{\"denied\":true}")
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION") super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQ_FILE -> {
                fileCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
                fileCallback = null
            }
            REQ_EXPORT -> {
                val uri = data?.data
                val text = pendingExport
                pendingExport = null
                var ok = false
                if (resultCode == RESULT_OK && uri != null && text != null) {
                    try { contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray()) }; ok = true } catch (_: Exception) { }
                }
                sendToJs("exported", "{\"ok\":$ok}")
            }
        }
    }

    // ------------------------------------------------------------- data for the pickers

    private fun toBitmap(d: Drawable, size: Int): Bitmap {
        val b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        d.setBounds(0, 0, size, size)
        d.draw(c)
        return b
    }

    private fun dataUrl(b: Bitmap, png: Boolean): String {
        val out = ByteArrayOutputStream()
        b.compress(if (png) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG, 85, out)
        return (if (png) "data:image/png;base64," else "data:image/jpeg;base64,") + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    private fun loadApps() = Thread {
        val pm = packageManager
        val list = JSONArray()
        try {
            val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            @Suppress("DEPRECATION")
            val found = pm.queryIntentActivities(main, 0)
            val seen = HashSet<String>()
            val rows = ArrayList<Pair<String, JSONObject>>()
            for (ri in found) {
                val pkg = ri.activityInfo.packageName
                if (pkg == packageName || !seen.add(pkg)) continue
                val label = ri.loadLabel(pm).toString()
                val icon = try { dataUrl(toBitmap(ri.loadIcon(pm), 96), true) } catch (_: Exception) { "" }
                rows.add(label to JSONObject().put("label", label).put("pkg", pkg).put("icon", icon))
            }
            rows.sortBy { it.first.lowercase() }
            rows.forEach { list.put(it.second) }
        } catch (_: Exception) { }
        sendToJs("apps", list.toString())
    }.start()

    private fun loadContacts() = Thread {
        val list = JSONArray()
        val seen = HashSet<String>()
        try {
            contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER,
                    ContactsContract.CommonDataKinds.Phone.PHOTO_THUMBNAIL_URI
                ),
                null, null, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC"
            )?.use { c ->
                while (c.moveToNext()) {
                    val name = c.getString(0)
                    val num = c.getString(1)
                    if (name != null && num != null && seen.add(name + "|" + num.filter { it.isDigit() })) {
                        list.put(JSONObject().put("name", name).put("number", num).put("photo", c.getString(2) ?: ""))
                    }
                }
            }
        } catch (_: Exception) { }
        sendToJs("contacts", JSONObject().put("list", list).toString())
    }.start()

    // ------------------------------------------------------------- JavaScript bridge

    inner class Bridge {
        @JavascriptInterface
        fun info(): String = JSONObject()
            .put("native", true)
            .put("version", "1.1")
            .put("pinSupported", AppWidgetManager.getInstance(this@MainActivity).isRequestPinAppWidgetSupported)
            .put("callPermission", checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED)
            .toString()

        @JavascriptInterface
        fun syncDesigns(json: String) {
            try {
                Store.saveDesigns(this@MainActivity, json)
                Widgets.updateAll(this@MainActivity)
            } catch (_: Exception) { }
        }

        @JavascriptInterface
        fun pinWidget(designId: String): String {
            val ctx = this@MainActivity
            val d = Store.design(ctx, designId) ?: return "missing"
            val mgr = AppWidgetManager.getInstance(ctx)
            if (!mgr.isRequestPinAppWidgetSupported) return "unsupported"
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
            val cb = PendingIntent.getBroadcast(ctx, designId.hashCode(),
                Intent(ctx, PinReceiver::class.java).putExtra("designId", designId), flags)
            return try {
                if (mgr.requestPinAppWidget(ComponentName(ctx, Widgets.providerFor(d.type)), null, cb)) "requested" else "unsupported"
            } catch (e: Exception) { "unsupported" }
        }

        @JavascriptInterface
        fun requestApps() { loadApps() }

        @JavascriptInterface
        fun iconPacks(): String = try { IconPacks.list(this@MainActivity).toString() } catch (e: Exception) { "[]" }

        @JavascriptInterface
        fun iconPackIcons(pkg: String, query: String, offset: Int, limit: Int): String =
            try { IconPacks.page(this@MainActivity, pkg, query, offset, limit).toString() } catch (e: Exception) { "{\"total\":0,\"items\":[]}" }

        @JavascriptInterface
        fun iconPackIcon(pkg: String, name: String): String = try { IconPacks.icon(this@MainActivity, pkg, name) } catch (e: Exception) { "" }

        @JavascriptInterface
        fun iconPackMatch(pkg: String, appPkg: String): String = try { IconPacks.match(this@MainActivity, pkg, appPkg) } catch (e: Exception) { "" }

        /** Website logo for a link (runs on the bridge thread, not the UI thread). */
        @JavascriptInterface
        fun fetchFavicon(url: String): String = try {
            val s = url.trim()
            val host = Uri.parse(if (s.contains("://")) s else "https://$s").host ?: ""
            if (host.isEmpty()) "" else {
                val conn = java.net.URL("https://www.google.com/s2/favicons?domain=" + Uri.encode(host) + "&sz=128").openConnection() as java.net.HttpURLConnection
                conn.connectTimeout = 6000
                conn.readTimeout = 6000
                conn.instanceFollowRedirects = true
                val bmp = conn.inputStream.use { BitmapFactory.decodeStream(it) }
                conn.disconnect()
                if (bmp == null || bmp.width < 8) "" else IconPacks.png(bmp)
            }
        } catch (e: Exception) { "" }

        @JavascriptInterface
        fun requestContacts() = runOnUiThread {
            if (checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) loadContacts()
            else requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), REQ_CONTACTS)
        }

        @JavascriptInterface
        fun contactPhoto(uri: String): String = try {
            contentResolver.openInputStream(Uri.parse(uri))?.use { ins ->
                val b = BitmapFactory.decodeStream(ins) ?: return ""
                val side = min(b.width, b.height)
                val out = Bitmap.createBitmap(160, 160, Bitmap.Config.ARGB_8888)
                Canvas(out).drawBitmap(b, Rect((b.width - side) / 2, (b.height - side) / 2, (b.width + side) / 2, (b.height + side) / 2), Rect(0, 0, 160, 160), null)
                dataUrl(out, false)
            } ?: ""
        } catch (e: Exception) { "" }

        @JavascriptInterface
        fun requestCallPermission() = runOnUiThread {
            if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED)
                requestPermissions(arrayOf(Manifest.permission.CALL_PHONE), REQ_CALL_PERMISSION)
        }

        @JavascriptInterface
        fun exportJson(name: String, text: String) = runOnUiThread {
            pendingExport = text
            try {
                @Suppress("DEPRECATION")
                startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                    .setType("application/json").putExtra(Intent.EXTRA_TITLE, name), REQ_EXPORT)
            } catch (e: Exception) { sendToJs("exported", "{\"ok\":false}") }
        }
    }
}
