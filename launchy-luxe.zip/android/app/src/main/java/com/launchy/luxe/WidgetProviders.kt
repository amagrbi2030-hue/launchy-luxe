package com.launchy.luxe

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Bundle

open class BaseWidget : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        for (id in ids) WidgetRenderer.update(ctx, mgr, id)
    }

    override fun onAppWidgetOptionsChanged(ctx: Context, mgr: AppWidgetManager, id: Int, newOptions: Bundle) {
        WidgetRenderer.update(ctx, mgr, id)
    }

    override fun onDeleted(ctx: Context, ids: IntArray) {
        for (id in ids) Store.unbind(ctx, id)
        TimeJobs.scheduleAll(ctx)
    }

    override fun onEnabled(ctx: Context) { TimeJobs.scheduleAll(ctx) }
}

class GridWidget : BaseWidget()
class PeopleWidget : BaseWidget()
class CardWidget : BaseWidget()
class DockWidget : BaseWidget()
class VerticalWidget : BaseWidget()
class CircleWidget : BaseWidget()
class FreeWidget : BaseWidget()
class CollectionsWidget : BaseWidget()
class ProfileWidget : BaseWidget()
class ClockWidget : BaseWidget()
class DateWidget : BaseWidget()
class WeatherWidget : BaseWidget()

/* One hidden provider per size (columns × rows), so a design pinned from the studio arrives at the size chosen there. */
class Sized_1x1 : BaseWidget()
class Sized_1x2 : BaseWidget()
class Sized_1x3 : BaseWidget()
class Sized_1x4 : BaseWidget()
class Sized_1x5 : BaseWidget()
class Sized_1x6 : BaseWidget()
class Sized_2x1 : BaseWidget()
class Sized_2x2 : BaseWidget()
class Sized_2x3 : BaseWidget()
class Sized_2x4 : BaseWidget()
class Sized_2x5 : BaseWidget()
class Sized_2x6 : BaseWidget()
class Sized_3x1 : BaseWidget()
class Sized_3x2 : BaseWidget()
class Sized_3x3 : BaseWidget()
class Sized_3x4 : BaseWidget()
class Sized_3x5 : BaseWidget()
class Sized_3x6 : BaseWidget()
class Sized_4x1 : BaseWidget()
class Sized_4x2 : BaseWidget()
class Sized_4x3 : BaseWidget()
class Sized_4x4 : BaseWidget()
class Sized_4x5 : BaseWidget()
class Sized_4x6 : BaseWidget()
class Sized_5x1 : BaseWidget()
class Sized_5x2 : BaseWidget()
class Sized_5x3 : BaseWidget()
class Sized_5x4 : BaseWidget()
class Sized_5x5 : BaseWidget()
class Sized_5x6 : BaseWidget()

/** Called by the launcher after a pin request from the app succeeds. */
class PinReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val wid = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
        val designId = intent.getStringExtra("designId")
        if (wid != AppWidgetManager.INVALID_APPWIDGET_ID && designId != null) {
            Store.bind(ctx, wid, designId)
            WidgetRenderer.update(ctx, AppWidgetManager.getInstance(ctx), wid)
            TimeJobs.scheduleAll(ctx)
            TimeJobs.bakeSoon(ctx, 800)
        }
    }
}
class Sized_1x7 : BaseWidget()
class Sized_1x8 : BaseWidget()
class Sized_2x7 : BaseWidget()
class Sized_2x8 : BaseWidget()
class Sized_3x7 : BaseWidget()
class Sized_3x8 : BaseWidget()
class Sized_4x7 : BaseWidget()
class Sized_4x8 : BaseWidget()
class Sized_5x7 : BaseWidget()
class Sized_5x8 : BaseWidget()
