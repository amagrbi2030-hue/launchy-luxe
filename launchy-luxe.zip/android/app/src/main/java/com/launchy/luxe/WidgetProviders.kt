package com.launchy.luxe

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Bundle

open class BaseWidget : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        for (id in ids) WidgetRenderer.update(ctx, mgr, id)
    }

    override fun onAppWidgetOptionsChanged(ctx: Context, mgr: AppWidgetManager, id: Int, newOptions: Bundle) {
        WidgetRenderer.update(ctx, mgr, id)
    }

    override fun onDeleted(ctx: Context, ids: IntArray) {
        for (id in ids) Store.unbind(ctx, id)
    }
}

class GridWidget : BaseWidget()
class PeopleWidget : BaseWidget()
class CardWidget : BaseWidget()
class DockWidget : BaseWidget()

/** Called by the launcher after a pin request from the app succeeds. */
class PinReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val wid = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
        val designId = intent.getStringExtra("designId")
        if (wid != AppWidgetManager.INVALID_APPWIDGET_ID && designId != null) {
            Store.bind(ctx, wid, designId)
            WidgetRenderer.update(ctx, AppWidgetManager.getInstance(ctx), wid)
        }
    }
}
