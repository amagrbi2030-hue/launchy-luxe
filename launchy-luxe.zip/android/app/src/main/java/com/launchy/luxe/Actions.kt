package com.launchy.luxe

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.widget.Toast

/** What happens when a shortcut is tapped — shared by widgets and the in-app screen. */
object Actions {
    private val SCHEME = Regex("^[a-zA-Z][a-zA-Z0-9+.-]*:")

    fun run(ctx: Context, kind: String, value: String) {
        try {
            when (kind) {
                "url" -> openUrl(ctx, value)
                "call" -> call(ctx, value)
                "wa" -> whatsapp(ctx, value)
                "app" -> openApp(ctx, value)
            }
        } catch (e: Exception) {
            Toast.makeText(ctx, "تعذّر تنفيذ الإجراء", Toast.LENGTH_SHORT).show()
        }
    }

    private fun start(ctx: Context, i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }

    /** Opens websites inside a browser (the default one, or the system chooser if none is set). */
    fun openUrl(ctx: Context, raw: String) {
        val s = raw.trim()
        val uri = Uri.parse(if (SCHEME.containsMatchIn(s)) s else "https://$s")
        val scheme = uri.scheme?.lowercase()
        if (scheme != "http" && scheme != "https") {
            if (scheme in setOf("mailto", "sms", "geo", "tel")) start(ctx, Intent(Intent.ACTION_VIEW, uri))
            return
        }
        val browser = Intent(Intent.ACTION_VIEW, uri).addCategory(Intent.CATEGORY_BROWSABLE)
        browser.selector = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_BROWSER)
        try {
            start(ctx, browser)
        } catch (e: ActivityNotFoundException) {
            start(ctx, Intent(Intent.ACTION_VIEW, uri).addCategory(Intent.CATEGORY_BROWSABLE))
        }
    }

    /** Direct call when permission was granted, otherwise opens the dialer with the number. */
    fun call(ctx: Context, number: String) {
        val clean = number.filter { it.isDigit() || it == '+' }
        val granted = ctx.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        start(ctx, Intent(if (granted) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:$clean")))
    }

    /** Opens the WhatsApp chat of that number. */
    fun whatsapp(ctx: Context, number: String) {
        val d = number.filter { it.isDigit() }
        val uri = Uri.parse("https://api.whatsapp.com/send?phone=$d")
        for (pkg in listOf("com.whatsapp", "com.whatsapp.w4b")) {
            if (isInstalled(ctx, pkg)) {
                try { start(ctx, Intent(Intent.ACTION_VIEW, uri).setPackage(pkg)); return } catch (_: Exception) { }
            }
        }
        start(ctx, Intent(Intent.ACTION_VIEW, uri))
    }

    fun openApp(ctx: Context, pkg: String) {
        val launch = ctx.packageManager.getLaunchIntentForPackage(pkg.trim())
        if (launch != null) { start(ctx, launch); return }
        try {
            start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$pkg")))
        } catch (e: ActivityNotFoundException) {
            openUrl(ctx, "https://play.google.com/store/apps/details?id=$pkg")
        }
    }

    private fun isInstalled(ctx: Context, pkg: String): Boolean = try {
        ctx.packageManager.getPackageInfo(pkg, 0); true
    } catch (e: Exception) { false }
}

/** Invisible trampoline that runs a widget tap (asks for call permission the first time). */
class ActionActivity : Activity() {
    private var pendingNumber: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val kind = intent.getStringExtra("kind")
        val value = intent.getStringExtra("value")
        if (kind == null || value == null) { finish(); return }
        if (kind == "call" && checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            pendingNumber = value
            requestPermissions(arrayOf(Manifest.permission.CALL_PHONE), 7)
            return
        }
        Actions.run(this, kind, value)
        finish()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        pendingNumber?.let { Actions.run(this, "call", it) }
        pendingNumber = null
        finish()
    }
}
