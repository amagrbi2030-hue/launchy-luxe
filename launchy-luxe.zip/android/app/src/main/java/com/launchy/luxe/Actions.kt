package com.launchy.luxe

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.widget.Toast

/** What happens when a shortcut is tapped — shared by widgets and the in-app screen. */
object Actions {
    private val SCHEME = Regex("^[a-zA-Z][a-zA-Z0-9+.-]*:")
    const val WA = "com.whatsapp"
    const val WAB = "com.whatsapp.w4b"

    fun run(ctx: Context, kind: String, value: String, pkg: String = "", biz: String = "auto") {
        try {
            when (kind) {
                "url" -> openUrl(ctx, value, pkg)
                "call" -> call(ctx, value)
                "wa" -> whatsapp(ctx, value, biz)
                "sms" -> sms(ctx, value)
                "app" -> openApp(ctx, value)
                "ishort" -> runShortcut(ctx, value)
                "clockApp", "alarms" -> openClock(ctx)
                "setAlarm" -> setAlarm(ctx)
                "calendarApp" -> openCalendar(ctx)
                "refresh" -> { TimeJobs.refreshWeatherNow(ctx); Toast.makeText(ctx, "جارٍ تحديث الطقس…", Toast.LENGTH_SHORT).show() }
            }
        } catch (e: Exception) {
            Toast.makeText(ctx, "تعذّر تنفيذ الإجراء", Toast.LENGTH_SHORT).show()
        }
    }

    private fun start(ctx: Context, i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }

    /** Opens websites inside a browser (or the app the user picked for this link). */
    fun openUrl(ctx: Context, raw: String, pkg: String = "") {
        val s = raw.trim()
        val uri = Uri.parse(if (SCHEME.containsMatchIn(s)) s else "https://$s")
        val scheme = uri.scheme?.lowercase()
        if (scheme != "http" && scheme != "https") {
            if (scheme in setOf("mailto", "sms", "geo", "tel")) start(ctx, Intent(Intent.ACTION_VIEW, uri))
            return
        }
        if (pkg.isNotEmpty() && isInstalled(ctx, pkg)) {
            try { start(ctx, Intent(Intent.ACTION_VIEW, uri).addCategory(Intent.CATEGORY_BROWSABLE).setPackage(pkg)); return } catch (_: Exception) { }
        }
        val browser = Intent(Intent.ACTION_VIEW, uri).addCategory(Intent.CATEGORY_BROWSABLE)
        browser.selector = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_BROWSER)
        try {
            start(ctx, browser)
        } catch (e: ActivityNotFoundException) {
            start(ctx, Intent(Intent.ACTION_VIEW, uri).addCategory(Intent.CATEGORY_BROWSABLE))
        }
    }

    /** Direct call when permission was granted, otherwise opens the dialer with the number. */
    fun call(ctx: Context, number: String) {
        val clean = number.filter { it.isDigit() || it == '+' }
        val granted = ctx.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        start(ctx, Intent(if (granted) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:$clean")))
    }

    fun sms(ctx: Context, number: String) {
        start(ctx, Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + number.filter { it.isDigit() || it == '+' })))
    }

    /** International digits: +966… / 00966… / 05… with the default country code. */
    fun intl(ctx: Context, number: String): String {
        val t = number.trim()
        if (t.startsWith("+")) return t.filter { it.isDigit() }
        var d = t.filter { it.isDigit() }
        if (d.startsWith("00")) return d.substring(2)
        val cc = Store.cc(ctx).filter { it.isDigit() }
        if (cc.isNotEmpty() && d.startsWith("0")) d = cc + d.trimStart('0')
        else if (cc.isNotEmpty() && d.length <= 9 && !d.startsWith(cc)) d = cc + d
        return d
    }

    /** Opens the WhatsApp chat of that number (WhatsApp, Business, or the web fallback). */
    fun whatsapp(ctx: Context, number: String, biz: String = "auto") {
        val d = intl(ctx, number)
        val uri = Uri.parse("https://wa.me/$d")
        val order = when (biz) { "wab" -> listOf(WAB, WA); "wa" -> listOf(WA, WAB); else -> listOf(WA, WAB) }
        for (pkg in order) {
            if (isInstalled(ctx, pkg)) {
                try { start(ctx, Intent(Intent.ACTION_VIEW, uri).setPackage(pkg)); return } catch (_: Exception) { }
            }
        }
        Toast.makeText(ctx, "واتساب غير مثبت — سيُفتح الرابط في المتصفح", Toast.LENGTH_SHORT).show()
        start(ctx, Intent(Intent.ACTION_VIEW, uri))
    }

    fun openApp(ctx: Context, pkg: String) {
        val launch = ctx.packageManager.getLaunchIntentForPackage(pkg.trim())
        if (launch != null) { Store.recordRecent(ctx, pkg.trim()); start(ctx, launch); return }
        Toast.makeText(ctx, "التطبيق غير مثبت أو معطّل — سيُفتح في المتجر", Toast.LENGTH_SHORT).show()
        try {
            start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$pkg")))
        } catch (e: ActivityNotFoundException) {
            openUrl(ctx, "https://play.google.com/store/apps/details?id=$pkg")
        }
    }

    /** An app's internal shortcut; when the app no longer offers it, says so and opens the app itself. */
    fun runShortcut(ctx: Context, value: String) {
        if (AppShortcuts.launch(ctx, value)) return
        val pkg = AppShortcuts.packageOf(value)
        Toast.makeText(ctx, "هذا الاختصار لم يعد متاحاً في التطبيق — سيُفتح التطبيق نفسه", Toast.LENGTH_LONG).show()
        if (pkg.isNotEmpty()) openApp(ctx, pkg)
    }

    /** The phone's clock app (alarms screen), with known clock packages as fallback. */
    fun openClock(ctx: Context) {
        try { start(ctx, Intent(android.provider.AlarmClock.ACTION_SHOW_ALARMS)); return } catch (_: Exception) { }
        for (p in listOf("com.hihonor.deskclock", "com.huawei.deskclock", "com.google.android.deskclock", "com.android.deskclock", "com.sec.android.app.clockpackage")) {
            val i = ctx.packageManager.getLaunchIntentForPackage(p) ?: continue
            start(ctx, i); return
        }
        Toast.makeText(ctx, "لم يُعثر على تطبيق الساعة", Toast.LENGTH_SHORT).show()
    }

    /** "New alarm" screen of the clock app; falls back to the alarm list, then to the clock app itself. */
    fun setAlarm(ctx: Context) {
        try { start(ctx, Intent(android.provider.AlarmClock.ACTION_SET_ALARM)); return } catch (_: Exception) { }
        openClock(ctx)
    }

    /** The calendar app on today's date. */
    fun openCalendar(ctx: Context) {
        try { start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("content://com.android.calendar/time/" + System.currentTimeMillis()))); return } catch (_: Exception) { }
        try { start(ctx, Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALENDAR)); return } catch (_: Exception) { }
        Toast.makeText(ctx, "لم يُعثر على تطبيق التقويم", Toast.LENGTH_SHORT).show()
    }

    /**
     * The final intent for a tap, built ahead of time (when the widget is drawn), so the home screen
     * hands it straight to Android: no process of ours is started, nothing is read or decoded on the tap
     * — the same path as tapping the app's own icon. null = this action needs our code at tap time
     * (contact sheet, permission request, internal shortcuts, weather refresh…).
     */
    fun directIntent(ctx: Context, kind: String, value: String, pkg: String = "", biz: String = "auto"): Intent? = try {
        val pm = ctx.packageManager
        val i: Intent? = when (kind) {
            "app" -> pm.getLaunchIntentForPackage(value.trim())?.addFlags(Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            "url" -> {
                val s = value.trim(); val uri = Uri.parse(if (SCHEME.containsMatchIn(s)) s else "https://$s")
                val sc = uri.scheme?.lowercase()
                when {
                    sc == "http" || sc == "https" ->
                        if (pkg.isNotEmpty() && isInstalled(ctx, pkg)) Intent(Intent.ACTION_VIEW, uri).addCategory(Intent.CATEGORY_BROWSABLE).setPackage(pkg)
                        else Intent(Intent.ACTION_VIEW, uri).addCategory(Intent.CATEGORY_BROWSABLE)
                    sc in setOf("mailto", "sms", "geo", "tel") -> Intent(Intent.ACTION_VIEW, uri)
                    else -> null
                }
            }
            "call" -> {
                val clean = value.filter { it.isDigit() || it == '+' }
                val granted = ctx.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
                if (clean.length < 3) null else Intent(if (granted) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:$clean"))
            }
            "sms" -> Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + value.filter { it.isDigit() || it == '+' }))
            "wa" -> {
                val order = if (biz == "wab") listOf(WAB, WA) else listOf(WA, WAB)
                val p = order.firstOrNull { isInstalled(ctx, it) }
                if (p == null) null else Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + intl(ctx, value))).setPackage(p)
            }
            "clockApp", "alarms" -> Intent(android.provider.AlarmClock.ACTION_SHOW_ALARMS)
            "setAlarm" -> Intent(android.provider.AlarmClock.ACTION_SET_ALARM)
            else -> null
        }
        if (i != null && i.resolveActivity(pm) != null) i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) else null
    } catch (_: Exception) { null }

    fun isInstalled(ctx: Context, pkg: String): Boolean = try {
        ctx.packageManager.getPackageInfo(pkg, 0); true
    } catch (e: Exception) { false }
}

/** Invisible trampoline that runs a widget tap (asks for call permission the first time). */
/**
 * Invisible trampoline (Theme.NoDisplay: no window, no animation) for the taps that need our code.
 * It measures itself: how long the process took to start (cold start) and how long the action took,
 * so the app can show real numbers from this phone.
 */
class ActionActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        val t0 = android.os.SystemClock.uptimeMillis()
        super.onCreate(savedInstanceState)
        val kind = intent.getStringExtra("kind")
        val value = intent.getStringExtra("value")
        if (kind == null || value == null) { finish(); return }
        val needsUi = kind == "contact" || (kind == "call" && checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED && Store.prefs(this).getBoolean("askCall", true))
        if (needsUi) startActivity(Intent(intent).setClass(this, ActionSheetActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        else if (kind == "open") startActivity(Intent(this, MainActivity::class.java).putExtra("route", value.ifEmpty { "screen" }).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        else Actions.run(this, kind, value, intent.getStringExtra("pkg") ?: "", intent.getStringExtra("biz") ?: "auto")
        finish()
        overridePendingTransition(0, 0)
        TapStats.record(this, kind, t0)
    }
}

/** Taps measured on the phone (trampoline path only — direct taps never run our code). */
object TapStats {
    fun record(ctx: Context, kind: String, t0: Long) {
        try {
            val now = android.os.SystemClock.uptimeMillis()
            val procAge = t0 - android.os.Process.getStartUptimeMillis()
            val cold = procAge in 0..4000
            val p = Store.prefs(ctx)
            val arr = try { org.json.JSONArray(p.getString("tapStats", "[]")) } catch (_: Exception) { org.json.JSONArray() }
            val e = org.json.JSONObject().put("k", kind).put("t", System.currentTimeMillis()).put("cold", cold).put("start", if (cold) procAge else 0).put("run", now - t0)
            val out = org.json.JSONArray().put(e)
            for (i in 0 until minOf(arr.length(), 19)) out.put(arr.get(i))
            p.edit().putString("tapStats", out.toString()).apply()
            android.util.Log.i("LaunchyTap", "kind=$kind cold=$cold processStart=${if (cold) procAge else 0}ms action=${now - t0}ms")
        } catch (_: Exception) { }
    }
}

class ActionSheetActivity : Activity() {
    private var pendingNumber: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val kind = intent.getStringExtra("kind")
        val value = intent.getStringExtra("value")
        if (kind == null || value == null) { finish(); return }
        if (kind == "open") { startActivity(Intent(this, MainActivity::class.java).putExtra("route", value.ifEmpty { "screen" }).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); finish(); return }
        if (kind == "contact") { showOptions(value, intent.getStringExtra("wa") ?: value, intent.getStringExtra("name") ?: "", intent.getStringExtra("biz") ?: "auto"); return }
        if (kind == "call" && checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            pendingNumber = value
            requestPermissions(arrayOf(Manifest.permission.CALL_PHONE), 7)
            return
        }
        Actions.run(this, kind, value, intent.getStringExtra("pkg") ?: "", intent.getStringExtra("biz") ?: "auto")
        finish()
    }

    /** "Contact options" sheet: call, WhatsApp, WhatsApp Business (if installed), SMS. */
    private fun showOptions(number: String, wa: String, name: String, biz: String) {
        val labels = ArrayList<String>(); val acts = ArrayList<() -> Unit>()
        labels.add("اتصال هاتفي"); acts.add { callOrAsk(number) }
        labels.add("محادثة واتساب"); acts.add { Actions.whatsapp(this, wa, if (biz == "wab") "wab" else "wa"); finish() }
        if (Actions.isInstalled(this, Actions.WAB)) { labels.add("واتساب للأعمال"); acts.add { Actions.whatsapp(this, wa, "wab"); finish() } }
        labels.add("رسالة SMS"); acts.add { Actions.sms(this, number); finish() }
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle(name.ifEmpty { number })
            .setItems(labels.toTypedArray()) { _, i -> acts[i]() }
            .setOnCancelListener { finish() }
            .show()
    }

    private fun callOrAsk(number: String) {
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            pendingNumber = number
            requestPermissions(arrayOf(Manifest.permission.CALL_PHONE), 7)
        } else { Actions.call(this, number); finish() }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        pendingNumber?.let { Actions.call(this, it) }
        pendingNumber = null
        finish()
    }
}
