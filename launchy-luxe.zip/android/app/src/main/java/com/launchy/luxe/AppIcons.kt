package com.launchy.luxe

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.util.LruCache

/**
 * App icons for the home-screen widgets, drawn from the installed app itself at the exact pixel size
 * they occupy (never a small stored copy scaled up). The launcher activity's icon is used — the same
 * one the phone's launcher shows — and AdaptiveIconDrawable is drawn with the system's own mask.
 */
object AppIcons {
    private val cache = object : LruCache<String, Bitmap>(12 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }

    private fun drawable(ctx: Context, pkg: String): Drawable? {
        val pm = ctx.packageManager
        return try {
            val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setPackage(pkg)
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(main, 0).firstOrNull()?.loadIcon(pm) ?: pm.getApplicationIcon(pkg)
        } catch (_: Exception) { null }
    }

    fun bitmap(ctx: Context, pkg: String, side: Int): Bitmap? {
        if (pkg.isEmpty() || side < 4) return null
        val key = "$pkg@$side"
        cache.get(key)?.let { return it }
        val d = drawable(ctx, pkg) ?: return null
        return try {
            val b = Bitmap.createBitmap(side, side, Bitmap.Config.ARGB_8888)
            d.setBounds(0, 0, side, side)
            d.draw(Canvas(b))
            cache.put(key, b)
            b
        } catch (_: Exception) { null }
    }
}
