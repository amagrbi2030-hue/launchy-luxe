package com.launchy.luxe

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.util.LruCache

/**
 * App icons for the home-screen widgets, drawn from the installed app itself at the exact pixel size
 * they occupy (never a small stored copy scaled up). The launcher activity's icon is used — the same
 * one the phone's launcher shows — and AdaptiveIconDrawable is drawn with the system's own mask.
 */
object AppIcons {
    private val cache = object : LruCache<String, Bitmap>(12 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }

    /**
     * The apps behind the action buttons, by their real package names: the phone's default dialer
     * (for «اتصال»), its default SMS app, WhatsApp and WhatsApp Business. Social apps for the profile
     * widget too. Only installed apps are listed — a missing app is never replaced by a look-alike.
     */
    val SOCIAL = mapOf("instagram" to "com.instagram.android", "x" to "com.twitter.android", "facebook" to "com.facebook.katana",
        "tiktok" to "com.zhiliaoapp.musically", "snapchat" to "com.snapchat.android", "youtube" to "com.google.android.youtube",
        "linkedin" to "com.linkedin.android", "telegram" to "org.telegram.messenger", "threads" to "com.instagram.barcelona")

    fun resolve(ctx: Context, key: String): String = try {
        val pm = ctx.packageManager
        when (key) {
            "@dialer" -> (ctx.getSystemService(Context.TELECOM_SERVICE) as android.telecom.TelecomManager).defaultDialerPackage
                ?: pm.resolveActivity(Intent(Intent.ACTION_DIAL, android.net.Uri.parse("tel:1")), 0)?.activityInfo?.packageName ?: ""
            "@sms" -> android.provider.Telephony.Sms.getDefaultSmsPackage(ctx) ?: ""
            else -> key
        }
    } catch (_: Exception) { "" }

    fun actionApps(ctx: Context): org.json.JSONObject {
        val o = org.json.JSONObject()
        fun put(k: String, pkg: String) { if (pkg.isNotEmpty() && Actions.isInstalled(ctx, pkg)) o.put(k, pkg) }
        put("call", resolve(ctx, "@dialer")); put("sms", resolve(ctx, "@sms")); put("wa", Actions.WA); put("wab", Actions.WAB)
        for ((k, p) in SOCIAL) put(k, p)
        return o
    }

    private fun drawable(ctx: Context, pkg0: String): Drawable? {
        val pm = ctx.packageManager
        val pkg = resolve(ctx, pkg0)
        if (pkg.isEmpty()) return null
        return try {
            val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setPackage(pkg)
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(main, 0).firstOrNull()?.loadIcon(pm) ?: pm.getApplicationIcon(pkg)
        } catch (_: Exception) { null }
    }

    fun bitmap(ctx: Context, pkg: String, side: Int): Bitmap? {
        if (pkg.isEmpty() || side < 4) return null
        // the key carries the app's last-update time, so an updated app never shows its old icon
        val real = resolve(ctx, pkg)
        val stamp = try { ctx.packageManager.getPackageInfo(real, 0).lastUpdateTime } catch (_: Exception) { 0L }
        val key = "$real@$side@$stamp"
        cache.get(key)?.let { return it }
        val d = drawable(ctx, pkg) ?: return null
        return try {
            val b = Bitmap.createBitmap(side, side, Bitmap.Config.ARGB_8888)
            d.setBounds(0, 0, side, side)
            d.draw(Canvas(b))
            cache.put(key, b)
            b
        } catch (_: Exception) { null }
    }
}
