package com.launchy.luxe

import android.graphics.Path

/** Parses the generated absolute M/L/C/Z glyph paths (24×24 units). */
object Glyphs {
    private val cache = HashMap<String, Path>()

    @Synchronized
    fun path(name: String): Path = cache.getOrPut(name) {
        parse(GlyphData.paths[name] ?: GlyphData.paths.getValue("apps"))
    }

    private fun parse(d: String): Path {
        val p = Path()
        val t = d.trim().split(Regex("\\s+"))
        var i = 0
        fun f(j: Int) = t[j].toFloat()
        while (i < t.size) {
            when (t[i]) {
                "M" -> { p.moveTo(f(i + 1), f(i + 2)); i += 3 }
                "L" -> { p.lineTo(f(i + 1), f(i + 2)); i += 3 }
                "C" -> { p.cubicTo(f(i + 1), f(i + 2), f(i + 3), f(i + 4), f(i + 5), f(i + 6)); i += 7 }
                "Z" -> { p.close(); i += 1 }
                else -> i += 1
            }
        }
        return p
    }
}
