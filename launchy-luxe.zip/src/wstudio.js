/* =========================================================
   «استوديو الويدجيت» — the five design libraries (Sea Glass, Lumen,
   Knitted, MonoPulse, 3D Fluffy) shown on every widget type, with
   ready palettes per library, an advanced customisation panel shared
   by all styles, personal saved themes and favourites.
   The libraries are ordinary styles of the engine, so they work with
   every widget type and are drawn on the home screen like all others.
   ========================================================= */
const LIB_STYLES = ['seaGlass', 'lumen', 'knitted', 'monoPulse', 'fluffy'];
/** Ready palettes per library: [name, theme | '#custom', extra] — extra may set the glow colour or a 2–3 colour gradient. */
const STYLE_PALETTES = {
  seaGlass: [['تركواز', 'turquoise'], ['سماوي', 'sky'], ['نعناعي', 'mint'], ['أزرق بحري', 'royal'], ['زجاج المحيط', 'turquoise', { grad: ['#9ff5e8', '#5ec8e5', '#3f8fd8'] }]],
  lumen: [['بنفسجي', 'purple', { light: '#8f7dff' }], ['لافندر', 'lavender', { light: '#b9a6ff' }], ['أزرق ليلي', 'navy', { light: '#4ea8ff' }], ['وردي مضيء', 'rose', { light: '#ff6fb5' }], ['شفق', 'purple', { light: '#7df9ff', grad: ['#2b1055', '#3d2c8d', '#1c6fb8'] }]],
  knitted: [['بيج', 'ivory'], ['كريمي', '#e9d8bf'], ['وردي', 'rose'], ['بني', 'brown'], ['رمادي دافئ', '#b7aca0']],
  monoPulse: [['نبض أحمر', 'coral', { light: '#ff3b4e' }], ['نبض أزرق', 'royal', { light: '#3b82ff' }], ['نبض بنفسجي', 'purple', { light: '#a855f7' }], ['نبض أخضر', 'mint', { light: '#22c55e' }], ['نبض فضي', 'silver', { light: '#d6dde6' }]],
  fluffy: [['وردي', 'rose'], ['أزرق', 'sky'], ['بنفسجي', 'lavender'], ['برتقالي', 'sunset'], ['أخضر', 'mint'],
    ['وردي وأزرق', '#e9b8d0', { grad: ['#ffc3d8', '#bcdcff'] }], ['غروب ناعم', '#ffc2a8', { grad: ['#ffd1a8', '#ffb3c7', '#c9b6ff'] }], ['نعناع وليمون', '#cdeccf', { grad: ['#b8f2d9', '#fff3b0'] }]]
};
function applyPalette(d, [, th, x = {}]) {
  if (th && th[0] === '#') { d.theme = 'custom'; d.custom = th; } else if (th) d.theme = th;
  const look = (STYLES[d.style] || {}).look || {};   // only materials the style tints follow the palette (MonoPulse stays black)
  if (d.a.mat && d.a.mat !== 'none' && look.matTint) d.a.matTint = true;
  if (d.a.tileMat && d.a.tileMat !== 'none' && look.tileTint) d.a.tileTint = true;
  if (x.light) d.a.lightColor = x.light;
  d.a.grad = x.grad ? { to: 'tint', c: x.grad.slice(), type: 'diagonal', ang: 135, alpha: 72 } : null;
}
function palettePanel() {
  const P = STYLE_PALETTES[draft.style]; if (!P) return [];
  return [h('div', { class: 'chips' }, P.map(p => h('button', { type: 'button', class: 'chip pal-chip', onclick: () => update(d => applyPalette(d, p), { rebuild: true }) },
    h('i', { class: 'pal-dot', style: { background: p[2] && p[2].grad ? `linear-gradient(135deg,${p[2].grad.join(',')})` : (p[1][0] === '#' ? p[1] : ((THEMES.find(t => t.k === p[1]) || {}).c || '#888')) } }), p[0])))];
}

/* ---------------------------------------------------------- advanced customisation (all styles) */
function advPanel() {
  const a = draft.a, dens = Math.round(((a.gap - 2) / 18 + (a.padding - 4) / 24) * 50);
  const dr = h('input', { type: 'range', min: 0, max: 100, step: 1, value: clamp(dens, 0, 100), 'aria-label': 'كثافة العناصر' });
  dr.addEventListener('input', () => update(d => { const t = 1 - dr.value / 100; d.a.gap = Math.round(2 + 18 * t); d.a.padding = Math.round(4 + 24 * t); }, { commit: false }));
  dr.addEventListener('change', () => commitHist());
  const lc = h('input', { type: 'color', value: a.lightColor || '#ffd98a', 'aria-label': 'لون الإضاءة' });
  lc.addEventListener('input', () => update(d => { d.a.lightColor = lc.value; }, { commit: false }));
  lc.addEventListener('change', () => commitHist());
  return [
    slider('الشفافية', 'a.transp', 0, 80, 1, '%'),
    slider('شدة الإضاءة المحيطية', 'a.fx.ambient', 0, 100, 1, '%'),
    h('div', { class: 'ctl-row' }, h('span', {}, 'لون الإضاءة'), lc),
    slider('عمق الظلال', 'a.fx.soft', 0, 100, 1, '%'),
    slider('استدارة الزوايا', 'a.radius', 0, 60, 1, 'px'),
    slider('كثافة الخامة والملمس', 'a.matAlpha', 0, 100, 1, '%'),
    slider('حجم الأيقونات', 'a.iconScale', 60, 130, 1, '%'),
    slider('حجم الخط والأرقام', 'a.font', 8, 20, .5, 'px'),
    h('div', { class: 'ctl-row' }, h('span', {}, 'كثافة العناصر (متباعدة ← متقاربة)'), dr),
    h('p', { class: 'fine' }, 'نوع التدرج وألوانه من «مكتبة الألوان المتدرجة». كل الإعدادات تُحفظ مع التصميم وتظهر على الشاشة الرئيسية.')];
}

/* ---------------------------------------------------------- personal themes */
const MY_THEME_KEYS = ['radius', 'transp', 'border', 'shadow', 'glow', 'blur', 'iconScale', 'font', 'padding', 'gap', 'grad', ...LOOK_KEYS];
const myThemes = () => store.get('llx.myThemes', []) || [];
function saveMyTheme(name) {
  const a = {}; for (const k of MY_THEME_KEYS) if (draft.a[k] !== undefined) a[k] = clone(draft.a[k]);
  const list = myThemes().filter(t => t.name !== name);
  list.unshift({ name, style: draft.style, theme: draft.theme, custom: draft.custom, a });
  store.set('llx.myThemes', list.slice(0, 40));
}
function applyMyTheme(d, t) { if (STYLES[t.style]) d.style = t.style; d.theme = t.theme; d.custom = t.custom; Object.assign(d.a, clone(t.a)); }
function myThemesPanel() {
  const list = myThemes();
  return [
    list.length ? h('div', { class: 'chips' }, list.map(t => h('span', { class: 'chip my-th' },
      h('button', { type: 'button', class: 'link-btn', onclick: () => { update(d => applyMyTheme(d, t), { rebuild: true }); toast('طُبّق «' + t.name + '»'); } }, t.name),
      h('button', { type: 'button', class: 'link-btn', 'aria-label': 'حذف', onclick: () => { store.set('llx.myThemes', myThemes().filter(x => x.name !== t.name)); renderStep(); } }, '×')))) : h('p', { class: 'fine' }, 'لم تحفظ ثيمات بعد.'),
    h('button', { type: 'button', class: 'btn btn-sm', onclick: async () => {
      const n = await promptBox('حفظ ثيم شخصي', 'اسم الثيم', (STYLES[draft.style] || {}).n || 'ثيمي');
      if (!n || !String(n).trim()) return; saveMyTheme(String(n).trim()); toast('حُفظ الثيم «' + n + '»'); renderStep();
    } }, icon('plus', 15), 'حفظ المظهر الحالي كثيم')];
}

/* ---------------------------------------------------------- the studio page */
const WS = { type: 'clock', size: null, all: false };
const WS_TYPES = [['clock', 'ساعة رقمية'], ['analog', 'ساعة تناظرية'], ['date', 'التاريخ الهجري والميلادي'], ['weather', 'الطقس والتوقعات'], ['grid', 'التطبيقات والاختصارات'],
  ['people', 'جهات الاتصال'], ['links', 'المواقع والروابط'], ['social', 'التواصل الاجتماعي'], ['vertical', 'الشريط الطولي'], ['profile', 'البروفايل الشخصي']];
const WS_SIZES = [[2, 1], [2, 2], [2, 3], [4, 1], [4, 2], [4, 3], [4, 4], [2, 4], [2, 5]];
const favStyles = () => new Set(store.get('llx.favStyles', []) || []);
/** A complete design of the chosen kind in one library (demo content only in this preview, like the gallery). */
function wsDesign(kind, st, size) {
  let d;
  const preset = { clock: 'digitalBig', analog: 'romanIvory', date: 'dateDual', weather: 'wxMedium' }[kind];
  if (preset) d = normalize(presetDesign(preset));
  else if (kind === 'links' || kind === 'social') {
    d = normalize(newDesign({ type: 'profile' }));
    d.profile.design = kind === 'links' ? 'links' : 'square'; d.profile.name = 'اسمك';
    d.profile.links = kind === 'links'
      ? [{ id: 'w1', kind: 'website', handle: 'example.com', label: 'موقعي', desc: 'رابط تجريبي', show: true }, { id: 'w2', kind: 'custom', handle: 'example.org', label: 'متجري', show: true }]
      : [{ id: 's1', kind: 'instagram', handle: 'user', show: true }, { id: 's2', kind: 'x', handle: 'user', show: true }, { id: 's3', kind: 'facebook', handle: 'user', show: true }];
  } else if (kind === 'profile') { d = normalize(newDesign({ type: 'profile' })); d.profile.design = 'ring'; d.profile.name = 'اسمك'; }
  else d = normalize(newDesign({ type: kind }));
  d.style = st; Object.assign(d.a, styleLook(st));
  const P = STYLE_PALETTES[st]; if (P) applyPalette(d, P[0]);
  const sizes = TYPES[d.type].sizes || [];
  if (size && sizes.some(s => s[0] === size[0] && s[1] === size[1])) d.sizes[d.type] = size.slice();
  if (preset && kind === 'clock' && size) { d.sizes.clock = size.slice(); }
  d.name = (STYLES[st] || {}).n + ' · ' + (WS_TYPES.find(x => x[0] === kind) || [, ''])[1];
  return d;
}
function viewWStudio() {
  const v = $('#view'), favs = favStyles();
  const styles = (WS.all ? Object.keys(STYLES).filter(k => STYLES[k].n && !TYPES[k] && !['call', 'contact', 'balanced', 'soft', 'bold', 'compact', 'app', 'url', 'wa', 'sms'].includes(k)) : LIB_STYLES)
    .sort((a, b) => (favs.has(b) ? 1 : 0) - (favs.has(a) ? 1 : 0));
  const kindSizes = () => { const d = wsDesign(WS.type, 'seaGlass'); const ok = TYPES[d.type].sizes || []; return WS_SIZES.filter(s => ok.some(o => o[0] === s[0] && o[1] === s[1])); };
  const grid = h('div', { class: 'ws-grid' });
  const paint = () => {
    grid.replaceChildren();
    for (const st of styles) {
      const S = STYLES[st]; let d = wsDesign(WS.type, st, WS.size);
      const slot = h('div', { class: 'ws-prev' });
      const pals = STYLE_PALETTES[st] || [];
      const card = h('div', { class: 'ws-card' },
        h('div', { class: 'ws-top' }, h('div', {}, h('strong', {}, S.n), h('small', { dir: 'ltr' }, S.en || '')),
          h('button', { type: 'button', class: 'btn btn-ghost icon-btn' + (favs.has(st) ? ' on' : ''), 'aria-label': 'مفضلة', 'aria-pressed': String(favs.has(st)), onclick: () => { const f = favStyles(); f.has(st) ? f.delete(st) : f.add(st); store.set('llx.favStyles', [...f]); viewWStudio(); } }, favs.has(st) ? '★' : '☆')),
        slot,
        pals.length ? h('div', { class: 'ws-pals' }, pals.map(p => h('button', { type: 'button', class: 'pal-dot', title: p[0], 'aria-label': p[0], style: { background: p[2] && p[2].grad ? `linear-gradient(135deg,${p[2].grad.join(',')})` : (p[1][0] === '#' ? p[1] : ((THEMES.find(t => t.k === p[1]) || {}).c || '#888')) },
          onclick: () => { applyPalette(d, p); slot.replaceChildren(fitScaled(d, 260, 230).el); slot._d = d; } }))) : null,
        h('p', { class: 'fine' }, S.desc || ''),
        h('div', { class: 'ws-acts' },
          h('button', { type: 'button', class: 'btn btn-sm', onclick: () => wsOpen(slot._d || d) }, icon('edit', 15), 'تخصيص'),
          NATIVE ? h('button', { type: 'button', class: 'btn btn-gold btn-sm', onclick: () => wsAddHome(slot._d || d) }, icon('plus', 15), 'أضف للشاشة الرئيسية') : h('button', { type: 'button', class: 'btn btn-gold btn-sm', onclick: () => wsSave(slot._d || d) }, icon('plus', 15), 'حفظ التصميم')));
      lazy(slot, () => { slot.replaceChildren(fitScaled(d, 260, 230).el); slot._d = d; });
      grid.append(card);
    }
  };
  v.replaceChildren(h('div', { class: 'wrap' },
    h('div', { class: 'page-h' }, h('h1', {}, 'استوديو الويدجيت'), h('p', { class: 'muted' }, 'خمس مكتبات تصميم جديدة — الزجاج البحري، الإضاءة الفاخرة، النسيج المحبوك، النبض الأحادي، والمنفوخ ثلاثي الأبعاد — على كل أنواع الويدجت. جرّب النوع والمقاس واللون، ثم خصّص أو أضف للشاشة الرئيسية.')),
    h('div', { class: 'sub-h' }, 'نوع الويدجت'),
    h('div', { class: 'chips' }, WS_TYPES.map(([k, n]) => h('button', { type: 'button', class: 'chip' + (WS.type === k ? ' on' : ''), onclick: () => { WS.type = k; WS.size = null; viewWStudio(); } }, n))),
    h('div', { class: 'sub-h' }, 'المقاس'),
    h('div', { class: 'chips' }, [h('button', { type: 'button', class: 'chip' + (!WS.size ? ' on' : ''), onclick: () => { WS.size = null; viewWStudio(); } }, 'المقاس المقترح'),
      ...kindSizes().map(s => h('button', { type: 'button', class: 'chip' + (WS.size && WS.size[0] === s[0] && WS.size[1] === s[1] ? ' on' : ''), dir: 'ltr', onclick: () => { WS.size = s; viewWStudio(); } }, s.join('×')))]),
    h('label', { class: 'ctl-row', style: { margin: '10px 0' } }, h('span', {}, 'عرض كل الأنماط (وليس المكتبات الخمس فقط)'), (() => { const c = h('input', { type: 'checkbox', checked: WS.all }); c.addEventListener('change', () => { WS.all = c.checked; viewWStudio(); }); return c; })()),
    grid));
  paint();
}
function wsOpen(d) {
  (async () => {
    if (!(await guardDirty())) return;
    draft = clone(d); draft.id = null; meta = { editingId: null, savedJSON: '' }; resetHist(); ui.step = 2; saveDraftNow(); goEditor();
  })();
}
function wsSave(d) {
  draft = clone(d); draft.id = null; meta = { editingId: null, savedJSON: '' }; resetHist();
  const s = saveDesign(); if (s) toast('حُفظ في «تصاميمي»'); return s;
}
async function wsAddHome(d) {
  if (!(await guardDirty())) return;
  // widgets that show YOUR content (apps, contacts, links) need it first: the preview here uses sample content only
  if (!isTimeType(d)) {
    draft = clone(d); draft.id = null; if (d.type === 'profile') draft.profile.links = []; meta = { editingId: null, savedJSON: '' }; resetHist(); ui.step = 3; saveDraftNow(); goEditor();
    toast('أضف محتواك، ثم «إضافة للشاشة الرئيسية» من خطوة الحفظ');
    return;
  }
  const s = wsSave(d); if (!s) return;
  await bakeAll(); pinNative(s);
}
