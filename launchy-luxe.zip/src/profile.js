/* =========================================================
   Personal Profile widgets — «البروفايل الشخصي | My Social Profile»
   A separate section from contacts: your own photo, name, short bio
   and your accounts / links. Five designs (square, large photo, ring,
   links list, wide), any material from the style library, gradients.
   Social icons are the REAL icons of the apps installed on the phone
   (Instagram, X, Facebook…); when an app is not installed the link
   shows a neutral badge with the platform's name — never a copied logo.
   Links open with ACTION_VIEW, in the platform's app when installed.
   ========================================================= */
Object.assign(TYPES, {
  profile: { n: 'البروفايل الشخصي', en: 'My Social Profile', short: 'بروفايل', g: 'users',
    sizes: [[2, 2], [2, 3], [2, 4], [3, 3], [3, 4], [4, 2], [4, 3], [4, 4]],
    desc: 'صورتك الشخصية واسمك وحساباتك وروابطك على الشاشة الرئيسية — منفصل عن جهات الاتصال.' }
});

/** Platforms: name, profile URL from a user name, badge colour (used only when the app is not installed). */
const PF_PLATFORMS = {
  instagram: { n: 'Instagram', ph: 'اسم المستخدم', url: h => 'https://instagram.com/' + h, c: '#c13584', s: 'IG' },
  x:         { n: 'X', ph: 'اسم المستخدم', url: h => 'https://x.com/' + h, c: '#16181c', s: 'X' },
  facebook:  { n: 'Facebook', ph: 'اسم المستخدم أو رابط الصفحة', url: h => 'https://facebook.com/' + h, c: '#1b5fd1', s: 'FB' },
  tiktok:    { n: 'TikTok', ph: 'اسم المستخدم', url: h => 'https://tiktok.com/@' + h, c: '#111111', s: 'TT' },
  snapchat:  { n: 'Snapchat', ph: 'اسم المستخدم', url: h => 'https://snapchat.com/add/' + h, c: '#c9b800', s: 'SC' },
  youtube:   { n: 'YouTube', ph: 'اسم القناة', url: h => 'https://youtube.com/@' + h, c: '#c4302b', s: 'YT' },
  linkedin:  { n: 'LinkedIn', ph: 'اسم المستخدم', url: h => 'https://linkedin.com/in/' + h, c: '#0a66c2', s: 'in' },
  telegram:  { n: 'Telegram', ph: 'اسم المستخدم', url: h => 'https://t.me/' + h, c: '#229ed9', s: 'TG' },
  threads:   { n: 'Threads', ph: 'اسم المستخدم', url: h => 'https://threads.net/@' + h, c: '#222222', s: 'TH' },
  website:   { n: 'الموقع', ph: 'https://…', url: h => h, c: '#8a6d2b', s: '', glyph: 'globe' },
  custom:    { n: 'رابط', ph: 'https://…', url: h => h, c: '#5b6b7a', s: '', glyph: 'link' }
};
/** Android package of each platform's app (the same list as AppIcons.SOCIAL). */
const PF_PKG = { instagram: 'com.instagram.android', x: 'com.twitter.android', facebook: 'com.facebook.katana', tiktok: 'com.zhiliaoapp.musically',
  snapchat: 'com.snapchat.android', youtube: 'com.google.android.youtube', linkedin: 'com.linkedin.android', telegram: 'org.telegram.messenger', threads: 'com.instagram.barcelona' };
const PF_DESIGNS = [['square', 'بروفايل مربع', [2, 3]], ['large', 'صورة كبيرة', [2, 3]], ['ring', 'حلقة دائرية', [2, 3]], ['links', 'المواقع والروابط', [2, 4]], ['wide', 'بروفايل عريض', [4, 2]]];
const PF_RINGS = [['gradient', 'متدرجة'], ['gold', 'ذهبية'], ['silver', 'فضية'], ['glass', 'زجاجية'], ['neon', 'نيون']];
const PF_FRAMES = [['none', 'بدون'], ['gold', 'ذهبي'], ['silver', 'فضي'], ['rose', 'ذهبي وردي'], ['glass', 'زجاجي']];
const defaultProfile = () => ({ design: 'square', photo: '', shape: 'circle', name: '', bio: '', links: [],
  ring: { kind: 'gradient', colors: ['#f9ce34', '#ee2a7b', '#6228d7'] }, glow: true, frame: 'gold', names: false, iconSize: 'm', iconFrame: 'none', bioOn: true });

/** The URL a link opens (a pasted full URL is kept as it is). */
function pfUrl(l) {
  const P = PF_PLATFORMS[l.kind] || PF_PLATFORMS.custom, v = String(l.handle || l.url || '').trim();
  if (!v) return '';
  if (/^[a-z][a-z0-9+.-]*:/i.test(v) || /^[\w-]+(\.[\w-]+)+(\/|$)/.test(v) && (l.kind === 'website' || l.kind === 'custom' || /\//.test(v))) return urlOf(v);
  return P.url(v.replace(/^@/, ''));
}
const pfLinks = o => (o.links || []).filter(l => l.show !== false && pfUrl(l));
/** Item for the tap: opens the link — in the platform's app when it is installed (Android chooses it). */
const pfItem = l => ({ id: 'pf_' + l.id, kind: 'url', label: l.label || (PF_PLATFORMS[l.kind] || {}).n || 'رابط', value: pfUrl(l), openWith: PF_PKG[l.kind] && actPkg(l.kind) ? PF_PKG[l.kind] : '' });

/* ---------------------------------------------------------- painting helpers */
function pfPhoto(ctx, S, L, o, x, y, w, h, shape) {
  const P = shape === 'circle' ? (() => { const p = new Path2D(); p.arc(x + w / 2, y + h / 2, Math.min(w, h) / 2, 0, TAU); return p; })()
    : rrPath(new Path2D(), x, y, w, h, shape === 'square' ? Math.min(w, h) * .06 : Math.min(w, h) * .2);
  const img = getImg(o.photo);
  ctx.save(); ctx.clip(P);
  if (img) drawCover(ctx, img, x, y, w, h);
  else {
    const g = ctx.createLinearGradient(x, y, x + w, y + h); g.addColorStop(0, mix(L.acc, '#ffffff', .25)); g.addColorStop(1, mix(L.acc, '#000000', .45));
    ctx.fillStyle = g; ctx.fillRect(x, y, w, h);
    fillText(ctx, initials(o.name || 'أنا'), x + w / 2, y + h / 2 + 1, w * .8, { size: Math.min(w, h) * .36, weight: 700, color: '#ffffff' });
  }
  ctx.restore();
  return P;
}
function pfFrame(ctx, S, L, kind, P, k) {
  if (!kind || kind === 'none') return;
  const col = { gold: '#d4af37', silver: '#c9ced6', rose: '#e0a899' }[kind];
  ctx.save();
  if (kind === 'glass') { ctx.lineWidth = 3 * k; ctx.strokeStyle = 'rgba(255,255,255,.75)'; ctx.stroke(P); }
  else { ctx.lineWidth = 3.4 * k; ctx.strokeStyle = metalGradFor(ctx, col, P); ctx.stroke(P); ctx.lineWidth = .8 * k; ctx.strokeStyle = 'rgba(255,255,255,.55)'; ctx.stroke(P); }
  ctx.restore();
}
/** a metal gradient over the whole canvas width (Path2D has no bounds API) */
function metalGradFor(ctx, col) { const g = ctx.createLinearGradient(0, 0, ctx.canvas.width, ctx.canvas.height); for (const [t, c] of metalStops(col)) g.addColorStop(t, c); return g; }
/** Glow behind the photo, in the design's accent (or the ring's first colour). */
function pfGlow(ctx, L, cx, cy, r, col) {
  const g = ctx.createRadialGradient(cx, cy, r * .5, cx, cy, r * 1.35);
  g.addColorStop(0, hexA(col || L.acc, .55)); g.addColorStop(1, hexA(col || L.acc, 0));
  ctx.fillStyle = g; ctx.fillRect(cx - r * 1.4, cy - r * 1.4, r * 2.8, r * 2.8);
}
function hexA(c, a) { const m = /^#?([0-9a-f]{6})$/i.exec(String(c).trim()); if (!m) return `rgba(212,175,55,${a})`; const n = parseInt(m[1], 16); return `rgba(${n >> 16},${(n >> 8) & 255},${n & 255},${a})`; }
function pfRing(ctx, L, o, cx, cy, R, t) {
  const kind = o.ring.kind || 'gradient', cols = (o.ring.colors || []).filter(Boolean);
  ctx.save();
  ctx.beginPath(); ctx.arc(cx, cy, R - t / 2, 0, TAU); ctx.lineWidth = t;
  if (kind === 'gold' || kind === 'silver') ctx.strokeStyle = (() => { const g = ctx.createLinearGradient(cx - R, cy - R, cx + R, cy + R); for (const [s, c] of metalStops(kind === 'gold' ? '#d4af37' : '#c9ced6')) g.addColorStop(s, c); return g; })();
  else if (kind === 'glass') ctx.strokeStyle = 'rgba(255,255,255,.55)';
  else if (kind === 'neon') { const c = cols[0] || L.acc; ctx.shadowColor = c; ctx.shadowBlur = t * 2.2; ctx.strokeStyle = c; }
  else {
    let g;
    try { g = ctx.createConicGradient(-Math.PI / 2, cx, cy); const cs = cols.length > 1 ? cols : [L.acc, mix(L.acc, '#ffffff', .4)]; cs.concat(cs[0]).forEach((c, i, a) => g.addColorStop(i / (a.length - 1), c)); }
    catch (e) { g = ctx.createLinearGradient(cx - R, cy - R, cx + R, cy + R); (cols.length ? cols : [L.acc, '#ffffff']).forEach((c, i, a) => g.addColorStop(i / Math.max(1, a.length - 1), c)); }
    ctx.strokeStyle = g;
  }
  ctx.stroke();
  if (kind === 'glass') { ctx.lineWidth = 1; ctx.strokeStyle = 'rgba(255,255,255,.9)'; ctx.beginPath(); ctx.arc(cx, cy, R - .5, 0, TAU); ctx.stroke(); }
  ctx.restore();
}
/** One social / link icon: the app's own icon when installed, else a neutral badge with the platform's short name. */
function pfIcon(ctx, S, L, o, l, cx, cy, s) {
  const P = PF_PLATFORMS[l.kind] || PF_PLATFORMS.custom, pkg = PF_PKG[l.kind] ? actPkg(l.kind) : '';
  const fr = l.frame || o.iconFrame || 'none';
  if (fr !== 'none') { const p = new Path2D(); p.arc(cx, cy, s * .62, 0, TAU); ctx.save(); ctx.fillStyle = fr === 'glass' ? 'rgba(255,255,255,.22)' : metalGradFor(ctx, { gold: '#d4af37', silver: '#c9ced6', rose: '#e0a899' }[fr] || '#d4af37'); ctx.fill(p); ctx.restore(); }
  const custom = l.img && getImg(l.img);
  if (custom) { const p = new Path2D(); p.arc(cx, cy, s / 2, 0, TAU); ctx.save(); ctx.clip(p); drawCover(ctx, custom, cx - s / 2, cy - s / 2, s, s); ctx.restore(); return; }
  if (pkg && realIcon(ctx, S, pkg, cx, cy, s)) return;
  const col = l.color || P.c, p = new Path2D(); p.arc(cx, cy, s / 2, 0, TAU);
  ctx.save(); ctx.shadowColor = 'rgba(0,0,0,.3)'; ctx.shadowBlur = 4 * S; ctx.shadowOffsetY = 1.5 * S;
  ctx.fillStyle = linGrad(ctx, cx, cy - s / 2, cx, cy + s / 2, [[0, mix(col, '#ffffff', .18)], [1, mix(col, '#000000', .2)]]); ctx.fill(p); ctx.restore();
  if (P.glyph) paintGlyph(ctx, S, P.glyph, cx, cy, s * .54, '#ffffff');
  else fillText(ctx, P.s, cx, cy + 1, s * .9, { size: s * (P.s.length > 1 ? .36 : .5), weight: 800, color: '#ffffff', dir: 'ltr' });
}
const PF_ICON = { s: 30, m: 38, l: 46, xl: 54 };

/* ---------------------------------------------------------- layout */
function layProfile(d, LY, C) {
  const o = d.profile, a = d.a, links = pfLinks(o);
  let design = o.design || 'square';
  // the chosen design adapts to the widget's real proportions
  if (design !== 'wide' && C.w > C.h * 1.5) design = 'wide';
  if (design === 'wide' && C.h > C.w * 1.1) design = 'square';
  LY.info.pf = design;
  LY.imgs = [o.photo, ...links.map(l => l.img)].filter(Boolean);   // the preview re-draws when they finish loading
  const draw = fn => LY.nodes.push({ k: 'draw', fn });
  let nameS = Math.max(13, Math.min(C.w * .1, 22) * a.font / 12); const bioS = Math.max(11, nameS * .66);
  if (design === 'wide') nameS = Math.max(13, Math.min(nameS, C.w * .4 / Math.max(4, [...(o.name || '')].length * .5)));
  const icS = (PF_ICON[o.iconSize] || 38) * Math.min(1.25, Math.max(.8, C.w / 150));
  const iconRow = (y, maxW, x0, rows = 1) => {
    // icons in rows; RTL (first link on the right). Returns the height used.
    const lbl = o.names ? bioS * 1.3 : 0, gap = icS * .32;
    const perRow = Math.max(1, Math.floor((maxW + gap) / (icS + gap)));
    const list = links.slice(0, perRow * rows), nr = Math.ceil(list.length / perRow);
    list.forEach((l, i) => {
      const r = Math.floor(i / perRow), inRow = Math.min(perRow, list.length - r * perRow), c = i % perRow;
      const tw = inRow * icS + (inRow - 1) * gap, cx = x0 + (maxW + tw) / 2 - icS / 2 - c * (icS + gap), cy = y + r * (icS + lbl + gap) + icS / 2;
      draw((ctx, S, L) => { pfIcon(ctx, S, L, o, l, cx, cy, icS); if (o.names) fillText(ctx, l.label || (PF_PLATFORMS[l.kind] || {}).n, cx, cy + icS / 2 + lbl / 2 + 1, icS + gap, { size: bioS * .85, color: L.sub }); });
      const t = Math.max(48, icS + 8); LY.hits.push({ x: cx - t / 2, y: cy - t / 2, w: t, h: t, it: pfItem(l), act: 'item' });
    });
    return nr ? nr * (icS + lbl) + (nr - 1) * gap : 0;
  };
  const nameBlock = (cx, y, w, align) => {
    let h = 0;
    if (o.name) { draw((ctx, S, L) => fillText(ctx, o.name, cx, y + nameS * .62, w, { size: nameS, weight: 700, color: L.text, font: FONT_D, align })); h += nameS * 1.3; }
    if (o.bio && o.bioOn !== false) { const yy = y + h; draw((ctx, S, L) => fillText(ctx, o.bio, cx, yy + bioS * .6, w, { size: bioS, color: L.sub, align })); h += bioS * 1.45; }
    return h;
  };
  const textH = (o.name ? nameS * 1.3 : 0) + (o.bio && o.bioOn !== false ? bioS * 1.45 : 0);
  const rowsH = links.length ? icS + (o.names ? bioS * 1.3 : 0) : 0, gap = Math.max(6, C.h * .035);
  if (design === 'wide') {
    // photo on the right · name and bio in the middle · the accounts on the left (up to 3 per row, 2 rows)
    const ph = Math.min(C.h * .9, C.w * .3), px = C.x + C.w - ph, py = C.y + (C.h - ph) / 2;
    draw((ctx, S, L) => { if (o.glow) pfGlow(ctx, L, px + ph / 2, py + ph / 2, ph / 2); const P = pfPhoto(ctx, S, L, o, px, py, ph, ph, o.shape); pfFrame(ctx, S, L, o.frame, P, ph / 80); });
    // at most 4 accounts here (2×2) so each stays big and tappable; the «links» design lists them all
    const n = Math.min(4, links.length), perRow = n <= 2 ? n : 2, rows = n <= 2 ? 1 : 2;
    const ws = Math.max(28, Math.min(icS * 1.1, (C.h - 8) / (rows * 1.25), (C.w * .32) / (Math.max(1, perRow) * 1.25)));
    const iw = perRow * ws * 1.3, tx = px - C.w * .04, mid = tx - (C.x + iw + C.w * .03);
    nameBlock(tx, C.y + (C.h - textH) / 2, mid, 'start');
    const gapI = ws * .3, top = C.y + (C.h - (rows * ws + (rows - 1) * gapI)) / 2;
    links.slice(0, n).forEach((l, i) => {
      const r = Math.floor(i / perRow), c = i % perRow, cx = C.x + iw - ws / 2 - c * (ws + gapI), cy = top + r * (ws + gapI) + ws / 2;
      draw((ctx, S, L) => pfIcon(ctx, S, L, o, l, cx, cy, ws));
      const t = Math.max(48, ws + 8); LY.hits.push({ x: cx - t / 2, y: cy - t / 2, w: t, h: t, it: pfItem(l), act: 'item' });
    });
    return;
  }
  if (design === 'links') {
    // photo + name on top, then one row per link (icon · label · short description); scrolls when long
    const ph = Math.min(C.w * .42, C.h * .26), py = C.y + gap * .4, cx = C.x + C.w / 2;
    draw((ctx, S, L) => { if (o.glow) pfGlow(ctx, L, cx, py + ph / 2, ph / 2); const P = pfPhoto(ctx, S, L, o, cx - ph / 2, py, ph, ph, o.shape); pfFrame(ctx, S, L, o.frame, P, ph / 80); });
    let y = py + ph + gap * .6;
    y += nameBlock(cx, y, C.w * .94) + gap * .4;
    const rowH = Math.max(44, icS + 10), cuts = [];
    links.forEach((l, i) => {
      const ry = y, it = pfItem(l), lab = l.label || (PF_PLATFORMS[l.kind] || {}).n || 'رابط', sub = l.desc || '';
      draw((ctx, S, L) => {
        const P = rrPath(new Path2D(), C.x, ry, C.w, rowH, Math.min(14, rowH * .3));
        ctx.save(); ctx.fillStyle = surfaceColors(L).bg; ctx.fill(P); ctx.lineWidth = 1; ctx.strokeStyle = surfaceColors(L).line; ctx.stroke(P); ctx.restore();
        const s2 = rowH - 12; pfIcon(ctx, S, L, o, l, C.x + C.w - 6 - s2 / 2, ry + rowH / 2, s2);
        const tx = C.x + C.w - 14 - s2, tw = C.w - s2 - 24;
        fillText(ctx, lab, tx, ry + rowH / 2 - (sub ? bioS * .62 : 0), tw, { size: bioS * 1.12, weight: 700, color: L.text, align: 'start' });
        if (sub) fillText(ctx, sub, tx, ry + rowH / 2 + bioS * .72, tw, { size: bioS * .9, color: L.sub, align: 'start' });
      });
      LY.hits.push({ x: C.x, y: ry, w: C.w, h: rowH, it, act: 'item' });
      y += rowH + 6; cuts.push(y - 3);
    });
    if (y - 6 > C.y + C.h && !SCROLL_OFF) LY.scroll = { x: C.x, y: C.y, w: C.w, h: C.h, total: y - 6 - C.y, cuts: cuts.slice(0, -1) };
    LY.info.scroll = !!LY.scroll;
    return;
  }
  // square / large / ring: photo on top, name, icons at the bottom
  const avail = C.h - textH - (rowsH ? rowsH + gap : 0) - gap;
  const cx = C.x + C.w / 2;
  if (design === 'large') {
    const pw = C.w, ph = Math.max(40, avail), py = C.y;
    draw((ctx, S, L) => { if (o.glow) pfGlow(ctx, L, cx, py + ph / 2, Math.min(pw, ph) / 2); const P = pfPhoto(ctx, S, L, o, C.x, py, pw, ph, o.shape === 'circle' ? 'soft' : o.shape); pfFrame(ctx, S, L, o.frame, P, Math.min(pw, ph) / 80); });
    nameBlock(cx, py + ph + gap * .5, C.w * .96);
  } else {
    const ring = design === 'ring', D = Math.max(40, Math.min(C.w * (ring ? .86 : .8), avail)), py = C.y + Math.max(0, (avail - D) / 2) * .5;
    draw((ctx, S, L) => {
      const R = D / 2, ccy = py + R;
      if (o.glow) pfGlow(ctx, L, cx, ccy, R, ring ? (o.ring.colors || [])[0] : null);
      if (ring) { const t = Math.max(4, R * .12); pfRing(ctx, L, o, cx, ccy, R, t); pfPhoto(ctx, S, L, o, cx - R + t * 1.5, ccy - R + t * 1.5, D - t * 3, D - t * 3, 'circle'); }
      else { const P = pfPhoto(ctx, S, L, o, cx - R, py, D, D, o.shape); pfFrame(ctx, S, L, o.frame, P, D / 80); }
    });
    nameBlock(cx, py + D + gap * .5, C.w * .96);
  }
  if (rowsH) iconRow(C.y + C.h - rowsH, C.w, C.x, 1);
  // the photo / name area opens the first link (or the website) — the icons each open their own
  const main = links.find(l => l.kind === 'website') || links[0];
  if (main) LY.hits.unshift({ x: C.x, y: C.y, w: C.w, h: C.h - rowsH - gap, it: pfItem(main), act: 'item' });
}

/* ---------------------------------------------------------- editor */
/** Square crop with zoom + drag, saved at 512 px (sharp on any phone). */
function pfCropDialog(src, done) {
  const img = new Image(); img.src = src;
  const cv = h('canvas', { width: 320, height: 320, class: 'pf-crop' }); let z = 1, ox = 0, oy = 0, drag = null;
  const paint = () => { const g = cv.getContext('2d'); g.clearRect(0, 0, 320, 320); if (!img.complete) return; const s = Math.max(320 / img.width, 320 / img.height) * z, w = img.width * s, hh = img.height * s;
    g.drawImage(img, (320 - w) / 2 + ox, (320 - hh) / 2 + oy, w, hh); g.fillStyle = 'rgba(0,0,0,.45)'; g.beginPath(); g.rect(0, 0, 320, 320); g.arc(160, 160, 158, 0, TAU, true); g.fill('evenodd'); };
  img.onload = paint;
  cv.addEventListener('pointerdown', e => { drag = [e.clientX - ox, e.clientY - oy]; cv.setPointerCapture(e.pointerId); });
  cv.addEventListener('pointermove', e => { if (!drag) return; ox = e.clientX - drag[0]; oy = e.clientY - drag[1]; paint(); });
  cv.addEventListener('pointerup', () => { drag = null; });
  const zr = h('input', { type: 'range', min: 1, max: 4, step: .02, value: 1, 'aria-label': 'تكبير' }); zr.addEventListener('input', () => { z = +zr.value; paint(); });
  const out = () => { const c = document.createElement('canvas'); c.width = c.height = 512; const g = c.getContext('2d'); const k = 512 / 320, s = Math.max(320 / img.width, 320 / img.height) * z, w = img.width * s, hh = img.height * s;
    g.drawImage(img, ((320 - w) / 2 + ox) * k, ((320 - hh) / 2 + oy) * k, w * k, hh * k); return c.toDataURL('image/jpeg', .9); };
  openDialog('قص الصورة', h('div', { class: 'form' }, cv, h('label', { class: 'field' }, h('span', {}, 'التكبير'), zr), h('p', { class: 'fine' }, 'اسحب الصورة لضبط موضعها داخل الدائرة.')),
    [{ label: 'إلغاء' }, { label: 'حفظ الصورة', cls: 'btn-gold', onClick: () => done(out()) }]);
}
function profileContent() {
  const o = draft.profile, els = [intro('بياناتك', 'صورتك واسمك وحساباتك. تُحفظ على هاتفك وتبقى بعد إعادة تشغيله.')];
  const fi = h('input', { type: 'file', accept: 'image/*', hidden: true });
  fi.addEventListener('change', async () => { if (!fi.files[0]) return; try { const src = await readImageKeep(fi.files[0], 1400); pfCropDialog(src, url => update(d => { d.profile.photo = url; }, { rebuild: true })); } catch (e) { toast('تعذّرت قراءة الصورة'); } });
  els.push(h('div', { class: 'pf-photo-row' }, fi,
    h('div', { class: 'pf-photo-prev' + (o.shape === 'circle' ? ' round' : '') }, o.photo ? h('img', { src: o.photo, alt: '' }) : icon('users', 30)),
    h('div', { class: 'pf-photo-btns' },
      h('button', { type: 'button', class: 'btn btn-gold', onclick: () => fi.click() }, icon('image', 18), o.photo ? 'تغيير الصورة' : 'رفع صورتي'),
      o.photo ? h('button', { type: 'button', class: 'btn', onclick: () => pfCropDialog(o.photo, url => update(d => { d.profile.photo = url; }, { rebuild: true })) }, 'قص وتعديل') : null,
      o.photo ? h('button', { type: 'button', class: 'btn btn-danger', onclick: () => update(d => { d.profile.photo = ''; }, { rebuild: true }) }, 'إزالة') : null)));
  els.push(seg('شكل الصورة', 'profile.shape', [['circle', 'دائرية'], ['soft', 'حواف دائرية'], ['square', 'مربعة']]));
  const nm = h('input', { type: 'text', class: 'inp', value: o.name, maxlength: 40, placeholder: 'اسمك' });
  nm.addEventListener('input', () => update(d => { d.profile.name = nm.value; }));
  const bio = h('input', { type: 'text', class: 'inp', value: o.bio, maxlength: 80, placeholder: 'وصف مختصر (اختياري)' });
  bio.addEventListener('input', () => update(d => { d.profile.bio = bio.value; }));
  els.push(h('label', { class: 'field' }, h('span', {}, 'الاسم'), nm), h('label', { class: 'field' }, h('span', {}, 'الوصف المختصر'), bio));
  els.push(h('div', { class: 'sub-h' }, 'الحسابات والروابط'));
  const list = h('ul', { class: 'it-list pf-links' });
  (o.links || []).forEach((l, i) => {
    const P = PF_PLATFORMS[l.kind] || PF_PLATFORMS.custom;
    list.append(h('li', { class: 'it-row', 'data-id': l.id },
      h('button', { type: 'button', class: 'grip', 'aria-label': 'اسحب لإعادة الترتيب' }, icon('grip')),
      h('span', { class: 'pf-badge', style: { background: l.color || P.c } }, P.s || '🔗'),
      h('div', { class: 'it-txt' }, h('strong', {}, l.label || P.n), h('small', { dir: 'ltr' }, pfUrl(l) || 'بلا رابط')),
      h('div', { class: 'it-act' },
        h('button', { type: 'button', class: 'btn', 'aria-label': 'تحريك لأعلى', disabled: i === 0, onclick: () => update(d => { const a = d.profile.links; [a[i - 1], a[i]] = [a[i], a[i - 1]]; }, { rebuild: true }) }, icon('up', 16)),
        h('button', { type: 'button', class: 'btn', 'aria-label': 'تعديل', onclick: () => pfLinkDialog(l) }, icon('edit', 16)),
        h('button', { type: 'button', class: 'btn btn-danger', 'aria-label': 'حذف', onclick: () => update(d => { d.profile.links = d.profile.links.filter(x => x.id !== l.id); }, { rebuild: true }) }, icon('trash', 16)))));
  });
  if ((o.links || []).length) { els.push(list); enableDrag(list, ids => update(d => d.profile.links.sort((a, b) => ids.indexOf(a.id) - ids.indexOf(b.id)), { rebuild: true }), true); }
  els.push(h('div', { class: 'chips' }, Object.entries(PF_PLATFORMS).map(([k, P]) => h('button', { type: 'button', class: 'chip', onclick: () => pfLinkDialog({ id: uid(), kind: k, handle: '', label: k === 'website' ? 'موقعي' : k === 'custom' ? '' : P.n, desc: '', show: true }, true) }, '+ ' + P.n))));
  els.push(h('p', { class: 'fine' }, NATIVE ? 'تظهر أيقونة كل منصة بأيقونة تطبيقها المثبت على هاتفك، ويفتح الرابط في التطبيق مباشرة. المنصة غير المثبتة تظهر بشارة باسمها وتفتح في المتصفح.' : 'في تطبيق Android تظهر أيقونات التطبيقات المثبتة نفسها. هنا تظهر شارة باسم المنصة.'));
  return els;
}
function pfLinkDialog(l0, isNew) {
  const l = Object.assign({}, l0), P = PF_PLATFORMS[l.kind] || PF_PLATFORMS.custom;
  const hi = h('input', { type: 'text', class: 'inp', dir: 'ltr', value: l.handle || '', placeholder: P.ph, autocapitalize: 'off', spellcheck: 'false' });
  const li = h('input', { type: 'text', class: 'inp', value: l.label || '', placeholder: P.n, maxlength: 30 });
  const di = h('input', { type: 'text', class: 'inp', value: l.desc || '', placeholder: 'وصف قصير (اختياري)', maxlength: 50 });
  const ci = h('input', { type: 'color', value: l.color || P.c });
  const fi = h('input', { type: 'file', accept: 'image/*', hidden: true });
  const st = h('p', { class: 'fine', dir: 'ltr' });
  const upd = () => { l.handle = hi.value.trim(); st.textContent = pfUrl(l) || ''; };
  hi.addEventListener('input', upd); upd();
  fi.addEventListener('change', async () => { if (!fi.files[0]) return; try { l.img = await readImageKeep(fi.files[0], 192); toast('تم اختيار الأيقونة'); } catch (e) {} });
  const fr = h('select', { class: 'inp' }, PF_FRAMES.map(([k, n]) => h('option', { value: k, selected: (l.frame || 'none') === k }, 'إطار: ' + n)));
  openDialog(isNew ? 'إضافة ' + P.n : 'تعديل ' + (l.label || P.n), h('div', { class: 'form' },
    h('label', { class: 'field' }, h('span', {}, l.kind === 'website' || l.kind === 'custom' ? 'الرابط' : 'اسم المستخدم أو رابط الحساب'), hi), st,
    h('label', { class: 'field' }, h('span', {}, 'الاسم الظاهر'), li),
    l.kind === 'website' || l.kind === 'custom' ? h('label', { class: 'field' }, h('span', {}, 'وصف الرابط'), di) : null,
    h('div', { class: 'ctl-row' }, h('span', {}, 'لون الشارة (عند عدم تثبيت التطبيق)'), ci), fr,
    h('div', { class: 'ctl-row' }, fi, h('button', { type: 'button', class: 'btn', onclick: () => fi.click() }, icon('image', 16), 'أيقونة خاصة'), l.img ? h('button', { type: 'button', class: 'btn', onclick: () => { l.img = ''; toast('أزيلت الأيقونة الخاصة'); } }, 'إزالتها') : null),
    h('label', { class: 'ctl-row' }, h('span', {}, 'إظهار في الويدجت'), (() => { const c = h('input', { type: 'checkbox', checked: l.show !== false }); c.addEventListener('change', () => { l.show = c.checked; }); return c; })())),
    [{ label: 'إلغاء' }, { label: 'حفظ', cls: 'btn-gold', onClick: () => {
      l.handle = hi.value.trim(); l.label = li.value.trim(); l.desc = di.value.trim(); l.color = ci.value === P.c ? '' : ci.value; l.frame = fr.value;
      if (!pfUrl(l)) { toast('اكتب اسم المستخدم أو الرابط'); return false; }
      update(d => { const a = d.profile.links; const i = a.findIndex(x => x.id === l.id); if (i >= 0) a[i] = l; else a.push(l); }, { rebuild: true });
    } }]);
}
/** The profile material library: each look sets the whole style (background, frame, text, icons, glow, shadows). */
const PF_LOOKS = [
  ['Liquid Glass', 'glass', 'royal'], ['Frosted Glass', 'glass', 'turquoise', { blur: 26 }], ['Crystal Glass', 'crystal', null], ['Soft Marble', 'marble', null],
  ['Black Luxury', 'obsidian', 'gold'], ['Royal Gold', 'royalGold', 'gold'], ['Premium Silver', 'carbon', null, { custom: '#c9ced6' }], ['Rose Gold', 'champagne', null, { custom: '#c98f7f' }],
  ['Velvet Texture', 'plush3d', 'purple'], ['Dark Leather', 'leather', null], ['Soft Glow', 'quiet', 'gold', { glow: true }], ['Neon Ring', 'neon', 'turquoise', { ring: 'neon' }],
  ['Holographic', 'holo', null], ['Gradient Luxury', 'aurora', 'purple'], ['Islamic Ornamental Frame', 'heritage', 'gold', { frame: 'islamicGeo' }], ['Geometric Gold Frame', 'royalGold', 'gold', { frame: 'repeatGeo' }],
  ['Minimal Luxury', 'minimal', null], ['3D Floating Profile', 'clay', 'royal'], ['Metallic Frame', 'carbon', null, { frame: 'metal3d' }], ['Aurora Glass', 'aurora', 'turquoise', { blur: 18 }]];
function applyPfLook(d, [, st, theme, x = {}]) {
  d.style = st; Object.assign(d.a, styleLook(st));
  if (theme) d.theme = theme;
  if (x.custom) { d.theme = 'custom'; d.custom = x.custom; }
  if (x.frame) d.a.frame = x.frame;
  if (x.blur) d.a.blur = x.blur;
  if (x.glow) d.profile.glow = true;
  if (x.ring) { d.profile.design = 'ring'; d.profile.ring.kind = x.ring; }
  d.a.grad = null;
}
function profileLookPanel() {
  const o = draft.profile;
  return [
    h('div', { class: 'sub-h' }, 'مكتبة خامات البروفايل'),
    h('div', { class: 'chips' }, PF_LOOKS.map(l => h('button', { type: 'button', class: 'chip' + (draft.style === l[1] && (!l[2] || draft.theme === l[2] || (l[3] && l[3].custom && draft.custom === l[3].custom)) ? ' on' : ''), onclick: () => update(d => applyPfLook(d, l), { rebuild: true }) }, l[0]))),
    h('div', { class: 'sub-h' }, 'التصميم'),
    h('div', { class: 'chips' }, PF_DESIGNS.map(([k, n, sz]) => h('button', { type: 'button', class: 'chip' + (o.design === k ? ' on' : ''), onclick: () => update(d => { d.profile.design = k; d.sizes.profile = sz.slice(); }, { rebuild: true }) }, n))),
    o.design === 'ring' ? seg('نوع الحلقة', 'profile.ring.kind', PF_RINGS) : null,
    o.design === 'ring' && (o.ring.kind === 'gradient' || o.ring.kind === 'neon') ? h('div', { class: 'ctl-row' }, h('span', {}, 'ألوان الحلقة (2–3)'),
      ...[0, 1, 2].map(i => { const c = h('input', { type: 'color', value: (o.ring.colors || [])[i] || '#ffffff' }); c.addEventListener('change', () => update(d => { d.profile.ring.colors[i] = c.value; })); return c; }),
      h('button', { type: 'button', class: 'btn btn-sm', onclick: () => update(d => { d.profile.ring.colors = d.profile.ring.colors.slice(0, 2); }, { rebuild: true }) }, 'لونان فقط')) : null,
    o.design !== 'ring' ? seg('إطار الصورة', 'profile.frame', PF_FRAMES) : null,
    toggle('إضاءة خلف الصورة', 'profile.glow'), toggle('إظهار الوصف', 'profile.bioOn'), toggle('أسماء المنصات تحت الأيقونات', 'profile.names'),
    seg('حجم أيقونات الحسابات', 'profile.iconSize', [['s', 'صغيرة'], ['m', 'متوسطة'], ['l', 'كبيرة'], ['xl', 'كبيرة جداً']]),
    seg('إطار الأيقونات', 'profile.iconFrame', PF_FRAMES),
    h('p', { class: 'fine' }, 'الخامة والإطار الخارجي والتدرج من «المظهر» تُطبَّق على البروفايل كله: الخلفية والإطار والنص والتوهج والظلال.')];
}
/* the profile's own section of the app: list + create */
function viewProfile() {
  const mine = loadDesigns().filter(d => d.type === 'profile'), v = $('#view');
  v.replaceChildren(h('div', { class: 'wrap' },
    h('div', { class: 'page-h' }, h('h1', {}, 'البروفايل الشخصي'), h('p', { class: 'muted' }, 'My Social Profile — صورتك وحساباتك وروابطك في ويدجت على الشاشة الرئيسية، منفصل عن جهات الاتصال.')),
    h('div', { class: 'sub-h' }, 'ابدأ بتصميم'),
    h('div', { class: 'pf-designs' }, PF_DESIGNS.map(([k, n, sz]) => h('button', { type: 'button', class: 'pf-design', onclick: async () => {
      if (!(await guardDirty())) return;
      const prev = mine[0] && normalize(mine[0]).profile;
      draft = newDesign({ type: 'profile', style: k === 'ring' ? 'midnight' : k === 'large' ? 'glass' : 'royalGold', theme: 'gold' });
      Object.assign(draft.a, styleLook(draft.style));
      if (prev) Object.assign(draft.profile, clone(prev));      // same person, another design
      draft.profile.design = k; draft.sizes.profile = sz.slice();
      meta = { editingId: null, savedJSON: '' }; resetHist(); ui.step = 3; saveDraftNow(); goEditor();
    } }, h('strong', {}, n), h('small', { dir: 'ltr' }, sz.join('×'))))),
    mine.length ? h('div', { class: 'sub-h' }, 'بروفايلاتي') : null,
    mine.length ? h('div', { class: 'pf-mine' }, mine.map(d => h('button', { type: 'button', class: 'btn', onclick: () => editDesign(d.id) }, (d.name || (d.profile && d.profile.name) || 'بروفايل') + ' · ' + ((PF_DESIGNS.find(x => x[0] === (d.profile && d.profile.design)) || [, ''])[1])))) : null));
}
