/* =========================================================
   Widget element (canvas + tap areas) and baking for Android
   ========================================================= */
const DPR = () => Math.min(3, window.devicePixelRatio || 1);
function appSettings() { return Object.assign({ cc: '966' }, store.get('llx.settings', {})); }
/** International digits for WhatsApp: +966… / 00966… / 05… (with the default country code). */
function intlNumber(v) {
  let s = String(v || '').trim().replace(/[^\d+]/g, '');
  if (s.startsWith('+')) return s.slice(1).replace(/\D/g, '');
  s = s.replace(/\D/g, '');
  if (s.startsWith('00')) return s.slice(2);
  const cc = String(appSettings().cc || '').replace(/\D/g, '');
  if (cc && s.startsWith('0')) return cc + s.replace(/^0+/, '');
  if (cc && s.length <= 9 && !s.startsWith(cc)) return cc + s;
  return s;
}
const dialNumber = v => String(v || '').replace(/[^\d+]/g, '');
function urlOf(v) {
  v = String(v || '').trim();
  const m = v.match(/^([a-z][a-z0-9+.-]*):/i);
  if (m) return ['http', 'https', 'mailto', 'sms', 'geo', 'tel'].includes(m[1].toLowerCase()) ? v : '';
  return v ? 'https://' + v : '';
}
/** Resolved tap action for a hit (shared by the web screen and the Android bake). */
function hitAction(hit) {
  if (hit.act === 'open') return { k: 'open', v: hit.route || 'screen' };
  if (hit.act === 'tap') return hit.tap && hit.tap.k !== 'none' ? Object.assign({}, hit.tap) : null;
  const it = hit.it; if (!it) return null;
  const kind = hit.act === 'item' ? it.kind : hit.act;
  switch (kind) {
    case 'app': return { k: 'app', v: it.value };
    case 'ishort': return { k: 'ishort', v: it.value || '', p: it.pkg || '' };
    case 'url': return { k: 'url', v: urlOf(it.value), p: it.openWith || '' };
    case 'call': return { k: 'call', v: dialNumber(it.value) };
    case 'sms': return { k: 'sms', v: dialNumber(it.value) };
    case 'wa': return { k: 'wa', v: intlNumber(it.waNum || it.value), b: it.waApp || 'auto' };
    case 'contact': return { k: 'contact', v: dialNumber(it.value), wn: intlNumber(it.waNum || it.value), n: it.label, b: it.waApp || 'auto' };
  }
  return null;
}
function actionHrefOf(a) {
  if (!a) return '#';
  switch (a.k) {
    case 'app': return `intent://#Intent;action=android.intent.action.MAIN;category=android.intent.category.LAUNCHER;package=${encodeURIComponent(a.v)};S.browser_fallback_url=${encodeURIComponent('https://play.google.com/store/apps/details?id=' + a.v)};end`;
    case 'url': return NATIVE && a.p ? `launchy://url?u=${encodeURIComponent(a.v)}&p=${encodeURIComponent(a.p)}` : (a.v || '#');
    case 'call': return 'tel:' + a.v;
    case 'sms': return 'sms:' + a.v;
    case 'wa': return NATIVE && a.b !== 'auto' ? `launchy://wa?n=${a.v}&b=${a.b}` : 'https://wa.me/' + a.v;
    case 'contact': return '#contact';
    case 'ishort': return NATIVE && a.v ? 'launchy://ishort?v=' + encodeURIComponent(a.v) : '#ishort';
    case 'open': return '#/' + a.v;
    case 'clockApp': case 'calendarApp': case 'refresh': case 'setAlarm': return '#time-' + a.k;
  }
  return '#';
}
/** Kept for older code paths: href for an item. */
function actionHref(it) { return actionHrefOf(hitAction({ act: 'item', it })); }
function contactSheet(a) {
  const btn = (label, href, g, col) => h('a', { class: 'btn', href, target: /^https?:/.test(href) ? '_blank' : null, rel: 'noopener', style: { justifyContent: 'flex-start' }, onclick: () => setTimeout(() => $('#dlg').close(), 50) }, h('span', { class: 'gl', style: { color: col } }, glyph(g, 18)), label);
  const box = h('div', { class: 'form' },
    btn('اتصال هاتفي', 'tel:' + a.v, 'phone', ACT_COL.call),
    btn('محادثة واتساب', a.b === 'wab' && NATIVE ? `launchy://wa?n=${a.wn}&b=wab` : 'https://wa.me/' + a.wn, 'chat', ACT_COL.wa),
    NATIVE ? btn('واتساب للأعمال', `launchy://wa?n=${a.wn}&b=wab`, 'chat', '#128c7e') : null,
    btn('رسالة SMS', 'sms:' + a.v, 'mail', ACT_COL.sms));
  openDialog(a.n || 'خيارات التواصل', box);
}

function itemsFor(d) {
  if (isTimeType(d) || d.type === 'profile') return { items: [], demo: false };
  if (d.items.length) return { items: d.items, demo: false };
  let items = DEMO_ITEMS;
  if (d.type === 'people') items = DEMO_PEOPLE;
  else if (d.type === 'vertical' || d.type === 'free' || d.type === 'card') items = DEMO_MIX;
  else if (d.type === 'collections') items = DEMO_INNER;
  else if (d.type === 'circle') items = ['hero', 'overlap'].includes(d.circle.layout) ? DEMO_PEOPLE : DEMO_ITEMS;
  return { items, demo: true };
}
function hasGlassBlur(d) { const mode = d.a.bgMode === 'style' ? STYLES[d.style].mode : d.a.bgMode; return mode === 'glass' && (!d.a.mat || d.a.mat === 'none' || MAT[d.a.mat].g === 'glass'); }

/**
 * Render a design at zoom k. opts.interactive adds real links over each tap area.
 * Returns { el, W, H, info, LY, redraw }.
 */
function renderWidget(d, opts = {}) {
  const { W, H } = sizeOf(d), k = opts.k || 1, dpr = opts.dpr || DPR();
  const src = itemsFor(d), interactive = !!opts.interactive && !src.demo;
  const wrap = h('div', { class: 'wscale wcv', role: 'group', 'aria-label': d.name || TYPES[d.type].n });
  wrap.style.width = W * k + 'px'; wrap.style.height = H * k + 'px';
  const cv = document.createElement('canvas');
  cv.width = Math.max(1, Math.round(W * k * dpr)); cv.height = Math.max(1, Math.round(H * k * dpr));
  cv.style.width = W * k + 'px'; cv.style.height = H * k + 'px';
  let LY, base = null, animKey = (d.id || d.name || '') + '|' + Math.random().toString(36).slice(2, 6);
  const S = k * dpr;
  // animated clocks: the still design is cached once, each frame only repaints the moving parts
  const frame = t => {
    const ctx = cv.getContext('2d'); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.clearRect(0, 0, cv.width, cv.height);
    const lv = alertLevel(t);
    if (lv > 0) { const sh = (t % 2400 < 900) ? Math.sin(t / 22) * 1.1 * lv * S : 0; ctx.translate(sh, 0); }
    ctx.drawImage(base, 0, 0); ctx.scale(S, S);
    const L = lookOf(d), mode = { anim: true, key: animKey, redraw: () => {} };
    for (const el of LY.live) { ctx.save(); paintLive(ctx, S, L, el, new Date(), d, mode); ctx.restore(); }
    if (lv > 0 && LY.alertFx) paintAlertFx(ctx, S, L, LY, lv, t);
    if (!needsAnim(LY, d)) { ANIMS.delete(wrap); draw(); }
  };
  const draw = () => {
    LY = layoutDesign(d, W, H, src.items);
    if (needsAnim(LY, d)) {
      if (!base) { base = document.createElement('canvas'); base.width = cv.width; base.height = cv.height; }
      const b = base.getContext('2d'); b.setTransform(1, 0, 0, 1, 0, 0); b.clearRect(0, 0, base.width, base.height); b.scale(S, S);
      paintDesign(b, S, d, LY, { still: true });
      frame(performance.now()); wrap._frame = frame; animAdd(wrap);
      return LY;
    }
    ANIMS.delete(wrap);
    const ctx = cv.getContext('2d'); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.clearRect(0, 0, cv.width, cv.height);
    ctx.scale(S, S);
    paintDesign(ctx, S, d, LY, { redraw: () => requestAnimationFrame(draw), key: d.id || d.name });
    return LY;
  };
  draw();
  wrap._redraw = draw;
  if (LY.live && LY.live.length) {
    // live widgets repaint each second (seconds shown) or when the minute changes
    wrap.dataset.live = '1';
    const secs = LY.live.some(e => e.kind === 'sec' || (e.kind === 'analog' && e.o.seconds));
    let last = '';
    wrap._tick = now => { const key = secs && !ANIMS.has(wrap) ? now.getSeconds() + ':' + now.getMinutes() : now.getHours() + ':' + now.getMinutes(); if (key !== last) { last = key; draw(); } };
    wrap._tick(new Date());
  }
  if (hasGlassBlur(d) && opts.blur !== false) {
    const B = LY.B, bl = h('div', { class: 'wblur' });
    Object.assign(bl.style, { left: B.x * k + 'px', top: B.y * k + 'px', width: B.w * k + 'px', height: B.h * k + 'px', borderRadius: (B.circle ? '50%' : B.r * k + 'px') });
    bl.style.setProperty('--blur', d.a.blur + 'px');
    wrap.append(bl);
  }
  wrap.append(cv);
  const pending = imagesOf(src.items).concat(LY.imgs || []).filter(s => !getImg(s));
  if (pending.length) {
    const fn = () => { draw(); if (pending.every(s => { const e = imgCache.get(s); return e && (e.ok || e.err); })) imgWaiters.delete(fn); };
    imgWaiters.add(fn); setTimeout(() => imgWaiters.delete(fn), 10000);
  }
  if (interactive) {
    for (const ht of LY.hits) {
      const a = hitAction(ht); if (!a) continue;
      const href = actionHrefOf(a), ext = /^https?:/i.test(href) && !NATIVE;
      const el = h('a', { class: 'hit', href, 'aria-label': (ht.it ? ht.it.label + ' — ' : '') + ({ call: 'اتصال', wa: 'واتساب', sms: 'رسالة', open: 'المزيد' }[ht.act] || (ht.it ? KIND[ht.it.kind].n : '')), target: ext ? '_blank' : null, rel: ext ? 'noopener' : null });
      Object.assign(el.style, { left: ht.x * k + 'px', top: ht.y * k + 'px', width: ht.w * k + 'px', height: ht.h * k + 'px' });
      if (a.k === 'contact') el.addEventListener('click', e => { e.preventDefault(); contactSheet(a); });
      if (a.k === 'ishort' && (!NATIVE || !a.v)) el.addEventListener('click', e => { e.preventDefault(); toast(a.v ? 'الاختصارات الداخلية تُفتح من تطبيق Android' : 'هذا عنصر تجريبي للمعاينة فقط'); });
      if (a.k === 'open') el.addEventListener('click', e => { e.preventDefault(); location.hash = '#/' + a.v; });
      if (['clockApp', 'calendarApp', 'refresh', 'setAlarm'].includes(a.k)) el.addEventListener('click', e => { e.preventDefault(); timeTap(d, a); });
      wrap.append(el);
    }
  }
  return { el: wrap, W, H, info: Object.assign({ demo: src.demo }, LY.info), LY, redraw: draw, canvas: cv };
}
function renderScaled(d, k, opts = {}) { return renderWidget(d, Object.assign({}, opts, { k })); }
function fitScaled(d, bw, bh, opts = {}, maxK = 1.25) {
  const { W, H } = sizeOf(d);
  return renderScaled(d, Math.max(.2, Math.min(bw / W, bh / H, maxK)), opts);
}

/* ---------------------------------------------------------- baking (Android) */
/**
 * Draw a design at an exact size into an image + tap areas for the native widget.
 * W,H are studio px; scale is device px per studio px.
 */
const NATIVE_CLOCK_FONTS = ['black', 'bold', 'geo', 'led', 'light', 'medium', 'royal', 'serif', 'thin', 'xlight'];
async function bakeDesign(d, W, H, scale, opts = {}) {
  const items = d.items;
  if (isTimeType(d)) { await ensureTimeFonts(d); const pre = layoutDesign(d, W, H, items); if (pre.imgs) await loadImgs(pre.imgs); }
  try { await document.fonts.ready; } catch (e) {}
  await loadImgs(imagesOf(items));
  if (d.type === 'collections') await loadImgs((d.collections.groups || []).map(g => g.icon).filter(Boolean));
  if (d.type === 'profile') await loadImgs([d.profile.photo, ...(d.profile.links || []).map(l => l.img)].filter(Boolean));
  const cv = document.createElement('canvas');
  cv.width = Math.round(W * scale); cv.height = Math.round(H * scale);
  const ctx = cv.getContext('2d'); ctx.scale(scale, scale);
  // the dock keeps its chosen bar height inside a taller home-screen cell
  let H2 = H, oy = 0;
  if (d.type === 'dock') { H2 = Math.min(H, Math.round((d.sizes.dock[1] * CELL_H - 8) * d.a.dockH / 100)); oy = (H - H2) / 2; ctx.translate(0, oy); }
  SCROLL_OFF = opts.scroll === false;
  let LY;
  try { LY = layoutDesign(d, W, H2, items); } finally { SCROLL_OFF = false; }
  NATIVE_ICONS = opts.nativeIcons ? [] : null;
  WX_LIVE = opts.liveWx && d.type === 'weather' ? [] : null;
  try { paintDesign(ctx, scale, d, LY, { bake: true, bodyOnly: !!LY.scroll }); } finally { LY.icons = NATIVE_ICONS || []; NATIVE_ICONS = null; LY.wxLive = WX_LIVE || []; WX_LIVE = null; }
  if (oy) { for (const ht of LY.hits) ht.y += oy; LY.B = Object.assign({}, LY.B, { y: LY.B.y + oy }); }
  let img = cv.toDataURL('image/webp', .96);
  if (!img.startsWith('data:image/webp')) img = cv.toDataURL('image/png');
  const r1 = v => Math.round(v * 10) / 10;
  const hits = LY.hits.map(ht => { const a = hitAction(ht); return a && (a.v || ['open', 'clockApp', 'calendarApp', 'refresh', 'setAlarm'].includes(a.k)) ? Object.assign({ x: r1(ht.x), y: r1(ht.y), w: r1(ht.w), h: r1(ht.h) }, a) : null; }).filter(Boolean);
  let scroll = null;
  if (LY.scroll) {
    // the content as rows of a scrolling list (Android draws the list over the baked background/frame)
    const sc = LY.scroll, bounds = [sc.y, ...sc.cuts, sc.y + sc.total];
    const rows = [];
    for (let j = 0; j < bounds.length - 1; j++) {
      const a = bounds[j], b = bounds[j + 1]; if (b - a < 2) continue;
      const rc = document.createElement('canvas'); rc.width = Math.round(sc.w * scale); rc.height = Math.round((b - a) * scale);
      const rx = rc.getContext('2d'); rx.scale(scale, scale); rx.translate(-sc.x, -a);
      NATIVE_ICONS = opts.nativeIcons ? [] : null;
      try { paintDesign(rx, scale, d, LY, { bake: true, noBody: true }); } finally { var icons = NATIVE_ICONS || []; NATIVE_ICONS = null; }
      const inRow = o => o.y + o.h / 2 >= a && o.y + o.h / 2 < b;
      let rimg = rc.toDataURL('image/webp', .96); if (!rimg.startsWith('data:image/webp')) rimg = rc.toDataURL('image/png');
      rows.push({ h: r1(b - a), img: rimg,
        hits: LY.hits.filter(inRow).map(ht => { const ac = hitAction(ht); return ac && ac.v ? Object.assign({ x: r1(ht.x - sc.x), y: r1(ht.y - a), w: r1(ht.w), h: r1(ht.h) }, ac) : null; }).filter(Boolean),
        icons: icons.filter(inRow).map(e => ({ x: r1(e.x - sc.x), y: r1(e.y - a), w: r1(e.w), h: r1(e.h), p: e.p })) });
    }
    scroll = { x: r1(sc.x), y: r1(sc.y + oy), w: r1(sc.w), h: r1(sc.h), rows };
  }
  const out = { w: W, h: H, s: scale, img, hits: scroll ? [] : hits, body: { x: r1(LY.B.x), y: r1(LY.B.y), w: r1(LY.B.w), h: r1(LY.B.h), r: r1(LY.B.r), c: !!LY.B.circle } };
  if (scroll) out.scroll = scroll;
  if (scroll || LY.icons.length) {
    // a complete picture (icons included, first screenful + hint when scrolling) for the "add widget" sheet and the picker
    const ps = Math.min(scale, 640 / Math.max(W, H)), pc = document.createElement('canvas');
    pc.width = Math.round(W * ps); pc.height = Math.round(H * ps);
    const px = pc.getContext('2d'); px.scale(ps, ps); if (oy) px.translate(0, oy);
    paintDesign(px, ps, d, LY, { bake: true });
    out.prev = pc.toDataURL('image/webp', .92);
  }
  if (LY.icons.length) out.live = LY.icons.map(e => ({ k: 'icon', x: r1(e.x), y: r1(e.y + oy), w: r1(e.w), h: r1(e.h), p: e.p }));
  if (LY.live) {
    // live parts for Android: AnalogClock hand images and TextClock boxes
    const L = lookOf(d);
    out.live = (out.live || []).concat(LY.live.map(el => {
      if (el.kind === 'pendulum') return bakePendulum(d, L, el, scale);
      if (el.kind === 'chrono') return { k: 'chrono', x: r1(el.x), y: r1(el.y + oy), w: r1(el.w), h: r1(el.h), size: r1(el.size), color: cssHex8(el.color) };
      if (el.kind === 'analog') {
        const px = Math.round(clamp(2 * el.R * scale * 1.15, 64, 720)), sec = !!el.o.seconds;
        return { k: 'analog', x: r1(el.cx - el.R), y: r1(el.cy - el.R + oy), w: r1(2 * el.R), h: r1(2 * el.R), tz: el.tz || '', px,
          hh: handImage(L, el.R, el.o, 'h', px, false), mm: handImage(L, el.R, el.o, 'm', px, !sec), ss: sec ? handImage(L, el.R, el.o, 's', px, true) : '' };
      }
      return { k: 'text', x: r1(el.x), y: r1(el.y + oy), w: r1(el.w), h: r1(el.h), f12: el.f12, f24: el.f24, size: r1(el.size), font: 'llx_' + el.font + '_' + (el.digits === 'arab' && el.font !== 'led' ? 'a' : 'l'),
        color: cssHex8(el.color), align: el.align || 'center', tz: el.tz || '' };
    }));
    out.day = isoDay(new Date());
    out.time = d.type;

    // the ringing look (only for clocks that use the alarm effects)
    if (LY.alertFx && LY.live.some(e => e.kind === 'pendulum' || e.kind === 'analog')) {
      const c2 = document.createElement('canvas'); c2.width = cv.width; c2.height = cv.height;
      const g2 = c2.getContext('2d'); g2.scale(scale, scale); if (oy) g2.translate(0, oy);
      paintDesign(g2, scale, d, layoutDesign(d, W, H2, items), { bake: true, alert: 1 });
      out.alert = c2.toDataURL('image/webp', .9).startsWith('data:image/webp') ? c2.toDataURL('image/webp', .9) : c2.toDataURL('image/png');
    }
  }
  if (LY.wxLive && LY.wxLive.length) {
    // live weather boxes: Android writes the newest temperature / update time into them every minute
    const loc = locOf(d), e = loc && wxCached(loc), o = d.weather, cur = e && e.cur || {};
    const meta = loc ? { lat: +(+loc.lat).toFixed(3), lon: +(+loc.lon).toFixed(3), u: o.unit === 'F' ? 'F' : 'C', dg: o.digits || 'latn', lang: o.lang || 'ar', at: e ? e.at : 0, code: cur.weather_code, day: cur.is_day } : null;
    if (meta) out.live = (out.live || []).concat(LY.wxLive.map(b => {
      const q = s => "'" + String(s).replace(/'/g, "''") + "'";
      if (b.f === 'temp') {
        const w = Math.max(b.w * 1.7, b.size * 2.4), h = b.size * 1.25;
        return { k: 'text', x: r1(b.cx - w / 2), y: r1(b.cy - h / 2 + oy), w: r1(w), h: r1(h), f12: q(b.text), f24: q(b.text), size: r1(b.size), font: 'llx_' + (NATIVE_CLOCK_FONTS.includes(b.nf) ? b.nf : 'light') + '_' + (b.dg === 'arab' ? 'a' : 'l'), color: cssHex8(b.color), align: 'center', wx: Object.assign({ f: 'temp' }, meta) };
      }
      const h = b.size * 1.6, x = b.align === 'start' ? b.x - b.w : b.align === 'end' ? b.x : b.x - b.w / 2;
      return { k: 'text', x: r1(x), y: r1(b.y - h / 2 + oy), w: r1(b.w), h: r1(h), f12: q(b.text), f24: q(b.text), size: r1(b.size), font: 'llx_medium_' + (meta.dg === 'arab' ? 'a' : 'l'), color: cssHex8(b.color), align: b.align === 'start' ? 'right' : b.align === 'end' ? 'left' : 'center', wx: Object.assign({ f: 'upd' }, meta) };
    }));
  }
  return out;
}

/** CSS colour (#rgb, #rrggbb, #rrggbbaa, rgba()) → #rrggbbaa for Android. */
function cssHex8(c) {
  c = String(c || '#ffffff').trim();
  const m = /^rgba?\(([^)]+)\)/.exec(c);
  if (m) { const p = m[1].split(',').map(x => parseFloat(x)); return rgbHex(p[0], p[1], p[2]) + Math.round((p[3] == null ? 1 : p[3]) * 255).toString(16).padStart(2, '0'); }
  if (/^#[0-9a-f]{8}$/i.test(c)) return c;
  return rgbHex(...hexRgb(c)) + 'ff';
}
