/* =========================================================
   Studio UI panels: libraries, sections, templates, pickers
   ========================================================= */
/** DOM icon for an item (lists, pickers). */
function faceOf(it, gpx) {
  if (it.photo) return h('img', { src: it.photo, alt: '', draggable: 'false', class: it.fit === 'contain' || (it.iconSrc === 'appicon' && !it.fit) ? 'fit-contain' : null });
  if (it.emoji) {
    const n = [...it.emoji].length, s = h('span', { class: 'wt-emoji' }, it.emoji);
    s.style.fontSize = Math.round(gpx * (n > 2 ? .6 : n === 2 ? .78 : 1)) + 'px';
    return s;
  }
  return glyph(it.glyph || (KIND[it.kind] || KIND.app).g, gpx);
}
function applyStyle(k) {
  if (!STYLES[k]) return;
  update(d => { d.style = k; Object.assign(d.a, styleLook(k)); }, { rebuild: true });
}
/** Render a canvas preview only when its card scrolls into view. */
const lazyIO = 'IntersectionObserver' in window ? new IntersectionObserver(es => es.forEach(e => {
  if (!e.isIntersecting) return; lazyIO.unobserve(e.target); const fn = e.target._lazy; e.target._lazy = null; fn && fn();
}), { rootMargin: '200px' }) : null;
function lazy(el, fn) { if (lazyIO) { el._lazy = fn; lazyIO.observe(el); } else requestAnimationFrame(fn); return el; }

/* ---------------------------------------------------------- style library */
function styleLibrary(onPick, opts = {}) {
  let tag = ui.styleTag || 'all';
  const grid = h('div', { class: 'choice-grid lib-grid' });
  const draw = () => {
    grid.replaceChildren();
    STYLE_ORDER.filter(k => tag === 'all' || (STYLES[k].tags || []).includes(tag)).forEach((k, i) => {
      const s = STYLES[k], prev = h('div', { class: 'choice-prev wp-' + wall });
      const on = draft.style === k;
      grid.append(h('button', { type: 'button', class: 'choice' + (on ? ' on' : ''), style: { '--i': Math.min(i, 12) }, 'aria-pressed': String(on), onclick: () => onPick(k) },
        lazy(prev, () => { const dd = clone(draft); dd.style = k; Object.assign(dd.a, styleLook(k)); if (opts.sampleTheme) dd.theme = SAMPLE_THEME[k] || dd.theme; prev.append(fitScaled(dd, prev.clientWidth - 16, 96, {}, 1).el); }),
        h('div', { class: 'choice-txt' }, h('strong', {}, s.n), h('em', {}, s.en), opts.compact ? null : h('span', {}, s.desc)), h('i', { class: 'choice-check' }, icon('check', 14))));
    });
  };
  const chips = h('div', { class: 'chips lib-filter' }, STYLE_TAGS.map(([k, n]) => h('button', { type: 'button', class: 'chip' + (tag === k ? ' on' : ''), onclick: e => { tag = ui.styleTag = k; $$('.chip', chips).forEach(c => c.classList.toggle('on', c === e.currentTarget)); draw(); } }, n)));
  draw();
  return h('div', { class: 'form' }, chips, grid);
}
function openStyleLibrary() {
  openDialog('مكتبة أنماط التصميم', styleLibrary(k => { applyStyle(k); $('#dlg').close(); toast('اعتُمد نمط «' + STYLES[k].n + '»'); }, { compact: true }), [], { wide: true });
}

/* ---------------------------------------------------------- swatch helpers */
function matSwatch(k, tint, size = 46) {
  const c = document.createElement('canvas'), dpr = DPR();
  c.width = c.height = size * dpr; c.style.width = c.style.height = size + 'px';
  const ctx = c.getContext('2d'); ctx.scale(dpr, dpr);
  if (k === 'none') { ctx.strokeStyle = 'rgba(128,128,128,.6)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(8, size - 8); ctx.lineTo(size - 8, 8); ctx.stroke(); return c; }
  const P = rrPath(new Path2D(), 1, 1, size - 2, size - 2, size * .26);
  ctx.save(); ctx.fillStyle = '#1b1b1f'; ctx.fill(P); ctx.fillStyle = materialFill(ctx, k, tint, size * 1.3); ctx.fill(P);
  ctx.fillStyle = linGrad(ctx, 0, 0, 0, size, [[0, 'rgba(255,255,255,.18)'], [.5, 'rgba(255,255,255,0)'], [1, 'rgba(0,0,0,.2)']]); ctx.fill(P); ctx.restore();
  return c;
}
function matGrid(path, tintPath, opts = {}) {
  const cur = getPath(draft, path), tint = getPath(draft, tintPath) ? accentOf(draft) : null;
  const wrap = h('div', { class: 'form' });
  const groups = [['none', null]].concat(Object.keys(MAT_GROUPS).map(g => [g, MATERIALS.filter(m => m.g === g && !m.hidden)]));
  for (const [g, list] of groups) {
    if (g === 'none') { if (opts.allowNone !== false) wrap.append(h('div', { class: 'mat-row' }, matBtn('none', 'بدون خامة'))); continue; }
    wrap.append(h('div', { class: 'sub-h' }, MAT_GROUPS[g]), h('div', { class: 'mat-row' }, list.map(m => matBtn(m.k, m.n))));
  }
  function matBtn(k, n) {
    return h('button', { type: 'button', class: 'mat' + (cur === k ? ' on' : ''), title: n, 'aria-pressed': String(cur === k), onclick: () => update(d => setPath(d, path, k), { rebuild: true }) }, matSwatch(k, MAT[k] && MAT[k].tint !== undefined ? (getPath(draft, tintPath) ? accentOf(draft) : null) : tint), h('span', {}, n));
  }
  return wrap;
}
function framePreview(k, L, w = 92, hh = 64) {
  const c = document.createElement('canvas'), dpr = DPR();
  c.width = w * dpr; c.height = hh * dpr; c.style.width = w + 'px'; c.style.height = hh + 'px';
  const ctx = c.getContext('2d'); ctx.scale(dpr, dpr);
  const B = { x: 3, y: 3, w: w - 6, h: hh - 6, r: 12 };
  ctx.fillStyle = L.darkText ? '#efe9dd' : '#15161b'; ctx.fill(boxPath(B));
  drawFrame(ctx, dpr, B, { k, color: L.frameColor, width: 2.2, density: 45, size: 34, pos: 'all', glow: k === 'geoGlow' || k === 'gradientGlow' ? 50 : 0, light: L.a.lightColor, inset: 3 });
  return c;
}
function frameGrid() {
  const L = lookOf(draft), cur = draft.a.frame;
  return h('div', { class: 'frame-grid' }, FRAMES.map(f => h('button', { type: 'button', class: 'mat frame' + (cur === f.k ? ' on' : ''), 'aria-pressed': String(cur === f.k), onclick: () => update(d => d.a.frame = f.k, { rebuild: true }) },
    (() => { const s = h('span', { class: 'fprev' }); lazy(s, () => s.append(framePreview(f.k, L))); return s; })(), h('span', {}, f.n))));
}
function colorCtl(label, path, auto) {
  const val = getPath(draft, path);
  const ci = h('input', { type: 'color', class: 'color-inp', value: val || auto || '#c9a24a', 'aria-label': label });
  ci.addEventListener('input', () => { setPath(draft, path, ci.value); renderPreview(); saveDraftSoon(); });
  ci.addEventListener('change', () => { commitHist(); refreshChrome(); renderStep(); });
  const row = h('div', { class: 'ctl-row' }, h('span', {}, label, auto != null ? h('small', {}, val ? 'لون مخصص' : 'تلقائي حسب النمط') : null), h('div', { style: { display: 'flex', gap: '6px', alignItems: 'center' } },
    auto != null && val ? h('button', { type: 'button', class: 'btn btn-sm btn-ghost', onclick: () => update(d => setPath(d, path, ''), { rebuild: true }) }, 'تلقائي') : null, ci));
  return row;
}
const QUICK_COLORS = [['#d4af37', 'ذهبي'], ['#c9ced6', 'فضي'], ['#b5793f', 'نحاسي'], ['#1f6f73', 'فيروزي'], ['#ffffff', 'أبيض'], ['#5ff2d6', 'نيون'], ['#7d1f36', 'عنابي']];
function quickColors(path) {
  return h('div', { class: 'pal' }, QUICK_COLORS.map(([c, n]) => h('button', { type: 'button', title: n, 'aria-label': n, class: getPath(draft, path) === c ? 'on' : '', style: { background: c }, onclick: () => update(d => setPath(d, path, c), { rebuild: true }) })));
}

/* ---------------------------------------------------------- look panels */
function materialPanel() {
  return [
    h('p', { class: 'fine' }, 'خامات حقيقية مولّدة بنسيج دقيق (مخمل، رخام، معادن، خشب…). يمكنك دمج خامتين: خامة للبطاقة وأخرى للإطار.'),
    toggle('تلوين الخامة بلون الثيم', 'a.matTint', 'مثل مخمل زمردي أو رخام ملوّن'),
    slider('عتامة الخامة', 'a.matAlpha', 20, 100, 1, '%'),
    h('div', { class: 'sub-h' }, 'خامة البطاقة'), matGrid('a.mat', 'a.matTint'),
    h('details', { class: 'sub-det' }, h('summary', {}, 'خامة الإطار (الدمج بين خامتين)'), matGrid('a.mat2', 'a.matTint')),
    h('details', { class: 'sub-det' }, h('summary', {}, 'خامة الأيقونات'), toggle('تلوين خامة الأيقونات بلون الثيم', 'a.tileTint'), matGrid('a.tileMat', 'a.tileTint'))];
}
function framePanel() {
  const a = draft.a, on = a.frame && a.frame !== 'none';
  return [frameGrid(),
    on ? h('div', { class: 'form' },
      colorCtl('لون الإطار', 'a.frameColor', lookOf(draft).frameColor), quickColors('a.frameColor'),
      slider('سمك الإطار', 'a.frameW', 1, 8, .5, 'px'),
      slider('كثافة الزخرفة', 'a.ornDensity', 10, 100, 1, '%'),
      slider('حجم النقوش', 'a.ornSize', 20, 100, 1, '%'),
      seg('موضع الزخارف', 'a.ornPos', [['all', 'الحواف والزوايا'], ['corners', 'الزوايا فقط'], ['edges', 'الحواف فقط']]),
      slider('شدة التوهج', 'a.frameGlow', 0, 100, 1, '%'),
      colorCtl('لون الإضاءة', 'a.lightColor'),
      slider('شفافية الإطار', 'a.frameAlpha', 10, 100, 1, '%'),
      slider('المسافة الداخلية للإطار', 'a.frameInset', 2, 16, 1, 'px'),
      slider('استدارة الزوايا', 'a.radius', 0, 44, 1, 'px'),
      h('p', { class: 'fine' }, 'تُترك مسافة آمنة داخل الإطار تلقائياً حتى لا تتداخل الزخارف مع الأيقونات والأسماء.')) : null];
}
function fxPanel() {
  const rows = FX_KEYS.map(([k, n, en]) => slider(n + ' · ' + en, 'a.fx.' + k, 0, 100, 1, '%'));
  return [h('p', { class: 'fine' }, 'اجعل القيمة 0 لإيقاف المؤثر. المؤثرات تُرسم مسبقاً في صورة الويدجت فلا تستهلك البطارية على الشاشة الرئيسية.'),
    ...rows,
    slider('اتجاه الظل والإضاءة', 'a.fx.angle', 0, 360, 5, '°'),
    slider('انتشار الظل', 'a.fx.spread', 0, 100, 1, '%'),
    colorCtl('لون الإضاءة', 'a.lightColor'),
    h('button', { type: 'button', class: 'btn btn-sm', onclick: () => update(d => { d.a.fx = Object.assign(defaultFx(), (STYLES[d.style].look || {}).fx || {}); }, { rebuild: true }) }, icon('reset', 15), 'مؤثرات النمط الافتراضية')];
}
function avatarPreview(mask, frame, size = 46) {
  const c = document.createElement('canvas'), dpr = DPR(), L = lookOf(draft);
  c.width = c.height = (size + 12) * dpr; c.style.width = c.style.height = (size + 12) + 'px';
  const ctx = c.getContext('2d'); ctx.scale(dpr, dpr);
  paintAvatar(ctx, dpr, L, { it: { label: 'سارة', color: '#c2477a' }, cx: (size + 12) / 2, cy: (size + 12) / 2, s: size, mask, frame });
  return c;
}
function avatarPanel(base = 'people') {
  const mask = draft[base].mask || 'circle', frame = draft[base].avatarFrame || 'ring';
  return [
    h('div', { class: 'sub-h' }, 'شكل الصورة (قص حقيقي بقناع)'),
    h('div', { class: 'mat-row' }, AV_MASKS.map(([k, n]) => h('button', { type: 'button', class: 'mat' + (mask === k ? ' on' : ''), onclick: () => update(d => { d[base].mask = k; }, { rebuild: true }) }, avatarPreview(k, 'none', 40), h('span', {}, n)))),
    h('div', { class: 'sub-h' }, 'إطار الصورة'),
    h('div', { class: 'mat-row' }, AV_FRAMES.map(([k, n]) => h('button', { type: 'button', class: 'mat' + (frame === k ? ' on' : ''), onclick: () => update(d => { d[base].avatarFrame = k; d[base].frame = k; }, { rebuild: true }) }, avatarPreview(mask, k, 40), h('span', {}, n))))];
}

/* ---------------------------------------------------------- type options (new) */
function typeOptionsX(t) {
  if (t === 'people') return [
    h('div', { class: 'sub-h' }, 'التخطيط'),
    h('div', { class: 'chips' }, PEOPLE_LAYOUTS.map(([k, n]) => h('button', { type: 'button', class: 'chip' + (draft.people.layout === k ? ' on' : ''), onclick: () => update(d => d.people.layout = k, { rebuild: true }) }, n))),
    slider('عدد الأشخاص', 'people.count', 1, 12),
    h('div', { class: 'sub-h' }, 'ما يظهر مع الصورة'),
    toggle('الاسم', 'people.name'), toggle('رقم الهاتف', 'people.number'),
    toggle('زر الاتصال', 'people.call'), toggle('زر واتساب', 'people.wa'), toggle('زر رسالة SMS', 'people.sms', 'في تخطيطات الأزرار'),
    ['row'].includes(draft.people.layout) ? seg('موضع الاسم', 'people.namePos', [['below', 'أسفل الصورة'], ['side', 'بجانبها']]) : null,
    draft.people.layout === 'card' ? textField('عنوان البطاقة', 'people.title', 24) : null,
    ...avatarPanel('people'),
    h('p', { class: 'fine' }, 'شريط «المزيد» يعرض ما يتسع ثم زر «+العدد» يفتح بقية الأشخاص داخل تطبيق الاختصارات الشامل، لأن الويدجت على الشاشة الرئيسية لا يدعم التمرير الأفقي.')];
  if (t === 'vertical') return verticalPanel();
  if (t === 'collections') return collectionsPanel();
  if (t === 'circle') return [
    h('div', { class: 'chips' }, CIRCLE_LAYOUTS.map(([k, n]) => h('button', { type: 'button', class: 'chip' + (draft.circle.layout === k ? ' on' : ''), onclick: () => update(d => d.circle.layout = k, { rebuild: true }) }, n))),
    slider('عدد العناصر', 'circle.count', 3, 18),
    draft.circle.layout === 'ring' ? seg('الوسط', 'circle.center', [['none', 'فارغ'], ['title', 'عنوان'], ['item', 'أول عنصر كبير']]) : null,
    draft.circle.layout === 'ring' && draft.circle.center === 'title' ? textField('عنوان الوسط', 'circle.title', 16) : null,
    seg('شكل الأيقونات', 'circle.shape', [['circle', 'دائرية'], ['rounded', 'زوايا دائرية'], ['hexagon', 'سداسية'], ['octagon', 'مثمنة']]),
    seg('خلفيات الأيقونات', 'circle.perIcon', [[false, 'موحدة'], [true, 'مستقلة']]),
    ...avatarPanel('people')];
  if (t === 'free') return [
    slider('الحجم الافتراضي', 'free.size', 28, 120, 1, 'px'),
    seg('الشكل الافتراضي', 'free.shape', [['rounded', 'زوايا دائرية'], ['circle', 'دائري'], ['square', 'مربع'], ['hexagon', 'سداسي'], ['avatar', 'صور الأشخاص']]),
    toggle('إظهار الأسماء', 'free.labels'), toggle('شارات الاتصال وواتساب على الصور', 'free.badges'),
    seg('خلفيات الأيقونات', 'free.perIcon', [[false, 'موحدة'], [true, 'مستقلة']]),
    h('div', { class: 'note' }, icon('move', 16), h('span', {}, 'اسحب أي عنصر داخل المعاينة لتحريكه. غيّر حجم كل عنصر وشكله من خطوة «المحتوى».')),
    h('button', { type: 'button', class: 'btn btn-sm', onclick: () => update(d => { d.free.pos = {}; }, { rebuild: true }) }, icon('reset', 15), 'إعادة التوزيع التلقائي'),
    ...avatarPanel('people')];
  return null;
}

/* ---------------------------------------------------------- free drag on preview */
function bindFreeDrag(wrapEl, r, k) {
  if (draft.type !== 'free' || !r || !r.LY) return;
  const cv = r.canvas; cv.style.touchAction = 'none'; cv.style.cursor = 'grab';
  const C = contentBox(draft, r.LY.B);
  cv.addEventListener('pointerdown', e => {
    const rc = cv.getBoundingClientRect(), x = (e.clientX - rc.left) / k, y = (e.clientY - rc.top) / k;
    const hit = [...r.LY.hits].reverse().find(ht => ht.free && x >= ht.x && x <= ht.x + ht.w && y >= ht.y && y <= ht.y + ht.h);
    if (!hit) return;
    e.preventDefault(); cv.setPointerCapture(e.pointerId); cv.style.cursor = 'grabbing';
    const id = hit.free, P = freeDefaults(draft, draft.items.length ? draft.items.slice(0, 24) : itemsFor(draft).items.slice(0, 24), C);
    const idx = (draft.items.length ? draft.items : itemsFor(draft).items).findIndex(i => i.id === id);
    const start = Object.assign({}, draft.free.pos[id] || P[idx]);
    const x0 = x, y0 = y;
    const move = ev => {
      const nx = (ev.clientX - rc.left) / k, ny = (ev.clientY - rc.top) / k;
      draft.free.pos[id] = Object.assign({}, start, { x: clamp(start.x + (nx - x0) / C.w, 0, 1), y: clamp(start.y + (ny - y0) / C.h, 0, 1) });
      r.redraw();
    };
    const up = () => { cv.removeEventListener('pointermove', move); cv.removeEventListener('pointerup', up); cv.removeEventListener('pointercancel', up); cv.style.cursor = 'grab'; commitHist(); refreshChrome(); renderPreview(); };
    cv.addEventListener('pointermove', move); cv.addEventListener('pointerup', up); cv.addEventListener('pointercancel', up);
  });
}
function freeItemCtl(it) {
  if (draft.type !== 'free') return null;
  const items = draft.items.slice(0, 24), C = contentBox(draft, layoutDesign(draft, sizeOf(draft).W, sizeOf(draft).H, items).B);
  const P = freeDefaults(draft, items, C)[items.findIndex(x => x.id === it.id)] || {};
  const cur = Object.assign({}, P, draft.free.pos[it.id] || {});
  const s = h('input', { type: 'range', min: 20, max: 140, step: 1, value: Math.round(cur.s || draft.free.size), 'aria-label': 'حجم ' + it.label });
  setFill(s);
  s.addEventListener('input', () => { draft.free.pos[it.id] = Object.assign({}, cur, { s: +s.value }); setFill(s); renderPreview(); saveDraftSoon(); });
  s.addEventListener('change', () => { commitHist(); refreshChrome(); });
  const shapes = [['', 'افتراضي'], ['rounded', 'مربع ناعم'], ['circle', 'دائري'], ['hexagon', 'سداسي'], ['octagon', 'مثمن']].concat(isPerson(it) ? [['avatar', 'صورة']] : []);
  const sel = h('select', { class: 'inp sel-sm', 'aria-label': 'شكل ' + it.label }, shapes.map(([v, n]) => h('option', { value: v, selected: (cur.shape || '') === v ? true : null }, n)));
  sel.addEventListener('change', () => update(d => { d.free.pos[it.id] = Object.assign({}, cur, { shape: sel.value }); }, { rebuild: true }));
  return h('div', { class: 'free-ctl' }, h('span', { class: 'fine' }, 'الحجم'), s, sel);
}

/* ---------------------------------------------------------- vertical editor */
/** A switch bound to a custom getter/setter (for controls that touch several fields). */
function fnToggle(label, get, set, hint) {
  const inp = h('input', { type: 'checkbox', class: 'sw', 'aria-label': label }); inp.checked = !!get();
  inp.addEventListener('change', () => update(d => set(d, inp.checked), { rebuild: true }));
  return h('label', { class: 'ctl-row' }, h('span', {}, label, hint ? h('small', {}, hint) : null), inp);
}
/** A slider bound to a custom getter/setter. */
function fnSlider(label, min, max, get, set, unit = '') {
  const out = h('output', {}, get() + unit);
  const inp = h('input', { type: 'range', min, max, step: 1, value: get(), 'aria-label': label });
  inp.addEventListener('input', () => { set(draft, +inp.value); out.textContent = inp.value + unit; setFill(inp); renderPreview(); saveDraftSoon(); });
  inp.addEventListener('change', () => { commitHist(); refreshChrome(); });
  setFill(inp);
  return h('label', { class: 'ctl' }, h('span', { class: 'ctl-top' }, h('span', {}, label), out), inp);
}
const SEC_FILL = [['auto', 'تلقائي'], ['none', 'بدون'], ['soft', 'ناعمة'], ['tint', 'ملوّنة'], ['glass', 'زجاج'], ['dark', 'داكنة'], ['mat', 'خامة']];
const SEC_FRAME = [['auto', 'تلقائي'], ['none', 'بدون'], ['line', 'خط رفيع'], ['gold', 'ذهبي'], ['double', 'مزدوج'], ['corners', 'زوايا'], ['islamic', 'هندسي']];
/** Grow/shrink the section list to n sections (new ones are mixed shortcuts). */
function setSectionCount(d, n) {
  const v = d.vertical, kinds = [['people', 'people', 'العائلة'], ['apps', 'icons', 'التطبيقات'], ['links', 'list', 'المواقع'], ['mixed', 'iconsLabels', 'اختصارات']];
  while (v.sections.length < n) { const [k, l, tt] = kinds[v.sections.length % kinds.length]; v.sections.push({ id: uid(), kind: k, layout: l, title: tt, show: true, cols: k === 'people' ? 2 : 3, count: 4, ids: null }); }
  v.sections.forEach((s, i) => s.show = i < n);
}
function verticalPanel() {
  const v = draft.vertical, shown = v.sections.filter(s => s.show !== false).length;
  return [
    h('div', { class: 'sub-h' }, 'العنوان'),
    textField('العنوان الزخرفي', 'vertical.title', 28),
    seg('شكل العنوان', 'vertical.titleStyle', TITLE_STYLES),
    slider('حجم العنوان', 'vertical.titleSize', 12, 30, 1, 'px'),
    fnSlider('حجم عناوين الأقسام', 70, 150, () => v.secTitleSize || 100, (d, x) => d.vertical.secTitleSize = x, '%'),
    h('div', { class: 'sub-h' }, 'الأقسام والعناصر'),
    fnSlider('عدد الأقسام الظاهرة', 1, Math.max(6, v.sections.length), () => shown, (d, x) => { setSectionCount(d, x); }),
    fnSlider('عناصر كل قسم', 1, 16, () => Math.max(...v.sections.map(s => s.count || 4)), (d, x) => d.vertical.sections.forEach(s => s.count = x)),
    seg('اتجاه توزيع الأقسام', 'vertical.flow', [['stack', 'فوق بعض'], ['columns', 'أعمدة جنباً لجنب']]),
    seg('محاذاة العناصر', 'vertical.align', [['center', 'وسط'], ['start', 'من البداية']]),
    seg('المحاذاة الرأسية', 'vertical.valign', [['center', 'وسط'], ['top', 'أعلى']]),
    slider('المسافات', 'vertical.gap', 2, 24, 1, 'px'),
    h('div', { class: 'sub-h' }, 'الأحجام'),
    slider('حجم الأيقونات', 'vertical.icon', 24, 80, 1, 'px'), slider('حجم صور الأشخاص', 'vertical.avatar', 26, 92, 1, 'px'),
    h('div', { class: 'sub-h' }, 'ما يظهر'),
    toggle('عناوين الأقسام', 'vertical.sectionTitles'), toggle('إظهار الأسماء', 'vertical.labels'), toggle('سطر فرعي (الرقم أو النطاق)', 'vertical.subs'),
    seg('الفاصل الزخرفي بين الأقسام', 'vertical.divider', DIVIDERS),
    h('div', { class: 'sub-h' }, 'لمسات الفخامة'),
    fnToggle('إطار خارجي كبير', () => draft.a.frame !== 'none', (d, on) => { d.a.frame = on ? (d.a.frame !== 'none' ? d.a.frame : 'goldDouble') : 'none'; }),
    toggle('خلفية مستقلة لكل قسم', 'vertical.sectionBg', 'يمكن تخصيصها لكل قسم من زر التعديل'),
    toggle('إطار داخلي لكل قسم', 'vertical.sectionFrame'),
    fnToggle('فواصل ذهبية', () => v.divider === 'goldLine', (d, on) => d.vertical.divider = on ? 'goldLine' : 'islamic'),
    fnToggle('زخارف الزوايا', () => !!draft.a.corners, (d, on) => d.a.corners = on),
    fnToggle('توهّج الحواف', () => (draft.a.fx || {}).edge > 0, (d, on) => { d.a.fx = fxOf(d.a.fx); d.a.fx.edge = on ? 60 : 0; }),
    fnToggle('ظل ناعم', () => (draft.a.fx || {}).soft > 0, (d, on) => { d.a.fx = fxOf(d.a.fx); d.a.fx.soft = on ? 50 : 0; }),
    h('p', { class: 'fine' }, 'الخامة العامة ولون الإضاءة والإطار من خطوة «الشكل». رتّب الأقسام بالسحب وعدّل خلفية وإطار كل قسم من خطوة «المحتوى».'),
    ...avatarPanel('people')];
}

/* ---------------------------------------------------------- vertical sections */
function sectionsManager() {
  const v = draft.vertical;
  const list = h('ul', { class: 'it-list sec-list', id: 'sec-list' });
  v.sections.forEach((s, i) => {
    const n = sectionItems(draft, s, draft.items.length ? draft.items : DEMO_MIX).length;
    list.append(h('li', { class: 'it-row' + (s.show === false ? ' off' : ''), 'data-id': s.id },
      h('button', { type: 'button', class: 'grip', 'aria-label': 'اسحب لإعادة ترتيب القسم' }, icon('grip')),
      h('span', { class: 'it-ico sec-ico' }, glyph({ people: 'users', apps: 'apps', links: 'globe', mixed: 'layers' }[s.kind] || 'layers', 20)),
      h('div', { class: 'it-txt' }, h('strong', {}, s.title || (SECTION_KINDS.find(x => x[0] === s.kind) || [, 'قسم'])[1]),
        h('small', {}, `${(SECTION_LAYOUTS.find(x => x[0] === s.layout) || [, ''])[1]} · ${n} عنصر${Array.isArray(s.ids) && s.ids.length ? ' · مختار يدوياً' : ''}`)),
      h('div', { class: 'it-act' },
        h('button', { type: 'button', class: 'btn', 'aria-label': s.show === false ? 'إظهار' : 'إخفاء', onclick: () => update(d => { const x = d.vertical.sections.find(q => q.id === s.id); x.show = x.show === false; }, { rebuild: true }) }, icon(s.show === false ? 'eyeOff' : 'eye', 16)),
        h('button', { type: 'button', class: 'btn', 'aria-label': 'تعديل القسم', onclick: () => openSectionDialog(s.id) }, icon('edit', 16)),
        h('button', { type: 'button', class: 'btn btn-danger', 'aria-label': 'حذف القسم', onclick: async () => { if (await confirmBox('حذف القسم', `حذف قسم «${s.title || 'بدون عنوان'}»؟ العناصر نفسها لا تُحذف.`, 'حذف', true)) update(d => d.vertical.sections = d.vertical.sections.filter(q => q.id !== s.id), { rebuild: true }); } }, icon('trash', 16)))));
  });
  enableDrag(list, ids => { draft.vertical.sections.sort((a, b) => ids.indexOf(a.id) - ids.indexOf(b.id)); });
  return [h('div', { class: 'sub-h' }, `أقسام الويدجت الطولي (${v.sections.length})`), list,
    h('div', { class: 'chips', style: { marginTop: '10px' } }, SECTION_KINDS.map(([k, n]) => h('button', { type: 'button', class: 'chip', onclick: () => update(d => d.vertical.sections.push({ id: uid(), kind: k, layout: k === 'people' ? 'people' : k === 'links' ? 'list' : 'icons', title: n, show: true, cols: k === 'people' ? 2 : 4, count: 6, ids: null }), { rebuild: true }) }, icon('plus', 14), 'قسم ' + n)))];
}
function openSectionDialog(id) {
  const s = clone(draft.vertical.sections.find(x => x.id === id)); if (!s) return;
  s.bg = s.bg || 'auto'; s.frame = s.frame || 'auto';
  const pool = draft.items.length ? draft.items : [];
  const body = h('div', { class: 'form' });
  const draw = () => {
    const title = h('input', { type: 'text', class: 'inp', value: s.title || '', maxlength: 24, placeholder: 'بدون عنوان' });
    title.addEventListener('input', () => s.title = title.value);
    const segOf = (opts, key) => h('div', { class: 'seg' }, opts.map(([v, n]) => h('button', { type: 'button', class: s[key] === v ? 'on' : '', onclick: () => { s[key] = v; draw(); } }, n)));
    const cols = h('input', { type: 'range', min: 1, max: 6, value: s.cols || 4 }); setFill(cols);
    const colsOut = h('output', {}, s.cols || 4); cols.addEventListener('input', () => { s.cols = +cols.value; colsOut.textContent = s.cols; setFill(cols); });
    const cnt = h('input', { type: 'range', min: 1, max: 24, value: s.count || 8 }); setFill(cnt);
    const cntOut = h('output', {}, s.count || 8); cnt.addEventListener('input', () => { s.count = +cnt.value; cntOut.textContent = s.count; setFill(cnt); });
    const manual = Array.isArray(s.ids);
    const matching = pool.filter(it => ({ people: isPerson, apps: i => i.kind === 'app', links: i => i.kind === 'url', mixed: () => true }[s.kind] || (() => true))(it));
    const picks = h('ul', { class: 'it-list pick-items', id: 'sec-picks' });
    if (manual) {
      const order = s.ids.filter(id2 => pool.some(p => p.id === id2)).concat(matching.filter(m => !s.ids.includes(m.id)).map(m => m.id));
      order.forEach(id2 => {
        const it = pool.find(p => p.id === id2); if (!it) return;
        const cb = h('input', { type: 'checkbox', class: 'sw', 'aria-label': it.label }); cb.checked = s.ids.includes(id2);
        cb.addEventListener('change', () => { s.ids = cb.checked ? [...s.ids, id2] : s.ids.filter(x => x !== id2); });
        picks.append(h('li', { class: 'it-row', 'data-id': id2 }, h('button', { type: 'button', class: 'grip', 'aria-label': 'ترتيب' }, icon('grip')), itemIcon(it, 34), h('div', { class: 'it-txt' }, h('strong', {}, it.label), h('small', {}, KIND[it.kind].n)), cb));
      });
      enableDrag(picks, ids => { s.ids = ids.filter(x => s.ids.includes(x)); }, true);
    }
    body.replaceChildren(
      h('label', { class: 'field' }, h('span', {}, 'عنوان القسم'), title),
      h('div', { class: 'field' }, h('span', {}, 'نوع المحتوى'), segOf(SECTION_KINDS, 'kind')),
      h('div', { class: 'field' }, h('span', {}, 'شكل التوزيع'), segOf(SECTION_LAYOUTS, 'layout')),
      ['icons', 'iconsLabels', 'people'].includes(s.layout) ? h('label', { class: 'ctl' }, h('span', { class: 'ctl-top' }, h('span', {}, 'عدد الأعمدة'), colsOut), cols) : null,
      h('label', { class: 'ctl' }, h('span', { class: 'ctl-top' }, h('span', {}, 'أقصى عدد للعناصر'), cntOut), cnt),
      h('div', { class: 'field' }, h('span', {}, 'خلفية القسم'), segOf(SEC_FILL, 'bg')),
      h('div', { class: 'field' }, h('span', {}, 'إطار القسم'), segOf(SEC_FRAME, 'frame')),
      (() => { const c = h('input', { type: 'color', value: s.color || '#d4af37', 'aria-label': 'لون القسم' }); c.addEventListener('input', () => s.color = c.value);
        const clr = h('button', { type: 'button', class: 'btn btn-ghost', onclick: () => { s.color = ''; draw(); } }, 'لون التصميم');
        return h('div', { class: 'field' }, h('span', {}, 'لون إطار/خلفية القسم'), h('div', { class: 'row', style: { display: 'flex', gap: '8px', alignItems: 'center' } }, c, clr)); })(),
      ['list', 'people'].includes(s.layout) || s.kind === 'people' ? h('div', { class: 'form' },
        (() => { const c1 = h('input', { type: 'checkbox', class: 'sw' }); c1.checked = s.call !== false; c1.onchange = () => s.call = c1.checked; return h('label', { class: 'ctl-row' }, h('span', {}, 'زر الاتصال'), c1); })(),
        (() => { const c2 = h('input', { type: 'checkbox', class: 'sw' }); c2.checked = s.wa !== false; c2.onchange = () => s.wa = c2.checked; return h('label', { class: 'ctl-row' }, h('span', {}, 'زر واتساب'), c2); })(),
        (() => { const c3 = h('input', { type: 'checkbox', class: 'sw' }); c3.checked = !!s.sms; c3.onchange = () => s.sms = c3.checked; return h('label', { class: 'ctl-row' }, h('span', {}, 'زر رسالة SMS'), c3); })()) : null,
      h('div', { class: 'field' }, h('span', {}, 'العناصر'),
        h('div', { class: 'seg' },
          h('button', { type: 'button', class: !manual ? 'on' : '', onclick: () => { s.ids = null; draw(); } }, 'تلقائي حسب النوع'),
          h('button', { type: 'button', class: manual ? 'on' : '', onclick: () => { s.ids = matching.map(m => m.id); draw(); } }, 'اختيار وترتيب يدوي')),
        !pool.length ? h('p', { class: 'fine' }, 'أضف عناصر للتصميم أولاً ليمكن اختيارها هنا.') : null,
        manual ? picks : h('p', { class: 'fine' }, `يعرض تلقائياً ${matching.length} عنصراً مطابقاً بترتيب قائمة المحتوى.`)));
  };
  draw();
  openDialog('تعديل القسم', body, [
    { label: 'حفظ القسم', cls: 'btn-gold', onClick: () => update(d => { const i = d.vertical.sections.findIndex(x => x.id === id); if (i >= 0) d.vertical.sections[i] = s; }, { rebuild: true }) },
    { label: 'إلغاء', cls: 'btn-ghost' }]);
}

/* ---------------------------------------------------------- templates */
function templateDesign(t, base) {
  const d = normalize(Object.assign(clone(base || newDesign()), { type: t.type, style: t.style, theme: t.theme }));
  Object.assign(d.a, styleLook(t.style), clone(t.a || {}));
  if (t.a && t.a.fx) d.a.fx = Object.assign(defaultFx(), t.a.fx);
  d.sizes[t.type] = t.size.slice();
  for (const k of ['grid', 'people', 'card', 'dock', 'circle', 'free']) if (t[k]) Object.assign(d[k], clone(t[k]));
  if (t.vertical) { Object.assign(d.vertical, clone(t.vertical)); d.vertical.sections = t.vertical.sections.map(s => Object.assign(clone(s), { id: uid(), ids: null })); }
  return d;
}
function templatesGrid(onPick) {
  const grid = h('div', { class: 'choice-grid lib-grid' });
  TEMPLATES.forEach((t, i) => {
    const prev = h('div', { class: 'choice-prev tpl-prev wp-' + wall });
    grid.append(h('button', { type: 'button', class: 'choice', style: { '--i': Math.min(i, 12) }, onclick: () => onPick(t) },
      lazy(prev, () => prev.append(fitScaled(templateDesign(t, newDesign()), prev.clientWidth - 16, 130, {}, 1).el)),
      h('div', { class: 'choice-txt' }, h('strong', {}, t.ar), h('em', {}, t.n), h('span', {}, `${TYPES[t.type].n} · ${STYLES[t.style].n}`))));
  });
  return grid;
}
function applyTemplate(t) {
  update(d => {
    const nd = templateDesign(t, d);
    for (const k of Object.keys(nd)) if (!['id', 'name', 'items', 'created', 'updated', 'v'].includes(k)) d[k] = nd[k];
  }, { rebuild: true });
  toast(`طُبّق قالب «${t.ar}» — محتواك كما هو`);
}
function openTemplates() {
  openDialog('القوالب الجاهزة', h('div', { class: 'form' }, h('p', { class: 'fine' }, 'كل قالب يحمل النمط والخامة والإطار والألوان والظلال والتوزيع. يُطبّق على تصميمك الحالي ويحتفظ بعناصرك.'),
    templatesGrid(t => { $('#dlg').close(); applyTemplate(t); })), [], { wide: true });
}

/* ---------------------------------------------------------- app library (native) */
const APP_CATS = { '-1': 'أخرى', 0: 'ألعاب', 1: 'صوتيات', 2: 'فيديو', 3: 'صور', 4: 'تواصل', 5: 'أخبار', 6: 'خرائط', 7: 'إنتاجية', 8: 'إمكانية الوصول' };
async function loadAppsNative() {
  if (!appsCache) { const r = await nativeRequest('apps', () => window.LaunchyNative.requestApps()); if (Array.isArray(r)) appsCache = r; }
  return appsCache;
}
async function openAppLibrary(single) {
  const apps = await loadAppsNative();
  if (!apps) { toast('تعذّر تحميل قائمة التطبيقات'); return null; }
  return new Promise(res => {
    let done = false, tab = 'all', cat = 'all';
    const sel = new Map();
    const favs = new Set(store.get('llx.favApps', []));
    let recent = store.get('llx.recentApps', []);
    try { if (window.LaunchyNative.recentApps) recent = [...new Set([...JSON.parse(window.LaunchyNative.recentApps()), ...recent])]; } catch (e) {}
    const q = h('input', { type: 'search', class: 'inp', placeholder: 'ابحث باسم التطبيق…', 'aria-label': 'بحث' });
    const list = h('div', { class: 'app-grid' });
    const count = h('span', { class: 'fine' });
    const addBtn = h('button', { type: 'button', class: 'btn btn-gold', disabled: true, onclick: () => { done = true; $('#dlg2').close(); res([...sel.values()]); } }, single ? 'اختيار' : 'إضافة المحدد');
    const filtered = () => {
      const t = q.value.trim().toLowerCase();
      let L = apps.slice();
      if (tab === 'fav') L = L.filter(a => favs.has(a.pkg));
      if (tab === 'recent') L = recent.map(p => apps.find(a => a.pkg === p)).filter(Boolean);
      if (tab === 'new') L = L.slice().sort((a, b) => (b.installed || 0) - (a.installed || 0)).slice(0, 30);
      if (cat !== 'all') L = L.filter(a => String(a.cat ?? -1) === cat);
      if (t) L = L.filter(a => (a.label + ' ' + a.pkg).toLowerCase().includes(t));
      return L;
    };
    const draw = () => {
      const L = filtered();
      list.replaceChildren(...L.slice(0, 400).map(a => {
        const on = sel.has(a.pkg);
        return h('div', { class: 'app-cell' + (on ? ' on' : ''), role: 'button', tabindex: 0, 'aria-pressed': String(on), onclick: () => { if (single) { sel.clear(); } on ? sel.delete(a.pkg) : sel.set(a.pkg, a); draw(); } },
          h('img', { src: a.icon, alt: '', loading: 'lazy' }), h('span', {}, a.label),
          h('button', { type: 'button', class: 'fav' + (favs.has(a.pkg) ? ' on' : ''), 'aria-label': 'مفضلة', onclick: e => { e.stopPropagation(); favs.has(a.pkg) ? favs.delete(a.pkg) : favs.add(a.pkg); store.set('llx.favApps', [...favs]); draw(); } }, icon('star', 14)),
          on ? h('i', { class: 'app-check' }, icon('check', 12)) : null);
      }));
      if (!L.length) list.append(h('p', { class: 'fine' }, tab === 'recent' ? 'لا توجد تطبيقات مستخدمة مؤخراً عبر تطبيق الاختصارات الشامل بعد.' : 'لا توجد نتائج'));
      count.textContent = `${sel.size} محدد · ${L.length} تطبيق`;
      addBtn.disabled = !sel.size;
    };
    q.addEventListener('input', debounce(draw, 150));
    const tabs = h('div', { class: 'seg' }, [['all', 'الكل أبجدياً'], ['fav', 'المفضلة'], ['recent', 'المستخدمة مؤخراً'], ['new', 'المثبتة حديثاً']].map(([k, n]) => h('button', { type: 'button', class: tab === k ? 'on' : '', onclick: e => { tab = k; $$('button', tabs).forEach(b => b.classList.toggle('on', b === e.currentTarget)); draw(); } }, n)));
    const cats = h('div', { class: 'chips' }, [['all', 'كل التصنيفات']].concat(Object.entries(APP_CATS)).map(([k, n]) => h('button', { type: 'button', class: 'chip' + (cat === k ? ' on' : ''), onclick: e => { cat = k; $$('.chip', cats).forEach(c => c.classList.toggle('on', c === e.currentTarget)); draw(); } }, n)));
    const tools = single ? null : h('div', { class: 'chips' },
      h('button', { type: 'button', class: 'chip', onclick: () => { filtered().forEach(a => sel.set(a.pkg, a)); draw(); } }, 'تحديد الكل'),
      h('button', { type: 'button', class: 'chip', onclick: () => { sel.clear(); draw(); } }, 'إلغاء التحديد'));
    draw();
    openDialog('مكتبة التطبيقات المثبتة', h('div', { class: 'form' }, q, tabs, cats, tools, list), [], { id: 'dlg2', wide: true });
    $('#dlg2 .dlg-in').append(h('div', { class: 'dlg-foot' }, addBtn, count));
    $('#dlg2').addEventListener('close', () => { if (!done) res(null); }, { once: true });
  });
}
function appItem(a) { return { kind: 'app', label: String(a.label).trim(), value: a.pkg, photo: a.icon || '', iconSrc: a.icon ? 'appicon' : '', fit: '', glyph: 'apps', emoji: '' }; }

/* ---------------------------------------------------------- contacts studio (native) */
async function openContactsPicker(single) {
  const r = await nativeRequest('contacts', () => window.LaunchyNative.requestContacts());
  if (!r || r.denied || !Array.isArray(r.list)) { toast(r && r.denied ? 'لم يُمنح إذن الوصول إلى جهات الاتصال' : 'تعذّر تحميل جهات الاتصال'); return null; }
  const people = r.list.map(c => Object.assign({}, c, { numbers: c.numbers || [{ n: c.number, t: '' }] }));
  return new Promise(res => {
    let done = false, asKind = 'wa';
    const order = []; const chosenNum = new Map();
    const q = h('input', { type: 'search', class: 'inp', placeholder: 'ابحث بالاسم أو الرقم…', 'aria-label': 'بحث' });
    const list = h('div', { class: 'pick-list' });
    const count = h('span', { class: 'fine' });
    const addBtn = h('button', { type: 'button', class: 'btn btn-gold', disabled: true, onclick: () => { done = true; $('#dlg2').close(); res({ kind: asKind, list: order.map(id => { const c = people.find(p => p.id === id); return Object.assign({}, c, { number: chosenNum.get(id) || c.numbers[0].n }); }) }); } }, single ? 'اختيار' : 'إضافة المحدد');
    const filtered = () => { const t = q.value.trim().toLowerCase(), td = t.replace(/\D/g, ''); return people.filter(p => !t || p.name.toLowerCase().includes(t) || (td && p.numbers.some(n => n.n.replace(/\D/g, '').includes(td)))); };
    const draw = () => {
      const L = filtered();
      list.replaceChildren(...L.slice(0, 500).map(p => {
        const idx = order.indexOf(p.id), on = idx >= 0;
        const numSel = p.numbers.length > 1 ? h('select', { class: 'inp sel-sm', 'aria-label': 'اختيار الرقم', onclick: e => e.stopPropagation() }, p.numbers.map(n => h('option', { value: n.n, selected: (chosenNum.get(p.id) || p.numbers[0].n) === n.n ? true : null }, (n.t ? n.t + ': ' : '') + n.n))) : null;
        if (numSel) numSel.addEventListener('change', () => chosenNum.set(p.id, numSel.value));
        return h('div', { class: 'pick-row' + (on ? ' on' : ''), role: 'button', tabindex: 0, onclick: () => { if (single) order.length = 0; on ? order.splice(idx, 1) : order.push(p.id); draw(); } },
          p.thumb ? h('img', { src: p.thumb, alt: '' }) : h('span', { class: 'pick-av' }, initials(p.name)),
          h('span', { class: 'pick-t' }, h('b', {}, p.name), numSel || h('small', { dir: 'ltr' }, p.numbers[0].n)),
          on ? h('span', { class: 'pick-num' }, single ? '✓' : String(idx + 1)) : null);
      }));
      if (!L.length) list.append(h('p', { class: 'fine' }, 'لا توجد نتائج'));
      count.textContent = `${order.length} محدد · بترتيب التحديد`;
      addBtn.disabled = !order.length;
    };
    q.addEventListener('input', debounce(draw, 150));
    const kinds = h('div', { class: 'seg' }, [['wa', 'واتساب'], ['call', 'اتصال'], ['contact', 'خيارات التواصل'], ['sms', 'رسالة SMS']].map(([k, n]) => h('button', { type: 'button', class: asKind === k ? 'on' : '', onclick: e => { asKind = k; $$('button', kinds).forEach(b => b.classList.toggle('on', b === e.currentTarget)); } }, n)));
    const tools = single ? null : h('div', { class: 'chips' },
      h('button', { type: 'button', class: 'chip', onclick: () => { filtered().forEach(p => { if (!order.includes(p.id)) order.push(p.id); }); draw(); } }, 'تحديد الكل'),
      h('button', { type: 'button', class: 'chip', onclick: () => { order.length = 0; draw(); } }, 'إلغاء التحديد'));
    draw();
    openDialog('جهات الاتصال', h('div', { class: 'form' }, single ? null : h('div', { class: 'field' }, h('span', {}, 'الإجراء عند الضغط'), kinds), q, tools, list), [], { id: 'dlg2', wide: true });
    $('#dlg2 .dlg-in').append(h('div', { class: 'dlg-foot' }, addBtn, count));
    $('#dlg2').addEventListener('close', () => { if (!done) res(null); }, { once: true });
  });
}
async function contactItem(c, kind) {
  let photo = '';
  if (c.photo && window.LaunchyNative.contactPhoto) { try { photo = window.LaunchyNative.contactPhoto(c.photo) || ''; } catch (e) {} }
  return { kind, label: String(c.name).trim(), value: c.number, photo, iconSrc: photo ? 'photo' : '', fit: '', glyph: 'user', emoji: '' };
}
async function addContactsFlow() {
  const r = await openContactsPicker(false); if (!r) return;
  const items = []; for (const c of r.list) items.push(await contactItem(c, r.kind));
  update(d => items.forEach(it => d.items.push(Object.assign({ id: uid(), color: PALETTE[d.items.length % PALETTE.length] }, it))), { rebuild: true });
  if (r.kind === 'call' && window.LaunchyNative.requestCallPermission) { try { window.LaunchyNative.requestCallPermission(); } catch (e) {} }
  toast(`أُضيف ${items.length} من جهات الاتصال`);
}
async function addAppsFlow() {
  const list = await openAppLibrary(false); if (!list) return;
  update(d => list.forEach(a => d.items.push(Object.assign({ id: uid(), color: PALETTE[d.items.length % PALETTE.length] }, appItem(a)))), { rebuild: true });
  const rec = store.get('llx.recentApps', []); store.set('llx.recentApps', [...list.map(a => a.pkg), ...rec.filter(p => !list.some(a => a.pkg === p))].slice(0, 30));
  toast(`أُضيف ${list.length} تطبيق`);
}

/* ---------------------------------------------------------- links library */
const loadLinks = () => (store.get('llx.links', []) || []).filter(l => l && l.id);
const saveLinks = l => store.set('llx.links', l);
function upsertLink(it, category, fav) {
  const L = loadLinks(), i = L.findIndex(x => x.libId && x.libId === it.libId || x.value === it.value);
  const rec = Object.assign({}, clone(it), { id: (i >= 0 ? L[i].id : uid()), category: category || it.category || 'عام', fav: !!fav });
  delete rec.libId;
  if (i >= 0) L[i] = rec; else L.unshift(rec);
  saveLinks(L);
  return rec;
}
function openLinksPicker() {
  const L = loadLinks();
  if (!L.length) { toast('مكتبة الروابط فارغة — أضف روابط من صفحة «روابطي»'); return; }
  const sel = new Set();
  const body = h('div', { class: 'pick-list' }, L.map(l => {
    const row = h('div', { class: 'pick-row', role: 'button', tabindex: 0, onclick: () => { sel.has(l.id) ? sel.delete(l.id) : sel.add(l.id); row.classList.toggle('on', sel.has(l.id)); } },
      itemIcon(l, 36), h('span', { class: 'pick-t' }, h('b', {}, (l.fav ? '★ ' : '') + l.label), h('small', { dir: 'ltr' }, domainOf(l.value) + ' · ' + (l.category || ''))));
    return row;
  }));
  openDialog('إضافة من مكتبة الروابط', body, [
    { label: 'إضافة المحدد', cls: 'btn-gold', onClick: () => { const pick = L.filter(l => sel.has(l.id)); update(d => pick.forEach(l => { const it = clone(l); it.id = uid(); it.libId = l.id; delete it.category; delete it.fav; d.items.push(it); }), { rebuild: true }); toast(`أُضيف ${pick.length} رابط`); } },
    { label: 'إلغاء', cls: 'btn-ghost' }]);
}
function viewLinks() {
  const v = $('#view');
  let cat = ui.linkCat || 'all';
  const L = loadLinks();
  const cats = ['all', 'fav', ...new Set(L.map(l => l.category || 'عام'))];
  const list = h('div', { class: 'links-list' });
  const draw = () => {
    const shown = L.filter(l => cat === 'all' || (cat === 'fav' ? l.fav : (l.category || 'عام') === cat));
    list.replaceChildren(...shown.map(l => h('div', { class: 'link-row' },
      itemIcon(l, 44),
      h('div', { class: 'it-txt' }, h('strong', {}, l.label), h('small', { dir: 'ltr' }, domainOf(l.value)), h('small', {}, (l.category || 'عام') + (l.openWith ? ' · يفتح بتطبيق محدد' : ''))),
      h('div', { class: 'it-act' },
        h('button', { type: 'button', class: 'btn' + (l.fav ? ' fav-on' : ''), 'aria-label': 'مفضلة', onclick: () => { l.fav = !l.fav; saveLinks(L); draw(); } }, icon('star', 16)),
        h('a', { class: 'btn', href: actionHrefOf(hitAction({ act: 'item', it: l })), target: NATIVE ? null : '_blank', rel: 'noopener', 'aria-label': 'فتح' }, icon('globe', 16)),
        h('button', { type: 'button', class: 'btn', 'aria-label': 'تعديل', onclick: () => openItemDialog(l, 'url', { library: true, onSave: rec => { const i = L.findIndex(x => x.id === l.id); L[i] = Object.assign(rec, { id: l.id }); saveLinks(L); route(false); } }) }, icon('edit', 16)),
        h('button', { type: 'button', class: 'btn btn-danger', 'aria-label': 'حذف', onclick: async () => { if (await confirmBox('حذف الرابط', `حذف «${l.label}» من المكتبة؟`, 'حذف', true)) { saveLinks(L.filter(x => x.id !== l.id)); route(false); } } }, icon('trash', 16))))));
    if (!shown.length) list.append(h('div', { class: 'empty' }, icon('globe', 30), h('h3', {}, 'لا توجد روابط هنا'), h('p', {}, 'أضف مواقعك المفضلة مرة واحدة، ثم استخدمها في أي ويدجت.')));
  };
  const chips = h('div', { class: 'chips' }, cats.map(c => h('button', { type: 'button', class: 'chip' + (cat === c ? ' on' : ''), onclick: e => { cat = ui.linkCat = c; $$('.chip', chips).forEach(x => x.classList.toggle('on', x === e.currentTarget)); draw(); } }, c === 'all' ? 'الكل' : c === 'fav' ? '★ المفضلة' : c)));
  draw();
  v.replaceChildren(h('div', { class: 'wrap' },
    h('div', { class: 'page-h' },
      h('div', {}, h('div', { class: 'eyebrow' }, 'المكتبة'), h('h1', { class: 'page-t' }, 'روابطي'), h('p', { class: 'page-d' }, `${L.length} رابط محفوظ — بتصنيفات ومفضلة، جاهزة للإضافة إلى أي ويدجت.`)),
      h('div', { class: 'page-act' }, h('button', { class: 'btn btn-gold', type: 'button', onclick: () => openItemDialog(null, 'url', { library: true, onSave: rec => { const L2 = loadLinks(); L2.unshift(Object.assign(rec, { id: uid() })); saveLinks(L2); route(false); } }) }, icon('plus', 18), 'إضافة رابط'))),
    chips, h('div', { style: { height: '14px' } }), list));
}
async function pickOpenWith(url) {
  const r = await nativeRequest('handlers', () => window.LaunchyNative.requestUrlHandlers(urlOf(url) || 'https://example.com'));
  if (!Array.isArray(r) || !r.length) { toast('لا توجد تطبيقات أخرى تفتح هذا الرابط'); return null; }
  return pickFromList('فتح الرابط باستخدام', r.map(a => ({ title: a.label, sub: a.pkg, img: a.icon, raw: a })));
}
