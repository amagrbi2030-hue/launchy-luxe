/* =========================================================
   Painter + layouts. layoutDesign() returns drawable nodes and
   tap areas (hits); paintDesign() draws them on a canvas. The
   Android app bakes the same canvas into its widgets.
   ========================================================= */
const PERSON_KINDS = ['call', 'wa', 'sms', 'contact'];
const isPerson = it => PERSON_KINDS.includes(it.kind);
const AV_MASKS = [['circle', 'دائري'], ['heart', 'قلب'], ['soft', 'مربع بزوايا دائرية'], ['rectH', 'مستطيل أفقي'], ['rectV', 'مستطيل عمودي'], ['oval', 'بيضاوي'], ['hexagon', 'سداسي'], ['octagon', 'مثمن']];
const AV_FRAMES = [['ring', 'حلقة رفيعة'], ['double', 'إطار دائري مزدوج'], ['gold', 'إطار ذهبي ملكي'], ['glass', 'إطار زجاجي'], ['velvet', 'إطار مخملي'], ['3d', 'إطار ثلاثي الأبعاد'], ['glow', 'توهج لوني'], ['none', 'بدون']];
const ACT_COL = { call: '#2f6fd6', wa: '#1f9d55', sms: '#7a5af0' };
const ACT_GLYPH = { call: 'phone', wa: 'chat', sms: 'mail' };

/** Everything the painter needs about a design's look. */
function lookOf(d) {
  const sp = buildSpec(d), a = d.a, A = accentOf(d);
  const st = STYLES[d.style] || {};
  const frameColor = a.frameColor || (st.look && st.look.frameColor) || (sp.gold ? sp.gold.slice(0, 7) : (lum(sp.text.slice(0, 7)) > .5 ? '#d4af37' : '#a8843f'));
  return {
    d, a, sp, A, fx: Object.assign(defaultFx(), a.fx || {}),
    text: sp.text, sub: sp.sub, acc: sp.acc.slice(0, 7), frameColor,
    tileTint: a.tileTint ? A : null, matTint: a.matTint ? A : null,
    darkText: lum(sp.text.slice(0, 7)) < .45
  };
}

/* ---------------------------------------------------------- body */
function fxMargin(d, W, H) {
  const L = lookOf(d), fx = L.fx, sp = L.sp, sp2 = 1 + (fx.spread - 50) / 100;
  let m = 0;
  if (sp.drop) m = Math.max(m, sp.drop.r * .45 * sp2 + Math.abs(sp.drop.dy || 0));
  if (sp.glow) m = Math.max(m, sp.glow.r * .5);
  if (fx.elev) m = Math.max(m, 4 + 14 * fx.elev / 100);
  for (const k of ['ambient', 'outer', 'golden', 'neon']) if (fx[k]) m = Math.max(m, 4 + 14 * fx[k] / 100);
  if (d.a.frame !== 'none' && d.a.frameGlow) m = Math.max(m, 3 + 8 * d.a.frameGlow / 100);
  return Math.round(clamp(m, 2, Math.min(W, H) * .07));
}
function frameAllowance(d) {
  const a = d.a; if (!a.frame || a.frame === 'none') return 0;
  const sz = (a.ornSize ?? 50) / 50;
  const extra = { islamicGeo: 9, arabesque: 9, royalOrn: 7, goldDouble: 4, copperEngr: 6, geoGlow: 5, roundOrn: 7, corners: 3, metal3d: 5, classic: 7, repeatGeo: 8, crystalF: 5, silverF: 4, royalGold: 8, gradientGlow: 2, modernArabic: 6, stitched: 5 }[a.frame] || 5;
  return (a.frameInset ?? 6) + a.frameW * 1.2 + extra * sz;
}
function frameOpts(L, b) {
  const a = L.a;
  return { k: a.frame, color: L.frameColor, width: a.frameW, density: a.ornDensity, size: a.ornSize, pos: a.ornPos, glow: a.frameGlow, light: a.lightColor, alpha: a.frameAlpha, inset: a.frameInset, mat: a.mat2 !== 'none' ? a.mat2 : null };
}
function paintBody(ctx, S, L, B, bgFn) {
  const { a, sp, fx } = L, P = boxPath(B), spr = 1 + (fx.spread - 50) / 100, ang = fx.angle * Math.PI / 180;
  const o = 1 - a.transp / 100;
  // outer
  if (sp.drop && sp.drop.r > 0) { const dist = Math.hypot(sp.drop.dx || 0, sp.drop.dy || 0) || sp.drop.dy; outerShadow(ctx, S, P, sp.drop.c, sp.drop.r * .5 * spr, Math.cos(ang) * dist, Math.sin(ang) * dist); }
  if (fx.elev) { const k = fx.elev / 100; outerShadow(ctx, S, P, rgba('#000000', .25 * k), 3, Math.cos(ang) * 2, Math.sin(ang) * 2); outerShadow(ctx, S, P, rgba('#000000', .4 * k), 22 * spr, Math.cos(ang) * 12 * k, Math.sin(ang) * 12 * k); }
  if (sp.glow) outerShadow(ctx, S, P, sp.glow.c, sp.glow.r * .5);
  if (fx.ambient) outerShadow(ctx, S, P, rgba(L.A, .55 * fx.ambient / 100), (10 + 20 * fx.ambient / 100) * spr);
  if (fx.outer) outerShadow(ctx, S, P, rgba(a.lightColor, .7 * fx.outer / 100), (6 + 16 * fx.outer / 100) * spr);
  if (fx.golden) outerShadow(ctx, S, P, rgba('#f5c84c', .75 * fx.golden / 100), (6 + 18 * fx.golden / 100) * spr);
  if (fx.neon) { const N = neonize(L.A); outerShadow(ctx, S, P, rgba(N, .8 * fx.neon / 100), 4); outerShadow(ctx, S, P, rgba(N, .6 * fx.neon / 100), (10 + 20 * fx.neon / 100) * spr); }
  // fill
  ctx.save();
  if (a.mat && a.mat !== 'none' && MAT[a.mat]) {
    ctx.globalAlpha = o * (a.matAlpha ?? 100) / 100;
    ctx.fillStyle = materialFill(ctx, a.mat, L.matTint, 128);
    ctx.fill(P);
    ctx.globalAlpha = 1;
    // gentle top light so materials read as surfaces
    ctx.fillStyle = linGrad(ctx, 0, B.y, 0, B.y + B.h, [[0, rgba('#ffffff', .07)], [.5, rgba('#ffffff', 0)], [1, rgba('#000000', .14)]]);
    ctx.fill(P);
  } else {
    const bg = sp.bg.length > 1 && sp.bg[0] !== sp.bg[1] ? linGrad(ctx, B.x, B.y, B.x + B.w, B.y + B.h, [[0, sp.bg[0]], [1, sp.bg[1]]]) : sp.bg[0];
    ctx.fillStyle = bg; ctx.fill(P);
  }
  if (bgFn) { ctx.restore(); ctx.save(); bgFn(ctx, S); }
  else if (sp.sheen) { ctx.fillStyle = linGrad(ctx, B.x, B.y, B.x + B.w * .7, B.y + B.h * .7, [[0, '#ffffff24'], [.55, '#ffffff00']]); ctx.fill(P); }
  ctx.restore();
  // inner
  if (sp.glow) innerShadow(ctx, S, P, sp.glow.ic, sp.glow.ir * .5);
  if (fx.inner) innerShadow(ctx, S, P, rgba('#000000', .6 * fx.inner / 100), 6 + 10 * fx.inner / 100, Math.cos(ang) * 2, Math.sin(ang) * 2);
  if (fx.emboss) { const k = fx.emboss / 100; innerShadow(ctx, S, P, rgba('#ffffff', .45 * k), 4, 2.5, 2.5); innerShadow(ctx, S, P, rgba('#000000', .5 * k), 4, -2.5, -2.5); }
  if (fx.depth) {
    const k = fx.depth / 100; ctx.save(); ctx.clip(P);
    ctx.fillStyle = linGrad(ctx, 0, B.y, 0, B.y + B.h, [[0, rgba('#000000', 0)], [.6, rgba('#000000', .12 * k)], [1, rgba('#000000', .45 * k)]]); ctx.fill(P); ctx.restore();
    innerShadow(ctx, S, P, rgba('#000000', .55 * k), 10, 0, 4);
  }
  if (fx.reflect) {
    const k = fx.reflect / 100; ctx.save(); ctx.clip(P);
    const p = new Path2D(); p.moveTo(B.x - B.w * .1, B.y + B.h * .62); p.lineTo(B.x + B.w * .62, B.y - B.h * .1); p.lineTo(B.x + B.w * .9, B.y - B.h * .1); p.lineTo(B.x - B.w * .1, B.y + B.h * .95); p.closePath();
    ctx.fillStyle = linGrad(ctx, B.x, B.y, B.x + B.w * .5, B.y + B.h * .5, [[0, rgba('#ffffff', .0)], [.35, rgba('#ffffff', .28 * k)], [1, rgba('#ffffff', 0)]]);
    ctx.fill(p);
    ctx.fillStyle = linGrad(ctx, 0, B.y, 0, B.y + B.h * .45, [[0, rgba('#ffffff', .22 * k)], [1, rgba('#ffffff', 0)]]); ctx.fill(P);
    ctx.restore();
  }
  if (fx.edge) {
    const k = fx.edge / 100; ctx.save(); ctx.clip(P);
    ctx.lineWidth = 1.6 + 2 * k; ctx.shadowColor = rgba(a.lightColor, .9 * k); ctx.shadowBlur = 8 * k * S;
    ctx.strokeStyle = linGrad(ctx, B.x, B.y, B.x + B.w, B.y + B.h, [[0, rgba(a.lightColor, .95 * k)], [.4, rgba(a.lightColor, .15 * k)], [.7, rgba(a.lightColor, .05)], [1, rgba(a.lightColor, .6 * k)]]);
    ctx.stroke(P); ctx.restore();
  }
  if (sp.hi) { ctx.save(); ctx.clip(P); ctx.translate(0, 1); ctx.lineWidth = 1; ctx.strokeStyle = sp.hi; const Q = boxPath(inset(B, .5)); ctx.clip(Q); ctx.stroke(Q); ctx.restore(); }
  // border
  if (sp.bw > 0 && alphaOf(sp.border) > 0) { ctx.save(); ctx.lineWidth = sp.bw; ctx.strokeStyle = sp.border; ctx.stroke(boxPath(inset(B, sp.bw / 2))); ctx.restore(); }
  if (sp.sheen) { ctx.save(); ctx.lineWidth = 1; ctx.strokeStyle = linGrad(ctx, B.x, B.y, B.x + B.w, B.y + B.h, [[0, '#ffffff99'], [.38, '#ffffff00'], [.7, '#ffffff00'], [1, '#ffffff38']]); ctx.stroke(boxPath(inset(B, .5))); ctx.restore(); }
  if (sp.gold && d_style(L) === 'quiet' && a.frame === 'none' && !B.circle) {
    const lw = B.w * .3, x = B.x + B.w / 2 - lw / 2; ctx.save();
    ctx.fillStyle = linGrad(ctx, x, 0, x + lw, 0, [[0, rgba(sp.gold.slice(0, 7), 0)], [.5, sp.gold], [1, rgba(sp.gold.slice(0, 7), 0)]]);
    ctx.fillRect(x, B.y, lw, 1.5); ctx.restore();
  }
  if (sp.dot && !B.circle) { ctx.save(); ctx.fillStyle = sp.acc; ctx.shadowColor = sp.acc; ctx.shadowBlur = 6 * S; ctx.beginPath(); ctx.arc(B.x + 11, B.y + 9, 2, 0, TAU); ctx.fill(); ctx.restore(); }
  drawFrame(ctx, S, B, frameOpts(L, B));
}
const d_style = L => L.d.style;

/* ---------------------------------------------------------- tiles */
function tileSkin(ctx, S, L, x, y, w, h, shape, it, perIcon) {
  const T = L.sp.tile, P = shapePath(shape, x, y, w, h), m = Math.min(w, h), k = m / 56;
  if (T.neu) { outerShadow(ctx, S, P, T.neu.light, T.neu.r * .5 * k, -T.neu.d * k, -T.neu.d * k); outerShadow(ctx, S, P, T.neu.dark, T.neu.r * .5 * k, T.neu.d * k, T.neu.d * k); }
  if (T.glow) outerShadow(ctx, S, P, T.glow.c, T.glow.r * .5 * k);
  if (T.drop) outerShadow(ctx, S, P, T.drop.c, T.drop.r * .5 * k, 0, T.drop.dy * k);
  ctx.save();
  if (perIcon) {
    const c = it.color || '#666'; ctx.fillStyle = linGrad(ctx, x, y, x + w, y + h, [[0, mix(c, '#ffffff', .14)], [1, mix(c, '#000000', .24)]]);
  } else if (L.a.tileMat && L.a.tileMat !== 'none' && MAT[L.a.tileMat]) {
    ctx.fillStyle = materialFill(ctx, L.a.tileMat, L.tileTint, Math.max(48, m * 1.6));
  } else ctx.fillStyle = T.bg.length > 1 && T.bg[0] !== T.bg[1] ? linGrad(ctx, x, y, x + w, y + h, [[0, T.bg[0]], [1, T.bg[1]]]) : T.bg[0];
  ctx.fill(P);
  if (L.a.tileMat && L.a.tileMat !== 'none' && !perIcon) { ctx.fillStyle = linGrad(ctx, 0, y, 0, y + h, [[0, rgba('#ffffff', .14)], [.5, rgba('#ffffff', 0)], [1, rgba('#000000', .18)]]); ctx.fill(P); }
  ctx.restore();
  if (T.glow) innerShadow(ctx, S, P, T.glow.ic, T.glow.ir * .5 * k);
  if (T.hi) { ctx.save(); ctx.clip(P); ctx.lineWidth = Math.max(1, k); ctx.strokeStyle = T.hi; ctx.translate(0, Math.max(1, k)); ctx.stroke(P); ctx.restore(); }
  if (T.lo) innerShadow(ctx, S, P, T.lo, 5 * k * .5, 0, -2 * k);
  if (T.bw > 0 && alphaOf(T.border) > 0) { ctx.save(); ctx.lineWidth = T.bw; ctx.strokeStyle = T.border; ctx.stroke(P); ctx.restore(); }
  return P;
}
function paintGlyph(ctx, S, name, cx, cy, size, color, glow) {
  ctx.save(); ctx.translate(cx - size / 2, cy - size / 2); ctx.scale(size / 24, size / 24);
  ctx.lineWidth = 1.9; ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.strokeStyle = color;
  if (glow) { ctx.shadowColor = glow.c; ctx.shadowBlur = glow.r * S; }
  ctx.stroke(glyphPath(name)); ctx.restore();
}
function paintFace(ctx, S, L, it, x, y, w, h, P, perIcon) {
  const m = Math.min(w, h), T = L.sp.tile;
  const img = getImg(it.photo);
  if (it.photo && img) {
    if (it.fit === 'contain' || (it.iconSrc === 'appicon' && !it.fit)) { const s = it.iconSrc === 'favicon' ? .62 : .8; drawContain(ctx, img, x + w * (1 - s) / 2, y + h * (1 - s) / 2, w * s, h * s); }
    else { ctx.save(); ctx.clip(P); drawCover(ctx, img, x, y, w, h); ctx.restore(); }
    return;
  }
  const col = perIcon ? '#ffffff' : T.glyph;
  const glow = !perIcon && T.glyphGlow ? T.glyphGlow : null;
  if (it.emoji) {
    const n = [...it.emoji].length;
    fillText(ctx, it.emoji, x + w / 2, y + h / 2 + 1, w, { size: m * .5 * (n > 2 ? .6 : n === 2 ? .78 : 1), weight: 700, color: col, dir: 'ltr' });
  } else paintGlyph(ctx, S, it.glyph || (KIND[it.kind] || KIND.app).g, x + w / 2, y + h / 2, Math.max(12, m * .5), col, glow);
}
/** Tile node: icon tile + optional label. */
function paintTile(ctx, S, L, n) {
  const it = n.it, w = n.s, h = n.h || n.s, shape = n.shape || 'rounded';
  // "full": the picture itself is the icon — shown whole, never cropped, no design background
  const bare = getImg(it.photo) && (it.fit === 'full' || (it.iconSrc === 'appicon' && !it.fit && L.a.appIcon === 'bare'));
  ctx.save();
  if (n.dim) ctx.globalAlpha = .45;
  if (bare) {
    const img = getImg(it.photo);
    withShadow(ctx, S, 'rgba(0,0,0,.28)', 6, 0, 2, () => drawContain(ctx, img, n.x, n.y, w, h));
  } else {
    const P = tileSkin(ctx, S, L, n.x, n.y, w, h, shape, it, n.perIcon && !(it.photo && it.fit === 'cover'));
    paintFace(ctx, S, L, it, n.x, n.y, w, h, P, n.perIcon);
  }
  ctx.restore();
  if (n.label) fillText(ctx, it.label, n.x + w / 2, n.label.y, n.label.w, { size: n.label.size, color: L.text, weight: 500 });
}

/* ---------------------------------------------------------- avatars */
function defaultAvatar(ctx, S, it, x, y, w, h, P) {
  const c = it.color || '#7a6f60', m = Math.min(w, h), cx = x + w / 2, cy = y + h / 2;
  ctx.save(); ctx.clip(P);
  const g = ctx.createRadialGradient(cx - w * .2, cy - h * .25, m * .05, cx, cy, m * .75);
  g.addColorStop(0, mix(c, '#ffffff', .3)); g.addColorStop(.6, c); g.addColorStop(1, mix(c, '#000000', .35));
  ctx.fillStyle = g; ctx.fillRect(x, y, w, h);
  ctx.globalAlpha = .12; ctx.fillStyle = '#ffffff';
  const st = new Path2D(); star8(st, cx + w * .32, cy + h * .3, m * .32); ctx.fill(st);
  ctx.restore();
  const t = it.emoji || initials(it.label);
  fillText(ctx, t, cx, cy + 1, w * .9, { size: m * .38, weight: 700, color: '#ffffff', shadow: 'rgba(0,0,0,.25)', S, dir: /^[A-Za-z]/.test(t) ? 'ltr' : 'rtl' });
}
function avatarFrameUnder(ctx, S, L, frame, mask, x, y, w, h) {
  const grow = g => shapePath(mask, x - g, y - g, w + 2 * g, h + 2 * g);
  const m = Math.min(w, h), k = m / 56, acc = L.acc;
  switch (frame) {
    case 'gold': { const P = grow(3.2 * k); outerShadow(ctx, S, P, 'rgba(0,0,0,.35)', 6 * k, 0, 2 * k); ctx.save(); ctx.fillStyle = linGrad(ctx, x, y, x + w, y + h, metalStops('#d4af37')); ctx.fill(P); ctx.restore(); break; }
    case 'velvet': { const P = grow(4.2 * k); outerShadow(ctx, S, P, 'rgba(0,0,0,.4)', 6 * k, 0, 2 * k); ctx.save(); ctx.fillStyle = materialFill(ctx, 'velvet', L.A, 40); ctx.fill(P); ctx.restore(); innerShadow(ctx, S, P, 'rgba(0,0,0,.5)', 3 * k); break; }
    case '3d': { const P = grow(3.6 * k); outerShadow(ctx, S, P, 'rgba(0,0,0,.45)', 8 * k, 0, 4 * k); ctx.save(); ctx.fillStyle = linGrad(ctx, x, y, x + w, y + h, [[0, mix(acc, '#ffffff', .65)], [.5, acc], [1, mix(acc, '#000000', .55)]]); ctx.fill(P); ctx.restore(); break; }
    case 'glass': { const P = grow(4 * k); outerShadow(ctx, S, P, 'rgba(0,0,0,.25)', 8 * k, 0, 3 * k); ctx.save(); ctx.fillStyle = 'rgba(255,255,255,.26)'; ctx.fill(P); ctx.lineWidth = 1; ctx.strokeStyle = 'rgba(255,255,255,.7)'; ctx.stroke(P); ctx.restore(); break; }
    case 'glow': { const P = grow(.8 * k); outerShadow(ctx, S, P, L.sp.accGlow, 9 * k); break; }
  }
}
function avatarFrameOver(ctx, S, L, frame, mask, x, y, w, h) {
  const grow = g => shapePath(mask, x - g, y - g, w + 2 * g, h + 2 * g);
  const m = Math.min(w, h), k = m / 56;
  ctx.save();
  switch (frame) {
    case 'ring': ctx.lineWidth = 1.5 * k; ctx.strokeStyle = L.acc; ctx.stroke(grow(3.3 * k)); break;
    case 'double': ctx.strokeStyle = L.acc; ctx.lineWidth = 1.5 * k; ctx.stroke(grow(2.6 * k)); ctx.lineWidth = 1 * k; ctx.stroke(grow(5.6 * k)); break;
    case 'gold': ctx.lineWidth = .8 * k; ctx.strokeStyle = 'rgba(60,40,5,.7)'; ctx.stroke(grow(.4 * k)); break;
    case 'glass': { ctx.clip(grow(4 * k)); ctx.lineWidth = 2 * k; ctx.strokeStyle = linGrad(ctx, x, y, x + w, y + h, [[0, 'rgba(255,255,255,.9)'], [.4, 'rgba(255,255,255,0)'], [1, 'rgba(255,255,255,.3)']]); ctx.stroke(grow(3 * k)); break; }
    case '3d': ctx.lineWidth = 1 * k; ctx.strokeStyle = 'rgba(0,0,0,.45)'; ctx.stroke(grow(.4 * k)); break;
    case 'glow': ctx.lineWidth = 1.5 * k; ctx.strokeStyle = L.acc; ctx.stroke(grow(.75 * k)); break;
  }
  ctx.restore();
}
function paintAvatar(ctx, S, L, n) {
  const it = n.it, box = maskBox(n.mask, n.s), x = n.cx - box.w / 2, y = n.cy - box.h / 2, frame = n.frame || 'none';
  avatarFrameUnder(ctx, S, L, frame, n.mask, x, y, box.w, box.h);
  if (n.sep) { ctx.save(); ctx.lineWidth = n.sep.w * 2; ctx.strokeStyle = n.sep.c; ctx.stroke(shapePath(n.mask, x, y, box.w, box.h)); ctx.restore(); }
  const P = shapePath(n.mask, x, y, box.w, box.h), img = getImg(it.photo);
  if (img) { ctx.save(); ctx.clip(P); drawCover(ctx, img, x, y, box.w, box.h); ctx.restore(); }
  else defaultAvatar(ctx, S, it, x, y, box.w, box.h, P);
  avatarFrameOver(ctx, S, L, frame, n.mask, x, y, box.w, box.h);
  if (n.badges) for (const b of n.badges) paintBtn(ctx, S, L, b.act, b.cx, b.cy, b.s, true);
}
function paintBtn(ctx, S, L, act, cx, cy, s, ring) {
  const col = ACT_COL[act] || L.acc;
  ctx.save();
  ctx.shadowColor = 'rgba(0,0,0,.3)'; ctx.shadowBlur = 3 * S; ctx.shadowOffsetY = 1 * S;
  ctx.beginPath(); ctx.arc(cx, cy, s / 2, 0, TAU); ctx.fillStyle = ring ? 'rgba(255,255,255,.92)' : linGrad(ctx, cx, cy - s / 2, cx, cy + s / 2, [[0, mix(col, '#ffffff', .12)], [1, mix(col, '#000000', .15)]]); ctx.fill();
  ctx.restore();
  if (ring) { ctx.save(); ctx.beginPath(); ctx.arc(cx, cy, s / 2 - Math.max(1, s * .08), 0, TAU); ctx.fillStyle = col; ctx.fill(); ctx.restore(); }
  paintGlyph(ctx, S, ACT_GLYPH[act] || 'phone', cx, cy, s * .56, '#ffffff');
}

/* ---------------------------------------------------------- cards & sections */
function surfaceColors(L) {
  return L.darkText ? { bg: 'rgba(255,255,255,.55)', line: 'rgba(60,45,20,.14)', soft: 'rgba(0,0,0,.05)' } : { bg: 'rgba(255,255,255,.07)', line: 'rgba(255,255,255,.13)', soft: 'rgba(0,0,0,.18)' };
}
function paintSection(ctx, S, L, n) {
  const sc = surfaceColors(L), b = { x: n.x, y: n.y, w: n.w, h: n.h, r: n.r };
  const P = boxPath(b), kind = n.bgKind || (n.bg ? 'soft' : 'none'), col = n.color || L.acc;
  if (kind !== 'none') {
    outerShadow(ctx, S, P, sc.soft, 6, 0, 2);
    ctx.save();
    if (kind === 'mat' && L.a.tileMat && L.a.tileMat !== 'none' && MAT[L.a.tileMat]) { ctx.globalAlpha = .9; ctx.fillStyle = materialFill(ctx, L.a.tileMat, L.tileTint, 110); }
    else if (kind === 'mat' && L.a.mat2 && L.a.mat2 !== 'none' && MAT[L.a.mat2]) { ctx.globalAlpha = .9; ctx.fillStyle = materialFill(ctx, L.a.mat2, L.A, 110); }
    else if (kind === 'tint') ctx.fillStyle = linGrad(ctx, b.x, b.y, b.x, b.y + b.h, [[0, rgba(col, .26)], [1, rgba(col, .12)]]);
    else if (kind === 'dark') ctx.fillStyle = 'rgba(0,0,0,.28)';
    else if (kind === 'glass') ctx.fillStyle = linGrad(ctx, b.x, b.y, b.x + b.w, b.y + b.h, [[0, 'rgba(255,255,255,.2)'], [1, 'rgba(255,255,255,.05)']]);
    else ctx.fillStyle = sc.bg;
    ctx.fill(P); ctx.globalAlpha = 1; ctx.lineWidth = .8; ctx.strokeStyle = sc.line; ctx.stroke(P);
    if (kind === 'glass') { ctx.clip(P); ctx.fillStyle = 'rgba(255,255,255,.08)'; ctx.beginPath(); ctx.moveTo(b.x, b.y); ctx.lineTo(b.x + b.w * .55, b.y); ctx.lineTo(b.x + b.w * .25, b.y + b.h); ctx.lineTo(b.x, b.y + b.h); ctx.fill(); }
    ctx.restore();
  }
  const fk = n.frameKind || (n.frame ? 'gold' : 'none');
  if (fk === 'line') { ctx.save(); ctx.lineWidth = Math.max(.8, L.a.frameW * .3); ctx.strokeStyle = n.color || L.frameColor; ctx.stroke(boxPath(inset(b, 1.5))); ctx.restore(); }
  else if (fk !== 'none') {
    const k = fk === 'double' ? 'goldDouble' : fk === 'corners' ? 'corners' : fk === 'islamic' ? 'islamicGeo' : (L.a.frame !== 'none' && ['goldDouble', 'silverF', 'metal3d', 'stitched', 'gradientGlow', 'geoGlow'].includes(L.a.frame) ? L.a.frame : 'goldDouble');
    drawFrame(ctx, S, b, { k, color: n.color || L.frameColor, width: Math.max(1, L.a.frameW * .5), size: fk === 'corners' ? 22 : 30, density: 40, inset: 2, glow: L.a.frameGlow * .5, light: L.a.lightColor, mat: L.a.mat2 !== 'none' ? L.a.mat2 : null });
  }
}
function paintCard(ctx, S, L, n) {
  const sc = surfaceColors(L), P = rrPath(new Path2D(), n.x, n.y, n.w, n.h, n.r);
  outerShadow(ctx, S, P, sc.soft, 5, 0, 2);
  ctx.save();
  if (L.a.tileMat && L.a.tileMat !== 'none' && MAT[L.a.tileMat] && n.mat) { ctx.globalAlpha = .9; ctx.fillStyle = materialFill(ctx, L.a.tileMat, L.tileTint, 96); }
  else ctx.fillStyle = sc.bg;
  ctx.fill(P); ctx.globalAlpha = 1; ctx.lineWidth = .8; ctx.strokeStyle = sc.line; ctx.stroke(P);
  ctx.restore();
}

/* ---------------------------------------------------------- paint all */
function paintDesign(ctx, S, d, LY, mode = {}) {
  const L = lookOf(d);
  paintBody(ctx, S, L, LY.B, LY.bg);
  for (const n of LY.nodes) {
    switch (n.k) {
      case 'tile': paintTile(ctx, S, L, n); break;
      case 'chip': paintChip(ctx, S, L, n); break;
      case 'avatar': paintAvatar(ctx, S, L, n); if (n.label) fillText(ctx, n.label.text, n.label.x, n.label.y, n.label.w, { size: n.label.size, color: L.text, weight: 600, align: n.label.align }); if (n.sub) fillText(ctx, n.sub.text, n.sub.x, n.sub.y, n.sub.w, { size: n.sub.size, color: L.sub, weight: 400, align: n.sub.align, dir: 'ltr' }); break;
      case 'btn': paintBtn(ctx, S, L, n.act, n.cx, n.cy, n.s, false); break;
      case 'text': fillText(ctx, n.text, n.x, n.y, n.w, { size: n.size, color: n.color === 'sub' ? L.sub : n.color === 'acc' ? L.acc : (n.color || L.text), weight: n.weight || 500, align: n.align, font: n.font, dir: n.dir }); break;
      case 'divider': drawDivider(ctx, S, n.x, n.y, n.w, n.style, L.frameColor, n.size || 1); break;
      case 'title': drawTitle(ctx, S, n.x, n.y, n.w, n.h, n.text, n.style, n.size, L.text, L.frameColor); break;
      case 'section': paintSection(ctx, S, L, n); break;
      case 'card': paintCard(ctx, S, L, n); break;
      case 'thumb': { const img = getImg(n.src); const P = rrPath(new Path2D(), n.x, n.y, n.w, n.h, n.r); if (img) { ctx.save(); ctx.clip(P); drawCover(ctx, img, n.x, n.y, n.w, n.h); ctx.restore(); } break; }
      case 'more': { const P = shapePath('circle', n.cx - n.s / 2, n.cy - n.s / 2, n.s, n.s); ctx.save(); ctx.fillStyle = surfaceColors(L).bg; ctx.fill(P); ctx.lineWidth = 1.2; ctx.strokeStyle = L.acc; ctx.stroke(P); ctx.restore(); fillText(ctx, '+' + n.n, n.cx, n.cy + 1, n.s, { size: n.s * .34, weight: 700, color: L.text, dir: 'ltr' }); break; }
      case 'center': { fillText(ctx, n.text, n.cx, n.cy, n.w, { size: n.size, weight: 700, color: L.text, font: FONT_D }); break; }
      case 'draw': ctx.save(); n.fn(ctx, S, L); ctx.restore(); break;
      case 'vrule': { const x = n.x, g = linGrad(ctx, 0, n.y0, 0, n.y1, [[0, rgba(L.frameColor, 0)], [.5, rgba(L.frameColor, .9)], [1, rgba(L.frameColor, 0)]]); ctx.save(); ctx.strokeStyle = g; ctx.lineWidth = Math.max(.8, n.size); ctx.beginPath(); ctx.moveTo(x, n.y0); ctx.lineTo(x, n.y1); ctx.stroke(); const st = new Path2D(); diamond(st, x, (n.y0 + n.y1) / 2, 3 * n.size, 4.5 * n.size); ctx.fillStyle = L.frameColor; ctx.fill(st); ctx.restore(); break; }
    }
  }
  // corner ornaments as an extra layer over any frame
  if (d.a.corners && d.a.frame !== 'corners' && !LY.time) drawFrame(ctx, S, LY.B, { k: 'corners', color: L.frameColor, width: Math.max(1.2, L.a.frameW * .6), size: 50, inset: d.a.frame !== 'none' ? 9 : 5, glow: L.a.frameGlow, light: L.a.lightColor });
  // live clock parts: drawn here for the preview; on Android the system draws them
  if (LY.live) for (const el of LY.live) { if (mode.bake && el.kind !== 'pendulum') continue; if (mode.still && !mode.bake) continue; ctx.save(); paintLive(ctx, S, L, el, mode.now || new Date(), d, mode); ctx.restore(); }
  if (mode.bake && mode.alert && LY.alertFx) paintAlertFx(ctx, S, L, LY, mode.alert, 0);
}

/* ---------------------------------------------------------- layout helpers */
const labelHOf = fs => Math.round(fs * 1.3) + 4;
function contentBox(d, B) {
  let pad = d.a.padding + frameAllowance(d);
  pad = Math.min(pad, Math.max(d.a.padding * .5, Math.min(B.w, B.h) * .2));
  if (B.circle) { const r = B.w / 2 - pad; return { x: B.x + B.w / 2 - r, y: B.y + B.h / 2 - r, w: 2 * r, h: 2 * r, circle: true }; }
  return { x: B.x + pad, y: B.y + pad, w: Math.max(10, B.w - 2 * pad), h: Math.max(10, B.h - 2 * pad) };
}
/** RTL column x: column 0 is on the right. */
const colX = (C, c, cellW, gap) => C.x + C.w - (c + 1) * cellW - c * gap;
function peopleMask(d) { const o = d.people; return o.mask || (o.shape === 'soft' ? 'soft' : 'circle'); }
function peopleFrame(d) { const f = d.people.avatarFrame || d.people.frame || 'ring'; return f === 'ring' || AV_FRAMES.some(x => x[0] === f) ? f : 'ring'; }
const phoneOk = it => isPerson(it) && digits(it.value).length >= 6;

function itemHit(LY, x, y, w, h, it) { LY.hits.push({ x, y, w, h, it, act: 'item' }); }
function tileCell(LY, d, it, cx, top, cellW, t, ratio, shape, labels, fs, perIcon) {
  const h = t * ratio;
  const n = { k: 'tile', x: cx - t / 2, y: top, s: t, h, shape, it, perIcon };
  if (labels) n.label = { y: top + h + 2 + labelHOf(fs) / 2, w: cellW, size: fs };
  LY.nodes.push(n);
  itemHit(LY, cx - cellW / 2, top - 2, cellW, h + (labels ? labelHOf(fs) : 0) + 4, it);
}
function avatarCell(LY, d, it, cx, cy, s, o) {
  const mask = o.mask || peopleMask(d), frame = o.frame || peopleFrame(d), box = maskBox(mask, s);
  const n = { k: 'avatar', it, cx, cy, s, mask, frame };
  if (o.badges && phoneOk(it)) {
    const bs = Math.max(13, s * .32), bl = [];
    if (o.call) bl.push({ act: 'call', cx: cx - box.w / 2 + bs * .3, cy: cy + box.h / 2 - bs * .3, s: bs });
    if (o.wa) bl.push({ act: 'wa', cx: cx + box.w / 2 - bs * .3, cy: cy + box.h / 2 - bs * .3, s: bs });
    n.badges = bl;
  }
  if (o.sep) n.sep = o.sep;
  LY.nodes.push(n);
  itemHit(LY, cx - Math.max(box.w, s) / 2, cy - box.h / 2, Math.max(box.w, s), box.h, it);
  if (n.badges) for (const b of n.badges) LY.hits.push({ x: b.cx - b.s * .7, y: b.cy - b.s * .7, w: b.s * 1.4, h: b.s * 1.4, it, act: b.act });
  return { n, box };
}
function actionButtons(LY, it, cx, cy, s, o, gap = 6) {
  const acts = []; if (o.call) acts.push('call'); if (o.wa) acts.push('wa'); if (o.sms) acts.push('sms');
  if (!phoneOk(it) || !acts.length) return 0;
  const total = acts.length * s + (acts.length - 1) * gap;
  acts.forEach((act, i) => {
    const x = cx + total / 2 - s / 2 - i * (s + gap);
    LY.nodes.push({ k: 'btn', act, cx: x, cy, s });
    LY.hits.push({ x: x - s / 2 - 2, y: cy - s / 2 - 2, w: s + 4, h: s + 4, it, act });
  });
  return total;
}

/** Buttons in a row starting at x0: dir -1 grows leftwards from a right edge, +1 rightwards from a left edge. */
function actionButtonsAt(LY, it, x0, cy, s, o, gap, dir) {
  const acts = ['call', 'wa', 'sms'].filter(k => o[k]);
  if (!phoneOk(it) || !acts.length) return 0;
  acts.forEach((act, i) => {
    const cx = dir < 0 ? x0 - s / 2 - i * (s + gap) : x0 + s / 2 + i * (s + gap);
    LY.nodes.push({ k: 'btn', act, cx, cy, s });
    LY.hits.push({ x: cx - s / 2 - 2, y: cy - s / 2 - 2, w: s + 4, h: s + 4, it, act });
  });
  return acts.length * s + (acts.length - 1) * gap;
}

/* ---------------------------------------------------------- grid / card / dock */
function layGrid(d, LY, C, items) {
  const a = d.a, o = d.grid, gap = a.gap, fs = a.font, labels = o.labels, shape = o.shape;
  const labelH = labels ? labelHOf(fs) : 0, ratio = shape === 'rect' ? .74 : 1, minT = 26;
  const cols = Math.max(1, Math.min(o.cols, Math.floor((C.w + gap) / (minT + gap))));
  const rowsFit = Math.max(1, Math.floor((C.h + gap) / (minT * ratio + labelH + gap)));
  const want = Math.min(o.count, items.length), n = Math.min(want, cols * rowsFit), rows = Math.max(1, Math.ceil(n / cols));
  const cellW = (C.w - gap * (cols - 1)) / cols, cellH = (C.h - gap * (rows - 1)) / rows - labelH;
  const t = Math.max(20, Math.floor(Math.min(cellW, cellH / ratio) * a.iconScale / 100));
  const rowH = t * ratio + labelH, total = rows * rowH + (rows - 1) * gap, y0 = C.y + (C.h - total) / 2;
  items.slice(0, n).forEach((it, i) => {
    const r = Math.floor(i / cols), c = i % cols;
    tileCell(LY, d, it, colX(C, c, cellW, gap) + cellW / 2, y0 + r * (rowH + gap), cellW, t, ratio, shape, labels, fs, o.perIcon);
  });
  LY.info = { shown: n, want, total: items.length, cols, colsWanted: o.cols };
}
function layDock(d, LY, C, items) {
  const a = d.a, o = d.dock, gap = Math.max(4, Math.round(a.gap * .8)), fs = a.font;
  let labels = o.labels, labelH = labels ? labelHOf(fs) - 1 : 0;
  if (labels && C.h - labelH < 24) { labels = false; labelH = 0; }
  let n = Math.min(o.count, items.length), t = 0;
  while (n > 0) { t = Math.min((C.w - gap * (n - 1)) / n, C.h - labelH); if (t >= 24) break; n--; }
  t = Math.max(18, Math.floor(t * a.iconScale / 100));
  const cellW = n ? (C.w - gap * (n - 1)) / n : C.w, top = C.y + (C.h - t - labelH) / 2;
  items.slice(0, n).forEach((it, i) => tileCell(LY, d, it, colX(C, i, cellW, gap) + cellW / 2, top, cellW, t, 1, o.shape, labels, fs, o.perIcon));
  LY.info = { shown: n, want: Math.min(o.count, items.length), total: items.length, labelsHidden: o.labels && !labels };
}
function layCard(d, LY, C, items) {
  const a = d.a, o = d.card, gap = a.gap, fs = Math.max(12, a.font);
  let y = C.y;
  if (o.title) { const s = fs * 1.45; LY.nodes.push({ k: 'text', text: o.title, x: C.x + C.w, y: y + s * .68, w: C.w, size: s, weight: 700, align: 'start', font: FONT_D }); y += s * 1.35; }
  if (o.subtitle) { const s = fs * .95; LY.nodes.push({ k: 'text', text: o.subtitle, x: C.x + C.w, y: y + s * .7, w: C.w, size: s, color: 'sub', align: 'start' }); y += s * 1.4; }
  if (o.title || o.subtitle) { y += Math.max(6, gap * .6); if (d.style === 'quiet' || d.a.frame !== 'none') { LY.nodes.push({ k: 'divider', x: C.x, y, w: C.w, style: 'goldLine' }); } y += Math.max(6, gap * .5); }
  const body = { x: C.x, y, w: C.w, h: C.y + C.h - y };
  const cols = Math.max(2, Math.min(o.cols, Math.floor((body.w + gap) / (38 + gap))));
  const labels = o.labels, labelH = labels ? labelHOf(fs) : 0, cellW = (body.w - gap * (cols - 1)) / cols;
  const t = Math.max(24, Math.floor(Math.min(cellW, 64) * a.iconScale / 100)), rowH = t + labelH;
  let shown = 0;
  if (!o.sections) {
    const rowsFit = Math.max(1, Math.floor((body.h + gap) / (rowH + gap)));
    const feat = o.featured && rowsFit >= 2 && cols >= 3 && items.length > 1;
    const total = rowsFit * rowH + (rowsFit - 1) * gap, y0 = body.y + Math.max(0, (body.h - total) / 2);
    let idx = 0;
    if (feat) {
      const fw = cellW * 2 + gap, big = Math.floor(Math.min(fw, total - labelH) * .86);
      tileCell(LY, d, items[0], colX(body, 0, cellW, gap) + cellW - fw / 2, y0 + (total - big - labelH) / 2, fw, big, 1, o.shape, labels, fs * 1.08, o.perIcon);
      idx = 1;
    }
    const startCol = feat ? 2 : 0, perRow = cols - startCol;
    for (let r = 0; r < rowsFit && idx < items.length; r++) for (let c = 0; c < perRow && idx < items.length; c++) {
      tileCell(LY, d, items[idx++], colX(body, startCol + c, cellW, gap) + cellW / 2, y0 + r * (rowH + gap), cellW, t, 1, o.shape, labels, fs, o.perIcon);
    }
    shown = idx;
  } else {
    const groups = [['app', 'التطبيقات'], ['url', 'المواقع'], [PERSON_KINDS, 'جهات الاتصال']].map(([k, n]) => ({ n, list: items.filter(i => Array.isArray(k) ? k.includes(i.kind) : i.kind === k) })).filter(g => g.list.length);
    const secH = Math.round(fs * .88 * 1.4) + 6; let yy = body.y;
    for (const gr of groups) {
      const left = body.y + body.h - yy; if (left < secH + rowH) break;
      const rows = Math.min(Math.ceil(gr.list.length / cols), Math.floor((left - secH + gap) / (rowH + gap))); if (rows < 1) break;
      LY.nodes.push({ k: 'text', text: gr.n, x: body.x + body.w, y: yy + secH / 2 - 2, w: body.w, size: fs * .88, weight: 600, color: 'sub', align: 'start' });
      yy += secH;
      gr.list.slice(0, rows * cols).forEach((it, i) => tileCell(LY, d, it, colX(body, i % cols, cellW, gap) + cellW / 2, yy + Math.floor(i / cols) * (rowH + gap), cellW, t, 1, o.shape, labels, fs, o.perIcon));
      shown += Math.min(gr.list.length, rows * cols);
      yy += rows * rowH + (rows - 1) * gap + gap;
    }
  }
  LY.info = { shown, total: items.length };
}

/* ---------------------------------------------------------- people */
const PEOPLE_LAYOUTS = [['row', 'صف أفقي'], ['rows2', 'صفّان'], ['grid2', 'شبكة عمودين'], ['grid3', 'شبكة ثلاثة أعمدة'], ['single', 'جهة اتصال واحدة'], ['ring', 'مجموعة دائرية'], ['card', 'داخل بطاقة كبيرة'], ['hero', 'صورة رئيسية مع صور صغيرة'], ['overlap', 'صور دائرية متداخلة'], ['strip', 'شريط مع «المزيد»']];
function layPeople(d, LY, C, items) {
  const o = d.people, a = d.a, gap = a.gap, fs = a.font, lay = o.layout || 'row';
  const showName = o.name !== false, showNum = !!o.number, side = o.namePos === 'side';
  const want = Math.min(o.count, items.length);
  const nameH = showName ? Math.round(fs * 1.35) + 3 : 0, numH = showNum ? Math.round(fs * .95 * 1.3) + 2 : 0;
  const opts = { badges: true, call: o.call, wa: o.wa };
  const below = (it, cx, top, s, w) => {
    let y = top;
    if (showName) { LY.nodes.push({ k: 'text', text: it.label, x: cx, y: y + nameH / 2, w, size: fs, weight: 600 }); y += nameH; }
    if (showNum) { LY.nodes.push({ k: 'text', text: it.value, x: cx, y: y + numH / 2, w, size: fs * .9, color: 'sub', dir: 'ltr' }); y += numH; }
    return y - top;
  };
  const gridOf = (cols, rowsMax, area, withText) => {
    const n = Math.min(want, cols * rowsMax); const rows = Math.max(1, Math.ceil(n / cols));
    const cellW = (area.w - gap * (cols - 1)) / cols, textH = withText ? nameH + numH : 0;
    let s = Math.min(cellW * .86, (area.h - (rows - 1) * gap) / rows - textH - 4) * a.iconScale / 100;
    s = Math.max(22, Math.min(s, 96));
    const rowH = s + textH + 4, total = rows * rowH + (rows - 1) * gap, y0 = area.y + (area.h - total) / 2;
    items.slice(0, n).forEach((it, i) => {
      const r = Math.floor(i / cols), c = i % cols, cx = colX(area, c, cellW, gap) + cellW / 2, top = y0 + r * (rowH + gap);
      avatarCell(LY, d, it, cx, top + s / 2, s, opts);
      if (withText) below(it, cx, top + s + 4, s, cellW);
    });
    return n;
  };
  let shown = 0;
  switch (lay) {
    case 'rows2': shown = gridOf(Math.max(1, Math.ceil(Math.min(want, 12) / 2)), 2, C, true); break;
    case 'grid3': shown = gridOf(3, 4, C, true); break;
    case 'grid2': {
      const cols = 2, cellW = (C.w - gap) / 2, minRow = Math.max(44, fs * 4.2), rowsFit = Math.max(1, Math.floor((C.h + gap) / (minRow + gap)));
      const n = Math.min(want, cols * rowsFit), rows = Math.max(1, Math.ceil(n / cols)), rowH = Math.min((C.h - (rows - 1) * gap) / rows, 84);
      const s = Math.min(rowH - 8, 60) * a.iconScale / 100, y0 = C.y + (C.h - (rows * rowH + (rows - 1) * gap)) / 2;
      const acts = { call: o.call, wa: o.wa, sms: o.sms }, nAct = ['call', 'wa', 'sms'].filter(k => acts[k]).length;
      items.slice(0, n).forEach((it, i) => {
        const r = Math.floor(i / cols), c = i % cols, x1 = colX(C, c, cellW, gap) + cellW, top = y0 + r * (rowH + gap), cy = top + rowH / 2;
        LY.nodes.push({ k: 'card', x: x1 - cellW, y: top, w: cellW, h: rowH, r: Math.min(14, rowH / 3) });
        avatarCell(LY, d, it, x1 - 6 - s / 2, cy, s, { badges: false });
        const tx = x1 - 12 - s, tw = cellW - s - 18;
        const btn = nAct && phoneOk(it), lines = [showName, showNum, btn].filter(Boolean).length || 1;
        const lh = Math.min((rowH - 8) / lines, fs * 2.1); let y = cy - (lines - 1) * lh / 2;
        if (showName) { LY.nodes.push({ k: 'text', text: it.label, x: tx, y, w: tw, size: fs, weight: 600, align: 'start' }); y += lh; }
        if (showNum) { LY.nodes.push({ k: 'text', text: it.value, x: tx, y, w: tw, size: fs * .85, color: 'sub', align: 'start', dir: 'ltr' }); y += lh; }
        if (btn) actionButtonsAt(LY, it, tx, y, Math.min(lh * .95, 24), acts, 5, -1);
      });
      shown = n; break;
    }
    case 'single': {
      const it = items[0]; if (!it) break;
      const wide = C.w > C.h * 1.5;
      if (wide) {
        const s = Math.min(C.h * .92, C.w * .4) * a.iconScale / 100, cx = C.x + C.w - s / 2 - 4, cy = C.y + C.h / 2;
        avatarCell(LY, d, it, cx, cy, s, { badges: false });
        const tx = C.x + C.w - s - 16, tw = tx - C.x;
        const lines = (showName ? 1 : 0) + (showNum ? 1 : 0) + ((o.call || o.wa) && phoneOk(it) ? 1 : 0);
        const lh = Math.min(C.h / Math.max(lines, 1), fs * 3);
        let y = cy - (lines * lh) / 2 + lh / 2;
        if (showName) { LY.nodes.push({ k: 'text', text: it.label, x: tx, y, w: tw, size: fs * 1.5, weight: 700, align: 'start', font: FONT_D }); y += lh; }
        if (showNum) { LY.nodes.push({ k: 'text', text: it.value, x: tx, y, w: tw, size: fs * 1.05, color: 'sub', align: 'start', dir: 'ltr' }); y += lh; }
        if (lines && (o.call || o.wa || o.sms)) { const bs = Math.min(lh * .9, 34); actionButtonsAt(LY, it, tx, y, bs, { call: o.call, wa: o.wa, sms: o.sms }, 10, -1); }
      } else {
        const btnH = (o.call || o.wa) && phoneOk(it) ? Math.min(30, C.h * .16) : 0, textH = nameH * 1.3 + numH;
        const s = Math.max(30, Math.min(C.w * .7, C.h - textH - btnH - 12) * a.iconScale / 100), cx = C.x + C.w / 2;
        let y = C.y + (C.h - (s + textH + btnH + 10)) / 2;
        avatarCell(LY, d, it, cx, y + s / 2, s, { badges: false }); y += s + 6;
        if (showName) { LY.nodes.push({ k: 'text', text: it.label, x: cx, y: y + nameH * .65, w: C.w, size: fs * 1.25, weight: 700, font: FONT_D }); y += nameH * 1.3; }
        if (showNum) { LY.nodes.push({ k: 'text', text: it.value, x: cx, y: y + numH / 2, w: C.w, size: fs * .95, color: 'sub', dir: 'ltr' }); y += numH; }
        if (btnH) actionButtons(LY, it, cx, y + 4 + btnH / 2, btnH, { call: o.call, wa: o.wa, sms: o.sms }, 10);
      }
      shown = 1; break;
    }
    case 'hero': {
      if (C.w < C.h * 1.3) { shown = layCircleGroup(d, LY, C, items.slice(0, want), 'hero', true); break; }
      const big = Math.min(C.h - (showName ? nameH + 4 : 0), C.w * .42) * a.iconScale / 100, bx = C.x + C.w - big / 2 - 2;
      const top = C.y + (C.h - big - (showName ? nameH + 4 : 0)) / 2;
      avatarCell(LY, d, items[0], bx, top + big / 2, big, { badges: true, call: o.call, wa: o.wa });
      if (showName) LY.nodes.push({ k: 'text', text: items[0].label, x: bx, y: top + big + 4 + nameH / 2, w: big + 20, size: fs * 1.1, weight: 700 });
      const area = { x: C.x, y: C.y, w: C.w - big - gap - 6, h: C.h }, rest = items.slice(1, want);
      const cols = Math.max(1, Math.ceil(Math.min(rest.length, 8) / 2)), rowsN = rest.length > cols ? 2 : 1;
      const cellW = (area.w - gap * (cols - 1)) / cols, s2 = Math.max(20, Math.min(cellW * .8, (area.h - gap) / rowsN - (showName ? nameH : 0) - 4)) * a.iconScale / 100;
      const rowH = s2 + (showName ? nameH : 0) + 4, y0 = area.y + (area.h - (rowsN * rowH + (rowsN - 1) * gap)) / 2;
      rest.slice(0, cols * rowsN).forEach((it, i) => {
        const r = Math.floor(i / cols), c = i % cols, cx = colX(area, c, cellW, gap) + cellW / 2, t2 = y0 + r * (rowH + gap);
        avatarCell(LY, d, it, cx, t2 + s2 / 2, s2, { badges: false });
        if (showName) LY.nodes.push({ k: 'text', text: it.label, x: cx, y: t2 + s2 + 2 + nameH / 2, w: cellW, size: fs * .92, weight: 600 });
      });
      shown = 1 + Math.min(rest.length, cols * rowsN); break;
    }
    case 'ring': case 'overlap': {
      shown = layCircleGroup(d, LY, C, items.slice(0, want), lay, true); break;
    }
    case 'card': {
      const tS = fs * 1.3; LY.nodes.push({ k: 'title', x: C.x, y: C.y, w: C.w, h: tS * 1.8, text: o.title || 'العائلة', style: d.a.titleStyle || 'flourish', size: tS });
      const area = { x: C.x, y: C.y + tS * 1.9, w: C.w, h: C.h - tS * 1.9 };
      shown = gridOf(Math.min(4, Math.max(2, want)), 2, area, showName); break;
    }
    case 'strip': {
      const s = Math.max(24, Math.min(C.h - nameH - 4, 56) * a.iconScale / 100), unit = s + gap, fit = Math.max(1, Math.floor((C.w + gap) / unit));
      const more = items.length > fit ? items.length - (fit - 1) : 0, n = more ? fit - 1 : Math.min(items.length, fit);
      const top = C.y + (C.h - s - nameH) / 2;
      items.slice(0, n).forEach((it, i) => { const cx = C.x + C.w - unit * i - s / 2; avatarCell(LY, d, it, cx, top + s / 2, s, opts); if (showName) LY.nodes.push({ k: 'text', text: it.label, x: cx, y: top + s + 2 + nameH / 2, w: unit, size: fs * .92, weight: 600 }); });
      if (more) { const cx = C.x + C.w - unit * n - s / 2; LY.nodes.push({ k: 'more', cx, cy: top + s / 2, s: s * .9, n: more }); LY.hits.push({ x: cx - s / 2, y: top, w: s, h: s, act: 'open', route: 'screen' }); }
      shown = n; break;
    }
    default: { // row
      const nameW = side ? Math.round(fs * 5.2) : 0, gp = peopleFrame(d) === 'none' ? 0 : 6;
      let s = side ? C.h - 4 : C.h - nameH - numH - 6;
      s = Math.max(22, Math.floor(Math.min(s, side ? 72 : 84) * a.iconScale / 100));
      const unit = (side ? s + 10 + nameW : Math.max(s + gp, fs * 4.4));
      const n = Math.min(want, Math.max(1, Math.floor((C.w + gap) / (unit + gap))));
      const tot = n * unit + (n - 1) * gap, x0 = C.x + C.w - (C.w - tot) / 2;
      items.slice(0, n).forEach((it, i) => {
        const x1 = x0 - i * (unit + gap);
        if (side) {
          const cy = C.y + C.h / 2; avatarCell(LY, d, it, x1 - s / 2, cy, s, opts);
          if (showName) LY.nodes.push({ k: 'text', text: it.label, x: x1 - s - 8, y: cy - (showNum ? fs * .6 : 0), w: nameW, size: fs, weight: 600, align: 'start' });
          if (showNum) LY.nodes.push({ k: 'text', text: it.value, x: x1 - s - 8, y: cy + fs * .7, w: nameW, size: fs * .85, color: 'sub', align: 'start', dir: 'ltr' });
        } else {
          const top = C.y + (C.h - (s + 4 + nameH + numH)) / 2, cx = x1 - unit / 2;
          avatarCell(LY, d, it, cx, top + s / 2, s, opts);
          below(it, cx, top + s + 4, s, unit);
        }
      });
      shown = n;
    }
  }
  LY.info = { shown, want, total: items.length };
}

/* ---------------------------------------------------------- circle groups */
const CIRCLE_LAYOUTS = [['ring', 'اختصارات حول دائرة'], ['hero', 'صورة رئيسية في الوسط'], ['rings', 'أيقونات على حلقات'], ['overlap', 'صور دائرية متداخلة']];
function placeItem(LY, d, it, cx, cy, s, opts = {}) {
  if (isPerson(it) && opts.personAsAvatar !== false) return avatarCell(LY, d, it, cx, cy, s, Object.assign({ badges: false }, opts));
  const shape = opts.shape || (d.type === 'circle' ? d.circle.shape : 'circle') || 'circle';
  tileCell(LY, d, it, cx, cy - s / 2, s, s, 1, shape, false, d.a.font, opts.perIcon);
}
function layCircleGroup(d, LY, C, items, mode, forPeople) {
  const cx = C.x + C.w / 2, cy = C.y + C.h / 2, Rb = Math.min(C.w, C.h) / 2, scale = d.a.iconScale / 100;
  const sepColor = lookOf(d).sp.bg[0].slice(0, 7);
  let n = items.length;
  if (!n) return 0;
  if (mode === 'overlap') {
    n = Math.min(n, 7);
    const wide = C.w > C.h * 1.6;
    const s = (wide ? Math.min(C.h * .94, 96) : Math.min(Rb * (n <= 3 ? 1.05 : .82), 88)) * scale;
    if (wide) {
      const step = s * .64, tot = s + (n - 1) * step, x0 = cx + tot / 2 - s / 2;
      items.slice(0, n).forEach((it, i) => placeItem(LY, d, it, x0 - i * step, cy, s, { sep: { w: 2.2, c: sepColor }, frame: 'none' }));
    } else {
      const ring = Math.min(n - 1, 6), r = s * .62;
      const pos = [[cx, cy]]; for (let i = 0; i < ring; i++) { const ang = -Math.PI / 2 + i * TAU / ring; pos.push([cx + r * Math.cos(ang), cy + r * Math.sin(ang)]); }
      pos.slice(1).concat([pos[0]]).forEach(([x, y], i) => { const it = items[i === pos.length - 1 ? 0 : i + 1]; if (it) placeItem(LY, d, it, x, y, i === pos.length - 1 ? s * 1.05 : s * .78, { sep: { w: 2.4, c: sepColor }, frame: 'none' }); });
    }
    return n;
  }
  if (mode === 'hero') {
    const big = Rb * .82 * scale, others = items.slice(1, 11), m = others.length;
    placeItem(LY, d, items[0], cx, cy, big, { frame: peopleFrame(d) });
    if (m) {
      const Rr = Rb - Math.min(Rb * .28, TAU * Rb / m * .3) / 1.2;
      const t = Math.min(Rb * .36, 2 * Rr * Math.sin(Math.PI / m) * .8) * scale;
      others.forEach((it, i) => { const ang = -Math.PI / 2 + i * TAU / m; placeItem(LY, d, it, cx + (Rb - t / 2 - 2) * Math.cos(ang), cy + (Rb - t / 2 - 2) * Math.sin(ang), t); });
    }
    return Math.min(items.length, 11);
  }
  if (mode === 'rings') {
    n = Math.min(n, 18);
    const inner = Math.min(6, Math.max(3, Math.round(n * .35))), outer = n - inner;
    const tO = Math.min(Rb * .3, outer ? 2 * (Rb * .8) * Math.sin(Math.PI / outer) * .78 : Rb) * scale;
    const RO = Rb - tO / 2 - 1, RI = RO - tO * 1.15;
    const tI = Math.min(tO, 2 * RI * Math.sin(Math.PI / inner) * .78);
    items.slice(0, inner).forEach((it, i) => { const ang = -Math.PI / 2 + i * TAU / inner; placeItem(LY, d, it, cx + RI * Math.cos(ang), cy + RI * Math.sin(ang), tI); });
    items.slice(inner, n).forEach((it, i) => { const ang = -Math.PI / 2 + (i + .5) * TAU / outer; placeItem(LY, d, it, cx + RO * Math.cos(ang), cy + RO * Math.sin(ang), tO); });
    return n;
  }
  // ring
  n = Math.min(n, 14);
  const ss = Math.sin(Math.PI / n), k = .8;
  const t = Math.min(Rb * .55, 2 * k * Rb * ss / (1 + k * ss)) * scale, R = Rb - t / 2 - 1;
  items.slice(0, n).forEach((it, i) => { const ang = -Math.PI / 2 + i * TAU / n; placeItem(LY, d, it, cx + R * Math.cos(ang), cy + R * Math.sin(ang), t); });
  return n;
}
function layCircle(d, LY, C, items) {
  const o = d.circle;
  let shown;
  if (o.layout === 'ring' && o.center === 'title' && o.title) {
    LY.nodes.push({ k: 'center', text: o.title, cx: C.x + C.w / 2, cy: C.y + C.h / 2, w: C.w * .42, size: Math.max(12, C.w * .085) });
  }
  if (o.layout === 'ring' && o.center === 'item' && items.length > 1) shown = layCircleGroup(d, LY, C, items.slice(0, o.count), 'hero', false);
  else shown = layCircleGroup(d, LY, C, items.slice(0, o.count), o.layout, false);
  LY.info = { shown, want: Math.min(o.count, items.length), total: items.length };
}

/* ---------------------------------------------------------- free (mixed) */
function freeDefaults(d, items, C) {
  const pos = d.free.pos || {}, cols = Math.min(4, Math.max(1, items.length)), rows = Math.max(1, Math.ceil(items.length / cols));
  const fit = C ? Math.min(C.w / cols, C.h / rows) * .78 : d.free.size;
  return items.map((it, i) => Object.assign({ x: (cols - (i % cols) - .5) / cols, y: (Math.floor(i / cols) + .5) / rows, s: Math.min(d.free.size, fit), shape: '' }, pos[it.id] || {}));
}
function layFree(d, LY, C, items) {
  const list = items.slice(0, 24), P = freeDefaults(d, list, C);
  list.forEach((it, i) => {
    const p = P[i], s = clamp(p.s || d.free.size, 18, 160) * d.a.iconScale / 88;
    const cx = C.x + clamp(p.x, 0, 1) * C.w, cy = C.y + clamp(p.y, 0, 1) * C.h;
    const before = LY.hits.length;
    if (isPerson(it) && (p.shape || d.free.shape) === 'avatar') avatarCell(LY, d, it, cx, cy, s, { badges: d.free.badges, call: true, wa: true, mask: p.mask });
    else {
      tileCell(LY, d, it, cx, cy - s / 2, s, s, 1, (p.shape && p.shape !== 'avatar') ? p.shape : (d.free.shape === 'avatar' ? 'circle' : d.free.shape), d.free.labels, d.a.font, d.free.perIcon);
    }
    for (let h = before; h < LY.hits.length; h++) LY.hits[h].free = it.id;
  });
  LY.info = { shown: list.length, total: items.length };
}

/* ---------------------------------------------------------- vertical (sections) */
const SECTION_KINDS = [['people', 'جهات الاتصال'], ['apps', 'التطبيقات'], ['links', 'المواقع والروابط'], ['mixed', 'مختلط']];
const SECTION_LAYOUTS = [['list', 'قائمة رأسية'], ['cards', 'بطاقات متتابعة'], ['icons', 'أيقونات فقط'], ['iconsLabels', 'أيقونات مع أسماء'], ['people', 'صور أشخاص مع أزرار تواصل']];
function sectionItems(d, s, items) {
  if (Array.isArray(s.ids) && s.ids.length) { const map = new Map(items.map(i => [i.id, i])); return s.ids.map(id => map.get(id)).filter(Boolean).slice(0, s.count || 24); }
  const f = { people: isPerson, apps: i => i.kind === 'app', links: i => i.kind === 'url', mixed: () => true }[s.kind] || (() => true);
  return items.filter(f).slice(0, s.count || 8);
}
function domainOf(v) { try { return new URL(/^[a-z][a-z0-9+.-]*:/i.test(v) ? v : 'https://' + v).hostname.replace(/^www\./, ''); } catch (e) { return v || ''; } }
function subOf(it) { if (it.kind === 'url') return domainOf(it.value); if (isPerson(it)) return it.value; return ''; }
/** Background / frame a vertical section actually uses (its own choice, or the design-wide one). */
function sectionLook(v, s) {
  const bg = !s.bg || s.bg === 'auto' ? (v.sectionBg ? 'soft' : 'none') : s.bg;
  const frame = !s.frame || s.frame === 'auto' ? (v.sectionFrame ? 'gold' : 'none') : s.frame;
  return { bg, frame, color: s.color || '' };
}
function layVertical(d, LY, C, items) {
  const v = d.vertical, cols = v.flow === 'columns';
  const secs = v.sections.filter(s => s.show !== false).map(s => ({ s, list: sectionItems(d, s, items) })).filter(x => x.list.length || x.s.title);
  /* one section inside a box; returns the y after it */
  const laySection = (P, s, list, x0, w0, y, u, si) => {
    const { nodes, hits } = P, fs = d.a.font * u, gap = v.gap * u, icon = v.icon * u, av = v.avatar * u;
    const look = sectionLook(v, s), sp = (look.bg !== 'none' || look.frame !== 'none') ? 9 * u : 0;
    const top = y, box = { x: x0 + sp, w: w0 - 2 * sp }; y += sp;
    if (s.title && v.sectionTitles !== false) { const sh = fs * 1.15; nodes.push({ k: 'text', text: s.title, x: box.x + box.w, y: y + sh * .55, w: box.w, size: fs * 1.08 * (v.secTitleSize || 100) / 100, weight: 700, align: 'start', color: 'acc' }); y += sh * 1.2; }
    const narrow = cols && secs.length > 1;
    const lay = narrow && (s.layout === 'list' || s.layout === 'cards') ? 'iconsLabels' : s.layout, labels = v.labels !== false && lay !== 'icons';
    const peopleOpts = { call: s.call !== false, wa: s.wa !== false, sms: !!s.sms };
    if (lay === 'icons' || lay === 'iconsLabels') {
      const cn = Math.max(1, narrow ? Math.min(s.cols || 4, Math.max(1, Math.floor((box.w + gap) / (icon * 1.15 + gap)))) : (s.cols || 4)), cellW = (box.w - gap * (cn - 1)) / cn, t = Math.min(icon, cellW), lh = labels ? labelHOf(fs) : 0;
      const rows = Math.ceil(list.length / cn);
      list.forEach((it, i) => {
        const r = Math.floor(i / cn), c = i % cn, rowCount = Math.min(cn, list.length - r * cn);
        const off = v.align === 'start' ? 0 : (cn - rowCount) * (cellW + gap) / 2;
        const cx = colX(box, c, cellW, gap) + cellW / 2 - off, top2 = y + r * (t + lh + gap);
        if (isPerson(it)) { avatarCell(P, d, it, cx, top2 + t / 2, t, { badges: false }); if (labels) nodes.push({ k: 'text', text: it.label, x: cx, y: top2 + t + 2 + lh / 2, w: cellW, size: fs, weight: 500 }); }
        else tileCell(P, d, it, cx, top2, cellW, t, 1, s.shape || 'rounded', labels, fs, s.perIcon);
      });
      y += rows * (t + lh) + Math.max(0, rows - 1) * gap;
    } else if (lay === 'people') {
      const cn = Math.max(1, narrow ? Math.min(s.cols || 3, Math.max(1, Math.floor((box.w + gap) / (av * 1.1 + gap)))) : (s.cols || 3)), cellW = (box.w - gap * (cn - 1)) / cn, a2 = Math.min(av, cellW * .9), nh = labels ? fs * 1.4 : 0, bs = Math.min(24 * u, cellW / 3.2);
      const btn = list.some(phoneOk) && (peopleOpts.call || peopleOpts.wa), cellH = a2 + 4 + nh + (btn ? bs + 6 : 0), rows = Math.ceil(list.length / cn);
      list.forEach((it, i) => {
        const r = Math.floor(i / cn), c = i % cn, rowCount = Math.min(cn, list.length - r * cn), off = v.align === 'start' ? 0 : (cn - rowCount) * (cellW + gap) / 2;
        const cx = colX(box, c, cellW, gap) + cellW / 2 - off, t2 = y + r * (cellH + gap);
        avatarCell(P, d, it, cx, t2 + a2 / 2, a2, { badges: false });
        if (labels) nodes.push({ k: 'text', text: it.label, x: cx, y: t2 + a2 + 4 + nh / 2, w: cellW, size: fs, weight: 600 });
        if (btn) actionButtons(P, it, cx, t2 + a2 + 4 + nh + bs / 2 + 2, bs, peopleOpts, 6 * u);
      });
      y += rows * cellH + Math.max(0, rows - 1) * gap;
    } else { // list & cards
      const rowH = Math.max(icon * .8, fs * 2.7) + (lay === 'cards' ? 10 * u : 4 * u), fsz = rowH - (lay === 'cards' ? 14 * u : 8 * u);
      list.forEach((it, i) => {
        const ry = y + i * (rowH + (lay === 'cards' ? gap * .7 : 2 * u)), cy = ry + rowH / 2, x1 = box.x + box.w - (lay === 'cards' ? 7 * u : 2 * u);
        if (lay === 'cards') nodes.push({ k: 'card', x: box.x, y: ry, w: box.w, h: rowH, r: Math.min(14 * u, rowH / 2.6), mat: true });
        else if (i > 0) nodes.push({ k: 'divider', x: box.x + box.w * .1, y: ry - 1 * u, w: box.w * .8, style: 'goldLine', size: u * .4 });
        if (isPerson(it)) avatarCell(P, d, it, x1 - fsz / 2, cy, fsz, { badges: false, frame: lay === 'cards' ? 'none' : undefined });
        else tileCell(P, d, it, x1 - fsz / 2, cy - fsz / 2, fsz, fsz, 1, s.shape || 'rounded', false, fs, s.perIcon);
        let right = box.x + (lay === 'cards' ? 7 * u : 2 * u);
        if (isPerson(it) && phoneOk(it)) { const bs = Math.min(rowH * .62, 28 * u); const w2 = actionButtonsAt(P, it, right, cy, bs, peopleOpts, 6 * u, 1); if (w2) right += w2 + 6 * u; }
        else if (it.kind === 'url' && it.thumb && lay === 'cards') { const tw = rowH * 1.25 - 10 * u; nodes.push({ k: 'thumb', src: it.thumb, x: right, y: ry + 5 * u, w: tw, h: rowH - 10 * u, r: 8 * u }); right += tw + 6 * u; }
        const tx = x1 - fsz - 8 * u, tw = tx - right, sub = v.subs !== false ? subOf(it) : '';
        if (v.labels !== false) {
          nodes.push({ k: 'text', text: it.label, x: tx, y: cy - (sub ? fs * .58 : 0), w: tw, size: fs * 1.05, weight: 600, align: 'start' });
          if (sub) nodes.push({ k: 'text', text: sub, x: tx, y: cy + fs * .7, w: tw, size: fs * .85, color: 'sub', align: 'start', dir: 'ltr' });
        }
        hits.push({ x: right, y: ry, w: x1 - right + 2 * u, h: rowH, it, act: 'item' });
      });
      y += list.length * rowH + Math.max(0, list.length - 1) * (lay === 'cards' ? gap * .7 : 2 * u);
    }
    y += sp;
    if (sp) nodes.unshift({ k: 'section', x: x0, y: top, w: w0, h: y - top, r: Math.min(16 * u, d.a.radius * .6), bg: look.bg !== 'none', bgKind: look.bg, frame: look.frame !== 'none', frameKind: look.frame, color: look.color, _order: si });
    return y;
  };
  const run = u => {
    const gap = v.gap * u;
    let y = C.y; const nodes = [], hits = [];
    const P = { nodes, hits, info: {} };
    if (v.title) {
      const ts = v.titleSize * u, th = ts * (v.titleStyle === 'arch' ? 2.3 : v.titleStyle === 'cartouche' ? 2.15 : 1.75);
      nodes.push({ k: 'title', x: C.x, y, w: C.w, h: th, text: v.title, style: v.titleStyle, size: ts }); y += th + gap * .6;
    }
    if (cols && secs.length > 1) {
      // sections side by side (RTL: the first section on the right), gold rules between them
      const n = secs.length, cg = gap * 1.4, cw = (C.w - cg * (n - 1)) / n;
      let maxY = y;
      secs.forEach(({ s, list }, si) => {
        const x0 = C.x + C.w - (si + 1) * cw - si * cg;
        maxY = Math.max(maxY, laySection(P, s, list, x0, cw, y, u, si));
        if (si > 0 && v.divider !== 'none') nodes.push({ k: 'vrule', x: x0 + cw + cg / 2, y0: y + gap, y1: null, size: u });
      });
      for (const nd of nodes) { if (nd.k === 'vrule') nd.y1 = maxY - gap; if (nd.k === 'section') nd.h = maxY - nd.y; }
      return { h: maxY - C.y, nodes, hits };
    }
    secs.forEach(({ s, list }, si) => {
      if (si > 0 && v.divider !== 'none') { const dh = 16 * u; nodes.push({ k: 'divider', x: C.x, y: y + dh / 2, w: C.w, style: v.divider, size: u }); y += dh + gap * .3; }
      y = laySection(P, s, list, C.x, C.w, y, u, si) + gap;
    });
    return { h: y - gap - C.y, nodes, hits };
  };
  let u = 1, r = run(u);
  if (r.h > C.h) { u = Math.max(.4, C.h / r.h); r = run(u); if (r.h > C.h) { u *= C.h / r.h * .995; r = run(u); } }
  const dy = Math.max(0, (C.h - r.h) / 2) * (v.valign === 'top' ? 0 : 1);
  for (const n of r.nodes) { if ('y' in n) n.y += dy; if ('cy' in n) n.cy += dy; if ('y0' in n) { n.y0 += dy; n.y1 += dy; } if (n.label) n.label.y += dy; if (n.sub) n.sub.y += dy; if (n.badges) n.badges.forEach(b => b.cy += dy); }
  for (const h of r.hits) h.y += dy;
  // sections must paint first (under their content)
  r.nodes.sort((a, b) => (a.k === 'section' ? 0 : 1) - (b.k === 'section' ? 0 : 1));
  LY.nodes.push(...r.nodes); LY.hits.push(...r.hits);
  LY.info = { shown: secs.reduce((n, x) => n + x.list.length, 0), total: items.length, scale: u };
}

/* ---------------------------------------------------------- entry points */
function layoutDesign(d, W, H, items) {
  if (isTimeType(d)) return layoutTime(d, W, H);
  const m = fxMargin(d, W, H);
  let B;
  if (d.type === 'circle') { const D = Math.min(W, H) - 2 * m; B = { x: (W - D) / 2, y: (H - D) / 2, w: D, h: D, r: D / 2, circle: true }; }
  else B = { x: m, y: m, w: W - 2 * m, h: H - 2 * m, r: Math.min(d.type === 'dock' ? (H - 2 * m) / 2 : 999, d.a.radius) };
  const LY = { B, nodes: [], hits: [], info: {} };
  const C = contentBox(d, B);
  ({ grid: layGrid, people: layPeople, card: layCard, dock: layDock, vertical: layVertical, circle: layCircle, free: layFree, collections: layCollections }[d.type] || layGrid)(d, LY, C, items);
  return LY;
}
function imagesOf(items) { const s = new Set(); for (const it of items) { if (it.photo) s.add(it.photo); if (it.thumb) s.add(it.thumb); if (it.appIcon) s.add(it.appIcon); } return [...s]; }
